package com.idcorporation.atlas.chat;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.ai.AIManager;
import com.idcorporation.atlas.ai.AIProvider;
import com.idcorporation.atlas.ai.AtlasActionTags;
import com.idcorporation.atlas.commands.CommandManager;
import com.idcorporation.atlas.commands.CommandOutcome;
import com.idcorporation.atlas.commands.ConfirmAction;
import com.idcorporation.atlas.memory.HistoryManager;
import com.idcorporation.atlas.models.HistoryMessage;
import com.idcorporation.atlas.utils.SecretUnlockManager;
import com.idcorporation.atlas.utils.TextSanitizer;
import com.idcorporation.atlas.utils.UserProfileManager;

import java.util.ArrayList;

/**
 * ATLAS MODOS - Chat mode brain. Text in, text out: no always-on
 * microphone and no spoken replies. (ATLAS VISAO added a tap-to-dictate
 * mic that only fills the text box, and lets a picked image be sent
 * alongside a message - see sendUserMessageWithImage below - but the
 * assistant itself still only ever answers in writing here.)
 *
 * It reuses the very same CommandManager (reminders, alarms, calendar,
 * notes, calls, open app...) and AIManager the voice mode uses, so
 * every command keeps working when typed. Lives for the whole process
 * (a screen only attaches a Listener while it is visible) so a rotation
 * or a trip to Settings never loses the conversation or a reply that
 * arrives in the meantime.
 */
public class ChatSession {

    public interface Listener {
        void onMessageAdded(ChatMessage message);
        void onMessageChanged(ChatMessage message);
        void onMessageRemoved(ChatMessage message);
        void onTypingChanged(boolean typing);
        void onConversationReset();
    }

    private static final String PREFS_NAME = "atlas_chat_prefs";
    private static final String KEY_TITLE = "current_title";
    private static final long MIN_TYPING_MS = 650L;
    private static final int MAX_RESTORED_MESSAGES = 200;
    private static final int MAX_AI_HISTORY = 40;

    private static ChatSession instance;

    public static synchronized ChatSession get(Context context) {
        if (instance == null) {
            instance = new ChatSession(context.getApplicationContext());
        }
        return instance;
    }

    private final Context appContext;
    private final CommandManager commandManager;
    private final AIManager aiManager;
    private final UserProfileManager profileManager;
    private final HistoryManager historyManager;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final ArrayList<ChatMessage> messages = new ArrayList<ChatMessage>();
    private final ArrayList<String> aiHistory = new ArrayList<String>();
    private String title;
    private Listener listener;
    private boolean typing = false;
    private boolean busy = false;
    private int generation = 0;

    private ChatSession(Context context) {
        this.appContext = context;
        this.commandManager = new CommandManager(context);
        this.aiManager = new AIManager(context);
        this.profileManager = new UserProfileManager(context);
        this.historyManager = new HistoryManager(context);

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String savedTitle = prefs.getString(KEY_TITLE, null);
        if (savedTitle == null) {
            this.title = createNewTitle();
        } else {
            this.title = savedTitle;
            restoreFromHistory();
        }
    }

    public void setListener(Listener newListener) {
        this.listener = newListener;
    }

    public void clearListener(Listener oldListener) {
        if (this.listener == oldListener) {
            this.listener = null;
        }
    }

    public ArrayList<ChatMessage> getMessages() {
        return messages;
    }

    public boolean isTyping() {
        return typing;
    }

    public boolean isBusy() {
        return busy;
    }

    // -----------------------------------------------------------------
    // Sending
    // -----------------------------------------------------------------

    public void sendUserMessage(String rawText) {
        if (rawText == null) {
            return;
        }
        String text = rawText.trim();
        if (text.length() == 0 || busy) {
            return;
        }
        ChatMessage userMessage = new ChatMessage(ChatMessage.ROLE_USER, text,
            System.currentTimeMillis(), ChatMessage.KIND_NORMAL);
        userMessage.setAnimateEntrance(true);
        addMessage(userMessage);
        historyManager.saveMessage(title, HistoryMessage.ROLE_USER, text);
        com.idcorporation.atlas.ai.ProactiveGreeter.noteInteraction(appContext);
        processText(text);
    }

    /** Runs the same text again after an error bubble was tapped (no new user bubble). */
    public void retryFrom(ChatMessage errorMessage) {
        String text = errorMessage.getRetryText();
        if (text == null || busy) {
            return;
        }
        messages.remove(errorMessage);
        if (listener != null) {
            listener.onMessageRemoved(errorMessage);
        }
        processText(text);
    }

    /**
     * Sends a picked image (already downscaled and base64-encoded by the
     * caller, off the UI thread) together with an optional caption.
     * Unlike sendUserMessage this never goes through CommandManager or the
     * secret-code check - an attached image always means "look at this",
     * so it goes straight to the vision-capable model.
     */
    public void sendUserMessageWithImage(String rawText, Uri imageUri,
                                          String imageBase64, String imageMimeType) {
        if (imageUri == null || imageBase64 == null || imageBase64.length() == 0 || busy) {
            return;
        }
        String displayText = (rawText == null) ? "" : rawText.trim();
        final String promptText = displayText.length() > 0
            ? displayText : appContext.getString(R.string.chat_default_image_prompt);

        ChatMessage userMessage = new ChatMessage(ChatMessage.ROLE_USER, displayText,
            System.currentTimeMillis(), ChatMessage.KIND_NORMAL);
        userMessage.setImageUri(imageUri);
        userMessage.setAnimateEntrance(true);
        addMessage(userMessage);
        historyManager.saveMessage(title, HistoryMessage.ROLE_USER,
            displayText.length() > 0 ? displayText
                : appContext.getString(R.string.chat_image_history_placeholder));

        busy = true;
        setTyping(true);
        final long startedAt = SystemClock.uptimeMillis();
        final int myGeneration = generation;

        aiManager.askWithImage(profileManager.getName(), aiHistory, promptText,
            imageBase64, imageMimeType, new AIProvider.AICallback() {
                @Override
                public void onSuccess(String responseText) {
                    String cleanText = TextSanitizer.stripMarkdown(responseText);
                    if (myGeneration == generation) {
                        aiHistory.add(promptText);
                        aiHistory.add(cleanText);
                        trimAiHistory();
                    }
                    deliverAtlas(cleanText, ChatMessage.KIND_NORMAL, null, null,
                        startedAt, myGeneration, promptText);
                }

                @Override
                public void onError(String errorMessage, int errorCode) {
                    // TEMPORARIO (diagnostico ATLAS VISAO round 2): o 404
                    // anterior foi corrigido trocando o modelo, mas o usuario
                    // reportou que ainda nao funciona - preciso ver o erro
                    // real de novo pra saber se e outra causa.
                    String shown = "[ATLAS VISAO debug] " + errorMessage + " (codigo " + errorCode + ")";
                    // No retryText here on purpose: the image bytes are not
                    // kept around after sending, so a naive retry would
                    // silently resend as plain text. The user just attaches
                    // the image again instead.
                    deliverAtlas(shown, ChatMessage.KIND_ERROR, null, null,
                        startedAt, myGeneration, null);
                }
            });
    }

    private void processText(final String text) {
        busy = true;
        setTyping(true);
        final long startedAt = SystemClock.uptimeMillis();
        final int myGeneration = generation;

        if (SecretUnlockManager.matchesSecretCode(text)
                && !SecretUnlockManager.isPermanentlyViewed(appContext)) {
            SecretUnlockManager.unlock(appContext);
            deliverAtlas(appContext.getString(R.string.secret_history_unlocked),
                ChatMessage.KIND_NORMAL, null, null, startedAt, myGeneration, text);
            return;
        }

        CommandOutcome outcome;
        try {
            outcome = commandManager.process(text);
        } catch (RuntimeException e) {
            deliverAtlas(appContext.getString(R.string.err_no_ai_connection),
                ChatMessage.KIND_ERROR, null, text, startedAt, myGeneration, null);
            return;
        }

        if (outcome.getType() == CommandOutcome.TYPE_HANDLED) {
            deliverAtlas(outcome.getSpokenResponse(), ChatMessage.KIND_NORMAL, null, null,
                startedAt, myGeneration, text);
        } else if (outcome.getType() == CommandOutcome.TYPE_NEEDS_CONFIRMATION) {
            deliverAtlas(outcome.getSpokenResponse(), ChatMessage.KIND_CONFIRM,
                outcome.getConfirmedAction(), null, startedAt, myGeneration, null);
        } else {
            forwardToAI(text, startedAt, myGeneration);
        }
    }

    private void forwardToAI(final String userText, final long startedAt, final int myGeneration) {
        // ATLAS AGENT CORE: the model can now plan and use real tools (weather, news, search,
        // WhatsApp chat, email app, device commands...). Plain conversation still costs one call.
        aiManager.askAgent(profileManager.getName(), aiHistory, userText, commandManager,
            new com.idcorporation.atlas.agent.AgentCallback() {
                @Override
                public void onResult(com.idcorporation.atlas.agent.AgentResult result) {
                    String cleanText = TextSanitizer.stripMarkdown(result.text);
                    if (myGeneration == generation) {
                        aiHistory.add(userText);
                        aiHistory.add(cleanText);
                        trimAiHistory();
                    }
                    if (result.panel != null && myGeneration == generation) {
                        com.idcorporation.atlas.agent.panel.PanelActivity.show(appContext, result.panel);
                    }
                    // A confirmation prepared by a tool (e.g. a WhatsApp message) wins; otherwise the
                    // AI may have asked, inside cleanText, whether to turn something into a reminder.
                    final AtlasActionTags.SuggestionFact suggestion = aiManager.consumeLastSuggestion();
                    if (result.confirmAction != null) {
                        deliverAtlas(cleanText, ChatMessage.KIND_CONFIRM, result.confirmAction, null,
                            startedAt, myGeneration, userText);
                    } else if (suggestion != null) {
                        ConfirmAction confirmAction = new ConfirmAction() {
                            @Override
                            public boolean run() {
                                return commandManager.createReminderFromSuggestion(
                                    suggestion.title, suggestion.when);
                            }
                        };
                        deliverAtlas(cleanText, ChatMessage.KIND_CONFIRM, confirmAction, null,
                            startedAt, myGeneration, userText);
                    } else {
                        deliverAtlas(cleanText, ChatMessage.KIND_NORMAL, null, null,
                            startedAt, myGeneration, userText);
                    }
                }

                @Override
                public void onError(String errorMessage, int errorCode) {
                    String friendly = appContext.getString(R.string.err_no_ai_connection);
                    String shown = appContext.getString(R.string.chat_error_retry, friendly);
                    deliverAtlas(shown, ChatMessage.KIND_ERROR, null, userText,
                        startedAt, myGeneration, null);
                }
            });
    }

    /**
     * ATLAS AGENT CORE: called once when the chat screen opens. The model decides whether to say
     * something spontaneous or stay quiet; nothing is shown when it stays quiet or anything fails.
     */
    public void maybeGreetOnOpen() {
        if (busy) {
            return;
        }
        final int myGeneration = generation;
        com.idcorporation.atlas.ai.ProactiveGreeter.maybeGreet(appContext, aiManager,
            new com.idcorporation.atlas.ai.ProactiveGreeter.Callback() {
                @Override
                public void onGreeting(String text) {
                    if (myGeneration != generation || busy) {
                        return;
                    }
                    ChatMessage message = new ChatMessage(ChatMessage.ROLE_ATLAS, text,
                        System.currentTimeMillis(), ChatMessage.KIND_NORMAL);
                    message.setAnimateEntrance(true);
                    message.setAnimateReveal(true);
                    addMessage(message);
                    historyManager.saveMessage(title, HistoryMessage.ROLE_ATLAS, text);
                }
            });
    }

    /**
     * Shows the reply after the typing dots had a moment on screen (so a
     * command that finishes instantly still feels like a real answer),
     * then logs it. userTextForNotes is only set for normal replies, to
     * feed the Notes "guarda isso" capture like the voice mode does.
     */
    private void deliverAtlas(final String text, final int kind, final ConfirmAction confirmAction,
                              final String retryText, long startedAt, final int myGeneration,
                              final String userTextForNotes) {
        long elapsed = SystemClock.uptimeMillis() - startedAt;
        long wait = MIN_TYPING_MS - elapsed;
        if (wait < 0L) {
            wait = 0L;
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (myGeneration != generation) {
                    return;
                }
                busy = false;
                setTyping(false);
                String safeText = (text == null) ? "" : text;
                ChatMessage message = new ChatMessage(ChatMessage.ROLE_ATLAS, safeText,
                    System.currentTimeMillis(), kind);
                message.setAnimateEntrance(true);
                message.setAnimateReveal(kind == ChatMessage.KIND_NORMAL && safeText.length() > 0);
                message.setConfirmAction(confirmAction);
                message.setRetryText(retryText);
                addMessage(message);
                if (kind != ChatMessage.KIND_ERROR) {
                    historyManager.saveMessage(title, HistoryMessage.ROLE_ATLAS, safeText);
                }
            }
        }, wait);
    }

    // -----------------------------------------------------------------
    // Confirmation bubbles (Yes / No)
    // -----------------------------------------------------------------

    public void resolveConfirmation(ChatMessage message, boolean accepted) {
        if (message.getConfirmState() != ChatMessage.CONFIRM_PENDING || busy) {
            return;
        }
        message.setConfirmState(accepted ? ChatMessage.CONFIRM_ACCEPTED : ChatMessage.CONFIRM_DECLINED);
        if (listener != null) {
            listener.onMessageChanged(message);
        }
        ConfirmAction action = message.getConfirmAction();
        // ATLAS FASE 3/4 rule: never tell the user something happened when
        // it did not. action.run() reports whether it actually succeeded
        // (e.g. a reminder the AI suggested whose date failed to parse),
        // and only then do we say "Feito!".
        boolean succeeded = true;
        if (accepted && action != null) {
            try {
                succeeded = action.run();
            } catch (RuntimeException e) {
                succeeded = false;
            }
        }
        int replyRes;
        if (!accepted) {
            replyRes = R.string.resp_cancelled;
        } else if (succeeded) {
            replyRes = R.string.resp_done;
        } else {
            replyRes = R.string.resp_action_failed;
        }
        busy = true;
        setTyping(true);
        deliverAtlas(appContext.getString(replyRes), ChatMessage.KIND_NORMAL, null, null,
            SystemClock.uptimeMillis(), generation, null);
    }

    // -----------------------------------------------------------------
    // Conversation lifecycle
    // -----------------------------------------------------------------

    public void newConversation() {
        generation = generation + 1;
        busy = false;
        typing = false;
        messages.clear();
        aiHistory.clear();
        title = createNewTitle();
        if (listener != null) {
            listener.onTypingChanged(false);
            listener.onConversationReset();
        }
    }

    /** The internal identifier of whichever conversation is currently live. */
    public String getCurrentConversationTitle() {
        return title;
    }

    /**
     * Switches the live session to a previously saved conversation and
     * restores its messages so the user can continue exactly where they
     * left off. The conversation being left is not touched or deleted -
     * every message already sent was persisted as it was sent, so simply
     * pointing "current" at a different title is enough to preserve
     * isolation between conversations.
     */
    public void openConversation(String conversationTitle) {
        if (conversationTitle == null || conversationTitle.equals(title)) {
            return;
        }
        generation = generation + 1;
        busy = false;
        typing = false;
        messages.clear();
        aiHistory.clear();
        title = conversationTitle;
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_TITLE, title).apply();
        restoreFromHistory();
        if (listener != null) {
            listener.onTypingChanged(false);
            listener.onConversationReset();
        }
    }

    private String createNewTitle() {
        String newTitle = "Chat " + System.currentTimeMillis();
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_TITLE, newTitle).apply();
        return newTitle;
    }

    private void restoreFromHistory() {
        ArrayList<HistoryMessage> stored = historyManager.getConversation(title);
        int start = 0;
        if (stored.size() > MAX_RESTORED_MESSAGES) {
            start = stored.size() - MAX_RESTORED_MESSAGES;
        }
        for (int i = start; i < stored.size(); i++) {
            HistoryMessage item = stored.get(i);
            int role = HistoryMessage.ROLE_USER.equals(item.getRole())
                ? ChatMessage.ROLE_USER : ChatMessage.ROLE_ATLAS;
            messages.add(new ChatMessage(role, item.getMessage(), item.getTimestamp(),
                ChatMessage.KIND_NORMAL));
        }
        // Rebuild the AI context only from clean user -> ATLAS pairs so the
        // strict user/assistant alternation the API expects is never broken.
        for (int i = 0; i + 1 < messages.size(); i++) {
            ChatMessage first = messages.get(i);
            ChatMessage second = messages.get(i + 1);
            if (first.isUser() && !second.isUser()) {
                aiHistory.add(first.getText());
                aiHistory.add(second.getText());
                i = i + 1;
            }
        }
        trimAiHistory();
    }

    private void trimAiHistory() {
        while (aiHistory.size() > MAX_AI_HISTORY) {
            aiHistory.remove(0);
            aiHistory.remove(0);
        }
    }

    // -----------------------------------------------------------------
    // Listener plumbing
    // -----------------------------------------------------------------

    private void addMessage(ChatMessage message) {
        messages.add(message);
        if (listener != null) {
            listener.onMessageAdded(message);
        }
    }

    private void setTyping(boolean value) {
        if (typing == value) {
            return;
        }
        typing = value;
        if (listener != null) {
            listener.onTypingChanged(value);
        }
    }
}
