package com.idcorporation.atlas.ai;

/**
 * Cole sua chave da API da Groq aqui embaixo, entre as aspas.
 * Pegue a chave em: https://console.groq.com/keys
 *
 * Exemplo:
 * public static final String GROQ_API_KEY = "gsk_abcd1234...";
 *
 * Atencao: colocar a chave direto aqui significa que ela vai
 * dentro do APK. Qualquer pessoa que descompilar o app consegue
 * ler essa chave e usar sua conta Groq. Isso e diferente de usar
 * um backend proxy, onde a chave fica escondida em um servidor.
 * Se for distribuir o ATLAS publicamente, o ideal e trocar para
 * o backend (Cloudflare Worker) que ja esta pronto no projeto.
 *
 * ATLAS foi feito pela ID | CORPORATION.
 */
public class ApiKeyConfig {

    public static final String GROQ_API_KEY = "COLE_SUA_CHAVE_GROQ_AQUI";

    /**
     * OPCIONAL - busca na web de verdade (produtos, precos, qualquer assunto).
     * Chave gratis em https://brave.com/search/api/ (plano gratuito). Sem ela
     * o Atlas usa so Wikipedia/DuckDuckGo, que servem para fatos, nao para compras.
     */
    public static final String BRAVE_SEARCH_API_KEY = "COLE_SUA_CHAVE_BRAVE_AQUI";

    public static boolean isSearchConfigured() {
        return BRAVE_SEARCH_API_KEY != null
                && BRAVE_SEARCH_API_KEY.length() > 0
                && !BRAVE_SEARCH_API_KEY.equals("COLE_SUA_CHAVE_BRAVE_AQUI");
    }

    public static boolean isConfigured() {
        return GROQ_API_KEY != null
                && GROQ_API_KEY.length() > 0
                && !GROQ_API_KEY.equals("COLE_SUA_CHAVE_GROQ_AQUI");
    }
}
