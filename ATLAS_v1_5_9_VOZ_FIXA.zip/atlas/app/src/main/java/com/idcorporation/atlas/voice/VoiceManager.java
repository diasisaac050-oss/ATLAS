package com.idcorporation.atlas.voice;

import android.content.Context;

public class VoiceManager {

    public interface VoiceEventListener {
        void onListeningStarted();
        void onUserSaid(String text);
        void onVoiceError(String message, int errorCode);
        void onSpeakingStarted();
        void onSpeakingFinished();
        void onAudioLevel(float rmsDb);
    }

    private final SpeechRecognizerManager speechRecognizerManager;
    private final TTSManager ttsManager;
    /** Optional live-transcription hook (what the recognizer has heard so far). */
    public interface PartialTextListener {
        void onPartialText(String text);
    }

    private VoiceEventListener eventListener;
    private PartialTextListener partialTextListener;
    private PartialTextListener bargeInListener;
    // True from the first spoken word until the reply ends or is cut. While it is set, what the
    // recognizer hears is Atlas's own voice or someone nearby: it goes ONLY to the stop-command
    // detector and never to the transcript on screen.
    private boolean speakingNow = false;

    public VoiceManager(Context context) {
        speechRecognizerManager = new SpeechRecognizerManager(context);
        ttsManager = new TTSManager(context);

        speechRecognizerManager.setCallback(new SpeechRecognizerManager.RecognitionCallback() {
            @Override
            public void onReadyForSpeech() {
                if (eventListener != null) {
                    eventListener.onListeningStarted();
                }
            }

            @Override
            public void onResult(String recognizedText) {
                if (eventListener != null) {
                    eventListener.onUserSaid(recognizedText);
                }
            }

            @Override
            public void onError(String errorMessage, int errorCode) {
                if (eventListener != null) {
                    eventListener.onVoiceError(errorMessage, errorCode);
                }
            }

            @Override
            public void onPartial(String partialText) {
                if (speakingNow) {
                    if (bargeInListener != null) {
                        bargeInListener.onPartialText(partialText);
                    }
                    return;
                }
                if (partialTextListener != null) {
                    partialTextListener.onPartialText(partialText);
                }
            }

            @Override
            public void onRmsChanged(float rmsDb) {
                if (eventListener != null) {
                    eventListener.onAudioLevel(rmsDb);
                }
            }
        });

        ttsManager.setListener(new TTSManager.SpeechStateListener() {
            @Override
            public void onSpeechStart() {
                speakingNow = true;
                if (eventListener != null) {
                    eventListener.onSpeakingStarted();
                }
            }

            @Override
            public void onSpeechDone() {
                speakingNow = false;
                if (eventListener != null) {
                    eventListener.onSpeakingFinished();
                }
            }

            @Override
            public void onSpeechError() {
                speakingNow = false;
                if (eventListener != null) {
                    eventListener.onSpeakingFinished();
                }
            }
        });
    }

    public void setEventListener(VoiceEventListener listener) {
        this.eventListener = listener;
    }

    public void setPartialTextListener(PartialTextListener listener) {
        this.partialTextListener = listener;
    }

    public void startListening() {
        speechRecognizerManager.startListening();
    }

    /** Cancels an in-progress listening session silently (used for a mid-listening barge-in tap). */
    public void cancelListening() {
        speechRecognizerManager.cancelListening();
    }

    public void speak(String text) {
        ttsManager.speak(text);
    }

    public void setBargeInPartialListener(PartialTextListener listener) {
        this.bargeInListener = listener;
    }

    public boolean isSpeakingNow() {
        return speakingNow;
    }

    public void stopSpeaking() {
        speakingNow = false;
        ttsManager.stopSpeaking();
    }

    public void setSpeechRate(float rate) {
        ttsManager.setSpeechRate(rate);
    }

    public void setSpeechPitch(float pitch) {
        ttsManager.setSpeechPitch(pitch);
    }

    public void destroy() {
        speechRecognizerManager.destroy();
        ttsManager.shutdown();
    }
}
