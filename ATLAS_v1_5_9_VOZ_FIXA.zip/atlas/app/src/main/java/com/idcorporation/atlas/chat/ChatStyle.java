package com.idcorporation.atlas.chat;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;

/**
 * Small helpers that turn the current theme's accent color into the
 * shapes and colors of the Chat screen. Everything is built in code
 * (not XML) so the chat follows whichever ATLAS theme is selected.
 */
public class ChatStyle {

    public static final int GLASS_FILL = 0xEB101826;
    public static final int TEXT_PRIMARY = 0xFFE8F6FF;
    public static final int TEXT_SECONDARY = 0xFF8FA6B8;
    public static final int ERROR_COLOR = 0xFFFF5252;

    private ChatStyle() {
    }

    public static int dp(Context context, float value) {
        float density = context.getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }

    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    public static int darken(int color, float factor) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] = hsv[2] * factor;
        return Color.HSVToColor(Color.alpha(color), hsv);
    }

    public static int lighten(int color, float amount) {
        int r = (int) (Color.red(color) + (255 - Color.red(color)) * amount);
        int g = (int) (Color.green(color) + (255 - Color.green(color)) * amount);
        int b = (int) (Color.blue(color) + (255 - Color.blue(color)) * amount);
        return Color.argb(Color.alpha(color), r, g, b);
    }

    public static boolean isLight(int color) {
        double luminance = (0.299 * Color.red(color) + 0.587 * Color.green(color)
            + 0.114 * Color.blue(color)) / 255.0;
        return luminance > 0.55;
    }

    /** Dark text on light accents, white text on dark accents. */
    public static int readableOn(int color) {
        return isLight(color) ? 0xFF061018 : 0xFFFFFFFF;
    }

    /** The user's bubble: accent gradient, flat corner at the bottom right. */
    public static GradientDrawable userBubble(Context context, int accent) {
        GradientDrawable drawable = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{lighten(accent, 0.08f), darken(accent, 0.78f)});
        float big = dp(context, 20);
        float small = dp(context, 6);
        drawable.setCornerRadii(new float[]{big, big, big, big, small, small, big, big});
        return drawable;
    }

    /** ATLAS bubble: dark glass with a thin accent edge, flat corner at the bottom left. */
    public static GradientDrawable atlasBubble(Context context, int accent, boolean error) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(GLASS_FILL);
        int edge = error ? withAlpha(ERROR_COLOR, 0xAA) : withAlpha(accent, 0x66);
        drawable.setStroke(dp(context, 1), edge);
        float big = dp(context, 20);
        float small = dp(context, 6);
        drawable.setCornerRadii(new float[]{big, big, big, big, big, big, small, small});
        return drawable;
    }

    public static GradientDrawable pill(Context context, int fill, int strokeColor, float strokeDp,
                                        float radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(context, radiusDp));
        if (strokeDp > 0f) {
            drawable.setStroke(Math.max(1, dp(context, strokeDp)), strokeColor);
        }
        return drawable;
    }

    public static GradientDrawable circle(int fill) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(fill);
        return drawable;
    }

    public static GradientDrawable accentCircle(int accent) {
        GradientDrawable drawable = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{lighten(accent, 0.1f), darken(accent, 0.75f)});
        drawable.setShape(GradientDrawable.OVAL);
        return drawable;
    }

    /** Solid accent pill (primary buttons). */
    public static GradientDrawable accentPill(Context context, int accent, float radiusDp) {
        GradientDrawable drawable = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{lighten(accent, 0.08f), darken(accent, 0.8f)});
        drawable.setCornerRadius(dp(context, radiusDp));
        return drawable;
    }
}
