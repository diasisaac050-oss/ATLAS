package com.idcorporation.atlas.activities;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.sphere.AtlasSphereView;
import com.idcorporation.atlas.theme.ThemeManager;
import com.idcorporation.atlas.theme.ThemePalette;
import com.idcorporation.atlas.utils.ModeManager;
import com.idcorporation.atlas.utils.UserProfileManager;

/**
 * ATLAS AWAKENING: the opening screen. Pure black; the core of the Atlas is
 * seen growing and lighting up in white. When it has finished expanding it
 * takes the theme colour and the background becomes the theme background,
 * then the Home opens with no cut (same sphere position, no slide) and its
 * buttons fade in.
 */
public class SplashActivity extends BaseActivity {

    /** Read (and cleared) by MainActivity: the sphere is already on screen, only the controls should fade in. */
    public static boolean awakenedHandoff = false;

    // Home layout: top bar ~66dp; state label + transcript + bottom controls ~198dp
    private static final float HOME_TOP_DP = 66f;
    private static final float HOME_BOTTOM_DP = 198f;

    private boolean navigated = false;
    private AtlasSphereView splashSphere;

    @Override
    protected boolean isVoiceCallScreen() {
        return false;
    }

    @Override
    protected boolean shouldApplyThemeBackground() {
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        final View root = findViewById(R.id.splash_root);
        final AtlasSphereView sphere = (AtlasSphereView) findViewById(R.id.view_splash_sphere);
        splashSphere = sphere;
        final ThemePalette palette = ThemeManager.getSelectedPalette(this);
        float d = getResources().getDisplayMetrics().density;

        sphere.startAwakening(palette.getAccentColor(), HOME_TOP_DP * d, HOME_BOTTOM_DP * d,
                new AtlasSphereView.AwakenListener() {
                    @Override
                    public void onExpanded() {
                        // background goes from black to the theme background while the core changes colour
                        ValueAnimator bg = ValueAnimator.ofObject(new ArgbEvaluator(), 0xFF000000, palette.getBackgroundColor());
                        bg.setDuration(600L);
                        bg.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                            @Override
                            public void onAnimationUpdate(ValueAnimator a) {
                                root.setBackgroundColor((Integer) a.getAnimatedValue());
                            }
                        });
                        bg.start();
                    }

                    @Override
                    public void onTinted() {
                        navigateNext();
                    }
                });
    }

    @Override
    public void onBackPressed() {
        // the awakening is short; ignore back so it never lands on a half-built screen
    }

    private void navigateNext() {
        if (navigated) {
            return;
        }
        navigated = true;
        UserProfileManager profileManager = new UserProfileManager(this);
        Intent intent;
        if (profileManager.isOnboardingDone()) {
            intent = ModeManager.homeIntent(this);
            awakenedHandoff = MainActivity.class.getName().equals(
                    intent.getComponent() != null ? intent.getComponent().getClassName() : "");
            if (awakenedHandoff && splashSphere != null) {
                // the Home will keep drawing this very sphere instead of building a new one
                splashSphere.publishForHandoff();
            }
        } else {
            intent = new Intent(this, OnboardingWelcomeActivity.class);
        }
        startActivity(intent);
        finish();
    }

    // no slide: the next screen must appear exactly where the sphere already is
    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransition(0, 0);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}
