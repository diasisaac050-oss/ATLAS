package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.MessageDigest;
import com.idcorporation.atlas.security.PasswordHasher;

/**
 * Stores only a slow salted PBKDF2 hash of the local account password, never
 * the password itself. This protects the password even if someone reads
 * the app's private SharedPreferences file directly (e.g. on a rooted
 * device or from a backup).
 */
public class SecurePasswordStore {

    private static final String PREFS_NAME = "atlas_password_prefs";
    private static final String KEY_HASH = "password_hash";
    private static final String KEY_SALT = "password_salt";

    private final SharedPreferences prefs;

    public SecurePasswordStore(Context context) {
        this.prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void savePassword(String plainPassword) {
        String hash = PasswordHasher.hash(plainPassword);
        if (hash == null) {
            return;
        }
        prefs.edit()
            .putString(KEY_HASH, hash)
            .remove(KEY_SALT)
            .apply();
    }

    public boolean verifyPassword(String plainPassword) {
        String storedHash = prefs.getString(KEY_HASH, null);
        if (storedHash == null || plainPassword == null) {
            return false;
        }
        if (PasswordHasher.isModernFormat(storedHash)) {
            return PasswordHasher.verify(plainPassword, storedHash);
        }
        // Old single-SHA-256 format: still accepted once, then upgraded.
        String storedSaltEncoded = prefs.getString(KEY_SALT, null);
        if (storedSaltEncoded == null) {
            return false;
        }
        try {
            byte[] salt = Base64.decode(storedSaltEncoded, Base64.NO_WRAP);
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(salt);
            byte[] hashedBytes = digest.digest(plainPassword.getBytes());
            String candidate = Base64.encodeToString(hashedBytes, Base64.NO_WRAP);
            if (MessageDigest.isEqual(candidate.getBytes(), storedHash.getBytes())) {
                savePassword(plainPassword);
                return true;
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }

    public boolean hasPasswordSet() {
        return prefs.contains(KEY_HASH);
    }

}
