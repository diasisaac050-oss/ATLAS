package com.idcorporation.atlas.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.idcorporation.atlas.activities.AlarmRingActivity;
import com.idcorporation.atlas.services.AlarmSoundService;
import com.idcorporation.atlas.utils.AlarmScheduler;

/**
 * Triggered by AlarmManager at the exact instant a reminder or quick
 * alarm is due. Starts the sound/vibration service and launches the
 * full-screen ring activity directly - the activity is also reachable
 * through the foreground notification's full-screen intent for the
 * cases where the direct launch is blocked by the OS (screen off,
 * background restrictions, etc).
 */
public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra(AlarmScheduler.EXTRA_TITLE);
        String message = intent.getStringExtra(AlarmScheduler.EXTRA_MESSAGE);
        if (title == null) {
            title = "";
        }
        if (message == null) {
            message = "";
        }

        Intent soundServiceIntent = new Intent(context, AlarmSoundService.class);
        soundServiceIntent.putExtra(AlarmScheduler.EXTRA_TITLE, title);
        soundServiceIntent.putExtra(AlarmScheduler.EXTRA_MESSAGE, message);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(soundServiceIntent);
        } else {
            context.startService(soundServiceIntent);
        }

        Intent ringActivityIntent = new Intent(context, AlarmRingActivity.class);
        ringActivityIntent.putExtra(AlarmScheduler.EXTRA_TITLE, title);
        ringActivityIntent.putExtra(AlarmScheduler.EXTRA_MESSAGE, message);
        ringActivityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
            | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            context.startActivity(ringActivityIntent);
        } catch (Exception e) {
            // Background-start restriction on some OEM builds; the notification's
            // full-screen intent from AlarmSoundService still covers this case.
        }
    }
}
