package com.idcorporation.atlas.activities;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.DateFormat;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.idcorporation.atlas.AtlasApplication;
import com.idcorporation.atlas.R;
import com.idcorporation.atlas.commands.ConfirmAction;
import com.idcorporation.atlas.sphere.AtlasSphereView;
import com.idcorporation.atlas.utils.DeviceInfoUtil;
import com.idcorporation.atlas.utils.NotificationHelper;
import com.idcorporation.atlas.utils.SoundManager;
import com.idcorporation.atlas.utils.HomeLayoutPrefs;
import com.idcorporation.atlas.utils.ViewAnimUtils;
import com.idcorporation.atlas.voice.AtlasVoiceSession;

import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends BaseActivity implements AtlasVoiceSession.UiListener {

    /** Set by PresenceOverlayService when the user tapped the mic icon on the shake overlay. */
    public static final String EXTRA_START_LISTENING = "com.idcorporation.atlas.EXTRA_START_LISTENING";
    /** Set by PresenceOverlayService when the user tapped the write icon on the shake overlay. */
    public static final String EXTRA_FOCUS_TEXT_INPUT = "com.idcorporation.atlas.EXTRA_FOCUS_TEXT_INPUT";
    /** Set by ContactActionHandler when a voice call/message command needs contacts/call permission granted. */
    public static final String EXTRA_REQUEST_CONTACT_PERMISSIONS = "com.idcorporation.atlas.EXTRA_REQUEST_CONTACT_PERMISSIONS";

    private static final int REQUEST_CODE_RECORD_AUDIO = 501;
    private static final int REQUEST_CODE_CONTACT_PERMISSIONS = 502;

    private AtlasVoiceSession session;
    private HudStateManager hudStateManager;

    private TextView transcriptView;
    private TextView dateTimeView;
    private TextView batteryView;
    private View confirmationCard;
    private TextView confirmationPromptView;

    private ConfirmAction pendingConfirmedAction;

    private AtlasSphereView sphereView;
    private View coreTouchArea;
    private final AtlasVoiceSession.AudioLevelListener sphereAudioListener =
        new AtlasVoiceSession.AudioLevelListener() {
            @Override
            public void onAudioLevel(float rmsDb) {
                if (sphereView != null) {
                    sphereView.setAudioLevelDb(rmsDb);
                }
            }
        };
    private View bottomControlsView;
    private ImageButton historyButton;
    private ImageButton modesButton;
    private ImageButton micButtonBig;
    private boolean micMuted = false;
    private final ArrayList<Long> recentTapTimestamps = new ArrayList<Long>();
    private Runnable longPressRunnable;
    private boolean longPressTriggered = false;
    private static final int RAPID_TAP_COUNT = 10;
    private static final long RAPID_TAP_WINDOW_MS = 3000;
    private static final long LONG_PRESS_DURATION_MS = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (redirectToChatIfNeeded(getIntent())) {
            return;
        }
        setContentView(R.layout.activity_main);

        session = AtlasApplication.voiceSession(this);

        bindViews();
        wireButtons();
        updateSystemInfo();
        NotificationHelper.createNotificationChannel(this);
        com.idcorporation.atlas.utils.AlarmPermissionHelper.ensureExactAlarmPermission(this);
        com.idcorporation.atlas.utils.AlarmPermissionHelper.ensureBatteryOptimizationExemption(this);
        playEntranceAnimation();
        handleLaunchExtras(getIntent());
        // ATLAS AGENT CORE: spontaneous spoken greeting (or silence) on a fresh open from the home screen.
        if (savedInstanceState == null && (getIntent() == null || getIntent().getExtras() == null)) {
            session.maybeGreetOnOpen();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (redirectToChatIfNeeded(intent)) {
            return;
        }
        handleLaunchExtras(intent);
    }

    /**
     * ATLAS MODOS safety net: notifications, the Presence bubble and the
     * permission prompts all open MainActivity. In Chat mode that must land
     * on the Chat screen instead (extras such as the contact-permission
     * request are carried over), without ever showing this voice screen.
     */
    private boolean redirectToChatIfNeeded(Intent source) {
        if (!com.idcorporation.atlas.utils.ModeManager.isChatMode(this)) {
            return false;
        }
        Intent chat = new Intent(this, ChatActivity.class);
        if (source != null && source.getExtras() != null) {
            chat.putExtras(source.getExtras());
        }
        chat.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(chat);
        finish();
        overridePendingTransition(0, 0);
        return true;
    }

    /**
     * Handles being opened from the Presenca shake overlay: jump straight
     * into listening or straight into the typed-message field instead of
     * making the user tap again once the app is on screen.
     */
    private void handleLaunchExtras(Intent intent) {
        if (intent == null) {
            return;
        }
        final boolean startListening = intent.getBooleanExtra(EXTRA_START_LISTENING, false);
        final boolean requestContactPermissions = intent.getBooleanExtra(EXTRA_REQUEST_CONTACT_PERMISSIONS, false);

        if (requestContactPermissions) {
            intent.removeExtra(EXTRA_REQUEST_CONTACT_PERMISSIONS);
            requestContactActionPermissions();
        }

        intent.removeExtra(EXTRA_FOCUS_TEXT_INPUT);
        if (!startListening) {
            return;
        }

        intent.removeExtra(EXTRA_START_LISTENING);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                startListeningIfPermitted();
            }
        }, 350);
    }

    private void bindViews() {
        // ATLAS ESFERA: the 3D particle sphere is the core of the Home.
        sphereView = (AtlasSphereView) findViewById(R.id.view_sphere);
        if (SplashActivity.awakenedHandoff) {
            // coming from the awakening: carry on with the same sphere the splash was drawing
            sphereView.adoptHandoff();
        }
        TextView stateLabel = (TextView) findViewById(R.id.text_state);
        hudStateManager = new HudStateManager(sphereView, stateLabel);

        transcriptView = (TextView) findViewById(R.id.text_transcript);
        dateTimeView = (TextView) findViewById(R.id.text_datetime);
        batteryView = (TextView) findViewById(R.id.text_battery);
        confirmationCard = findViewById(R.id.layout_confirmation_card);
        confirmationPromptView = (TextView) findViewById(R.id.text_confirmation_prompt);

        coreTouchArea = sphereView;
        bottomControlsView = findViewById(R.id.layout_bottom_controls);
    }

    private void wireButtons() {
        micButtonBig = (ImageButton) findViewById(R.id.button_microphone);
        ViewAnimUtils.applyPressFeedback(micButtonBig);
        micButtonBig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SoundManager.playScifiClick(MainActivity.this);
                toggleMicMute();
            }
        });

        ImageButton settingsButton = (ImageButton) findViewById(R.id.button_settings);
        ViewAnimUtils.applyPressFeedback(settingsButton);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        modesButton = (ImageButton) findViewById(R.id.button_modes);
        ViewAnimUtils.applyPressFeedback(modesButton);
        modesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ModesActivity.class));
            }
        });

        historyButton = (ImageButton) findViewById(R.id.button_history);
        ViewAnimUtils.applyPressFeedback(historyButton);
        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, HistoryActivity.class));
            }
        });

        Object yesButton = findViewById(R.id.button_confirm_yes);
        ViewAnimUtils.applyPressFeedback((View) yesButton);
        ((View) yesButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SoundManager.playScifiClick(MainActivity.this);
                confirmPendingAction(true);
            }
        });

        Object noButton = findViewById(R.id.button_confirm_no);
        ViewAnimUtils.applyPressFeedback((View) noButton);
        ((View) noButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmPendingAction(false);
            }
        });

        wireCoreGestures();
    }

    // coming from the awakening: how long the theme background and the controls take to appear
    private static final long HANDOFF_FADE_MS = 1100L;
    private boolean bgFadePending = false;

    /** Alpha-only fade (no movement, no overshoot): the view starts transparent and slowly takes its own colour. */
    private void fadeInGently(View view, long delayMs) {
        view.setAlpha(0f);
        view.animate()
                .alpha(1f)
                .setStartDelay(delayMs)
                .setDuration(HANDOFF_FADE_MS)
                .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                .start();
    }

    /** Fades the animated theme background in (BaseActivity re-applies it in onResume, so this runs after that). */
    private void fadeInThemeBackground() {
        if (!bgFadePending) {
            return;
        }
        bgFadePending = false;
        android.view.ViewGroup content = (android.view.ViewGroup) findViewById(android.R.id.content);
        if (content == null || content.getChildCount() == 0) {
            return;
        }
        View bg = content.getChildAt(0);
        if (bg instanceof com.idcorporation.atlas.theme.ThemeBackgroundView) {
            bg.setAlpha(0f);
            bg.animate()
                    .alpha(1f)
                    .setDuration(HANDOFF_FADE_MS)
                    .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                    .start();
        }
    }

    /** Plays once, when the HUD first appears: the core and controls settle into place. */
    private void playEntranceAnimation() {
        View core = findViewById(R.id.layout_core);
        View stateLabel = findViewById(R.id.text_state);
        View bottomControls = findViewById(R.id.layout_bottom_controls);
        View statusBar = findViewById(R.id.layout_status_bar);

        if (SplashActivity.awakenedHandoff) {
            // coming from the awakening: the sphere is already where the splash left it
            SplashActivity.awakenedHandoff = false;
            // the splash ended on the solid theme colour: keep it under the window so the
            // theme background (animated or not) can fade in over it instead of popping in
            getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                    com.idcorporation.atlas.theme.ThemeManager.getSelectedPalette(this).getBackgroundColor()));
            bgFadePending = true;
            fadeInGently(statusBar, 150);
            fadeInGently(stateLabel, 250);
            fadeInGently(bottomControls, 250);
            return;
        }

        core.setAlpha(0f);
        core.setScaleX(0.85f);
        core.setScaleY(0.85f);
        ObjectAnimator coreFade = ObjectAnimator.ofFloat(core, "alpha", 0f, 1f);
        ObjectAnimator coreScaleX = ObjectAnimator.ofFloat(core, "scaleX", 0.85f, 1f);
        ObjectAnimator coreScaleY = ObjectAnimator.ofFloat(core, "scaleY", 0.85f, 1f);
        coreFade.setDuration(900);
        coreScaleX.setDuration(900);
        coreScaleY.setDuration(900);
        coreScaleX.setInterpolator(new android.view.animation.DecelerateInterpolator(2f));
        coreScaleY.setInterpolator(new android.view.animation.DecelerateInterpolator(2f));
        coreFade.start();
        coreScaleX.start();
        coreScaleY.start();

        ViewAnimUtils.animateEntrance(stateLabel, 200);
        ViewAnimUtils.animateEntrance(bottomControls, 260);
        ViewAnimUtils.animateEntrance(statusBar, 0);
    }

    private void wireCoreGestures() {
        coreTouchArea.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startLongPressTimer();
                    registerTap();
                } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    cancelLongPressTimer();
                }
                // false: let the sphere react too (energy wave + drag to rotate).
                return false;
            }
        });
    }

    private void startLongPressTimer() {
        longPressTriggered = false;
        longPressRunnable = new Runnable() {
            @Override
            public void run() {
                longPressTriggered = true;
                playAnnoyedShakeAnimation();
            }
        };
        new Handler(Looper.getMainLooper()).postDelayed(longPressRunnable, LONG_PRESS_DURATION_MS);
    }

    private void cancelLongPressTimer() {
        if (longPressRunnable != null) {
            new Handler(Looper.getMainLooper()).removeCallbacks(longPressRunnable);
        }
    }

    private void playAnnoyedShakeAnimation() {
        ObjectAnimator shake = ObjectAnimator.ofFloat(coreTouchArea, "rotation",
            0f, -6f, 6f, -6f, 6f, -4f, 4f, -4f, 4f, -2f, 2f, 0f);
        shake.setDuration(5000);
        shake.start();
    }

    private void registerTap() {
        long now = System.currentTimeMillis();
        recentTapTimestamps.add(now);

        ArrayList<Long> stillRecent = new ArrayList<Long>();
        for (int i = 0; i < recentTapTimestamps.size(); i++) {
            long timestamp = recentTapTimestamps.get(i);
            if (now - timestamp <= RAPID_TAP_WINDOW_MS) {
                stillRecent.add(timestamp);
            }
        }
        recentTapTimestamps.clear();
        recentTapTimestamps.addAll(stillRecent);

        if (recentTapTimestamps.size() >= RAPID_TAP_COUNT) {
            recentTapTimestamps.clear();
            SoundManager.playScifiClick(this);
            startActivity(new Intent(MainActivity.this, AboutActivity.class));
        }
    }

    private void startListeningIfPermitted() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_CODE_RECORD_AUDIO);
            return;
        }
        session.notifyPermissionGranted();
    }

    /**
     * Requests READ_CONTACTS and CALL_PHONE together, the first time a
     * voice "ligar para X" / "mandar mensagem para X" command needs
     * them. Nothing is auto-retried after this: if granted, the user
     * simply repeats the voice command and it goes through; if denied,
     * ContactActionHandler already falls back to ACTION_DIAL (opens the
     * dialer pre-filled) for calls instead of failing silently.
     */
    private void requestContactActionPermissions() {
        String[] missing = com.idcorporation.atlas.utils.ContactsPermissionHelper.missingPermissions(this);
        if (missing.length == 0) {
            return;
        }
        ActivityCompat.requestPermissions(this, missing, REQUEST_CODE_CONTACT_PERMISSIONS);
    }

    /**
     * ATLAS VOID "estilo ligacao": the mic is always on, listening
     * continuously from the moment ATLAS opens until the app is fully
     * closed - across every screen, not just this one - and only pauses
     * while ATLAS itself is talking (it comes right back once speech
     * finishes; see onSpeakingFinished in AtlasVoiceSession).
     * This button only mutes/unmutes that always-on call instead of
     * starting a single listening turn.
     */
    private void toggleMicMute() {
        session.toggleMicMute();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_RECORD_AUDIO && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            session.notifyPermissionGranted();
        }
        if (requestCode == REQUEST_CODE_CONTACT_PERMISSIONS) {
            // Nothing to notify the session about here - the user just
            // repeats "ligar para..." / "mandar mensagem para..." and
            // ContactActionHandler checks the permission fresh each time.
        }
    }

    // -----------------------------------------------------------------
    // AtlasVoiceSession.UiListener - mirrors the shared call session's
    // state into this screen's own HUD orb, transcript and mic icons.
    // -----------------------------------------------------------------

    @Override
    public void onStateChanged(int hudState) {
        hudStateManager.setState(hudState);
    }

    @Override
    public void onTranscriptLine(String line) {
        appendTranscriptLine(line);
    }

    @Override
    public void onMicMutedChanged(boolean muted) {
        micMuted = muted;
        int icon = muted ? R.drawable.ic_mic_off : R.drawable.ic_mic;
        micButtonBig.setImageResource(icon);
    }

    @Override
    public void onConfirmationNeeded(String prompt, ConfirmAction confirmedAction) {
        pendingConfirmedAction = confirmedAction;
        confirmationPromptView.setText(prompt);
        confirmationCard.setVisibility(View.VISIBLE);
    }

    private void appendTranscriptLine(String line) {
        transcriptView.setText(line);
    }

    private void confirmPendingAction(boolean confirmed) {
        confirmationCard.setVisibility(View.GONE);
        if (confirmed && pendingConfirmedAction != null) {
            hudStateManager.setState(HudStateManager.STATE_EXECUTING);
            // ATLAS FASE 3/4 rule: never tell the user something happened when
            // it did not - a suggested reminder whose date failed to parse,
            // for instance, must not be spoken back as "Pronto!".
            boolean succeeded;
            try {
                succeeded = pendingConfirmedAction.run();
            } catch (RuntimeException e) {
                succeeded = false;
            }
            session.speakAndLog(getString(succeeded ? R.string.resp_done : R.string.resp_action_failed));
        } else {
            session.speakAndLog(getString(R.string.resp_cancelled));
        }
        pendingConfirmedAction = null;
    }

    private void updateSystemInfo() {
        boolean online = DeviceInfoUtil.isConnectedToInternet(this);
        if (!online) {
            hudStateManager.setState(HudStateManager.STATE_OFFLINE);
        }
        String time = DateFormat.getTimeFormat(this).format(new Date());
        dateTimeView.setText(time);
        int batteryPercent = DeviceInfoUtil.getBatteryPercent(this);
        batteryView.setText(batteryPercent + "%");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (redirectToChatIfNeeded(getIntent())) {
            return;
        }
        fadeInThemeBackground();
        updateSystemInfo();
        session.setUiListener(this);
        applyVoicePreferences();
        int accentColor = com.idcorporation.atlas.theme.ThemeManager.getSelectedPalette(this).getAccentColor();
        hudStateManager.setAccentColor(accentColor);
        applyThemeToControls(accentColor);
        applyHomeLayoutPrefs();
        micButtonBig.setBackground(HudStateManager.buildCoreSolidDrawable(micButtonBig, accentColor));
        session.setUiAudioLevelListener(sphereAudioListener);
        sphereView.setRunning(true);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_CODE_RECORD_AUDIO);
        }
    }

    /** The Home's line icons wear the theme colour, so nothing stays "cyan" in a purple or red theme. */
    private void applyThemeToControls(int accentColor) {
        int[] ids = {
            R.id.button_settings, R.id.button_history, R.id.button_modes
        };
        for (int i = 0; i < ids.length; i++) {
            View v = findViewById(ids[i]);
            if (v instanceof ImageButton) {
                ((ImageButton) v).setColorFilter(accentColor);
            }
        }
    }

    /**
     * Settings > Home screen: which buttons are shown, and whether the microphone
     * button is invisible (then the whole bottom strip is the microphone).
     */
    private void applyHomeLayoutPrefs() {
        modesButton.setVisibility(HomeLayoutPrefs.isModesButtonShown(this) ? View.VISIBLE : View.GONE);
        historyButton.setVisibility(HomeLayoutPrefs.isHistoryButtonShown(this) ? View.VISIBLE : View.GONE);
        // INVISIBLE (not GONE) so the room is kept and the sphere never moves
        findViewById(R.id.scroll_transcript).setVisibility(
            HomeLayoutPrefs.isCaptionShown(this) ? View.VISIBLE : View.INVISIBLE);
        findViewById(R.id.layout_sysinfo).setVisibility(
            HomeLayoutPrefs.isTimeBatteryShown(this) ? View.VISIBLE : View.INVISIBLE);
        if (HomeLayoutPrefs.isMicInvisible(this)) {
            micButtonBig.setAlpha(0f);
            bottomControlsView.setClickable(true);
            bottomControlsView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SoundManager.playScifiClick(MainActivity.this);
                    toggleMicMute();
                }
            });
        } else {
            micButtonBig.setAlpha(1f);
            bottomControlsView.setOnClickListener(null);
            bottomControlsView.setClickable(false);
        }
    }

    private void applyVoicePreferences() {
        android.content.SharedPreferences voicePrefs = getSharedPreferences("atlas_voice_prefs", MODE_PRIVATE);
        int rateProgress = voicePrefs.getInt("speech_rate_x10", 10);
        int pitchProgress = voicePrefs.getInt("speech_pitch_x10", 10);
        session.setSpeechRate(rateProgress / 10.0f);
        session.setSpeechPitch(pitchProgress / 10.0f);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Deliberately does NOT stop the mic anymore - the whole point of
        // "estilo ligacao" is that leaving this screen for another ATLAS
        // screen keeps the call going. Only unregister this screen's own
        // HUD from the shared session; AtlasApplication decides if/when
        // the call itself should actually hang up (see hangUp()).
        session.clearUiListener(this);
        session.setUiAudioLevelListener(null);
        if (sphereView != null) {
            sphereView.setRunning(false);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (hudStateManager != null) {
            hudStateManager.release();
        }
    }
}
