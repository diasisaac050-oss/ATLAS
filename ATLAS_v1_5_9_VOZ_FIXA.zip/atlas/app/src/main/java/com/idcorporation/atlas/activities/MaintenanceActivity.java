package com.idcorporation.atlas.activities;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.control.RemoteControl;
import com.idcorporation.atlas.utils.LocaleHelper;

/**
 * ATLAS CONSOLE: tela cheia mostrada quando o admin bloqueia o Atlas.
 * So tem a mensagem e UM botao, "Aguardar". Nao da pra voltar nem fechar:
 * ela so some sozinha quando o admin libera o Atlas no Console.
 *
 * Activity simples (nao BaseActivity) de proposito: nao liga voz, tema nem
 * a chamada de voz do Atlas enquanto estiver bloqueado.
 */
public class MaintenanceActivity extends Activity {

    public static final String EXTRA_MESSAGE = "message";

    private static final long POLL_MS = 8000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView messageView;
    private TextView hintView;
    private Button waitButton;
    private boolean checking = false;

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            check(false);
            handler.postDelayed(this, POLL_MS);
        }
    };

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.wrapContext(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (28 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(0xFF0A0E14);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText(R.string.maintenance_title);
        title.setTextColor(0xFF00E5FF);
        title.setTextSize(24f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        ScrollView scroll = new ScrollView(this);
        messageView = new TextView(this);
        messageView.setTextColor(0xFFE8F6FF);
        messageView.setTextSize(17f);
        messageView.setGravity(Gravity.CENTER);
        messageView.setLineSpacing(0f, 1.2f);
        messageView.setPadding(0, (int) (20 * d), 0, (int) (20 * d));
        scroll.addView(messageView);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(scroll, sp);

        hintView = new TextView(this);
        hintView.setTextColor(0xFF8FA6B8);
        hintView.setTextSize(13f);
        hintView.setGravity(Gravity.CENTER);
        hintView.setVisibility(View.INVISIBLE);
        hintView.setText(R.string.maintenance_still);
        root.addView(hintView);

        waitButton = new Button(this);
        waitButton.setText(R.string.maintenance_wait);
        waitButton.setAllCaps(false);
        waitButton.setTextSize(17f);
        waitButton.setTypeface(Typeface.DEFAULT_BOLD);
        waitButton.setTextColor(0xFF0A0E14);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF00E5FF);
        bg.setCornerRadius(14 * d);
        waitButton.setBackground(bg);
        waitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check(true);
            }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (int) (54 * d));
        bp.topMargin = (int) (12 * d);
        root.addView(waitButton, bp);

        setContentView(root);
        showMessage(getIntent().getStringExtra(EXTRA_MESSAGE));
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        showMessage(intent.getStringExtra(EXTRA_MESSAGE));
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.postDelayed(poll, POLL_MS);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(poll);
    }

    /** Sem botao de voltar: so o "Aguardar". */
    @Override
    public void onBackPressed() {
        // intencionalmente vazio
    }

    private void showMessage(String message) {
        if (message == null || message.trim().isEmpty()) {
            messageView.setText(R.string.maintenance_default_message);
        } else {
            messageView.setText(message);
        }
    }

    private void check(final boolean fromButton) {
        if (checking) {
            return;
        }
        checking = true;
        if (fromButton) {
            waitButton.setEnabled(false);
            waitButton.setAlpha(0.5f);
        }
        RemoteControl.fetch(this, new RemoteControl.Callback() {
            @Override
            public void onResult(boolean ok, boolean blocked, String message) {
                checking = false;
                if (isFinishing()) {
                    return;
                }
                waitButton.setEnabled(true);
                waitButton.setAlpha(1f);
                if (ok && !blocked) {
                    finish(); // liberado: volta pra tela que o usuario estava
                    return;
                }
                if (ok) {
                    showMessage(message); // admin pode ter trocado o texto
                }
                if (fromButton) {
                    hintView.setVisibility(View.VISIBLE);
                    handler.removeCallbacks(hideHint);
                    handler.postDelayed(hideHint, 3000);
                }
            }
        });
    }

    private final Runnable hideHint = new Runnable() {
        @Override
        public void run() {
            hintView.setVisibility(View.INVISIBLE);
        }
    };
}
