package com.idcorporation.atlas.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.HomeLayoutPrefs;

/** Settings > Home screen: what appears on the home screen. The Home applies these on its next resume. */
public class HomeScreenSettingsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_settings);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Switch modes = (Switch) findViewById(R.id.switch_home_modes);
        modes.setChecked(HomeLayoutPrefs.isModesButtonShown(this));
        modes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                HomeLayoutPrefs.setModesButtonShown(HomeScreenSettingsActivity.this, checked);
            }
        });

        Switch history = (Switch) findViewById(R.id.switch_home_history);
        history.setChecked(HomeLayoutPrefs.isHistoryButtonShown(this));
        history.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                HomeLayoutPrefs.setHistoryButtonShown(HomeScreenSettingsActivity.this, checked);
            }
        });

        Switch caption = (Switch) findViewById(R.id.switch_home_caption);
        caption.setChecked(HomeLayoutPrefs.isCaptionShown(this));
        caption.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                HomeLayoutPrefs.setCaptionShown(HomeScreenSettingsActivity.this, checked);
            }
        });

        Switch timeBattery = (Switch) findViewById(R.id.switch_home_time_battery);
        timeBattery.setChecked(HomeLayoutPrefs.isTimeBatteryShown(this));
        timeBattery.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                HomeLayoutPrefs.setTimeBatteryShown(HomeScreenSettingsActivity.this, checked);
            }
        });

        Switch mic = (Switch) findViewById(R.id.switch_home_mic_invisible);
        mic.setChecked(HomeLayoutPrefs.isMicInvisible(this));
        mic.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                HomeLayoutPrefs.setMicInvisible(HomeScreenSettingsActivity.this, checked);
            }
        });
    }
}
