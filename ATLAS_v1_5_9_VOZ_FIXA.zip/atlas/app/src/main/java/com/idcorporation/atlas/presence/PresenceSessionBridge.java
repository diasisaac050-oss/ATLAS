package com.idcorporation.atlas.presence;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import androidx.core.content.ContextCompat;

import com.idcorporation.atlas.AtlasApplication;
import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.HudStateManager;
import com.idcorporation.atlas.commands.ConfirmAction;
import com.idcorporation.atlas.utils.SoundManager;
import com.idcorporation.atlas.voice.AtlasVoiceSession;
import com.idcorporation.atlas.voice.VoiceManager;

/**
 * Connects the app-wide AtlasVoiceSession to the floating bubble: voice
 * states drive the bubble animation and sounds, what was heard/answered
 * goes into the caption pill, and a 1-second tick handles the "nobody is
 * talking any more" timeout plus the "I cannot hear you" hint.
 */
public class PresenceSessionBridge implements AtlasVoiceSession.UiListener,
        VoiceManager.PartialTextListener, AtlasVoiceSession.AudioLevelListener {

    public interface Host {
        void requestHide();
        void requestHandOver();
    }

    private static final long IDLE_TIMEOUT_MS = 15000;
    private static final long TICK_MS = 1000;

    private final Context context;
    private final PresenceBubbleView bubble;
    private final PresenceCaption caption;
    private final Host host;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private int lastState = HudStateManager.STATE_IDLE;
    private long idleMs = 0;
    private boolean hintShown = false;
    private boolean running = false;
    private Runnable tickRunnable;

    public PresenceSessionBridge(Context context, PresenceBubbleView bubble,
                                 PresenceCaption caption, Host host) {
        this.context = context.getApplicationContext();
        this.bubble = bubble;
        this.caption = caption;
        this.host = host;
    }

    public void resetIdle() {
        idleMs = 0;
    }

    /**
     * Attaches the bubble to the session (states, captions, levels) and
     * starts the idle timer. It does NOT open the microphone yet: the
     * service calls beginCall() once Android has granted the microphone
     * foreground type, otherwise the first turn can be recorded as silence.
     */
    public void start() {
        AtlasVoiceSession session = AtlasApplication.voiceSession(context);
        running = true;
        session.setUiListener(this);
        session.setPartialTextListener(this);
        session.setAudioLevelListener(this);
        boolean granted = (ContextCompat.checkSelfPermission(context,
            Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED);
        if (!granted) {
            caption.show(context.getString(R.string.presence_hint_no_permission), false);
        }
        startTick();
    }

    /** Opens the live call: the microphone turns on right now. */
    public void beginCall() {
        if (!running) {
            return;
        }
        AtlasApplication.voiceSession(context).startPresenceCall();
    }

    /** The microphone became available late: restart the turn that may have heard silence. */
    public void refreshCall() {
        if (!running) {
            return;
        }
        AtlasApplication.voiceSession(context).refreshPresenceListening();
    }

    /** Stops listening to the session. The caller decides what happens to the call itself. */
    public void stop() {
        running = false;
        handler.removeCallbacks(tickRunnable);
        caption.cancelFade();
        AtlasVoiceSession session = AtlasApplication.voiceSession(context);
        session.clearUiListener(this);
        session.setPartialTextListener(null);
        session.setAudioLevelListener(null);
    }

    @Override
    public void onStateChanged(int hudState) {
        int previous = lastState;
        lastState = hudState;
        bubble.setHudState(hudState);
        caption.setFadeBlocked(hudState == HudStateManager.STATE_SPEAKING);
        if (hudState == HudStateManager.STATE_LISTENING && previous != HudStateManager.STATE_LISTENING) {
            SoundManager.playPresenceListen(context);
            bubble.pingRipple();
        }
    }

    @Override
    public void onTranscriptLine(String line) {
        if (line == null) {
            return;
        }
        idleMs = 0;
        if (line.startsWith("You: ")) {
            caption.show(line.substring(5), false);
        } else if (line.startsWith("ATLAS: ")) {
            caption.show(line.substring(7), true);
        } else {
            caption.show(line, true);
        }
    }

    @Override
    public void onPartialText(String text) {
        idleMs = 0;
        caption.show(text, false);
    }

    @Override
    public void onAudioLevel(float rmsDb) {
        // Real microphone loudness drives the sound-wave line in the bubble.
        bubble.setAudioLevel(rmsDb);
    }

    @Override
    public void onMicMutedChanged(boolean muted) {
    }

    @Override
    public void onConfirmationNeeded(String prompt, ConfirmAction confirmedAction) {
        // The bubble has no Yes/No card, so it never runs sensitive actions
        // on its own - the session already speaks the prompt out loud.
    }

    private void startTick() {
        tickRunnable = new Runnable() {
            @Override
            public void run() {
                if (!running) {
                    return;
                }
                if (AtlasApplication.isForeground(context)) {
                    host.requestHandOver();
                    return;
                }
                boolean quiet = (lastState == HudStateManager.STATE_IDLE
                    || lastState == HudStateManager.STATE_LISTENING
                    || lastState == HudStateManager.STATE_ERROR);
                idleMs = quiet ? (idleMs + TICK_MS) : 0;
                AtlasVoiceSession session = AtlasApplication.voiceSession(context);
                if (!hintShown && session.hasMicPermission() && session.getSilentErrorStreak() >= 2) {
                    hintShown = true;
                    caption.show(context.getString(R.string.presence_hint_no_speech), true);
                }
                if (idleMs >= IDLE_TIMEOUT_MS) {
                    host.requestHide();
                    return;
                }
                handler.postDelayed(this, TICK_MS);
            }
        };
        handler.postDelayed(tickRunnable, TICK_MS);
    }
}
