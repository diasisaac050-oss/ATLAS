package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

/**
 * The moving content inside the transparent orb. Nothing here has a color:
 * every layer is white with a changing transparency, so it reads as light
 * moving inside clear glass. Layers, back to front:
 * 1) six soft petals that turn at different speeds and breathe with the voice,
 * 2) two dashed rings turning in opposite directions,
 * 3) a bright core with thin star rays,
 * 4) sparkles drifting inside,
 * 5) pulse rings while ATLAS speaks and three orbiting dots while it thinks.
 * The caller clips the canvas to the circle before calling draw().
 */
public class PresenceOrbInner {

    private static final float[] LOBE_ANGLE = {0f, 62f, 118f, 181f, 243f, 301f};
    private static final float[] LOBE_SPEED = {22f, -30f, 41f, -18f, 27f, -36f};
    private static final float[] LOBE_LEN = {0.92f, 0.80f, 0.98f, 0.72f, 0.86f, 0.66f};
    private static final float[] LOBE_WIDTH = {0.90f, 0.70f, 0.55f, 0.80f, 0.65f, 0.75f};
    private static final float[] LOBE_WOBBLE = {1.3f, 1.9f, 0.9f, 1.6f, 2.2f, 1.1f};
    private static final int[] LOBE_ALPHA = {74, 60, 84, 52, 66, 48};

    private final float d;
    private final Path lens = new Path();
    private final Paint lobePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    private float spin = 0f;
    private float lastPhase = 0f;

    public PresenceOrbInner(float density) {
        this.d = density;
        // One unit-size petal lying along +X. It is scaled and rotated on the canvas.
        lens.moveTo(0f, 0f);
        lens.quadTo(0.45f, -1f, 1f, 0f);
        lens.quadTo(0.45f, 1f, 0f, 0f);
        lens.close();
        lobePaint.setShader(new LinearGradient(0f, 0f, 1f, 0f,
            new int[] {0xFFFFFFFF, 0x8CFFFFFF, 0x00FFFFFF},
            new float[] {0f, 0.38f, 1f}, Shader.TileMode.CLAMP));
        glowPaint.setShader(new RadialGradient(0f, 0f, 1f,
            new int[] {0xEBFFFFFF, 0x5AFFFFFF, 0x00FFFFFF},
            new float[] {0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        dotPaint.setColor(0xFFFFFFFF);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeCap(Paint.Cap.ROUND);
        ringPaint.setColor(0xFFFFFFFF);
    }

    void draw(Canvas c, float cx, float cy, float r, PresenceBubbleState st,
              float pulse, float alpha) {
        float dt = st.phase - lastPhase;
        lastPhase = st.phase;
        if (dt < 0f || dt > 0.25f) {
            dt = 0f;
        }
        spin = spin + dt * (1f + st.thinkAmt * 3.2f + st.level * 1.8f + st.speakAmt * 0.9f);

        float a = alpha * (0.35f + 0.65f * st.ignite) * (1f - 0.5f * st.errAmt);
        drawLobes(c, cx, cy, r, st, pulse, a);
        drawDashedRings(c, cx, cy, r, a);
        drawCore(c, cx, cy, r, pulse, a);
        drawSparkles(c, cx, cy, r, a);
        drawSpeakRings(c, cx, cy, r, st, a);
        drawThinkingDots(c, cx, cy, r, st, a);
    }

    private void drawLobes(Canvas c, float cx, float cy, float r, PresenceBubbleState st,
                           float pulse, float a) {
        for (int i = 0; i < LOBE_ANGLE.length; i++) {
            float wobble = 1f + 0.16f * (float) Math.sin(st.phase * LOBE_WOBBLE[i] + i)
                + st.level * 0.30f + pulse * 0.22f;
            float len = r * LOBE_LEN[i] * wobble;
            c.save();
            c.translate(cx, cy);
            c.rotate(LOBE_ANGLE[i] + spin * LOBE_SPEED[i]);
            c.scale(len, len * LOBE_WIDTH[i]);
            lobePaint.setAlpha((int) (LOBE_ALPHA[i] * a));
            c.drawPath(lens, lobePaint);
            c.restore();
        }
    }

    private void drawDashedRings(Canvas c, float cx, float cy, float r, float a) {
        ringPaint.setStrokeWidth(1.1f * d);
        ringPaint.setAlpha((int) (95 * a));
        float outer = r * 0.74f;
        oval.set(cx - outer, cy - outer, cx + outer, cy + outer);
        for (int k = 0; k < 3; k++) {
            c.drawArc(oval, spin * 34f + k * 120f, 38f, false, ringPaint);
        }
        float inner = r * 0.52f;
        ringPaint.setAlpha((int) (70 * a));
        oval.set(cx - inner, cy - inner, cx + inner, cy + inner);
        for (int k = 0; k < 2; k++) {
            c.drawArc(oval, -spin * 52f + k * 180f, 52f, false, ringPaint);
        }
    }

    private void drawCore(Canvas c, float cx, float cy, float r, float pulse, float a) {
        float rad = r * 0.46f * (1f + 0.5f * pulse);
        c.save();
        c.translate(cx, cy);
        c.scale(rad, rad);
        glowPaint.setAlpha((int) (255 * a));
        c.drawCircle(0f, 0f, 1f, glowPaint);
        c.restore();

        float ray = r * (0.95f + 0.25f * pulse);
        for (int k = 0; k < 6; k++) {
            c.save();
            c.translate(cx, cy);
            c.rotate(spin * 40f + k * 60f);
            c.scale(ray, ray * 0.09f);
            lobePaint.setAlpha((int) (130 * a));
            c.drawPath(lens, lobePaint);
            c.restore();
        }
    }

    private void drawSparkles(Canvas c, float cx, float cy, float r, float a) {
        for (int i = 0; i < 9; i++) {
            float life = spin * 0.18f + i * 0.13f;
            life = life - (float) Math.floor(life);
            float angle = (float) (i * 2.399f + spin * 0.25f * ((i % 2 == 0) ? 1f : -1f));
            float dist = r * (0.15f + 0.68f * life);
            float x = cx + (float) Math.cos(angle) * dist;
            float y = cy + (float) Math.sin(angle) * dist;
            float fade = (float) Math.sin(Math.PI * life);
            dotPaint.setAlpha((int) (170 * fade * a));
            c.drawCircle(x, y, (0.9f + (i % 3) * 0.5f) * d, dotPaint);
        }
    }

    private void drawSpeakRings(Canvas c, float cx, float cy, float r,
                                PresenceBubbleState st, float a) {
        if (st.speakAmt <= 0.02f) {
            return;
        }
        ringPaint.setStrokeWidth(1.4f * d);
        for (int k = 0; k < 2; k++) {
            float t = st.phase * 0.9f + k * 0.5f;
            t = t - (float) Math.floor(t);
            ringPaint.setAlpha((int) (110 * (1f - t) * st.speakAmt * a));
            c.drawCircle(cx, cy, r * (0.2f + 0.75f * t), ringPaint);
        }
    }

    private void drawThinkingDots(Canvas c, float cx, float cy, float r,
                                  PresenceBubbleState st, float a) {
        if (st.thinkAmt <= 0.02f) {
            return;
        }
        for (int k = 0; k < 3; k++) {
            double ang = Math.toRadians(spin * 130f + k * 120f);
            float x = cx + (float) Math.cos(ang) * r * 0.6f;
            float y = cy + (float) Math.sin(ang) * r * 0.6f;
            dotPaint.setAlpha((int) (230 * st.thinkAmt * a));
            c.drawCircle(x, y, 3f * d, dotPaint);
        }
    }
}
