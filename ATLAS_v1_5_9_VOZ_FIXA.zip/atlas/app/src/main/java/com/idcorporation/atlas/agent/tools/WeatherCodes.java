package com.idcorporation.atlas.agent.tools;

/**
 * WMO weather codes -> short text. Portuguese and English are written out;
 * every other app language falls back to English.
 */
final class WeatherCodes {

    private WeatherCodes() {
    }

    static boolean pt(String lang) {
        return lang != null && lang.startsWith("pt");
    }

    static String describe(int code, String lang) {
        boolean p = pt(lang);
        if (code == 0) return p ? "C\u00E9u limpo" : "Clear sky";
        if (code == 1) return p ? "Quase limpo" : "Mostly clear";
        if (code == 2) return p ? "Parcialmente nublado" : "Partly cloudy";
        if (code == 3) return p ? "Nublado" : "Overcast";
        if (code == 45 || code == 48) return p ? "Neblina" : "Fog";
        if (code >= 51 && code <= 57) return p ? "Garoa" : "Drizzle";
        if (code >= 61 && code <= 65) return p ? "Chuva" : "Rain";
        if (code == 66 || code == 67) return p ? "Chuva congelante" : "Freezing rain";
        if (code >= 71 && code <= 77) return p ? "Neve" : "Snow";
        if (code >= 80 && code <= 82) return p ? "Pancadas de chuva" : "Rain showers";
        if (code == 85 || code == 86) return p ? "Pancadas de neve" : "Snow showers";
        if (code == 95) return p ? "Trovoada" : "Thunderstorm";
        if (code == 96 || code == 99) return p ? "Trovoada com granizo" : "Thunderstorm with hail";
        return p ? "Tempo vari\u00E1vel" : "Mixed conditions";
    }

    static String feelsLike(String lang) {
        return pt(lang) ? "Sensa\u00E7\u00E3o" : "Feels like";
    }

    static String humidity(String lang) {
        return pt(lang) ? "Umidade" : "Humidity";
    }

    static String wind(String lang) {
        return pt(lang) ? "Vento" : "Wind";
    }

    static String today(String lang) {
        return pt(lang) ? "Hoje" : "Today";
    }

    static String rain(String lang) {
        return pt(lang) ? "Chuva" : "Rain";
    }
}
