package com.idcorporation.atlas.utils;

import android.app.Application;
import android.content.Intent;
import android.os.Build;

import com.idcorporation.atlas.activities.CrashReportActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Catches any crash of ATLAS, saves the full error text and opens a small
 * screen (in its own process, so it still works when the main process is
 * dying) that shows the error and lets the user copy it. Built so a crash
 * can be diagnosed on a phone without a computer or logcat.
 */
public class CrashReporter {

    private static final String FILE_NAME = "last_crash.txt";
    private static final int MAX_CHARS = 30000;
    private static final long MIN_GAP_MS = 3000L;

    /** The crash screen runs in the ":crash" process; the app itself must not start up there. */
    public static boolean isCrashProcess() {
        try {
            FileInputStream in = new FileInputStream("/proc/self/cmdline");
            byte[] buffer = new byte[256];
            int count = in.read(buffer);
            in.close();
            if (count <= 0) {
                return false;
            }
            int length = 0;
            while (length < count && buffer[length] != 0) {
                length = length + 1;
            }
            String name = new String(buffer, 0, length, "UTF-8");
            return name.endsWith(":crash");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * For a failure that is caught and handled (not a true uncaught crash) but is
     * still serious enough that the person should see it - e.g. one piece of
     * AtlasApplication's startup failing. Shows the same crash screen as a real
     * crash, but does NOT kill the process, so the rest of the app still has a
     * chance to come up (possibly with that one feature missing) instead of the
     * whole app being unable to open at all.
     */
    public static void logNonFatal(final Application app, Throwable error) {
        try {
            report(app, Thread.currentThread(), error);
        } catch (Throwable ignored) {
            // Reporting must never raise a crash of its own.
        }
    }

    public static void install(final Application app) {
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable error) {
                try {
                    report(app, thread, error);
                } catch (Throwable ignored) {
                    // Reporting must never raise a second crash.
                }
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(10);
            }
        });
    }

    /** Removes anything that looks like an API key or a bearer token before the text is stored or shown. */
    private static String redactSecrets(String text) {
        String cleaned = text.replaceAll("gsk_[A-Za-z0-9_\\-]+", "[redacted-key]");
        cleaned = cleaned.replaceAll("(?i)bearer\\s+[A-Za-z0-9._\\-]+", "Bearer [redacted]");
        return cleaned;
    }

    private static void report(Application app, Thread thread, Throwable error) throws Exception {
        StringWriter writer = new StringWriter();
        error.printStackTrace(new PrintWriter(writer));
        String text = "ATLAS crash\n"
            + "Android " + Build.VERSION.SDK_INT + " / " + Build.MANUFACTURER + " " + Build.MODEL + "\n"
            + "Thread: " + thread.getName() + "\n\n" + writer.toString();
        text = redactSecrets(text);
        if (text.length() > MAX_CHARS) {
            text = text.substring(0, MAX_CHARS);
        }

        File file = new File(app.getFilesDir(), FILE_NAME);
        boolean recent = file.exists() && (System.currentTimeMillis() - file.lastModified()) < MIN_GAP_MS;
        FileOutputStream out = new FileOutputStream(file);
        out.write(text.getBytes("UTF-8"));
        out.close();
        // ATLAS is developed and used by the same person (no separate "end user"
        // to hide a stack trace from), and this is the only way to see why the
        // app crashed on a phone with no computer/logcat attached. So the crash
        // screen always opens now, in every build type - release included -
        // instead of only when the APK happens to be built as debuggable.
        if (recent) {
            // Crashing again right away: do not open the report screen in a loop.
            return;
        }

        Intent intent = new Intent(app, CrashReportActivity.class);
        intent.putExtra(CrashReportActivity.EXTRA_TRACE, text);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        app.startActivity(intent);
        Thread.sleep(700);
    }
}
