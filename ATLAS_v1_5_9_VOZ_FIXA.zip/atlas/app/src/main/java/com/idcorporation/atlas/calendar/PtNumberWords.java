package com.idcorporation.atlas.calendar;

/**
 * Spoken Portuguese numbers (um, dois ... cinquenta e nove) as a regex
 * piece plus a converter to int. The speech recognizer sometimes writes
 * "5 minutos" and sometimes "cinco minutos", so every parser that reads
 * a number uses NUM and accepts both. Text must already be lower-cased
 * and accent-stripped (see DateTimeCommandParser.normalize).
 */
public class PtNumberWords {

    private static final String[] WORDS = new String[]{
        "um", "uma", "dois", "duas", "tres", "quatro", "cinco", "seis", "sete", "oito", "nove",
        "dez", "onze", "doze", "treze", "catorze", "quatorze", "quinze",
        "dezesseis", "dezasseis", "dezessete", "dezassete", "dezoito", "dezenove",
        "vinte", "trinta", "quarenta", "cinquenta"
    };

    private static final int[] VALUES = new int[]{
        1, 1, 2, 2, 3, 4, 5, 6, 7, 8, 9,
        10, 11, 12, 13, 14, 14, 15,
        16, 16, 17, 17, 18, 19,
        20, 30, 40, 50
    };

    public static final String UNIT = "(?:uma|um|dois|duas|tres|quatro|cinco|seis|sete|oito|nove)";
    public static final String TEEN = "(?:dezesseis|dezasseis|dezessete|dezassete|dezenove|dezoito"
        + "|dez|onze|doze|treze|catorze|quatorze|quinze)";
    public static final String TENS = "(?:vinte|trinta|quarenta|cinquenta)";

    /** Digits or spoken number. Contains no capturing groups, so it is safe inside bigger patterns. */
    public static final String NUM = "(?:\\d{1,4}|" + TENS + "\\s+e\\s+" + UNIT + "|" + TENS
        + "|" + TEEN + "|" + UNIT + ")";

    /** Converts a token matched by NUM (digits or words) to an int, or -1 when it is not a number. */
    public static int value(String token) {
        if (token == null) {
            return -1;
        }
        String t = token.trim();
        if (t.length() == 0) {
            return -1;
        }
        if (Character.isDigit(t.charAt(0))) {
            try {
                return Integer.parseInt(t);
            } catch (NumberFormatException e) {
                return -1;
            }
        }
        String[] parts = t.split("\\s+e\\s+");
        int total = 0;
        for (int i = 0; i < parts.length; i++) {
            int wordValue = wordValue(parts[i].trim());
            if (wordValue < 0) {
                return -1;
            }
            total += wordValue;
        }
        return total;
    }

    private static int wordValue(String word) {
        for (int i = 0; i < WORDS.length; i++) {
            if (WORDS[i].equals(word)) {
                return VALUES[i];
            }
        }
        return -1;
    }
}
