package com.idcorporation.atlas.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.adapters.GenericListAdapter;
import com.idcorporation.atlas.adapters.RowItem;
import com.idcorporation.atlas.calendar.CalendarDateUtils;
import com.idcorporation.atlas.calendar.CalendarEventManager;
import com.idcorporation.atlas.models.CalendarEventItem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

/**
 * ATLAS GENESYS - Compromissos: one place where the user can see every
 * compromisso (notified, never rings) and every despertador (real alarm,
 * rings) that is still scheduled, and cancel any of them. Reuses the same
 * generic list screen as Memory/History for a consistent look.
 */
public class CompromissosActivity extends BaseActivity {

    private CalendarEventManager calendarEventManager;
    private RecyclerView recyclerView;
    private TextView emptyStateView;
    private final ArrayList<CalendarEventItem> currentItems = new ArrayList<CalendarEventItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generic_list);

        calendarEventManager = new CalendarEventManager(this);

        TextView titleView = (TextView) findViewById(R.id.text_screen_title);
        titleView.setText(R.string.title_compromissos);

        emptyStateView = (TextView) findViewById(R.id.text_empty_state);
        emptyStateView.setText(R.string.empty_state_compromissos);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        View addButton = findViewById(R.id.button_add_row);
        addButton.setVisibility(View.GONE);

        findViewById(R.id.button_clear_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmClearAll();
            }
        });

        loadItems();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    private void loadItems() {
        currentItems.clear();
        currentItems.addAll(calendarEventManager.getFutureTimedEvents());
        Collections.sort(currentItems, new Comparator<CalendarEventItem>() {
            @Override
            public int compare(CalendarEventItem a, CalendarEventItem b) {
                long ta = CalendarDateUtils.toEpochMillis(a.getYear(), a.getMonth(), a.getDay(), a.getHour(), a.getMinute());
                long tb = CalendarDateUtils.toEpochMillis(b.getYear(), b.getMonth(), b.getDay(), b.getHour(), b.getMinute());
                return Long.valueOf(ta).compareTo(Long.valueOf(tb));
            }
        });

        ArrayList<RowItem> rows = new ArrayList<RowItem>();
        for (int i = 0; i < currentItems.size(); i++) {
            CalendarEventItem item = currentItems.get(i);
            boolean isAlarm = CalendarEventItem.TYPE_ALARM.equals(item.getEventType());
            String kind = getString(isAlarm ? R.string.label_despertador : R.string.label_compromisso);
            String when = String.format(Locale.US, "%02d/%02d %02d:%02d",
                item.getDay(), item.getMonth(), item.getHour(), item.getMinute());
            rows.add(new RowItem(item.getId(), item.getTitle(), kind + " - " + when));
        }

        recyclerView.setAdapter(new GenericListAdapter(rows, new GenericListAdapter.OnRowDeleteListener() {
            @Override
            public void onDelete(long rowId) {
                calendarEventManager.deleteEvent(rowId);
                loadItems();
            }
        }));
        emptyStateView.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void confirmClearAll() {
        if (currentItems.isEmpty()) {
            return;
        }
        new AlertDialog.Builder(this)
            .setTitle(R.string.action_clear_all)
            .setMessage(R.string.confirm_delete_all_compromissos)
            .setPositiveButton(R.string.action_clear_all, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ArrayList<CalendarEventItem> toDelete = new ArrayList<CalendarEventItem>(currentItems);
                    for (int i = 0; i < toDelete.size(); i++) {
                        calendarEventManager.deleteEvent(toDelete.get(i).getId());
                    }
                    loadItems();
                }
            })
            .setNegativeButton(R.string.action_cancel, null)
            .show();
    }
}
