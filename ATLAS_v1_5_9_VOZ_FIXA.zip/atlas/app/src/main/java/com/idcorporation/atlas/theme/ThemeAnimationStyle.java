package com.idcorporation.atlas.theme;

/**
 * Identifies which animated background algorithm a theme uses. Kept as
 * plain int constants (not an enum) to match the rest of this codebase.
 */
public class ThemeAnimationStyle {

    public static final int NONE = 0;
    public static final int DRIFT_DOTS = 1;
    public static final int RISING_PARTICLES = 3;
    public static final int SCAN_GRID = 4;
    public static final int SWARM = 5;
    public static final int AURORA_WAVES = 6;
    public static final int SHEEN_SWEEP = 7;
    public static final int GLACIAL_SHIMMER = 8;
    public static final int PURPURA_BLOOM = 9;
    public static final int RED_DRY_EMBER = 11;

    private ThemeAnimationStyle() {
    }
}
