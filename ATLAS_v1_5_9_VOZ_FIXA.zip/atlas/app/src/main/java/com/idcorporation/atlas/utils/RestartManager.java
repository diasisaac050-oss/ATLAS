package com.idcorporation.atlas.utils;

/**
 * Restarting the device is a privileged operation. Regular apps (no root,
 * not the device owner, not preinstalled as a system app) have no public
 * Android API to reboot the phone - Settings.System has nothing for it and
 * android.permission.REBOOT is signature/system protected, so declaring it
 * in the manifest would not actually grant it here.
 *
 * This still gives ATLAS something to try: on a rooted phone "su -c reboot"
 * works. On every other phone it fails fast, and CommandManager reports that
 * honestly instead of pretending the restart happened.
 */
public class RestartManager {

    /** @return true only if the reboot command was actually accepted by a root shell. */
    public boolean tryRestart() {
        try {
            Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "reboot"});
            int exitCode = process.waitFor();
            return exitCode == 0;
        } catch (Exception e) {
            // No root available - expected on the vast majority of devices.
            return false;
        }
    }
}
