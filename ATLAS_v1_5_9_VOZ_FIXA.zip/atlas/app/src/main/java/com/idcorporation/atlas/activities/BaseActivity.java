package com.idcorporation.atlas.activities;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.core.content.ContextCompat;

import com.idcorporation.atlas.AtlasApplication;
import com.idcorporation.atlas.R;
import com.idcorporation.atlas.control.RemoteControl;
import com.idcorporation.atlas.theme.ThemeManager;
import com.idcorporation.atlas.utils.LocaleHelper;
import com.idcorporation.atlas.utils.ModeManager;

/**
 * All ATLAS activities extend this instead of Activity directly so the
 * user's chosen in-app language (Settings > Languages) and the selected
 * theme (Settings > Temas) are applied consistently everywhere,
 * independent of the phone's system language or theme. It also applies
 * a consistent fade transition between every screen in the app.
 *
 * This extends the plain framework Activity, not AppCompatActivity -
 * the app does not use an ActionBar or other AppCompat-only features,
 * and avoiding the appcompat library keeps theme resolution simple in
 * Code Assist (AppCompatActivity requires a Theme.AppCompat descendant,
 * which pulls in the whole appcompat resource graph).
 */
public class BaseActivity extends Activity {

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.wrapContext(newBase));
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        if (shouldApplyThemeBackground()) {
            ThemeManager.applyToActivity(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (shouldApplyThemeBackground()) {
            ThemeManager.applyToActivity(this);
        }
        // ATLAS CONSOLE: se o admin bloqueou o Atlas, abre a tela "Aguardar".
        if (!isMaintenanceExempt()) {
            RemoteControl.guard(this);
        }
        if (isVoiceCallScreen() && ModeManager.isVoiceMode(this)) {
            boolean recordAudioGranted = ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            AtlasApplication.voiceSession(this).onAppForeground(recordAudioGranted);
        }
    }

    /**
     * ATLAS VOID "estilo ligacao": the always-on call keeps listening on
     * every screen that returns true here (the default - almost every
     * ATLAS screen). A handful of screens override this to false because
     * having the mic live there would be wrong or unsafe: onboarding
     * (no profile/consent yet), the Vault PIN screen, and the full-screen
     * alarm-ringing screen.
     */
    /** ATLAS AWAKENING: the splash keeps its own black background until the core has expanded. */
    protected boolean shouldApplyThemeBackground() {
        return true;
    }

    protected boolean isVoiceCallScreen() {
        return true;
    }

    /**
     * ATLAS CONSOLE: telas que NUNCA podem ser cobertas pela tela de
     * manutencao (ex.: o alarme tocando). Por padrao, nenhuma.
     */
    protected boolean isMaintenanceExempt() {
        return false;
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransition(R.anim.glacial_slide_in, R.anim.glacial_slide_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.glacial_slide_in, R.anim.glacial_slide_out);
    }
}
