package com.idcorporation.atlas;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import com.idcorporation.atlas.activities.BaseActivity;
import com.idcorporation.atlas.commands.InstalledAppFinder;
import com.idcorporation.atlas.utils.CrashReporter;
import com.idcorporation.atlas.utils.SoundManager;
import com.idcorporation.atlas.voice.AtlasVoiceSession;

/**
 * ATLAS VOID "estilo ligacao": owns the one AtlasVoiceSession for the
 * app's whole life, instead of letting each Activity create and destroy
 * its own voice pipeline. ActivityLifecycleCallbacks tracks how many
 * ATLAS screens are currently started; the call only actually hangs up
 * once that count drops to zero and stays there for a short grace
 * window, so moving from one ATLAS screen to another (old one stops,
 * new one starts a moment later) never interrupts the call - only
 * truly leaving the app does.
 */
public class AtlasApplication extends Application {

    private static final long HANG_UP_GRACE_MS = 400;

    private AtlasVoiceSession voiceSession;
    private int startedScreens = 0;
    private final Handler hangUpHandler = new Handler(Looper.getMainLooper());
    private Runnable hangUpRunnable;

    @Override
    public void onCreate() {
        super.onCreate();
        if (CrashReporter.isCrashProcess()) {
            // The crash-report screen lives in its own process and needs nothing else.
            return;
        }
        CrashReporter.install(this);
        // ATLAS CONSOLE: sinal de vida anonimo + relatorio do ultimo erro.
        try {
            com.idcorporation.atlas.control.Telemetry.start(this);
        } catch (Throwable ignored) {
            // nunca impede o app de abrir
        }

        // ATLAS PRESENCA: if Presence is switched on but its service is not running (killed by an
        // update, by the system, or by a force-stop), bring it back whenever ATLAS starts.
        // Starting a service can be refused when the process was woken up in the background;
        // that is fine - the update/boot receiver covers that case.
        try {
            com.idcorporation.atlas.utils.PresenceManager.restartIfEnabled(this);
        } catch (Throwable ignored) {
            // never blocks the app from opening
        }

        // Each of these is wrapped on its own: a bug freshly introduced in any ONE
        // of them (sound setup, the installed-app scan, or the voice/AI pipeline)
        // used to be able to throw during Application startup and take the whole
        // app down before a single screen could be shown - every launch, with no
        // way to even see why. Now a failure here is reported (see CrashReportActivity)
        // and skipped instead, so the rest of the app still opens.
        try {
            SoundManager.initialize(this);
        } catch (Throwable error) {
            CrashReporter.logNonFatal(this, error);
        }
        try {
            // Reads the list of installed apps in the background so "abrir <app>" is instant.
            InstalledAppFinder.warmUp(this);
        } catch (Throwable error) {
            CrashReporter.logNonFatal(this, error);
        }
        try {
            voiceSession = new AtlasVoiceSession(this);
        } catch (Throwable error) {
            CrashReporter.logNonFatal(this, error);
        }
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityStarted(Activity activity) {
                if (!(activity instanceof BaseActivity)) {
                    return;
                }
                startedScreens = startedScreens + 1;
                if (hangUpRunnable != null) {
                    hangUpHandler.removeCallbacks(hangUpRunnable);
                    hangUpRunnable = null;
                }
            }

            @Override
            public void onActivityStopped(Activity activity) {
                if (!(activity instanceof BaseActivity)) {
                    return;
                }
                startedScreens = startedScreens - 1;
                if (startedScreens <= 0) {
                    startedScreens = 0;
                    armHangUp();
                }
            }

            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
            }

            @Override
            public void onActivityResumed(Activity activity) {
            }

            @Override
            public void onActivityPaused(Activity activity) {
            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
            }

            @Override
            public void onActivityDestroyed(Activity activity) {
            }
        });
    }

    private void armHangUp() {
        hangUpRunnable = new Runnable() {
            @Override
            public void run() {
                if (startedScreens <= 0) {
                    voiceSession.hangUp();
                }
            }
        };
        hangUpHandler.postDelayed(hangUpRunnable, HANG_UP_GRACE_MS);
    }

    public AtlasVoiceSession getVoiceSession() {
        return voiceSession;
    }

    public boolean isAppInForeground() {
        return startedScreens > 0;
    }

    public static AtlasVoiceSession voiceSession(Context context) {
        return ((AtlasApplication) context.getApplicationContext()).getVoiceSession();
    }

    public static boolean isForeground(Context context) {
        return ((AtlasApplication) context.getApplicationContext()).isAppInForeground();
    }
}
