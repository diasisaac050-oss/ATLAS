package com.idcorporation.atlas.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.CallConfirmationSettings;
import com.idcorporation.atlas.utils.ModeManager;
import com.idcorporation.atlas.utils.PresenceManager;
import com.idcorporation.atlas.utils.ReminderScheduler;
import com.idcorporation.atlas.utils.SecretUnlockManager;
import com.idcorporation.atlas.utils.ViewAnimUtils;

public class SettingsActivity extends BaseActivity {

    private static final String PREFS_VOICE = "atlas_voice_prefs";
    private static final String KEY_RATE = "speech_rate_x10";
    private static final String KEY_PITCH = "speech_pitch_x10";
    private static final int REQUEST_CODE_NOTIFICATIONS = 601;
    private static final int REQUEST_CODE_OVERLAY_PERMISSION = 602;

    private SeekBar rateSeekBar;
    private SeekBar pitchSeekBar;
    private Switch notificationSwitch;
    private Switch presenceSwitch;
    private Switch confirmBeforeCallSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        wireRow(R.id.row_profile, ProfileActivity.class);
        wireRow(R.id.row_modes, ModesActivity.class);
        wireRow(R.id.row_language, LanguageActivity.class);
        wireRow(R.id.row_theme, ThemeActivity.class);
        wireRow(R.id.row_home_screen, HomeScreenSettingsActivity.class);
        wireRow(R.id.row_presence_layout, PresenceLayoutActivity.class);
        wireRow(R.id.row_memory, MemoryActivity.class);
        wireRow(R.id.row_history, HistoryActivity.class);
        wireRow(R.id.row_novidades, NovidadesActivity.class);
        wireRow(R.id.row_calendar, CalendarActivity.class);
        wireRow(R.id.row_compromissos, CompromissosActivity.class);
        wireRow(R.id.row_help, HelpActivity.class);
        wireRow(R.id.row_about, AboutActivity.class);
        wireRow(R.id.row_lore, LoreActivity.class);

        rateSeekBar = (SeekBar) findViewById(R.id.seekbar_speech_rate);
        pitchSeekBar = (SeekBar) findViewById(R.id.seekbar_speech_pitch);
        notificationSwitch = (Switch) findViewById(R.id.switch_daily_notification);
        notificationSwitch.setChecked(ReminderScheduler.isDailyReminderEnabled(this));
        notificationSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                onNotificationToggle(isChecked);
            }
        });

        presenceSwitch = (Switch) findViewById(R.id.switch_presence);
        presenceSwitch.setChecked(PresenceManager.isEnabled(this));
        presenceSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                onPresenceToggle(isChecked);
            }
        });

        final android.content.SharedPreferences voicePrefs = getSharedPreferences("atlas_voice_prefs", MODE_PRIVATE);
        Switch listenWhileSpeakingSwitch = (Switch) findViewById(R.id.switch_listen_while_speaking);
        listenWhileSpeakingSwitch.setChecked(voicePrefs.getBoolean("listen_while_speaking", true));
        listenWhileSpeakingSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                voicePrefs.edit().putBoolean("listen_while_speaking", isChecked).apply();
            }
        });
        confirmBeforeCallSwitch = (Switch) findViewById(R.id.switch_confirm_before_call);
        confirmBeforeCallSwitch.setChecked(CallConfirmationSettings.isConfirmBeforeCallEnabled(this));
        confirmBeforeCallSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                CallConfirmationSettings.setConfirmBeforeCallEnabled(SettingsActivity.this, isChecked);
            }
        });

        loadStoredValues();

        Button saveButton = (Button) findViewById(R.id.button_save_settings);
        ViewAnimUtils.applyPressFeedback(saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });
    }

    private void wireRow(int rowId, final Class<?> targetActivity) {
        View row = findViewById(rowId);
        ViewAnimUtils.applyPressFeedback(row);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsActivity.this, targetActivity));
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        int visibility = SecretUnlockManager.shouldShowInSettings(this) ? View.VISIBLE : View.GONE;
        findViewById(R.id.row_lore).setVisibility(visibility);
        findViewById(R.id.divider_lore).setVisibility(visibility);

        boolean presenceActuallyOn = PresenceManager.isEnabled(this) && PresenceManager.canDrawOverlays(this);
        presenceSwitch.setChecked(presenceActuallyOn);

        TextView currentMode = (TextView) findViewById(R.id.label_mode_current);
        currentMode.setText(ModeManager.isChatMode(this)
            ? R.string.mode_chat_title : R.string.mode_voice_title);

        TextView currentLayout = (TextView) findViewById(R.id.label_presence_layout_current);
        int selectedLayout = PresenceManager.getLayout(this);
        if (selectedLayout == PresenceManager.LAYOUT_ORB) {
            currentLayout.setText(R.string.presence_layout_orb_title);
        } else if (selectedLayout == PresenceManager.LAYOUT_NUCLEUS) {
            currentLayout.setText(R.string.presence_layout_nucleus_title);
        } else if (selectedLayout == PresenceManager.LAYOUT_CARD) {
            currentLayout.setText(R.string.presence_layout_card_title);
        } else {
            currentLayout.setText(R.string.presence_layout_glass_title);
        }
    }

    private void loadStoredValues() {
        android.content.SharedPreferences voicePrefs = getSharedPreferences(PREFS_VOICE, MODE_PRIVATE);
        rateSeekBar.setProgress(voicePrefs.getInt(KEY_RATE, 10));
        pitchSeekBar.setProgress(voicePrefs.getInt(KEY_PITCH, 10));
    }

    private void onNotificationToggle(boolean enabled) {
        if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_CODE_NOTIFICATIONS);
                return;
            }
        }
        ReminderScheduler.setDailyReminderEnabled(this, enabled);
    }

    private void onPresenceToggle(boolean enabled) {
        if (!enabled) {
            PresenceManager.setEnabled(this, false);
            return;
        }

        if (PresenceManager.canDrawOverlays(this)) {
            PresenceManager.setEnabled(this, true);
            return;
        }

        Toast.makeText(this, R.string.presence_permission_rationale, Toast.LENGTH_LONG).show();
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_OVERLAY_PERMISSION) {
            boolean granted = PresenceManager.canDrawOverlays(this);
            presenceSwitch.setChecked(granted);
            PresenceManager.setEnabled(this, granted);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_NOTIFICATIONS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            notificationSwitch.setChecked(granted);
            ReminderScheduler.setDailyReminderEnabled(this, granted);
        }
    }

    private void saveSettings() {
        android.content.SharedPreferences voicePrefs = getSharedPreferences(PREFS_VOICE, MODE_PRIVATE);
        voicePrefs.edit()
            .putInt(KEY_RATE, rateSeekBar.getProgress())
            .putInt(KEY_PITCH, pitchSeekBar.getProgress())
            .apply();

        Toast.makeText(this, R.string.btn_save, Toast.LENGTH_SHORT).show();
        finish();
    }
}
