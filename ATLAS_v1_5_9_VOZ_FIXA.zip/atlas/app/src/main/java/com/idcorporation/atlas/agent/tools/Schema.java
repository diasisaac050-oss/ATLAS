package com.idcorporation.atlas.agent.tools;

import org.json.JSONArray;
import org.json.JSONObject;

/** Tiny builder for the JSON-schema "parameters" object of a tool. */
public final class Schema {

    private final JSONObject properties = new JSONObject();
    private final JSONArray required = new JSONArray();

    private Schema() {
    }

    public static Schema obj() {
        return new Schema();
    }

    public Schema str(String name, String description, boolean isRequired) {
        try {
            JSONObject p = new JSONObject();
            p.put("type", "string");
            p.put("description", description);
            properties.put(name, p);
            if (isRequired) {
                required.put(name);
            }
        } catch (Exception ignored) {
            // Plain strings cannot fail here.
        }
        return this;
    }

    public JSONObject build() {
        try {
            JSONObject o = new JSONObject();
            o.put("type", "object");
            o.put("properties", properties);
            o.put("required", required);
            return o;
        } catch (Exception e) {
            return new JSONObject();
        }
    }
}
