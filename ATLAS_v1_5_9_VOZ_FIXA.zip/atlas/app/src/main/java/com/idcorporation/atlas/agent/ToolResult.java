package com.idcorporation.atlas.agent;

import com.idcorporation.atlas.agent.panel.PanelData;
import com.idcorporation.atlas.commands.ConfirmAction;

import org.json.JSONObject;

/**
 * What a tool reports back to the agent loop. The status is deliberately
 * granular so the model (and the code) can tell "Android accepted the
 * launch" apart from "I confirmed the result":
 *
 *   OK                - the tool did the work and verified what it can verify
 *   REPORTED          - an existing app handler answered; the message says what happened
 *   PARTIAL           - something real happened but not the whole goal
 *   NEEDS_INFO        - cannot continue without a missing detail / a choice
 *   NEEDS_CONFIRMATION- a sensitive action is ready, waiting for the user's Yes
 *   BLOCKED           - refused by a safety rule
 *   FAILED            - did not work
 */
public final class ToolResult {

    public static final String OK = "ok";
    public static final String REPORTED = "reported";
    public static final String PARTIAL = "partial";
    public static final String NEEDS_INFO = "needs_info";
    public static final String NEEDS_CONFIRMATION = "needs_confirmation";
    public static final String BLOCKED = "blocked";
    public static final String FAILED = "failed";

    public final String status;
    public final String message;
    public final JSONObject data;
    public PanelData panel;
    public String confirmPrompt;
    public ConfirmAction confirmAction;

    public ToolResult(String status, String message, JSONObject data) {
        this.status = status;
        this.message = message == null ? "" : message;
        this.data = data;
    }

    public static ToolResult ok(String message) {
        return new ToolResult(OK, message, null);
    }

    public static ToolResult ok(String message, JSONObject data) {
        return new ToolResult(OK, message, data);
    }

    public static ToolResult reported(String message) {
        return new ToolResult(REPORTED, message, null);
    }

    public static ToolResult partial(String message) {
        return new ToolResult(PARTIAL, message, null);
    }

    public static ToolResult needsInfo(String message, JSONObject data) {
        return new ToolResult(NEEDS_INFO, message, data);
    }

    public static ToolResult failed(String message) {
        return new ToolResult(FAILED, message, null);
    }

    public static ToolResult blocked(String message) {
        return new ToolResult(BLOCKED, message, null);
    }

    public static ToolResult needsConfirmation(String message, String prompt, ConfirmAction action) {
        ToolResult r = new ToolResult(NEEDS_CONFIRMATION, message, null);
        r.confirmPrompt = prompt;
        r.confirmAction = action;
        return r;
    }

    public ToolResult withPanel(PanelData panelData) {
        this.panel = panelData;
        return this;
    }

    /** True when the tool actually changed something or showed real data. */
    public boolean isSuccessLike() {
        return OK.equals(status) || REPORTED.equals(status) || PARTIAL.equals(status);
    }

    /** The JSON the model sees as the tool message. Never contains phone numbers or raw private ids. */
    public String toModelJson(boolean untrusted) {
        try {
            JSONObject o = new JSONObject();
            o.put("status", status);
            o.put("message", message);
            if (data != null) {
                o.put("data", data);
            }
            if (panel != null) {
                o.put("panel_shown_to_user", true);
            }
            if (untrusted) {
                o.put("untrusted_content", true);
            }
            return o.toString();
        } catch (Exception e) {
            return "{\"status\":\"failed\",\"message\":\"result encoding error\"}";
        }
    }
}
