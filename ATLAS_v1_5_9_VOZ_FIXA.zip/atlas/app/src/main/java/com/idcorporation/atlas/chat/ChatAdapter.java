package com.idcorporation.atlas.chat;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.format.DateFormat;
import android.text.style.ForegroundColorSpan;
import android.view.HapticFeedbackConstants;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;

import java.util.ArrayList;
import java.util.Date;

/**
 * Bubbles for the Chat mode. New bubbles glide in from their own side
 * with a small overshoot, ATLAS replies "write themselves" letter by
 * letter (the bubble is already full size, so the text never jumps
 * around), and while ATLAS is working a bouncing-dots bubble sits at
 * the end of the list.
 */
public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface ActionListener {
        void onConfirm(ChatMessage message, boolean accepted);
        void onRetry(ChatMessage message);
    }

    private static final int TYPE_USER = 0;
    private static final int TYPE_ATLAS = 1;
    private static final int TYPE_TYPING = 2;

    private final Context context;
    private final LayoutInflater inflater;
    private final ArrayList<ChatMessage> items = new ArrayList<ChatMessage>();
    private boolean typing = false;
    private int accent;
    private ActionListener actionListener;

    public ChatAdapter(Context context, int accent) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.accent = accent;
    }

    public void setActionListener(ActionListener listener) {
        this.actionListener = listener;
    }

    public void setAccent(int newAccent) {
        if (newAccent != accent) {
            accent = newAccent;
            notifyDataSetChanged();
        }
    }

    public void setAll(ArrayList<ChatMessage> messages, boolean showTyping) {
        items.clear();
        items.addAll(messages);
        typing = showTyping;
        notifyDataSetChanged();
    }

    public int getMessageCount() {
        return items.size();
    }

    public boolean isTyping() {
        return typing;
    }

    public void addMessage(ChatMessage message) {
        int index = items.size();
        items.add(message);
        notifyItemInserted(index);
    }

    public void removeMessage(ChatMessage message) {
        int index = items.indexOf(message);
        if (index >= 0) {
            items.remove(index);
            notifyItemRemoved(index);
        }
    }

    public void notifyMessageChanged(ChatMessage message) {
        int index = items.indexOf(message);
        if (index >= 0) {
            notifyItemChanged(index);
        }
    }

    public void setTyping(boolean value) {
        if (typing == value) {
            return;
        }
        typing = value;
        if (value) {
            notifyItemInserted(items.size());
        } else {
            notifyItemRemoved(items.size());
        }
    }

    public void clear() {
        items.clear();
        typing = false;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return items.size() + (typing ? 1 : 0);
    }

    @Override
    public int getItemViewType(int position) {
        if (position >= items.size()) {
            return TYPE_TYPING;
        }
        return items.get(position).isUser() ? TYPE_USER : TYPE_ATLAS;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_USER) {
            return new UserHolder(inflater.inflate(R.layout.item_chat_user, parent, false));
        }
        if (viewType == TYPE_ATLAS) {
            return new AtlasHolder(inflater.inflate(R.layout.item_chat_atlas, parent, false));
        }
        return new TypingHolder(inflater.inflate(R.layout.item_chat_typing, parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        resetItemView(holder.itemView);
        if (holder instanceof UserHolder) {
            bindUser((UserHolder) holder, items.get(position));
        } else if (holder instanceof AtlasHolder) {
            bindAtlas((AtlasHolder) holder, items.get(position));
        } else {
            bindTyping((TypingHolder) holder);
        }
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);
        holder.itemView.animate().cancel();
        if (holder instanceof AtlasHolder) {
            stopReveal((AtlasHolder) holder);
        }
    }

    // -----------------------------------------------------------------
    // Binding
    // -----------------------------------------------------------------

    private void bindUser(UserHolder holder, final ChatMessage message) {
        holder.bubble.setBackground(ChatStyle.userBubble(context, accent));
        int textColor = ChatStyle.readableOn(accent);
        holder.text.setTextColor(textColor);
        holder.time.setTextColor(textColor);
        boolean hasText = message.getText() != null && message.getText().length() > 0;
        holder.text.setVisibility(hasText ? View.VISIBLE : View.GONE);
        holder.text.setText(message.getText());
        holder.time.setText(formatTime(message.getTimestamp()));
        attachCopy(holder.bubble, message.getText());

        if (message.getImageUri() != null) {
            holder.image.setVisibility(View.VISIBLE);
            // setImageURI() decodes at full resolution - a large source
            // photo can crash the canvas when it tries to draw ("trying
            // to draw too large bitmap"). Downsample first, same as the
            // compose-box preview.
            android.graphics.Bitmap thumb = com.idcorporation.atlas.utils.ImageUtils
                .decodeThumbnail(context, message.getImageUri());
            if (thumb != null) {
                holder.image.setImageBitmap(thumb);
            } else {
                holder.image.setImageDrawable(null);
            }
        } else {
            holder.image.setVisibility(View.GONE);
            holder.image.setImageDrawable(null);
        }
        if (message.shouldAnimateEntrance()) {
            message.setAnimateEntrance(false);
            playEntrance(holder.itemView, true);
        }
    }

    private void bindAtlas(final AtlasHolder holder, final ChatMessage message) {
        stopReveal(holder);
        holder.boundMessage = message;
        boolean isError = message.getKind() == ChatMessage.KIND_ERROR;
        holder.bubble.setBackground(ChatStyle.atlasBubble(context, accent, isError));
        holder.avatar.setAccent(accent);
        holder.text.setTextColor(isError ? 0xFFFFB4B4 : ChatStyle.TEXT_PRIMARY);
        holder.time.setTextColor(ChatStyle.TEXT_SECONDARY);
        holder.time.setText(formatTime(message.getTimestamp()));
        attachCopy(holder.bubble, message.getText());

        boolean showConfirm = message.getKind() == ChatMessage.KIND_CONFIRM
            && message.getConfirmState() == ChatMessage.CONFIRM_PENDING;
        holder.confirmRow.setVisibility(showConfirm ? View.VISIBLE : View.GONE);
        if (showConfirm) {
            styleConfirmButtons(holder);
            holder.confirmYes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (actionListener != null) {
                        actionListener.onConfirm(message, true);
                    }
                }
            });
            holder.confirmNo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (actionListener != null) {
                        actionListener.onConfirm(message, false);
                    }
                }
            });
        }

        if (isError && message.getRetryText() != null) {
            holder.bubble.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (actionListener != null) {
                        actionListener.onRetry(message);
                    }
                }
            });
        } else {
            holder.bubble.setOnClickListener(null);
            holder.bubble.setClickable(false);
        }

        if (message.shouldAnimateReveal()) {
            startReveal(holder, message);
        } else {
            holder.text.setText(message.getText());
        }
        if (message.shouldAnimateEntrance()) {
            message.setAnimateEntrance(false);
            playEntrance(holder.itemView, false);
        }
    }

    private void bindTyping(TypingHolder holder) {
        holder.bubble.setBackground(ChatStyle.atlasBubble(context, accent, false));
        holder.avatar.setAccent(accent);
        holder.avatar.setMode(ChatOrbView.MODE_THINKING);
        holder.dots.setAccent(accent);
        playEntrance(holder.itemView, false);
    }

    private void styleConfirmButtons(AtlasHolder holder) {
        holder.confirmYes.setBackground(ChatStyle.pill(context, accent, accent, 0f, 18f));
        holder.confirmYes.setTextColor(ChatStyle.readableOn(accent));
        holder.confirmNo.setBackground(ChatStyle.pill(context, 0x00000000,
            ChatStyle.withAlpha(accent, 0xAA), 1.2f, 18f));
        holder.confirmNo.setTextColor(ChatStyle.TEXT_PRIMARY);
    }

    // -----------------------------------------------------------------
    // Animations
    // -----------------------------------------------------------------

    private void resetItemView(View view) {
        view.animate().cancel();
        view.setAlpha(1f);
        view.setTranslationX(0f);
        view.setTranslationY(0f);
        view.setScaleX(1f);
        view.setScaleY(1f);
    }

    private void playEntrance(View view, boolean fromRight) {
        float screenWidth = context.getResources().getDisplayMetrics().widthPixels;
        view.setPivotX(fromRight ? screenWidth : 0f);
        view.setPivotY(ChatStyle.dp(context, 28));
        view.setAlpha(0f);
        view.setTranslationX(ChatStyle.dp(context, fromRight ? 30 : -30));
        view.setTranslationY(ChatStyle.dp(context, 18));
        view.setScaleX(0.88f);
        view.setScaleY(0.88f);
        view.animate()
            .alpha(1f)
            .translationX(0f)
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(420L)
            .setInterpolator(new OvershootInterpolator(1.15f))
            .start();
    }

    private void startReveal(final AtlasHolder holder, final ChatMessage message) {
        final String full = message.getText();
        final int total = full.length();
        if (total == 0) {
            message.setAnimateReveal(false);
            return;
        }
        long duration = Math.min(2600L, Math.max(450L, total * 16L));
        final int step = (int) Math.max(1L, (total * 16L) / duration);
        holder.revealIndex = 0;
        renderRevealed(holder.text, full, 0);
        holder.revealRunnable = new Runnable() {
            @Override
            public void run() {
                holder.revealIndex = Math.min(total, holder.revealIndex + step);
                renderRevealed(holder.text, full, holder.revealIndex);
                if (holder.revealIndex >= total) {
                    holder.revealRunnable = null;
                    message.setAnimateReveal(false);
                    return;
                }
                holder.text.postDelayed(this, 16L);
            }
        };
        holder.text.postDelayed(holder.revealRunnable, 120L);
    }

    private void stopReveal(AtlasHolder holder) {
        if (holder.revealRunnable != null) {
            holder.text.removeCallbacks(holder.revealRunnable);
            holder.revealRunnable = null;
            if (holder.boundMessage != null) {
                holder.boundMessage.setAnimateReveal(false);
            }
        }
    }

    /** Unrevealed letters are painted fully transparent, so line breaks never change while typing. */
    private void renderRevealed(TextView target, String full, int upTo) {
        if (upTo >= full.length()) {
            target.setText(full);
            return;
        }
        SpannableString spannable = new SpannableString(full);
        spannable.setSpan(new ForegroundColorSpan(0x00000000), upTo, full.length(),
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        target.setText(spannable);
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    private String formatTime(long timestamp) {
        return DateFormat.getTimeFormat(context).format(new Date(timestamp));
    }

    private void attachCopy(View bubble, final String text) {
        bubble.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                ClipboardManager clipboard =
                    (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard == null) {
                    return false;
                }
                clipboard.setPrimaryClip(ClipData.newPlainText("ATLAS", text));
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                Toast.makeText(context, R.string.chat_copied, Toast.LENGTH_SHORT).show();
                return true;
            }
        });
    }

    // -----------------------------------------------------------------
    // Holders
    // -----------------------------------------------------------------

    private static class UserHolder extends RecyclerView.ViewHolder {
        final LinearLayout bubble;
        final ImageView image;
        final TextView text;
        final TextView time;

        UserHolder(View itemView) {
            super(itemView);
            bubble = (LinearLayout) itemView.findViewById(R.id.chat_bubble);
            image = (ImageView) itemView.findViewById(R.id.chat_image);
            text = (TextView) itemView.findViewById(R.id.chat_text);
            time = (TextView) itemView.findViewById(R.id.chat_time);
        }
    }

    private static class AtlasHolder extends RecyclerView.ViewHolder {
        final ChatOrbView avatar;
        final LinearLayout bubble;
        final TextView text;
        final TextView time;
        final LinearLayout confirmRow;
        final TextView confirmYes;
        final TextView confirmNo;
        Runnable revealRunnable;
        int revealIndex;
        ChatMessage boundMessage;

        AtlasHolder(View itemView) {
            super(itemView);
            avatar = (ChatOrbView) itemView.findViewById(R.id.chat_avatar);
            bubble = (LinearLayout) itemView.findViewById(R.id.chat_bubble);
            text = (TextView) itemView.findViewById(R.id.chat_text);
            time = (TextView) itemView.findViewById(R.id.chat_time);
            confirmRow = (LinearLayout) itemView.findViewById(R.id.chat_confirm_row);
            confirmYes = (TextView) itemView.findViewById(R.id.chat_confirm_yes);
            confirmNo = (TextView) itemView.findViewById(R.id.chat_confirm_no);
        }
    }

    private static class TypingHolder extends RecyclerView.ViewHolder {
        final ChatOrbView avatar;
        final View bubble;
        final TypingDotsView dots;

        TypingHolder(View itemView) {
            super(itemView);
            avatar = (ChatOrbView) itemView.findViewById(R.id.chat_avatar);
            bubble = itemView.findViewById(R.id.chat_bubble);
            dots = (TypingDotsView) itemView.findViewById(R.id.chat_dots);
        }
    }
}
