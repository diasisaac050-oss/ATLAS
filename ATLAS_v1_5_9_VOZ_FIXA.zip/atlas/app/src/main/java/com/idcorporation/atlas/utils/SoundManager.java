package com.idcorporation.atlas.utils;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import com.idcorporation.atlas.R;

/**
 * Short UI sound effects. Deliberately NOT wired into every tap in the
 * app - only into a handful of meaningful moments (starting to listen,
 * confirming an action, unlocking a theme, marking the calendar,
 * birthday congratulations) so it enhances rather than annoys.
 * SoundPool is used instead of MediaPlayer since these are short
 * one-shot effects that can overlap. The long looping alarm tone is
 * handled separately by AlarmSoundService with MediaPlayer, since
 * SoundPool is not meant for multi-minute looping playback.
 */
public class SoundManager {

    private static SoundPool soundPool;
    private static int soundIdScifiClick = 0;
    private static int soundIdEventMarked = 0;
    private static int soundIdBirthday = 0;
    private static boolean scifiClickLoaded = false;
    private static boolean eventMarkedLoaded = false;
    private static boolean birthdayLoaded = false;
    private static int soundIdPresenceOpen = 0;
    private static int soundIdPresenceListen = 0;
    private static int soundIdPresenceClose = 0;
    private static boolean presenceOpenLoaded = false;
    private static boolean presenceListenLoaded = false;
    private static boolean presenceCloseLoaded = false;

    public static void initialize(Context context) {
        if (soundPool != null) {
            return;
        }
        AudioAttributes attributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();

        soundPool = new SoundPool.Builder()
            .setMaxStreams(3)
            .setAudioAttributes(attributes)
            .build();

        soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
            @Override
            public void onLoadComplete(SoundPool pool, int sampleId, int status) {
                if (status != 0) {
                    return;
                }
                if (sampleId == soundIdScifiClick) {
                    scifiClickLoaded = true;
                } else if (sampleId == soundIdEventMarked) {
                    eventMarkedLoaded = true;
                } else if (sampleId == soundIdBirthday) {
                    birthdayLoaded = true;
                } else if (sampleId == soundIdPresenceOpen) {
                    presenceOpenLoaded = true;
                } else if (sampleId == soundIdPresenceListen) {
                    presenceListenLoaded = true;
                } else if (sampleId == soundIdPresenceClose) {
                    presenceCloseLoaded = true;
                }
            }
        });

        Context appContext = context.getApplicationContext();
        soundIdScifiClick = soundPool.load(appContext, R.raw.sound_scifi_click, 1);
        soundIdEventMarked = soundPool.load(appContext, R.raw.sfx_event_marked, 1);
        soundIdBirthday = soundPool.load(appContext, R.raw.sfx_birthday, 1);
        soundIdPresenceOpen = soundPool.load(appContext, R.raw.presence_open, 1);
        soundIdPresenceListen = soundPool.load(appContext, R.raw.presence_listen, 1);
        soundIdPresenceClose = soundPool.load(appContext, R.raw.presence_close, 1);
    }

    /** Futuristic click - used for standout ATLAS moments (mic activation, confirm, unlock). */
    public static void playScifiClick(Context context) {
        initialize(context);
        if (soundPool != null && scifiClickLoaded) {
            soundPool.play(soundIdScifiClick, 0.6f, 0.6f, 0, 0, 1f);
        }
    }

    /** Short confirmation blip played whenever ATLAS marks a reminder or birthday on the calendar. */
    public static void playEventMarked(Context context) {
        initialize(context);
        if (soundPool != null && eventMarkedLoaded) {
            soundPool.play(soundIdEventMarked, 0.6f, 0.6f, 0, 0, 1f);
        }
    }

    /** Celebratory chime used for the in-app birthday congratulations moment. */
    public static void playBirthday(Context context) {
        initialize(context);
        if (soundPool != null && birthdayLoaded) {
            soundPool.play(soundIdBirthday, 0.8f, 0.8f, 0, 0, 1f);
        }
    }

    /** Whoosh + glass chime played when the Presence bubble drops in. */
    public static void playPresenceOpen(Context context) {
        initialize(context);
        if (soundPool != null && presenceOpenLoaded) {
            soundPool.play(soundIdPresenceOpen, 0.7f, 0.7f, 0, 0, 1f);
        }
    }

    /** Soft rising blip played when the Presence mic is live and ready. */
    public static void playPresenceListen(Context context) {
        initialize(context);
        if (soundPool != null && presenceListenLoaded) {
            soundPool.play(soundIdPresenceListen, 0.55f, 0.55f, 0, 0, 1f);
        }
    }

    /** Descending sweep played when the Presence bubble retracts. */
    public static void playPresenceClose(Context context) {
        initialize(context);
        if (soundPool != null && presenceCloseLoaded) {
            soundPool.play(soundIdPresenceClose, 0.55f, 0.55f, 0, 0, 1f);
        }
    }

    public static void release() {
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
            scifiClickLoaded = false;
            eventMarkedLoaded = false;
            birthdayLoaded = false;
            presenceOpenLoaded = false;
            presenceListenLoaded = false;
            presenceCloseLoaded = false;
        }
    }
}
