package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.security.SecurityManager;

/**
 * Third onboarding question: the user's email address.
 */
public class OnboardingEmailActivity extends OnboardingStepActivity {

    private static final int STEP_INDEX = 3;
    private static final int TOTAL_STEPS = 6;

    private EditText emailInput;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_email);

        View backButton = findViewById(R.id.button_step_back);
        ViewGroup dotsContainer = (ViewGroup) findViewById(R.id.container_step_dots);
        View badge = findViewById(R.id.badge_email);
        View title = findViewById(R.id.text_email_question);
        emailInput = (EditText) findViewById(R.id.input_email);
        errorText = (TextView) findViewById(R.id.text_email_error);
        final View continueButton = findViewById(R.id.button_email_continue);

        renderProgressDots(dotsContainer, STEP_INDEX, TOTAL_STEPS);
        animateEntrance(badge, title, null, emailInput, continueButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bounceButton(continueButton);
                attemptContinue();
            }
        });
    }

    private void attemptContinue() {
        String email = emailInput.getText().toString();

        if (!SecurityManager.isValidEmail(email)) {
            showFieldError(errorText, getString(R.string.error_email_invalid));
            return;
        }

        Intent next = buildForwardIntent(OnboardingDetailsActivity.class);
        next.putExtra(OnboardingKeys.EMAIL, email.trim());
        goToNext(next);
    }
}
