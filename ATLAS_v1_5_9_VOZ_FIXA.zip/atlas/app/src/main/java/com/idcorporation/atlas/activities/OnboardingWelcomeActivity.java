package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.idcorporation.atlas.R;

/**
 * Warm first-contact screen shown right after the splash animation,
 * before any question is asked. Replaces the old behaviour of dropping
 * the user straight onto a form full of fields.
 */
public class OnboardingWelcomeActivity extends OnboardingStepActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_welcome);

        View badge = findViewById(R.id.badge_welcome);
        View title = findViewById(R.id.text_welcome_title);
        View message = findViewById(R.id.text_welcome_message);
        final View continueButton = findViewById(R.id.button_welcome_continue);

        animateEntrance(badge, title, message, null, continueButton);

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bounceButton(continueButton);
                Intent next = new Intent(OnboardingWelcomeActivity.this, OnboardingCountryActivity.class);
                goToNext(next);
            }
        });
    }
}
