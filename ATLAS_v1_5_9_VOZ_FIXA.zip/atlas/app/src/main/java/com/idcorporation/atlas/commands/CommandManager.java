package com.idcorporation.atlas.commands;

import android.content.Context;
import android.content.Intent;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.CalendarActivity;
import com.idcorporation.atlas.activities.CompromissosActivity;
import com.idcorporation.atlas.activities.ModesActivity;
import com.idcorporation.atlas.activities.ThemeActivity;
import com.idcorporation.atlas.utils.ModeManager;
import com.idcorporation.atlas.memory.HistoryManager;
import com.idcorporation.atlas.memory.MemoryManager;
import com.idcorporation.atlas.models.CustomCommand;
import com.idcorporation.atlas.utils.AtlasBluetoothManager;
import com.idcorporation.atlas.utils.BrightnessManager;
import com.idcorporation.atlas.utils.Calculator;
import com.idcorporation.atlas.utils.DeviceInfoUtil;
import com.idcorporation.atlas.utils.FlashlightManager;
import com.idcorporation.atlas.utils.RestartManager;
import com.idcorporation.atlas.utils.VolumeManager;

import java.util.Random;

/**
 * Classifies spoken text into: system command, app command, information
 * request, automation command, custom command or AI question, and
 * executes the ones that do not need the AI API. This keeps simple
 * device commands off the network entirely. Every spoken reply comes
 * from a string resource so it follows the user's chosen app language.
 */
public class CommandManager {

    private final Context context;
    private final AppCommandHandler appCommandHandler;
    private final SystemCommandHandler systemCommandHandler;
    private final CustomCommandManager customCommandManager;
    private final MemoryManager memoryManager;
    private final HistoryManager historyManager;
    private final FlashlightManager flashlightManager;
    private final VolumeManager volumeManager;
    private final BrightnessManager brightnessManager;
    private final AtlasBluetoothManager bluetoothManager;
    private final RestartManager restartManager;
    private final ReminderAlarmHandler reminderAlarmHandler;
    private final ContactActionHandler contactActionHandler;
    private final ScreenshotCommandHandler screenshotCommandHandler;

    public CommandManager(Context context) {
        this.context = context.getApplicationContext();
        this.appCommandHandler = new AppCommandHandler();
        this.systemCommandHandler = new SystemCommandHandler();
        this.customCommandManager = new CustomCommandManager(this.context);
        this.memoryManager = new MemoryManager(this.context);
        this.historyManager = new HistoryManager(this.context);
        this.flashlightManager = new FlashlightManager(this.context);
        this.volumeManager = new VolumeManager(this.context);
        this.brightnessManager = new BrightnessManager(this.context);
        this.bluetoothManager = new AtlasBluetoothManager(this.context);
        this.restartManager = new RestartManager();
        this.reminderAlarmHandler = new ReminderAlarmHandler(this.context);
        this.contactActionHandler = new ContactActionHandler(this.context);
        this.screenshotCommandHandler = new ScreenshotCommandHandler(this.context);
    }

    public CommandOutcome process(String rawText) {
        String text = rawText.trim();
        String lowerText = text.toLowerCase();

        CustomCommand customCommand = customCommandManager.findByPhrase(lowerText);
        if (customCommand != null) {
            return runCustomCommand(customCommand);
        }

        CommandOutcome reminderOutcome = reminderAlarmHandler.handle(text, lowerText);
        if (reminderOutcome != null) {
            return reminderOutcome;
        }
        CommandOutcome contactOutcome = contactActionHandler.handle(text, lowerText);
        if (contactOutcome != null) {
            return contactOutcome;
        }
        CommandOutcome screenshotOutcome = screenshotCommandHandler.handle(text, lowerText);
        if (screenshotOutcome != null) {
            return screenshotOutcome;
        }
        if (CommandParser.isCalendarOpenCommand(lowerText)) {
            Intent openCalendar = new Intent(context, CalendarActivity.class);
            openCalendar.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(openCalendar);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_calendar));
        }
        if (CommandParser.isOpenCompromissosCommand(lowerText)) {
            Intent openCompromissos = new Intent(context, CompromissosActivity.class);
            openCompromissos.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(openCompromissos);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_compromissos));
        }
        // ATLAS GENESYS: full control commands - open Themes / open Modes / switch mode directly.
        int modeSwitchTarget = CommandParser.detectModeSwitchTarget(lowerText);
        if (modeSwitchTarget == ModeManager.MODE_CHAT || modeSwitchTarget == ModeManager.MODE_VOICE) {
            ModeManager.setMode(context, modeSwitchTarget);
            int respKey = modeSwitchTarget == ModeManager.MODE_CHAT
                ? R.string.resp_mode_switched_chat : R.string.resp_mode_switched_voice;
            return CommandOutcome.handled(context.getString(respKey));
        }
        if (CommandParser.isOpenThemesCommand(lowerText)) {
            Intent openThemes = new Intent(context, ThemeActivity.class);
            openThemes.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(openThemes);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_themes));
        }
        if (CommandParser.isOpenModesCommand(lowerText)) {
            Intent openModes = new Intent(context, ModesActivity.class);
            openModes.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(openModes);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_modes));
        }
        if (CommandParser.isOpenAppCommand(lowerText)) {
            return handleOpenAppCommand(lowerText);
        }
        if (CommandParser.isSearchCommand(lowerText)) {
            return handleSearchCommand(lowerText);
        }
        if (CommandParser.isTimeRequest(lowerText)) {
            String spoken = context.getString(R.string.resp_time_is, DeviceInfoUtil.getCurrentTimeSpoken(context));
            return CommandOutcome.handled(spoken);
        }
        if (CommandParser.isDateRequest(lowerText)) {
            String spoken = context.getString(R.string.resp_date_is, DeviceInfoUtil.getCurrentDateSpoken(context));
            return CommandOutcome.handled(spoken);
        }
        if (CommandParser.isBatteryRequest(lowerText)) {
            return handleBatteryRequest();
        }
        if (CommandParser.isStorageRequest(lowerText)) {
            String spoken = context.getString(R.string.resp_storage_free, DeviceInfoUtil.getAvailableStorageFormatted());
            return CommandOutcome.handled(spoken);
        }
        if (CommandParser.isCalculationCommand(lowerText)) {
            CommandOutcome mathOutcome = handleCalculation(lowerText);
            if (mathOutcome != null) {
                return mathOutcome;
            }
        }
        if (CommandParser.isFlashlightOnCommand(lowerText)) {
            return handleFlashlight(true);
        }
        if (CommandParser.isFlashlightOffCommand(lowerText)) {
            return handleFlashlight(false);
        }
        if (CommandParser.isVolumeUpCommand(lowerText)) {
            volumeManager.increaseVolume();
            return CommandOutcome.handled(context.getString(R.string.resp_volume_up));
        }
        if (CommandParser.isVolumeDownCommand(lowerText)) {
            volumeManager.decreaseVolume();
            return CommandOutcome.handled(context.getString(R.string.resp_volume_down));
        }
        if (CommandParser.isMuteCommand(lowerText)) {
            volumeManager.mute();
            return CommandOutcome.handled(context.getString(R.string.resp_volume_muted));
        }
        // ATLAS GENESYS: brightness, Bluetooth and restart - must run before the
        // generic "mentions bluetooth" -> open settings fallback further down.
        if (CommandParser.isBrightnessUpCommand(lowerText)) {
            return handleBrightness(true);
        }
        if (CommandParser.isBrightnessDownCommand(lowerText)) {
            return handleBrightness(false);
        }
        if (CommandParser.isBluetoothOnCommand(lowerText)) {
            return handleBluetoothOn();
        }
        if (CommandParser.isRestartCommand(lowerText)) {
            return handleRestart();
        }
        if (CommandParser.isSetAlarmCommand(lowerText)) {
            systemCommandHandler.openSetAlarm(context);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_alarm));
        }
        if (CommandParser.isJokeCommand(lowerText)) {
            return handleJoke();
        }
        if (CommandParser.isMemoryForgetAllCommand(lowerText)) {
            memoryManager.deleteAllMemories();
            return CommandOutcome.handled(context.getString(R.string.resp_memory_cleared));
        }
        if (CommandParser.isMemoryQuestion(lowerText)) {
            return handleMemoryQuestion(lowerText);
        }
        if (CommandParser.isMemorySaveCommand(lowerText)) {
            return handleMemorySave(text, lowerText);
        }
        if (lowerText.contains("settings") || lowerText.contains("configurac") || lowerText.contains("ajustes")
                || lowerText.contains("impostazioni")) {
            systemCommandHandler.openSettings(context);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_settings));
        }
        if (lowerText.contains("wifi") || lowerText.contains("wi-fi")) {
            systemCommandHandler.openWifiSettings(context);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_wifi));
        }
        if (lowerText.contains("bluetooth")) {
            systemCommandHandler.openBluetoothSettings(context);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_bluetooth));
        }

        if (CommandParser.mentionsReminderOrAlarmIntent(lowerText)) {
            return CommandOutcome.handled(context.getString(R.string.resp_reminder_alarm_not_understood));
        }

        // Nothing local matched: treat as a conversational question for the AI.
        return CommandOutcome.forwardToAI();
    }

    private CommandOutcome runCustomCommand(final CustomCommand command) {
        executeCustomAction(command);
        return CommandOutcome.handled(context.getString(R.string.resp_running_command, command.getPhrase()));
    }

    private void executeCustomAction(CustomCommand command) {
        String type = command.getActionType();
        String value = command.getActionValue();
        if (CustomCommand.ACTION_OPEN_APP.equals(type)) {
            appCommandHandler.openAppByPackage(context, value);
        } else if (CustomCommand.ACTION_OPEN_URL.equals(type)) {
            appCommandHandler.openUrl(context, value);
        } else if (CustomCommand.ACTION_OPEN_SETTING.equals(type)) {
            if ("wifi".equals(value)) {
                systemCommandHandler.openWifiSettings(context);
            } else if ("bluetooth".equals(value)) {
                systemCommandHandler.openBluetoothSettings(context);
            } else {
                systemCommandHandler.openSettings(context);
            }
        }
    }

    private CommandOutcome handleBatteryRequest() {
        int percent = DeviceInfoUtil.getBatteryPercent(context);
        boolean charging = DeviceInfoUtil.isCharging(context);
        String spoken = charging
            ? context.getString(R.string.resp_battery_charging, percent)
            : context.getString(R.string.resp_battery_normal, percent);
        return CommandOutcome.handled(spoken);
    }

    private CommandOutcome handleCalculation(String lowerText) {
        String mathResult = Calculator.tryCalculate(lowerText);
        if (mathResult == null) {
            return null;
        }
        if ("DIVIDE_BY_ZERO".equals(mathResult)) {
            return CommandOutcome.handled(context.getString(R.string.resp_divide_by_zero));
        }
        return CommandOutcome.handled(context.getString(R.string.resp_math_result, mathResult));
    }

    private CommandOutcome handleFlashlight(boolean turnOn) {
        boolean success = flashlightManager.setTorchEnabled(turnOn);
        if (!success) {
            return CommandOutcome.handled(context.getString(R.string.resp_flashlight_unavailable));
        }
        int stringRes = turnOn ? R.string.resp_flashlight_on : R.string.resp_flashlight_off;
        return CommandOutcome.handled(context.getString(stringRes));
    }

    private CommandOutcome handleBrightness(boolean increase) {
        if (!brightnessManager.canAdjust()) {
            // First ask, then send the user to the one-time permission screen.
            brightnessManager.requestPermission();
            return CommandOutcome.handled(context.getString(R.string.resp_brightness_permission_needed));
        }
        boolean success = increase ? brightnessManager.increase() : brightnessManager.decrease();
        if (!success) {
            return CommandOutcome.handled(context.getString(R.string.resp_brightness_unavailable));
        }
        int stringRes = increase ? R.string.resp_brightness_up : R.string.resp_brightness_down;
        return CommandOutcome.handled(context.getString(stringRes));
    }

    private CommandOutcome handleBluetoothOn() {
        if (!bluetoothManager.isSupported()) {
            return CommandOutcome.handled(context.getString(R.string.resp_bluetooth_unavailable));
        }
        boolean success = bluetoothManager.enable();
        if (!success) {
            // No BLUETOOTH_CONNECT permission or the OEM blocked it silently -
            // fall back to the settings screen so the user can flip it themselves.
            systemCommandHandler.openBluetoothSettings(context);
            return CommandOutcome.handled(context.getString(R.string.resp_bluetooth_needs_settings));
        }
        return CommandOutcome.handled(context.getString(R.string.resp_bluetooth_on));
    }

    private CommandOutcome handleRestart() {
        boolean success = restartManager.tryRestart();
        if (success) {
            return CommandOutcome.handled(context.getString(R.string.resp_restart_started));
        }
        // Honest fallback: stock, non-rooted Android gives no app a way to
        // reboot the device by itself, so ATLAS says so instead of pretending.
        return CommandOutcome.handled(context.getString(R.string.resp_restart_unavailable));
    }

    private CommandOutcome handleJoke() {
        String[] jokes = context.getResources().getStringArray(R.array.jokes_list);
        Random random = new Random();
        String joke = jokes[random.nextInt(jokes.length)];
        return CommandOutcome.handled(joke);
    }

    private CommandOutcome handleOpenAppCommand(String lowerText) {
        String appName = CommandParser.extractAppNameFromOpenCommand(lowerText);

        // ATLAS AGENT CORE: "abre o WhatsApp na conversa da minha princesa" is not "open an app
        // called <that whole sentence>". Anything longer than a plain app name is a goal for the
        // agent, which can combine tools (contact lookup + WhatsApp chat) and verify the result.
        if (appName.trim().split("\\s+").length > 3) {
            return CommandOutcome.forwardToAI();
        }

        if (appName.contains("settings") || appName.contains("configuracoes")
                || appName.contains("configurac\u00f5es") || appName.contains("ajustes")
                || appName.contains("einstellungen") || appName.contains("ustawienia")
                || appName.contains("param\u00e8tres") || appName.contains("impostazioni")) {
            systemCommandHandler.openSettings(context);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_settings));
        }
        if (appName.contains("browser") || appName.contains("navegador") || appName.contains("navigateur")
                || appName.contains("browser") || appName.contains("przegladarka")
                || appName.contains("przegl\u0105darka")) {
            appCommandHandler.openBrowser(context);
            return CommandOutcome.handled(context.getString(R.string.resp_opening_browser));
        }

        String openedLabel = null;
        try {
            openedLabel = appCommandHandler.openAppAndReturnLabel(context, appName);
        } catch (RuntimeException e) {
            openedLabel = null;
        }
        if (openedLabel != null) {
            return CommandOutcome.handled(context.getString(R.string.resp_opening_app, openedLabel));
        }
        // Not a plain installed app: let the agent look for another way instead of giving up here.
        return CommandOutcome.forwardToAI();
    }

    private CommandOutcome handleSearchCommand(String lowerText) {
        String query;
        if (lowerText.startsWith("search for ")) {
            query = CommandParser.extractAfterKeyword(lowerText, "search for ");
        } else if (lowerText.startsWith("search ")) {
            query = CommandParser.extractAfterKeyword(lowerText, "search ");
        } else {
            query = CommandParser.extractAfterKeyword(lowerText, "google ");
        }
        appCommandHandler.openBrowserSearch(context, query);
        return CommandOutcome.handled(context.getString(R.string.resp_searching, query));
    }

    private CommandOutcome handleMemorySave(String originalText, String lowerText) {
        String key;
        String value;
        if (lowerText.contains("my favorite")) {
            int index = lowerText.indexOf("my favorite");
            String remainder = originalText.substring(index);
            String[] parts = remainder.split(" is ", 2);
            if (parts.length == 2) {
                key = parts[0].trim();
                value = parts[1].trim();
            } else {
                key = "note";
                value = originalText;
            }
        } else {
            key = "note";
            value = originalText;
        }
        memoryManager.saveOrUpdate(key, value, "general");
        return CommandOutcome.handled(context.getString(R.string.resp_memory_saved));
    }

    private CommandOutcome handleMemoryQuestion(String lowerText) {
        String keyword = CommandParser.extractAfterKeyword(lowerText, "what is my");
        if (keyword.length() == 0) {
            keyword = CommandParser.extractAfterKeyword(lowerText, "what's my");
        }
        keyword = keyword.trim();
        String value = memoryManager.findMemoryValueByKeyword(keyword);
        if (value == null) {
            return CommandOutcome.handled(context.getString(R.string.resp_memory_not_found));
        }
        return CommandOutcome.handled(context.getString(R.string.resp_memory_value, keyword, value));
    }

    public void logToHistory(String conversationTitle, String role, String message) {
        historyManager.saveMessage(conversationTitle, role, message);
    }

    /**
     * Actually creates the reminder a proactive AI suggestion offered
     * (see AtlasActionTags / ChatSession), once the user has tapped "yes"
     * on the confirmation bubble. Reuses the exact same parsing and
     * scheduling path a direct "me lembra..." command goes through -
     * nothing is duplicated here. Returns false (never throws, never
     * pretends success) when the "when" text the AI captured cannot
     * actually be resolved to a date.
     */
    public boolean createReminderFromSuggestion(String title, String whenText) {
        return reminderAlarmHandler.createFromSuggestion(title, whenText, System.currentTimeMillis());
    }
}
