package com.idcorporation.atlas.presence;

import android.graphics.Canvas;

/**
 * Anything that can paint one frame of the Presence visual. Two drawers
 * exist: PresenceBubblePainter (the glass lens under the notch) and
 * PresenceOrbPainter (the transparent ball that rises from the bottom).
 * PresenceBubbleView owns the timing and just asks the drawer to paint.
 */
public interface PresenceDrawer {

    void draw(Canvas canvas, int width, int height, PresenceBubbleState state);
}
