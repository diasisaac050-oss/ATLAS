package com.idcorporation.atlas.services;

import android.app.Notification;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Toast;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.presence.PresenceOverlayController;
import com.idcorporation.atlas.utils.NotificationHelper;
import com.idcorporation.atlas.utils.SoundManager;

import java.io.OutputStream;
import java.nio.ByteBuffer;

/**
 * Captures exactly one frame of the screen using the MediaProjection token
 * ScreenshotActivity just obtained, saves it to Pictures/ATLAS via
 * MediaStore (works without WRITE_EXTERNAL_STORAGE on modern Android),
 * plays a short confirmation cue and tears everything down. Nothing is
 * kept running after that single frame - this is a one-shot capture, not
 * continuous screen recording.
 */
public class ScreenshotService extends Service {

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    private static final int NOTIFICATION_ID = 7001;
    private static final long CAPTURE_TIMEOUT_MS = 4000L;
    // Gives the compositor time to redraw one frame without the presence
    // bubble after it's hidden, before the virtual display starts mirroring.
    private static final long HIDE_ORB_SETTLE_MS = 80L;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Handler backgroundHandler;
    private Handler mainHandler;
    private boolean finished;
    private boolean overlayWasHidden;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mainHandler = new Handler(Looper.getMainLooper());
        finished = false;

        NotificationHelper.createNotificationChannel(this);
        Notification notification = NotificationHelper.buildScreenshotForegroundNotification(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }

        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        if (resultData == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager projectionManager =
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (projectionManager == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
        if (mediaProjection == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        // Take the presence bubble (if it's up) out of the frame before we
        // mirror the screen, and give the compositor one redraw to catch up.
        PresenceOverlayController.hideForScreenshot();
        overlayWasHidden = true;
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startCapture();
                armSafetyTimeout();
            }
        }, HIDE_ORB_SETTLE_MS);
        return START_NOT_STICKY;
    }

    private void startCapture() {
        WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        int width;
        int height;
        int density;
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            width = metrics.widthPixels;
            height = metrics.heightPixels;
            density = metrics.densityDpi;
        } else {
            width = 1080;
            height = 1920;
            density = 420;
        }

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        backgroundHandler = new Handler(Looper.getMainLooper());

        imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader reader) {
                handleFrame(reader);
            }
        }, backgroundHandler);

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "AtlasScreenshot", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.getSurface(), null, backgroundHandler);
    }

    private void handleFrame(ImageReader reader) {
        if (finished) {
            return;
        }
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) {
                return;
            }
            Bitmap bitmap = imageToBitmap(image);
            boolean saved = saveBitmap(bitmap);
            finished = true;
            notifyResult(saved);
        } catch (RuntimeException e) {
            finished = true;
            notifyResult(false);
        } finally {
            if (image != null) {
                image.close();
            }
            teardownAndStop();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();

        Bitmap bitmap = Bitmap.createBitmap(
            image.getWidth() + rowPadding / pixelStride, image.getHeight(), Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        return Bitmap.createBitmap(bitmap, 0, 0, image.getWidth(), image.getHeight());
    }

    private boolean saveBitmap(Bitmap bitmap) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, "ATLAS_" + System.currentTimeMillis() + ".png");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ATLAS");
        }

        Uri collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Uri itemUri = getContentResolver().insert(collection, values);
        if (itemUri == null) {
            return false;
        }
        OutputStream out = null;
        try {
            out = getContentResolver().openOutputStream(itemUri);
            if (out == null) {
                return false;
            }
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            return true;
        } catch (java.io.IOException e) {
            return false;
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (java.io.IOException e) {
                    // Nothing more to do.
                }
            }
        }
    }

    private void notifyResult(final boolean saved) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                SoundManager.playEventMarked(ScreenshotService.this);
                String title = saved ? getString(R.string.screenshot_saved_title)
                    : getString(R.string.screenshot_permission_title);
                String body = saved ? getString(R.string.screenshot_saved_body)
                    : getString(R.string.screenshot_failed_body);
                NotificationHelper.showNotification(ScreenshotService.this, NOTIFICATION_ID, title, body);
                Toast.makeText(ScreenshotService.this, body, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void armSafetyTimeout() {
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!finished) {
                    finished = true;
                    notifyResult(false);
                    teardownAndStop();
                }
            }
        }, CAPTURE_TIMEOUT_MS);
    }

    private void teardownAndStop() {
        if (overlayWasHidden) {
            overlayWasHidden = false;
            PresenceOverlayController.restoreAfterScreenshot();
        }
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        teardownAndStop();
    }
}
