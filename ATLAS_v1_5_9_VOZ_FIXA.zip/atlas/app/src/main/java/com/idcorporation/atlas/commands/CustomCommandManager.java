package com.idcorporation.atlas.commands;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.idcorporation.atlas.memory.AtlasDatabase;
import com.idcorporation.atlas.models.CustomCommand;
import com.idcorporation.atlas.security.SecurityManager;

import java.util.ArrayList;

/**
 * Stores user-defined "phrase -> action" shortcuts. Only the safe action
 * types defined in CustomCommand (open app, open URL, open a system
 * setting) can ever be stored - there is no path from here to arbitrary
 * code execution.
 */
public class CustomCommandManager {

    private final AtlasDatabase dbHelper;

    public CustomCommandManager(Context context) {
        this.dbHelper = AtlasDatabase.getInstance(context);
    }

    public boolean isSupportedActionType(String actionType) {
        return CustomCommand.ACTION_OPEN_APP.equals(actionType)
            || CustomCommand.ACTION_OPEN_URL.equals(actionType)
            || CustomCommand.ACTION_OPEN_SETTING.equals(actionType);
    }

    public long addCommand(String phrase, String actionType, String actionValue) {
        if (!isSupportedActionType(actionType)) {
            return -1;
        }
        String safePhrase = SecurityManager.sanitizeText(phrase, 100).toLowerCase();
        String safeValue = SecurityManager.sanitizeText(actionValue, 200);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("phrase", safePhrase);
        values.put("action_type", actionType);
        values.put("action_value", safeValue);
        return db.insert(AtlasDatabase.TABLE_CUSTOM_COMMANDS, null, values);
    }

    public ArrayList<CustomCommand> getAllCommands() {
        ArrayList<CustomCommand> results = new ArrayList<CustomCommand>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(AtlasDatabase.TABLE_CUSTOM_COMMANDS, null, null, null, null, null, "id DESC");

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
            String phrase = cursor.getString(cursor.getColumnIndexOrThrow("phrase"));
            String actionType = cursor.getString(cursor.getColumnIndexOrThrow("action_type"));
            String actionValue = cursor.getString(cursor.getColumnIndexOrThrow("action_value"));
            results.add(new CustomCommand(id, phrase, actionType, actionValue));
        }
        cursor.close();
        return results;
    }

    public CustomCommand findByPhrase(String spokenText) {
        ArrayList<CustomCommand> all = getAllCommands();
        String lowerSpoken = spokenText.toLowerCase();
        for (int i = 0; i < all.size(); i++) {
            CustomCommand command = all.get(i);
            if (lowerSpoken.contains(command.getPhrase())) {
                return command;
            }
        }
        return null;
    }

    public void deleteCommand(long id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(AtlasDatabase.TABLE_CUSTOM_COMMANDS, "id=?", new String[]{String.valueOf(id)});
    }
}
