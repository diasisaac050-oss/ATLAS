package com.idcorporation.atlas.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.idcorporation.atlas.receivers.AlarmReceiver;

/**
 * Schedules the real, exact alarms that back voice reminders and quick
 * "wake me in N minutes" requests. Separate from ReminderScheduler,
 * which only handles the spontaneous chatty pings - these alarms need
 * to fire at one precise instant and actually ring, so they go through
 * AlarmManager.setExactAndAllowWhileIdle with a full-screen receiver.
 */
public class AlarmScheduler {

    public static final String EXTRA_TITLE = "atlas_alarm_title";
    public static final String EXTRA_MESSAGE = "atlas_alarm_message";
    public static final String EXTRA_REQUEST_CODE = "atlas_alarm_request_code";

    public static boolean canScheduleExact(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager alarmManager = (AlarmManager) context.getApplicationContext()
                .getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) {
                return false;
            }
            return alarmManager.canScheduleExactAlarms();
        }
        return true;
    }

    public static void scheduleAlarm(Context context, long triggerMillis, int requestCode,
            String title, String message) {
        Context appContext = context.getApplicationContext();
        AlarmManager alarmManager = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }

        Intent intent = new Intent(appContext, AlarmReceiver.class);
        intent.putExtra(EXTRA_TITLE, title);
        intent.putExtra(EXTRA_MESSAGE, message);
        intent.putExtra(EXTRA_REQUEST_CODE, requestCode);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags | PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getBroadcast(appContext, requestCode, intent, flags);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent);
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent);
            }
        } catch (SecurityException e) {
            // Exact-alarm permission not granted on this OS version; fall back to inexact.
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent);
        }
    }

    public static void cancelAlarm(Context context, int requestCode) {
        Context appContext = context.getApplicationContext();
        AlarmManager alarmManager = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }
        Intent intent = new Intent(appContext, AlarmReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags | PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getBroadcast(appContext, requestCode, intent, flags);
        alarmManager.cancel(pendingIntent);
    }
}
