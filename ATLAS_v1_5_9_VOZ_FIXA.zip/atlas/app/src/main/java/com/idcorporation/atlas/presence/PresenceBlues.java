package com.idcorporation.atlas.presence;

/**
 * The only colors the Presence glass uses: a range from ice blue to
 * near-black navy. The glass does not follow the app theme color on
 * purpose, so it always looks like clear smoked-blue glass.
 */
final class PresenceBlues {

    static final int ICE = 0xFFE4F4FF;
    static final int SKY = 0xFFA6DCFF;
    static final int LIGHT = 0xFF63BDFF;
    static final int MID = 0xFF2F86E8;
    static final int DEEP = 0xFF0F49B5;
    static final int NAVY = 0xFF061B52;
    static final int ABYSS = 0xFF020B26;
    static final int WHITE = 0xFFFFFFFF;

    private PresenceBlues() {
    }

    /** Same color with a new alpha (0..255, clamped). */
    static int alpha(int color, int alpha) {
        int al = Math.max(0, Math.min(255, alpha));
        return (color & 0x00FFFFFF) | (al << 24);
    }

    /** Clamps a paint alpha given as 0..1 into 0..255. */
    static int a255(float amount) {
        int v = (int) (255f * amount);
        return Math.max(0, Math.min(255, v));
    }
}
