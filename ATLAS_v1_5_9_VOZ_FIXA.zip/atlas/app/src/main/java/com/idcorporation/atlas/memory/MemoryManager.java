package com.idcorporation.atlas.memory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.idcorporation.atlas.models.MemoryItem;
import com.idcorporation.atlas.security.SecurityManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

/**
 * Full user control over what ATLAS remembers: add, list, delete one,
 * delete all. Most writes still come from an explicit "remember that"
 * command or the Memory screen - but ATLAS FASE 3/4 also lets the AI
 * itself flag a fact worth remembering mid-conversation (see
 * saveOrUpdateAuto, driven by AIManager); those are tagged category
 * "auto" so they stay visibly distinguishable from what the user
 * explicitly asked to be remembered.
 */
public class MemoryManager {

    private static final int MAX_VALUE_LENGTH = 500;

    private final AtlasDatabase dbHelper;

    public MemoryManager(Context context) {
        this.dbHelper = AtlasDatabase.getInstance(context);
    }

    // Safety cap on how many facts the "auto" (AI-detected) category may hold,
    // so a chatty conversation can never grow the Memory tab without bound.
    // Manually-added memories ("manual"/"general") are never affected by this.
    private static final int MAX_AUTO_MEMORIES = 200;

    public long saveMemory(String key, String value, String category) {
        String safeKey = SecurityManager.sanitizeText(key, 100);
        String safeValue = SecurityManager.sanitizeText(value, MAX_VALUE_LENGTH);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("memory_key", safeKey);
        values.put("memory_value", safeValue);
        values.put("category", category);
        values.put("created_at", System.currentTimeMillis());
        return db.insert(AtlasDatabase.TABLE_MEMORIES, null, values);
    }

    /**
     * Same as saveMemory, but first looks for an existing memory with the
     * same key (case-insensitive) and updates it in place instead of
     * inserting a duplicate. This is what keeps a correction ("na verdade
     * prefiro ser chamado de X") from piling up as Nome/Isaac, Nome/X,
     * Nome/Isaac, Nome/X... - see MemoryManager's class doc for the rule
     * this implements.
     */
    public long saveOrUpdate(String key, String value, String category) {
        String safeKey = SecurityManager.sanitizeText(key, 100);
        String safeValue = SecurityManager.sanitizeText(value, MAX_VALUE_LENGTH);
        if (safeKey.length() == 0 || safeValue.length() == 0) {
            return -1L;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Cursor cursor = db.query(AtlasDatabase.TABLE_MEMORIES, new String[]{"id"},
            "LOWER(memory_key) = ?", new String[]{safeKey.toLowerCase()}, null, null, null, "1");
        long existingId = -1L;
        if (cursor.moveToFirst()) {
            existingId = cursor.getLong(0);
        }
        cursor.close();

        if (existingId >= 0L) {
            ContentValues values = new ContentValues();
            values.put("memory_value", safeValue);
            values.put("category", category);
            db.update(AtlasDatabase.TABLE_MEMORIES, values, "id = ?", new String[]{String.valueOf(existingId)});
            return existingId;
        }

        ContentValues values = new ContentValues();
        values.put("memory_key", safeKey);
        values.put("memory_value", safeValue);
        values.put("category", category);
        values.put("created_at", System.currentTimeMillis());
        return db.insert(AtlasDatabase.TABLE_MEMORIES, null, values);
    }

    /**
     * Entry point for facts ATLAS itself noticed in the conversation (see
     * AIManager / the \u00a7MEM\u00a7 directive). Capped separately from
     * manual memories so an automatic write can never silently take over
     * the whole Memory tab.
     */
    public long saveOrUpdateAuto(String key, String value) {
        String safeKey = SecurityManager.sanitizeText(key, 100);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor existing = db.query(AtlasDatabase.TABLE_MEMORIES, new String[]{"id"},
            "LOWER(memory_key) = ?", new String[]{safeKey.toLowerCase()}, null, null, null, "1");
        boolean isUpdate = existing.moveToFirst();
        existing.close();
        if (!isUpdate && countMemories() >= MAX_AUTO_MEMORIES) {
            return -1L;
        }
        return saveOrUpdate(key, value, "auto");
    }

    private int countMemories() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + AtlasDatabase.TABLE_MEMORIES, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public ArrayList<MemoryItem> getAllMemories() {
        ArrayList<MemoryItem> results = new ArrayList<MemoryItem>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(AtlasDatabase.TABLE_MEMORIES, null, null, null, null, null, "created_at DESC");

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
            String key = cursor.getString(cursor.getColumnIndexOrThrow("memory_key"));
            String value = cursor.getString(cursor.getColumnIndexOrThrow("memory_value"));
            String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
            long createdAt = cursor.getLong(cursor.getColumnIndexOrThrow("created_at"));
            results.add(new MemoryItem(id, key, value, category, createdAt));
        }
        cursor.close();
        return results;
    }

    /** Simple keyword lookup used when the user asks "what is my X". */
    public String findMemoryValueByKeyword(String keyword) {
        ArrayList<MemoryItem> all = getAllMemories();
        String lowerKeyword = keyword.toLowerCase();
        for (int i = 0; i < all.size(); i++) {
            MemoryItem item = all.get(i);
            if (item.getKey().toLowerCase().contains(lowerKeyword)) {
                return item.getValue();
            }
        }
        return null;
    }

    /** Lets the user correct or rewrite a memory from the Memory Control screen. */
    public void updateMemory(long id, String key, String value) {
        String safeKey = SecurityManager.sanitizeText(key, 100);
        String safeValue = SecurityManager.sanitizeText(value, MAX_VALUE_LENGTH);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("memory_key", safeKey);
        values.put("memory_value", safeValue);
        db.update(AtlasDatabase.TABLE_MEMORIES, values, "id=?", new String[]{String.valueOf(id)});
    }

    public void deleteMemory(long id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(AtlasDatabase.TABLE_MEMORIES, "id=?", new String[]{String.valueOf(id)});
    }

    public void deleteAllMemories() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(AtlasDatabase.TABLE_MEMORIES, null, null);
    }

    /**
     * CHAMIZO INTELLIGENCE memory improvement: instead of always sending only
     * the most recently created memories to the AI (which can push out an old
     * but important fact once the user has taught ATLAS many things), this
     * scores every memory against the current message and returns the most
     * relevant ones first, falling back to recency to fill any remaining
     * slots. This keeps the prompt small while making ATLAS far more likely
     * to actually use a fact that is relevant to what the user just said.
     */
    public ArrayList<MemoryItem> getRelevantMemories(String userMessage, int limit) {
        final ArrayList<MemoryItem> all = getAllMemories();
        if (all.size() <= limit || userMessage == null || userMessage.trim().length() == 0) {
            return trimTo(all, limit);
        }

        final String[] queryWords = tokenize(userMessage);
        final HashMap<Long, Integer> scores = new HashMap<Long, Integer>();
        for (int i = 0; i < all.size(); i++) {
            MemoryItem item = all.get(i);
            scores.put(Long.valueOf(item.getId()), Integer.valueOf(scoreMatch(item, queryWords)));
        }

        ArrayList<MemoryItem> ranked = new ArrayList<MemoryItem>(all);
        Collections.sort(ranked, new Comparator<MemoryItem>() {
            @Override
            public int compare(MemoryItem a, MemoryItem b) {
                int scoreA = scores.get(Long.valueOf(a.getId())).intValue();
                int scoreB = scores.get(Long.valueOf(b.getId())).intValue();
                if (scoreA != scoreB) {
                    return scoreB - scoreA;
                }
                long diff = b.getCreatedAt() - a.getCreatedAt();
                return diff > 0 ? 1 : (diff < 0 ? -1 : 0);
            }
        });
        return trimTo(ranked, limit);
    }

    private static ArrayList<MemoryItem> trimTo(ArrayList<MemoryItem> source, int limit) {
        if (source.size() <= limit) {
            return source;
        }
        ArrayList<MemoryItem> trimmed = new ArrayList<MemoryItem>();
        for (int i = 0; i < limit; i++) {
            trimmed.add(source.get(i));
        }
        return trimmed;
    }

    private static int scoreMatch(MemoryItem item, String[] queryWords) {
        String haystack = (item.getKey() + " " + item.getValue()).toLowerCase();
        int score = 0;
        for (int i = 0; i < queryWords.length; i++) {
            String word = queryWords[i];
            if (word.length() >= 3 && haystack.contains(word)) {
                score = score + 1;
            }
        }
        return score;
    }

    private static String[] tokenize(String text) {
        return text.toLowerCase().split("[^\\p{L}\\p{Nd}]+");
    }
}
