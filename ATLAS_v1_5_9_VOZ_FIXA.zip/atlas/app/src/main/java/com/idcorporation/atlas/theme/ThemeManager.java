package com.idcorporation.atlas.theme;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;

import com.idcorporation.atlas.R;

import java.util.ArrayList;

/**
 * Thirty-nine themes in total, all free to pick - there are no ads in ATLAS, so
 * nothing is locked. NORMAL, BLACK and PURPLE are the static defaults;
 * every other theme is animated (SPACE and MEGA_PURPLE keep their
 * original drifting-dots look).
 */
public class ThemeManager {

    public static final String THEME_NORMAL = "normal";
    public static final String THEME_BLACK = "black";
    public static final String THEME_PURPLE = "purple";
    public static final String THEME_SPACE = "space";
    public static final String THEME_MEGA_PURPLE = "mega_purple";

    public static final String THEME_DEEP_OCEAN = "deep_ocean";
    public static final String THEME_NEON_PINK = "neon_pink";
    public static final String THEME_FOREST_NIGHT = "forest_night";
    public static final String THEME_GOLDEN_HOUR = "golden_hour";
    public static final String THEME_SILVER_STEEL = "silver_steel";
    public static final String THEME_CYBER_GRID = "cyber_grid";
    public static final String THEME_LAVA_FLOW = "lava_flow";
    public static final String THEME_MIDNIGHT_AURORA = "midnight_aurora";

    public static final String THEME_GLACIAL = "glacial";
    public static final String THEME_PURPURA = "purpura";
    public static final String THEME_RED_DRY = "red_dry";

    public static final String THEME_EMERALD_COAST = "emerald_coast";
    public static final String THEME_ROSE_QUARTZ = "rose_quartz";
    public static final String THEME_STORM_GRID = "storm_grid";
    public static final String THEME_ARCTIC_FOX = "arctic_fox";
    public static final String THEME_VELVET_NIGHT = "velvet_night";
    public static final String THEME_COPPER_DUST = "copper_dust";
    public static final String THEME_NEBULA_DRIFT = "nebula_drift";
    public static final String THEME_FIREFLY_SWARM = "firefly_swarm";
    public static final String THEME_CHROME_PULSE = "chrome_pulse";
    public static final String THEME_DEEP_TRENCH = "deep_trench";
    public static final String THEME_NEON_CIRCUIT = "neon_circuit";

    public static final String THEME_OBSIDIAN_FLAME = "obsidian_flame";
    public static final String THEME_ROYAL_AMETHYST = "royal_amethyst";
    public static final String THEME_FROSTBYTE = "frostbyte";
    public static final String THEME_TOXIC_BLOOM = "toxic_bloom";
    public static final String THEME_CRIMSON_CIRCUIT = "crimson_circuit";
    public static final String THEME_AURORA_PRIME = "aurora_prime";
    public static final String THEME_MOLTEN_CORE = "molten_core";
    public static final String THEME_PLATINUM_EDGE = "platinum_edge";
    public static final String THEME_COBALT_REACTOR = "cobalt_reactor";
    public static final String THEME_BLOOD_MOON = "blood_moon";
    public static final String THEME_EMERALD_CIRCUIT = "emerald_circuit";
    public static final String THEME_STARLIGHT_VEIL = "starlight_veil";

    private static final String PREFS_NAME = "atlas_theme_prefs";
    private static final String KEY_SELECTED_THEME = "selected_theme";

    private static final ArrayList<ThemePalette> PALETTES = buildPalettes();

    private static ArrayList<ThemePalette> buildPalettes() {
        ArrayList<ThemePalette> list = new ArrayList<ThemePalette>();

        list.add(new ThemePalette(THEME_NORMAL, R.string.theme_normal_name,
            Color.parseColor("#0A0E14"), Color.parseColor("#0A0E14"), Color.parseColor("#00E5FF"),
            false, ThemeAnimationStyle.NONE));
        list.add(new ThemePalette(THEME_BLACK, R.string.theme_black_name,
            Color.parseColor("#000000"), Color.parseColor("#000000"), Color.parseColor("#E8F6FF"),
            false, ThemeAnimationStyle.NONE));
        list.add(new ThemePalette(THEME_PURPLE, R.string.theme_purple_name,
            Color.parseColor("#150A1F"), Color.parseColor("#150A1F"), Color.parseColor("#B266FF"),
            false, ThemeAnimationStyle.NONE));
        list.add(new ThemePalette(THEME_SPACE, R.string.theme_space_name,
            Color.parseColor("#050B18"), Color.parseColor("#0E2A4A"), Color.parseColor("#00E5FF"),
            true, ThemeAnimationStyle.DRIFT_DOTS));
        list.add(new ThemePalette(THEME_MEGA_PURPLE, R.string.theme_mega_purple_name,
            Color.parseColor("#1A0B2E"), Color.parseColor("#3A0E3E"), Color.parseColor("#FF4FD8"),
            true, ThemeAnimationStyle.DRIFT_DOTS));

        list.add(new ThemePalette(THEME_DEEP_OCEAN, R.string.theme_deep_ocean_name,
            Color.parseColor("#001018"), Color.parseColor("#003044"), Color.parseColor("#00C2FF"),
            true, ThemeAnimationStyle.RISING_PARTICLES));
        list.add(new ThemePalette(THEME_NEON_PINK, R.string.theme_neon_pink_name,
            Color.parseColor("#14000E"), Color.parseColor("#2E001F"), Color.parseColor("#FF2DAF"),
            true, ThemeAnimationStyle.SCAN_GRID));
        list.add(new ThemePalette(THEME_FOREST_NIGHT, R.string.theme_forest_night_name,
            Color.parseColor("#050F08"), Color.parseColor("#0E2013"), Color.parseColor("#4CFF7A"),
            true, ThemeAnimationStyle.SWARM));
        list.add(new ThemePalette(THEME_GOLDEN_HOUR, R.string.theme_golden_hour_name,
            Color.parseColor("#1A1200"), Color.parseColor("#3D2C00"), Color.parseColor("#FFC93C"),
            true, ThemeAnimationStyle.SHEEN_SWEEP));
        list.add(new ThemePalette(THEME_SILVER_STEEL, R.string.theme_silver_steel_name,
            Color.parseColor("#101214"), Color.parseColor("#2B2F33"), Color.parseColor("#CFE3EC"),
            true, ThemeAnimationStyle.SHEEN_SWEEP));
        list.add(new ThemePalette(THEME_CYBER_GRID, R.string.theme_cyber_grid_name,
            Color.parseColor("#000B0D"), Color.parseColor("#002326"), Color.parseColor("#00FFF0"),
            true, ThemeAnimationStyle.SCAN_GRID));
        list.add(new ThemePalette(THEME_LAVA_FLOW, R.string.theme_lava_flow_name,
            Color.parseColor("#1A0500"), Color.parseColor("#401200"), Color.parseColor("#FF5A1F"),
            true, ThemeAnimationStyle.RISING_PARTICLES));
        list.add(new ThemePalette(THEME_MIDNIGHT_AURORA, R.string.theme_midnight_aurora_name,
            Color.parseColor("#05081A"), Color.parseColor("#0E1B3D"), Color.parseColor("#6BE7FF"),
            true, ThemeAnimationStyle.AURORA_WAVES));

        list.add(new ThemePalette(THEME_GLACIAL, R.string.theme_glacial_name,
            Color.parseColor("#0B1620"), Color.parseColor("#1C3A4A"), Color.parseColor("#D9F4FF"),
            true, ThemeAnimationStyle.GLACIAL_SHIMMER));
        list.add(new ThemePalette(THEME_PURPURA, R.string.theme_purpura_name,
            Color.parseColor("#1A0512"), Color.parseColor("#3D0E2E"), Color.parseColor("#FF9EDB"),
            true, ThemeAnimationStyle.PURPURA_BLOOM));
        list.add(new ThemePalette(THEME_RED_DRY, R.string.theme_red_dry_name,
            Color.parseColor("#1C0000"), Color.parseColor("#3D0812"), Color.parseColor("#FF4438"),
            true, ThemeAnimationStyle.RED_DRY_EMBER));

        // ATLAS VOID "Personalizacao" - 15 new free themes.
        list.add(new ThemePalette(THEME_EMERALD_COAST, R.string.theme_emerald_coast_name,
            Color.parseColor("#001410"), Color.parseColor("#013026"), Color.parseColor("#34FFC4"),
            true, ThemeAnimationStyle.RISING_PARTICLES));
        list.add(new ThemePalette(THEME_ROSE_QUARTZ, R.string.theme_rose_quartz_name,
            Color.parseColor("#1A0510"), Color.parseColor("#3D1428"), Color.parseColor("#FF9ED2"),
            true, ThemeAnimationStyle.SHEEN_SWEEP));
        list.add(new ThemePalette(THEME_STORM_GRID, R.string.theme_storm_grid_name,
            Color.parseColor("#05080F"), Color.parseColor("#14263D"), Color.parseColor("#6FD8FF"),
            true, ThemeAnimationStyle.SCAN_GRID));
        list.add(new ThemePalette(THEME_ARCTIC_FOX, R.string.theme_arctic_fox_name,
            Color.parseColor("#0A1418"), Color.parseColor("#1E3540"), Color.parseColor("#C9F3FF"),
            true, ThemeAnimationStyle.GLACIAL_SHIMMER));
        list.add(new ThemePalette(THEME_VELVET_NIGHT, R.string.theme_velvet_night_name,
            Color.parseColor("#100015"), Color.parseColor("#26002E"), Color.parseColor("#C77DFF"),
            true, ThemeAnimationStyle.PURPURA_BLOOM));
        list.add(new ThemePalette(THEME_COPPER_DUST, R.string.theme_copper_dust_name,
            Color.parseColor("#180800"), Color.parseColor("#3A1A05"), Color.parseColor("#FF8A4C"),
            true, ThemeAnimationStyle.RED_DRY_EMBER));
        list.add(new ThemePalette(THEME_NEBULA_DRIFT, R.string.theme_nebula_drift_name,
            Color.parseColor("#06041A"), Color.parseColor("#140F3D"), Color.parseColor("#9E8CFF"),
            true, ThemeAnimationStyle.AURORA_WAVES));
        list.add(new ThemePalette(THEME_FIREFLY_SWARM, R.string.theme_firefly_swarm_name,
            Color.parseColor("#051005"), Color.parseColor("#0F2A0F"), Color.parseColor("#B6FF6B"),
            true, ThemeAnimationStyle.SWARM));
        list.add(new ThemePalette(THEME_CHROME_PULSE, R.string.theme_chrome_pulse_name,
            Color.parseColor("#0E0E10"), Color.parseColor("#26282B"), Color.parseColor("#E8F0F5"),
            true, ThemeAnimationStyle.SHEEN_SWEEP));
        list.add(new ThemePalette(THEME_DEEP_TRENCH, R.string.theme_deep_trench_name,
            Color.parseColor("#00060F"), Color.parseColor("#002038"), Color.parseColor("#37C6FF"),
            true, ThemeAnimationStyle.RISING_PARTICLES));
        list.add(new ThemePalette(THEME_NEON_CIRCUIT, R.string.theme_neon_circuit_name,
            Color.parseColor("#10001A"), Color.parseColor("#26003D"), Color.parseColor("#FF4CE0"),
            true, ThemeAnimationStyle.SCAN_GRID));

        // ATLAS VOID "Personalizacao" - 15 new themes.
        list.add(new ThemePalette(THEME_OBSIDIAN_FLAME, R.string.theme_obsidian_flame_name,
            Color.parseColor("#000000"), Color.parseColor("#240A00"), Color.parseColor("#FF5A1F"),
            true, ThemeAnimationStyle.RED_DRY_EMBER));
        list.add(new ThemePalette(THEME_ROYAL_AMETHYST, R.string.theme_royal_amethyst_name,
            Color.parseColor("#140018"), Color.parseColor("#33003D"), Color.parseColor("#E0A6FF"),
            true, ThemeAnimationStyle.PURPURA_BLOOM));
        list.add(new ThemePalette(THEME_FROSTBYTE, R.string.theme_frostbyte_name,
            Color.parseColor("#001018"), Color.parseColor("#013040"), Color.parseColor("#A8F0FF"),
            true, ThemeAnimationStyle.GLACIAL_SHIMMER));
        list.add(new ThemePalette(THEME_TOXIC_BLOOM, R.string.theme_toxic_bloom_name,
            Color.parseColor("#060A00"), Color.parseColor("#172400"), Color.parseColor("#C8FF3D"),
            true, ThemeAnimationStyle.SWARM));
        list.add(new ThemePalette(THEME_CRIMSON_CIRCUIT, R.string.theme_crimson_circuit_name,
            Color.parseColor("#140000"), Color.parseColor("#380008"), Color.parseColor("#FF3355"),
            true, ThemeAnimationStyle.SCAN_GRID));
        list.add(new ThemePalette(THEME_AURORA_PRIME, R.string.theme_aurora_prime_name,
            Color.parseColor("#020A14"), Color.parseColor("#0A2038"), Color.parseColor("#6BFFD9"),
            true, ThemeAnimationStyle.AURORA_WAVES));
        list.add(new ThemePalette(THEME_MOLTEN_CORE, R.string.theme_molten_core_name,
            Color.parseColor("#1A0300"), Color.parseColor("#400A00"), Color.parseColor("#FF7A1A"),
            true, ThemeAnimationStyle.RISING_PARTICLES));
        list.add(new ThemePalette(THEME_PLATINUM_EDGE, R.string.theme_platinum_edge_name,
            Color.parseColor("#121212"), Color.parseColor("#2E2E2E"), Color.parseColor("#F2F2F2"),
            true, ThemeAnimationStyle.SHEEN_SWEEP));
        list.add(new ThemePalette(THEME_COBALT_REACTOR, R.string.theme_cobalt_reactor_name,
            Color.parseColor("#000A1A"), Color.parseColor("#002C4D"), Color.parseColor("#33AFFF"),
            true, ThemeAnimationStyle.SCAN_GRID));
        list.add(new ThemePalette(THEME_BLOOD_MOON, R.string.theme_blood_moon_name,
            Color.parseColor("#140000"), Color.parseColor("#330005"), Color.parseColor("#FF2E2E"),
            true, ThemeAnimationStyle.RED_DRY_EMBER));
        list.add(new ThemePalette(THEME_EMERALD_CIRCUIT, R.string.theme_emerald_circuit_name,
            Color.parseColor("#001408"), Color.parseColor("#013D1A"), Color.parseColor("#33FF88"),
            true, ThemeAnimationStyle.SCAN_GRID));
        list.add(new ThemePalette(THEME_STARLIGHT_VEIL, R.string.theme_starlight_veil_name,
            Color.parseColor("#04081A"), Color.parseColor("#101E40"), Color.parseColor("#CBD9FF"),
            true, ThemeAnimationStyle.AURORA_WAVES));

        return list;
    }

    public static ArrayList<ThemePalette> getAllPalettes() {
        return PALETTES;
    }

    /**
     * Groups the theme catalog into named "types" for the theme picker
     * screen (Color / Drift / Pulse / Particles / etc), one group per
     * animation engine plus a group for the flat static themes. Used to
     * lay the picker out as separate labeled rows instead of one long
     * list, similar to a wallpaper-app category layout.
     */
    public static final int CATEGORY_STATIC = -1;

    public static int getCategoryKey(ThemePalette palette) {
        if (!palette.isAnimated()) {
            return CATEGORY_STATIC;
        }
        return palette.getAnimationStyle();
    }

    public static int getCategoryNameResId(int categoryKey) {
        if (categoryKey == CATEGORY_STATIC) {
            return R.string.theme_category_color;
        }
        if (categoryKey == ThemeAnimationStyle.DRIFT_DOTS) {
            return R.string.theme_category_drift;
        }
        if (categoryKey == ThemeAnimationStyle.RISING_PARTICLES) {
            return R.string.theme_category_particles;
        }
        if (categoryKey == ThemeAnimationStyle.SCAN_GRID) {
            return R.string.theme_category_grid;
        }
        if (categoryKey == ThemeAnimationStyle.SWARM) {
            return R.string.theme_category_swarm;
        }
        if (categoryKey == ThemeAnimationStyle.AURORA_WAVES) {
            return R.string.theme_category_aurora;
        }
        if (categoryKey == ThemeAnimationStyle.SHEEN_SWEEP) {
            return R.string.theme_category_sheen;
        }
        if (categoryKey == ThemeAnimationStyle.GLACIAL_SHIMMER) {
            return R.string.theme_category_glacial;
        }
        if (categoryKey == ThemeAnimationStyle.PURPURA_BLOOM) {
            return R.string.theme_category_purpura;
        }
        if (categoryKey == ThemeAnimationStyle.RED_DRY_EMBER) {
            return R.string.theme_category_ember;
        }
        return R.string.theme_category_color;
    }

    /**
     * Builds a small rounded-rect preview swatch for a theme card in the
     * picker: a diagonal gradient between the theme's two background
     * colors (a flat static theme just repeats one color, which reads as
     * a plain color chip) with a thin border in the theme's accent
     * color.
     */
    public static GradientDrawable buildCardPreviewDrawable(View anchor, ThemePalette palette) {
        float density = anchor.getContext().getResources().getDisplayMetrics().density;
        GradientDrawable gradient = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{palette.getBackgroundColorAlt(), palette.getBackgroundColor()});
        gradient.setShape(GradientDrawable.RECTANGLE);
        gradient.setCornerRadius(14f * density);
        gradient.setStroke(Math.round(1.5f * density), palette.getAccentColor());
        return gradient;
    }

    public static ThemePalette getPaletteById(String id) {
        for (int i = 0; i < PALETTES.size(); i = i + 1) {
            if (PALETTES.get(i).getId().equals(id)) {
                return PALETTES.get(i);
            }
        }
        return PALETTES.get(0);
    }

    public static String getSelectedThemeId(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_SELECTED_THEME, THEME_NORMAL);
    }

    public static ThemePalette getSelectedPalette(Context context) {
        return getPaletteById(getSelectedThemeId(context));
    }

    public static void setSelectedTheme(Context context, String themeId) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_SELECTED_THEME, themeId).apply();
    }

    private static final String ANIMATED_BG_TAG = "atlas_animated_bg";

    private static View createBackgroundView(Context context, ThemePalette palette) {
        int style = palette.getAnimationStyle();
        if (style == ThemeAnimationStyle.RISING_PARTICLES) {
            return new RisingParticlesBackgroundView(context);
        }
        if (style == ThemeAnimationStyle.SCAN_GRID) {
            return new ScanGridBackgroundView(context);
        }
        if (style == ThemeAnimationStyle.SWARM) {
            return new SwarmBackgroundView(context);
        }
        if (style == ThemeAnimationStyle.AURORA_WAVES) {
            return new AuroraWaveBackgroundView(context);
        }
        if (style == ThemeAnimationStyle.SHEEN_SWEEP) {
            return new SheenSweepBackgroundView(context);
        }
        if (style == ThemeAnimationStyle.GLACIAL_SHIMMER) {
            return new GlacialShimmerBackgroundView(context);
        }
        if (style == ThemeAnimationStyle.PURPURA_BLOOM) {
            return new PurpuraBloomBackgroundView(context);
        }
        if (style == ThemeAnimationStyle.RED_DRY_EMBER) {
            return new RedDryEmberBackgroundView(context);
        }
        return new AnimatedThemeBackgroundView(context);
    }

    /**
     * Applies the current theme to the activity: a plain background color
     * for the static free themes, or a live animated background layer
     * (its style chosen per theme) for the animated ones. Called
     * automatically for every screen from BaseActivity, so switching
     * themes takes effect immediately.
     */
    public static void applyToActivity(Activity activity) {
        ThemePalette palette = getSelectedPalette(activity);
        ViewGroup contentRoot = (ViewGroup) activity.findViewById(android.R.id.content);
        if (contentRoot == null || contentRoot.getChildCount() == 0) {
            return;
        }
        View rootView = contentRoot.getChildAt(0);

        View existingAnimatedBg = contentRoot.findViewWithTag(ANIMATED_BG_TAG);
        if (existingAnimatedBg != null) {
            if (existingAnimatedBg instanceof ThemeBackgroundView) {
                ((ThemeBackgroundView) existingAnimatedBg).stopAnimating();
            }
            contentRoot.removeView(existingAnimatedBg);
        }

        if (palette.isAnimated()) {
            View animatedView = createBackgroundView(activity, palette);
            animatedView.setTag(ANIMATED_BG_TAG);
            ((ThemeBackgroundView) animatedView).setPalette(palette);
            rootView.setBackgroundColor(0x00000000);
            contentRoot.addView(animatedView, 0,
                new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            rootView.setBackgroundColor(palette.getBackgroundColor());
        }
    }
}
