package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;

/**
 * Draws the "orb" Presence layout: a see-through glass ball with NO color
 * (only white light and neutral gray shadow) that rises from the bottom
 * edge of the screen with a little overshoot, breathes while idle, swells
 * with the user's voice, and sinks back down when it closes. The moving
 * light inside it is drawn by PresenceOrbInner. Plain Canvas only.
 */
public class PresenceOrbPainter implements PresenceDrawer {

    private static final float RADIUS_DP = 62f;
    private static final float BOTTOM_MARGIN_DP = 34f;

    private final float d;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path circle = new Path();
    private final RectF oval = new RectF();
    private final Matrix matrix = new Matrix();
    private final PresenceOrbInner inner;

    public PresenceOrbPainter(float density) {
        this.d = density;
        this.inner = new PresenceOrbInner(density);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override
    public void draw(Canvas canvas, int w, int h, PresenceBubbleState st) {
        float p = st.open;
        if (p <= 0.01f) {
            return;
        }
        float alpha = Math.min(1f, p * 2.2f);
        float full = RADIUS_DP * d;
        float pulse = Math.max(st.level, st.speakAmt * (0.45f + 0.35f * (float) Math.sin(st.phase * 9.0)));
        float breathe = 1f + 0.018f * (float) Math.sin(st.phase * 1.7) + pulse * 0.07f;
        float r = full * (0.55f + 0.45f * Math.min(p, 1.12f)) * breathe;

        float restY = h - BOTTOM_MARGIN_DP * d - full;
        float travel = full * 2f + 44f * d;
        float cx = w / 2f + (float) Math.sin(st.phase * 38.0) * 2f * d * st.errAmt;
        float cy = restY + (1f - p) * travel;

        drawHalo(canvas, cx, cy, r, st, pulse, alpha);
        drawBody(canvas, cx, cy, r, alpha);

        circle.reset();
        circle.addCircle(cx, cy, r, Path.Direction.CW);
        canvas.save();
        canvas.clipPath(circle);
        inner.draw(canvas, cx, cy, r, st, pulse, alpha);
        drawLowerShade(canvas, cx, cy, r, alpha);
        canvas.restore();

        drawRim(canvas, cx, cy, r, st, alpha);
        drawHighlights(canvas, cx, cy, r, alpha);
        drawRipple(canvas, cx, cy, r, st);
    }

    /** Faint white glow outside the ball; kept weak so the ball stays transparent. */
    private void drawHalo(Canvas canvas, float cx, float cy, float r,
                          PresenceBubbleState st, float pulse, float alpha) {
        float strength = (0.35f + 0.5f * pulse + 0.25f * st.thinkAmt) * alpha;
        fill.setShader(new RadialGradient(cx, cy, r * 1.55f,
            new int[] {gray(0xFFFFFF, 64 * strength), gray(0xFFFFFF, 0f)},
            new float[] {0.5f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, r * 1.55f, fill);
        fill.setShader(null);
    }

    /** The glass: almost clear in the middle, a smoky gray edge and a frosty white edge. */
    private void drawBody(Canvas canvas, float cx, float cy, float r, float alpha) {
        fill.setShader(new RadialGradient(cx - r * 0.22f, cy - r * 0.28f, r * 1.3f,
            new int[] {gray(0xFFFFFF, 20 * alpha), gray(0xFFFFFF, 5 * alpha), gray(0x1C1C1C, 62 * alpha)},
            new float[] {0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, r, fill);
        fill.setShader(null);
    }

    /** Slightly darker, frosted bottom so the ball looks round and heavy. */
    private void drawLowerShade(Canvas canvas, float cx, float cy, float r, float alpha) {
        fill.setShader(new LinearGradient(0f, cy, 0f, cy + r,
            new int[] {gray(0xFFFFFF, 0f), gray(0xFFFFFF, 34 * alpha)},
            null, Shader.TileMode.CLAMP));
        canvas.drawRect(cx - r, cy, cx + r, cy + r, fill);
        fill.setShader(null);
    }

    private void drawRim(Canvas canvas, float cx, float cy, float r,
                         PresenceBubbleState st, float alpha) {
        SweepGradient rim = new SweepGradient(cx, cy,
            new int[] {gray(0xFFFFFF, 35 * alpha), gray(0xFFFFFF, 235 * alpha),
                       gray(0xFFFFFF, 90 * alpha), gray(0xFFFFFF, 25 * alpha),
                       gray(0xFFFFFF, 35 * alpha)},
            new float[] {0f, 0.62f, 0.78f, 0.90f, 1f});
        matrix.setRotate(st.phase * 22f, cx, cy);
        rim.setLocalMatrix(matrix);
        // Paint alpha multiplies a shader's alpha, so reset it to fully opaque first.
        line.setColor(0xFFFFFFFF);
        line.setShader(rim);
        line.setStrokeWidth(1.6f * d);
        canvas.drawCircle(cx, cy, r, line);
        line.setShader(null);

        line.setStrokeWidth(1f * d);
        line.setColor(gray(0x000000, 70 * alpha));
        canvas.drawCircle(cx, cy, r * 1.012f, line);
        line.setColor(gray(0xFFFFFF, 50 * alpha));
        canvas.drawCircle(cx, cy, r * 0.955f, line);
    }

    private void drawHighlights(Canvas canvas, float cx, float cy, float r, float alpha) {
        line.setStrokeWidth(2.8f * d);
        line.setColor(gray(0xFFFFFF, 200 * alpha));
        oval.set(cx - r * 0.88f, cy - r * 0.88f, cx + r * 0.88f, cy + r * 0.88f);
        canvas.drawArc(oval, 198f, 44f, false, line);
        line.setStrokeWidth(1.8f * d);
        line.setColor(gray(0xFFFFFF, 90 * alpha));
        canvas.drawArc(oval, 24f, 30f, false, line);
        dot.setColor(gray(0xFFFFFF, 190 * alpha));
        canvas.drawCircle(cx - r * 0.5f, cy - r * 0.6f, 2.2f * d, dot);
    }

    private void drawRipple(Canvas canvas, float cx, float cy, float r, PresenceBubbleState st) {
        if (st.ripple < 0f || st.ripple > 1f) {
            return;
        }
        float fade = 1f - st.ripple;
        line.setStrokeWidth(1.6f * d);
        line.setColor(gray(0xFFFFFF, 165 * fade * fade));
        canvas.drawCircle(cx, cy, r * (1f + 0.55f * st.ripple), line);
    }

    /** Neutral color (white or gray) with an alpha 0..255 (clamped). */
    private static int gray(int rgb, float alpha) {
        int al = (int) Math.max(0f, Math.min(255f, alpha));
        return (rgb & 0x00FFFFFF) | (al << 24);
    }
}
