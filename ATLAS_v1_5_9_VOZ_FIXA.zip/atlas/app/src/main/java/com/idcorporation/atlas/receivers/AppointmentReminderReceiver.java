package com.idcorporation.atlas.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.idcorporation.atlas.calendar.CalendarEventManager;
import com.idcorporation.atlas.utils.AppointmentReminderScheduler;
import com.idcorporation.atlas.utils.NotificationHelper;

/**
 * ATLAS GENESYS - Compromissos: fired by AlarmManager at the exact minute a
 * compromisso (appointment) is due. Unlike AlarmReceiver, this never rings,
 * vibrates or opens a full-screen activity - it only posts a normal
 * notification reminding the user, exactly as a personal assistant would.
 */
public class AppointmentReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra(AppointmentReminderScheduler.EXTRA_TITLE);
        String message = intent.getStringExtra(AppointmentReminderScheduler.EXTRA_MESSAGE);
        int notificationId = intent.getIntExtra(AppointmentReminderScheduler.EXTRA_NOTIFICATION_ID, 0);
        long eventId = intent.getLongExtra(AppointmentReminderScheduler.EXTRA_EVENT_ID, -1L);
        if (title == null) {
            title = "";
        }
        if (message == null) {
            message = "";
        }
        NotificationHelper.showNotification(context, notificationId, title, message);

        // ATLAS FASE 3/4 item 21: if this compromisso repeats ("toda sexta",
        // "todo mes"...), roll the same row forward to its next occurrence
        // and arm a fresh alarm for it. A one-off compromisso (the vast
        // majority) simply has no recurrence rule, so rescheduleRecurrence
        // does nothing for it - exactly the previous behavior.
        if (eventId >= 0L) {
            CalendarEventManager calendarEventManager = new CalendarEventManager(context);
            calendarEventManager.rescheduleRecurrence(eventId);
        }
    }
}
