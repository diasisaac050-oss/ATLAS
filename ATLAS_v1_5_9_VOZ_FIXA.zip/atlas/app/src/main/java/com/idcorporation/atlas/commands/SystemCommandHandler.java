package com.idcorporation.atlas.commands;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

/**
 * Opens system settings screens through the standard android.provider.Settings
 * intent actions. These are the only officially supported way to reach
 * these screens, so nothing here bypasses Android's security model.
 */
public class SystemCommandHandler {

    public void openSettings(Context context) {
        launch(context, new Intent(Settings.ACTION_SETTINGS));
    }

    public void openWifiSettings(Context context) {
        launch(context, new Intent(Settings.ACTION_WIFI_SETTINGS));
    }

    public void openBluetoothSettings(Context context) {
        launch(context, new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
    }

    public void openNotificationSettings(Context context) {
        launch(context, new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS));
    }

    public void openAppSettings(Context context) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + context.getPackageName()));
        launch(context, intent);
    }

    public void openDialer(Context context) {
        launch(context, new Intent(Intent.ACTION_DIAL));
    }

    public void openContacts(Context context) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(android.provider.ContactsContract.Contacts.CONTENT_URI);
        launch(context, intent);
    }

    public void openSetAlarm(Context context) {
        Intent intent = new Intent(android.provider.AlarmClock.ACTION_SET_ALARM);
        launch(context, intent);
    }

    private void launch(Context context, Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
        } catch (Exception e) {
            // Screen not available on this device/OEM skin; caller reports failure via speech.
        }
    }
}
