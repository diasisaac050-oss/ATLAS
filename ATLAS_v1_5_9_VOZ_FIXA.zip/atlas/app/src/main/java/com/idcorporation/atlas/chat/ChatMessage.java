package com.idcorporation.atlas.chat;

import android.net.Uri;

import com.idcorporation.atlas.commands.ConfirmAction;

/** One bubble in the Chat mode conversation. */
public class ChatMessage {

    public static final int ROLE_USER = 0;
    public static final int ROLE_ATLAS = 1;

    public static final int KIND_NORMAL = 0;
    public static final int KIND_ERROR = 1;
    public static final int KIND_CONFIRM = 2;

    public static final int CONFIRM_PENDING = 0;
    public static final int CONFIRM_ACCEPTED = 1;
    public static final int CONFIRM_DECLINED = 2;

    private static long nextId = 1L;

    private final long id;
    private final int role;
    private final String text;
    private final long timestamp;
    private final int kind;

    private boolean animateEntrance = false;
    private boolean animateReveal = false;
    private ConfirmAction confirmAction = null;
    private int confirmState = CONFIRM_PENDING;
    private String retryText = null;
    // ATLAS VISAO: a picked image attached to a user bubble, if any. Not
    // persisted across app restarts - only the message text is saved to
    // history (see HistoryManager), so this Uri only lives for the current
    // ChatSession's lifetime.
    private Uri imageUri = null;

    public ChatMessage(int role, String text, long timestamp, int kind) {
        synchronized (ChatMessage.class) {
            this.id = nextId;
            nextId = nextId + 1L;
        }
        this.role = role;
        this.text = text;
        this.timestamp = timestamp;
        this.kind = kind;
    }

    public long getId() {
        return id;
    }

    public int getRole() {
        return role;
    }

    public boolean isUser() {
        return role == ROLE_USER;
    }

    public String getText() {
        return text;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public int getKind() {
        return kind;
    }

    public boolean shouldAnimateEntrance() {
        return animateEntrance;
    }

    public void setAnimateEntrance(boolean value) {
        this.animateEntrance = value;
    }

    public boolean shouldAnimateReveal() {
        return animateReveal;
    }

    public void setAnimateReveal(boolean value) {
        this.animateReveal = value;
    }

    public ConfirmAction getConfirmAction() {
        return confirmAction;
    }

    public void setConfirmAction(ConfirmAction action) {
        this.confirmAction = action;
    }

    public int getConfirmState() {
        return confirmState;
    }

    public void setConfirmState(int state) {
        this.confirmState = state;
    }

    public String getRetryText() {
        return retryText;
    }

    public void setRetryText(String value) {
        this.retryText = value;
    }

    public Uri getImageUri() {
        return imageUri;
    }

    public void setImageUri(Uri value) {
        this.imageUri = value;
    }
}
