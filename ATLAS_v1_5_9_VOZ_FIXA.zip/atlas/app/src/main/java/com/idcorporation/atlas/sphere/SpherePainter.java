package com.idcorporation.atlas.sphere;

/**
 * The tiny drawing surface SphereEngine needs. AtlasSphereView implements it
 * on top of an Android Canvas (additive blending); keeping it an interface
 * means all the 3D maths in SphereEngine is plain Java with no Android
 * dependency.
 */
public interface SpherePainter {

    /** Draws round dots. xy holds x,y pairs; count is the number of FLOATS used. */
    void points(float[] xy, int count, float sizePx, int argb);

    /** Draws line segments. xyxy holds x1,y1,x2,y2 groups; count is the number of FLOATS used. */
    void lines(float[] xyxy, int count, float widthPx, int argb);

    /**
     * Soft radial glow centered on (cx, cy): rgb at the given alpha (0..1) in
     * the middle fading to nothing at radiusPx. slot (0..3) lets the painter
     * cache one gradient per distinct glow colour.
     */
    void glow(int slot, float cx, float cy, float radiusPx, int rgb, float alpha);
}
