package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class UserProfileManager {

    public static final String GENDER_MALE = "male";
    public static final String GENDER_FEMALE = "female";
    public static final String GENDER_UNSPECIFIED = "unspecified";

    private static final String PREFS_NAME = "atlas_profile_prefs";
    private static final String KEY_NAME = "profile_name";
    private static final String KEY_FULL_NAME = "profile_full_name";
    private static final String KEY_EMAIL = "profile_email";
    private static final String KEY_AGE = "profile_age";
    private static final String KEY_GENDER = "profile_gender";
    private static final String KEY_ONBOARDING_DONE = "onboarding_done";
    private static final String KEY_BIRTH_YEAR = "profile_birth_year";
    private static final String KEY_BIRTH_MONTH = "profile_birth_month";
    private static final String KEY_BIRTH_DAY = "profile_birth_day";
    private static final String KEY_COUNTRY = "profile_country";

    private final SharedPreferences prefs;
    private final SecurePasswordStore passwordStore;

    public UserProfileManager(Context context) {
        this.prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.passwordStore = new SecurePasswordStore(context);
    }

    /** Kept for the legacy password-based onboarding path. */
    public void saveProfile(String fullName, String callName, String email, int age, String gender, String password) {
        saveProfileCommon(fullName, callName, email, age, gender);
        passwordStore.savePassword(password);
    }

    /** Current onboarding path: no password, birthday collected instead. */
    public void saveProfileWithBirthday(String fullName, String callName, String email, int age, String gender,
            int birthYear, int birthMonth, int birthDay) {
        saveProfileCommon(fullName, callName, email, age, gender);
        setBirthday(birthYear, birthMonth, birthDay);
    }

    private void saveProfileCommon(String fullName, String callName, String email, int age, String gender) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_FULL_NAME, fullName);
        editor.putString(KEY_NAME, callName);
        editor.putString(KEY_EMAIL, email);
        editor.putInt(KEY_AGE, age);
        editor.putString(KEY_GENDER, gender);
        editor.putBoolean(KEY_ONBOARDING_DONE, true);
        editor.apply();
    }

    public void setBirthday(int year, int month, int day) {
        prefs.edit()
            .putInt(KEY_BIRTH_YEAR, year)
            .putInt(KEY_BIRTH_MONTH, month)
            .putInt(KEY_BIRTH_DAY, day)
            .apply();
    }

    public boolean hasBirthday() {
        return prefs.getInt(KEY_BIRTH_MONTH, -1) > 0 && prefs.getInt(KEY_BIRTH_DAY, -1) > 0;
    }

    public int getBirthYear() {
        return prefs.getInt(KEY_BIRTH_YEAR, -1);
    }

    public int getBirthMonth() {
        return prefs.getInt(KEY_BIRTH_MONTH, -1);
    }

    public int getBirthDay() {
        return prefs.getInt(KEY_BIRTH_DAY, -1);
    }

    /** ISO 3166-1 alpha-2 code (e.g. "BR") chosen on the onboarding country step, if any. */
    public void setCountry(String isoCountryCode) {
        prefs.edit().putString(KEY_COUNTRY, isoCountryCode).apply();
    }

    public String getCountry() {
        return prefs.getString(KEY_COUNTRY, "");
    }

    public String getName() {
        return prefs.getString(KEY_NAME, "");
    }

    public String getFullName() {
        return prefs.getString(KEY_FULL_NAME, "");
    }

    public String getEmail() {
        return prefs.getString(KEY_EMAIL, "");
    }

    public int getAge() {
        return prefs.getInt(KEY_AGE, 0);
    }

    public String getGender() {
        return prefs.getString(KEY_GENDER, GENDER_UNSPECIFIED);
    }

    public void setName(String name) {
        prefs.edit().putString(KEY_NAME, name).apply();
    }

    public void setFullName(String fullName) {
        prefs.edit().putString(KEY_FULL_NAME, fullName).apply();
    }

    public void setEmail(String email) {
        prefs.edit().putString(KEY_EMAIL, email).apply();
    }

    public void setGender(String gender) {
        prefs.edit().putString(KEY_GENDER, gender).apply();
    }

    public boolean isOnboardingDone() {
        return prefs.getBoolean(KEY_ONBOARDING_DONE, false);
    }

    public boolean checkPassword(String password) {
        return passwordStore.verifyPassword(password);
    }
}
