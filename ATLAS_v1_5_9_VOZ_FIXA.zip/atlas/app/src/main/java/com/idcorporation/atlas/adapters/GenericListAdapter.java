package com.idcorporation.atlas.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.ViewAnimUtils;

import java.util.ArrayList;

public class GenericListAdapter extends RecyclerView.Adapter<GenericListAdapter.RowViewHolder> {

    private static final long STAGGER_DELAY_MS = 40;

    public interface OnRowDeleteListener {
        void onDelete(long rowId);
    }

    /** Optional: tapping the row itself (e.g. to edit it). Null means rows are not clickable. */
    public interface OnRowClickListener {
        void onRowClick(long rowId);
    }

    private final ArrayList<RowItem> items;
    private final OnRowDeleteListener deleteListener;
    private final OnRowClickListener clickListener;

    public GenericListAdapter(ArrayList<RowItem> items, OnRowDeleteListener deleteListener) {
        this(items, deleteListener, null);
    }

    public GenericListAdapter(ArrayList<RowItem> items, OnRowDeleteListener deleteListener,
                               OnRowClickListener clickListener) {
        this.items = items;
        this.deleteListener = deleteListener;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public RowViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_list_row, parent, false);
        ViewAnimUtils.applyPressFeedback(view);
        return new RowViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RowViewHolder holder, int position) {
        final RowItem item = items.get(position);
        holder.primaryText.setText(item.getPrimaryText());
        holder.secondaryText.setText(item.getSecondaryText());
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (deleteListener != null) {
                    deleteListener.onDelete(item.getId());
                }
            }
        });

        if (clickListener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickListener.onRowClick(item.getId());
                }
            });
        } else {
            holder.itemView.setOnClickListener(null);
            holder.itemView.setClickable(false);
        }

        long delay = Math.min(position, 8) * STAGGER_DELAY_MS;
        ViewAnimUtils.animateEntrance(holder.itemView, delay);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class RowViewHolder extends RecyclerView.ViewHolder {
        TextView primaryText;
        TextView secondaryText;
        ImageButton deleteButton;

        RowViewHolder(View itemView) {
            super(itemView);
            primaryText = (TextView) itemView.findViewById(R.id.text_line_primary);
            secondaryText = (TextView) itemView.findViewById(R.id.text_line_secondary);
            deleteButton = (ImageButton) itemView.findViewById(R.id.button_delete_row);
        }
    }
}
