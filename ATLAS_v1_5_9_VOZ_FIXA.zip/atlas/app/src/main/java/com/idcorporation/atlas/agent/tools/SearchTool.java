package com.idcorporation.atlas.agent.tools;

import com.idcorporation.atlas.agent.ToolResult;
import com.idcorporation.atlas.agent.panel.PanelData;
import com.idcorporation.atlas.ai.ApiKeyConfig;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Real search results. With a Brave Search key (ApiKeyConfig) it searches
 * the whole web - products, prices, anything. Without a key it falls back
 * to two free sources (Wikipedia and DuckDuckGo's instant answers), which
 * are good for facts and topics but NOT for shopping or local business
 * lookups; the result says which source answered so the user is never
 * misled about it.
 */
public class SearchTool extends BaseTool {

    public SearchTool(ToolEnv env) {
        super(env);
    }

    @Override
    public String name() {
        return "web_search";
    }

    @Override
    public String description() {
        return "Search the web for facts, products or information and show the results in a panel.";
    }

    @Override
    public JSONObject parameters() {
        return Schema.obj().str("query", "What to search for.", true).build();
    }

    @Override
    public boolean returnsUntrustedContent() {
        return true;
    }

    @Override
    public ToolResult execute(JSONObject args) throws Exception {
        String query = arg(args, "query");
        if (query.length() == 0) {
            return ToolResult.failed("Missing query.");
        }
        PanelData panel = new PanelData();
        panel.type = PanelData.TYPE_SEARCH;
        panel.title = query;
        panel.subtitle = env.context.getString(com.idcorporation.atlas.R.string.panel_search_title);

        if (ApiKeyConfig.isSearchConfigured()) {
            try {
                String lang = env.lang();
                String raw = Http.get("https://api.search.brave.com/res/v1/web/search?count=8&q=" + Http.enc(query)
                    + "&search_lang=" + Http.enc(lang), "Accept", "application/json",
                    "X-Subscription-Token", ApiKeyConfig.BRAVE_SEARCH_API_KEY);
                addBrave(panel, new JSONObject(raw));
                panel.source = "Brave Search";
            } catch (Exception e) {
                // Fall through to the free sources below.
            }
        }
        if (panel.rows.isEmpty()) {
            addDuckDuckGo(panel, query);
            addWikipedia(panel, query, env.lang());
            if (!panel.rows.isEmpty()) {
                panel.source = "DuckDuckGo / Wikipedia";
            }
        }
        if (panel.rows.isEmpty()) {
            return ToolResult.failed("No results from the available sources"
                + (ApiKeyConfig.isSearchConfigured() ? "." : " (full web search needs a Brave Search key, which is not set up)."));
        }
        JSONArray summary = new JSONArray();
        for (int i = 0; i < panel.rows.size() && i < 4; i++) {
            PanelData.Row r = panel.rows.get(i);
            JSONObject s = new JSONObject();
            s.put("title", r.title);
            s.put("snippet", clip(r.subtitle, 120));
            summary.put(s);
        }
        JSONObject data = new JSONObject();
        data.put("source", panel.source);
        data.put("results", summary);
        String note = ApiKeyConfig.isSearchConfigured() ? "" : " Limited free sources (facts/topics); not a full web or shopping search.";
        return ToolResult.ok("Real results from " + panel.source + ". A results panel is on screen." + note, data)
            .withPanel(panel);
    }

    static void addBrave(PanelData panel, JSONObject root) {
        JSONObject web = root.optJSONObject("web");
        JSONArray results = web == null ? null : web.optJSONArray("results");
        if (results == null) {
            return;
        }
        for (int i = 0; i < results.length() && panel.rows.size() < 8; i++) {
            JSONObject r = results.optJSONObject(i);
            if (r == null) continue;
            String url = r.optString("url", "");
            if (!url.startsWith("https://") && !url.startsWith("http://")) continue;
            panel.rows.add(new PanelData.Row(stripTags(r.optString("title", "")),
                stripTags(r.optString("description", "")), hostOf(url), url));
        }
    }

    private void addDuckDuckGo(PanelData panel, String query) {
        try {
            JSONObject o = new JSONObject(Http.get("https://api.duckduckgo.com/?q=" + Http.enc(query)
                + "&format=json&no_html=1&skip_disambig=1&t=atlas"));
            String abs = o.optString("AbstractText", "");
            String url = o.optString("AbstractURL", "");
            if (abs.length() > 0 && url.startsWith("http")) {
                panel.rows.add(new PanelData.Row(o.optString("Heading", query), abs, hostOf(url), url));
            }
            JSONArray related = o.optJSONArray("RelatedTopics");
            for (int i = 0; related != null && i < related.length() && panel.rows.size() < 4; i++) {
                JSONObject r = related.optJSONObject(i);
                if (r == null) continue;
                String text = r.optString("Text", "");
                String link = r.optString("FirstURL", "");
                if (text.length() > 0 && link.startsWith("http")) {
                    panel.rows.add(new PanelData.Row(clip(text, 80), text, hostOf(link), link));
                }
            }
        } catch (Exception ignored) {
            // This source is optional.
        }
    }

    private void addWikipedia(PanelData panel, String query, String lang) {
        try {
            String wl = ("pt es fr de it pl en").contains(lang) ? lang : "en";
            JSONObject o = new JSONObject(Http.get("https://" + wl + ".wikipedia.org/w/api.php?action=query&list=search"
                + "&srsearch=" + Http.enc(query) + "&srlimit=4&format=json&utf8=1"));
            JSONArray hits = o.getJSONObject("query").getJSONArray("search");
            for (int i = 0; i < hits.length() && panel.rows.size() < 8; i++) {
                JSONObject h = hits.getJSONObject(i);
                String title = h.optString("title", "");
                panel.rows.add(new PanelData.Row(title, stripTags(h.optString("snippet", "")) + "...",
                    wl + ".wikipedia.org", "https://" + wl + ".wikipedia.org/wiki/" + Http.enc(title.replace(' ', '_'))));
            }
        } catch (Exception ignored) {
            // This source is optional.
        }
    }

    static String stripTags(String html) {
        if (html == null) return "";
        return html.replaceAll("<[^>]*>", "").replace("&quot;", "\"").replace("&amp;", "&")
            .replace("&#39;", "'").replace("&nbsp;", " ").trim();
    }

    private static String hostOf(String url) {
        try {
            return new java.net.URL(url).getHost();
        } catch (Exception e) {
            return "";
        }
    }
}
