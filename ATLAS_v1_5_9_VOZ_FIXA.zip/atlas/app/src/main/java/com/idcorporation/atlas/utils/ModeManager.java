package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.idcorporation.atlas.activities.ChatActivity;
import com.idcorporation.atlas.activities.MainActivity;

/**
 * ATLAS MODOS: remembers how the user talks to ATLAS.
 *
 *  - MODE_VOICE: the original experience (always-on microphone, ATLAS
 *    answers out loud). This is the default, so nobody's app changes
 *    after updating until they choose Chat on their own.
 *  - MODE_CHAT: text only. No microphone, no speech, no Presence bubble.
 *
 * Every place that used to open MainActivity as "home" can ask this
 * class which screen is home right now.
 */
public class ModeManager {

    public static final int MODE_VOICE = 0;
    public static final int MODE_CHAT = 1;

    private static final String PREFS_NAME = "atlas_mode_prefs";
    private static final String KEY_MODE = "app_mode";

    private ModeManager() {
    }

    public static int getMode(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int stored = prefs.getInt(KEY_MODE, MODE_VOICE);
        if (stored != MODE_CHAT) {
            return MODE_VOICE;
        }
        return MODE_CHAT;
    }

    public static void setMode(Context context, int mode) {
        int safeMode = (mode == MODE_CHAT) ? MODE_CHAT : MODE_VOICE;
        context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_MODE, safeMode)
            .commit();
    }

    public static boolean isChatMode(Context context) {
        return getMode(context) == MODE_CHAT;
    }

    public static boolean isVoiceMode(Context context) {
        return getMode(context) == MODE_VOICE;
    }

    /** Intent for the screen that is "home" in the current mode (no flags set). */
    public static Intent homeIntent(Context context) {
        if (isChatMode(context)) {
            return new Intent(context, ChatActivity.class);
        }
        return new Intent(context, MainActivity.class);
    }
}
