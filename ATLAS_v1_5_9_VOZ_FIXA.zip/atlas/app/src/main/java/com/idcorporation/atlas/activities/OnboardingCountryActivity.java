package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.CountryCatalog;
import com.idcorporation.atlas.utils.CountryOption;
import com.idcorporation.atlas.utils.LocaleHelper;
import com.idcorporation.atlas.utils.SoundManager;
import com.idcorporation.atlas.utils.UserProfileManager;

import java.util.ArrayList;
import java.util.Locale;

/**
 * First onboarding question, right after the welcome screen: "What is
 * your country?". The answer both gets stored on the profile and picks
 * the app's initial language (through LocaleHelper, the app's single
 * source of truth for language) so the rest of onboarding, and the app
 * itself, opens already speaking a language close to the user's.
 */
public class OnboardingCountryActivity extends OnboardingStepActivity {

    private static final int STEP_INDEX = 0;
    private static final int TOTAL_STEPS = 6;

    private final ArrayList<View> countryRows = new ArrayList<View>();
    private String selectedIsoCode = null;
    private String selectedLanguageCode = null;

    private TextView errorText;
    private View continueButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_country);

        View backButton = findViewById(R.id.button_step_back);
        ViewGroup dotsContainer = (ViewGroup) findViewById(R.id.container_step_dots);
        View badge = findViewById(R.id.badge_country);
        View title = findViewById(R.id.text_country_question);
        EditText searchInput = (EditText) findViewById(R.id.input_country_search);
        errorText = (TextView) findViewById(R.id.text_country_error);
        continueButton = findViewById(R.id.button_country_continue);

        renderProgressDots(dotsContainer, STEP_INDEX, TOTAL_STEPS);
        animateEntrance(badge, title, searchInput, null, continueButton);

        buildCountryRows();

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterRows(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bounceButton(continueButton);
                attemptContinue();
            }
        });
    }

    private void buildCountryRows() {
        LinearLayout container = (LinearLayout) findViewById(R.id.container_country_rows);
        LayoutInflater inflater = LayoutInflater.from(this);
        ArrayList<CountryOption> countries = CountryCatalog.getAllCountries();

        for (int i = 0; i < countries.size(); i = i + 1) {
            final CountryOption option = countries.get(i);
            View row = inflater.inflate(R.layout.item_country_row, container, false);
            row.setTag(option);

            ((TextView) row.findViewById(R.id.text_country_flag)).setText(option.getFlagEmoji());
            ((TextView) row.findViewById(R.id.text_country_name)).setText(option.getDisplayName());

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectCountry(option);
                }
            });

            container.addView(row);
            countryRows.add(row);
        }
    }

    private void selectCountry(CountryOption option) {
        SoundManager.playScifiClick(this);
        selectedIsoCode = option.getIsoCode();
        selectedLanguageCode = option.getLanguageCode();
        errorText.setVisibility(View.GONE);
        refreshRowSelection();
    }

    private void refreshRowSelection() {
        for (int i = 0; i < countryRows.size(); i = i + 1) {
            View row = countryRows.get(i);
            CountryOption option = (CountryOption) row.getTag();
            boolean isSelected = option.getIsoCode().equals(selectedIsoCode);
            ImageView check = (ImageView) row.findViewById(R.id.check_country_item);
            check.setVisibility(isSelected ? View.VISIBLE : View.GONE);
        }
    }

    private void filterRows(String rawQuery) {
        String query = rawQuery.trim().toLowerCase(Locale.ENGLISH);
        for (int i = 0; i < countryRows.size(); i = i + 1) {
            View row = countryRows.get(i);
            CountryOption option = (CountryOption) row.getTag();
            boolean matches = query.length() == 0
                || option.getDisplayName().toLowerCase(Locale.ENGLISH).contains(query);
            row.setVisibility(matches ? View.VISIBLE : View.GONE);
        }
    }

    private void attemptContinue() {
        if (selectedIsoCode == null || selectedLanguageCode == null) {
            showFieldError(errorText, getString(R.string.error_country_required));
            return;
        }

        new UserProfileManager(this).setCountry(selectedIsoCode);
        LocaleHelper.setSavedLanguage(this, selectedLanguageCode);

        Intent next = buildForwardIntent(OnboardingNameActivity.class);
        goToNext(next);
    }
}
