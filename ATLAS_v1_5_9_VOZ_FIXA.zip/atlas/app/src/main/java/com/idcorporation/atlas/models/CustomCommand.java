package com.idcorporation.atlas.models;

public class CustomCommand {

    public static final String ACTION_OPEN_APP = "OPEN_APP";
    public static final String ACTION_OPEN_URL = "OPEN_URL";
    public static final String ACTION_OPEN_SETTING = "OPEN_SETTING";

    private long id;
    private String phrase;
    private String actionType;
    private String actionValue;

    public CustomCommand(long id, String phrase, String actionType, String actionValue) {
        this.id = id;
        this.phrase = phrase;
        this.actionType = actionType;
        this.actionValue = actionValue;
    }

    public long getId() {
        return id;
    }

    public String getPhrase() {
        return phrase;
    }

    public String getActionType() {
        return actionType;
    }

    public String getActionValue() {
        return actionValue;
    }
}
