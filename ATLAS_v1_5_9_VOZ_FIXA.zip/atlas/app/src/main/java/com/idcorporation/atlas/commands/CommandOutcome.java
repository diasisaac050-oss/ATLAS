package com.idcorporation.atlas.commands;

public class CommandOutcome {

    public static final int TYPE_HANDLED = 0;
    public static final int TYPE_NEEDS_CONFIRMATION = 1;
    public static final int TYPE_AI_QUESTION = 2;

    private int type;
    private String spokenResponse;
    private ConfirmAction confirmedAction;

    public CommandOutcome(int type, String spokenResponse, ConfirmAction confirmedAction) {
        this.type = type;
        this.spokenResponse = spokenResponse;
        this.confirmedAction = confirmedAction;
    }

    public static CommandOutcome handled(String spokenResponse) {
        return new CommandOutcome(TYPE_HANDLED, spokenResponse, null);
    }

    public static CommandOutcome needsConfirmation(String confirmationPrompt, ConfirmAction action) {
        return new CommandOutcome(TYPE_NEEDS_CONFIRMATION, confirmationPrompt, action);
    }

    public static CommandOutcome forwardToAI() {
        return new CommandOutcome(TYPE_AI_QUESTION, null, null);
    }

    public int getType() {
        return type;
    }

    public String getSpokenResponse() {
        return spokenResponse;
    }

    public ConfirmAction getConfirmedAction() {
        return confirmedAction;
    }
}
