package com.idcorporation.atlas.sphere;

import android.content.Context;
import android.graphics.Canvas;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * ATLAS ESFERA: the Atlas itself, drawn live as a 3D particle sphere.
 *
 * This is only the Android glue. All the 3D maths is in SphereEngine; this
 * view runs the frame loop, forwards touch / audio / tilt to it, and draws
 * what it produces with additive blending on a Canvas (so the glow adds up
 * over whatever theme background sits behind it).
 *
 * Everything is coloured from one accent colour - call setAccentColor with
 * the theme's accent and the whole sphere follows.
 *
 * The view is transparent: it never paints a background, so animated theme
 * backgrounds stay visible behind it.
 */
public class AtlasSphereView extends View implements SensorEventListener {

    private SphereEngine engine = new SphereEngine();
    private final SphereCanvasPainter painter = new SphereCanvasPainter();

    private boolean running = false;
    private long lastFrameNanos = 0L;

    // adaptive quality: if drawing keeps taking too long, drop to the lighter tier
    private long costNanosSum = 0L;
    private int costFrames = 0;
    private static final long SLOW_NANOS = 11_000_000L;
    private static final int COST_WINDOW = 90;

    // parallax from the accelerometer
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float fastX, fastY, slowX, slowY;
    private boolean sensorSeeded = false;
    private boolean sensorRegistered = false;

    // ------------------------------------------------------------------
    // awakening (splash): the core grows from a point, white, then takes the theme colour
    // ------------------------------------------------------------------
    /** Called once the awakening has fully finished (core expanded and tinted). */
    public interface AwakenListener {
        /** The core has finished expanding: switch the colour / background now. */
        void onExpanded();
        /** The colour change is done. */
        void onTinted();
    }

    private static final long AWAKEN_EXPAND_MS = 2300L;
    private static final long AWAKEN_TINT_MS = 600L;
    private boolean awakening = false;
    private long awakenStart = 0L;
    private boolean awakenExpandedFired = false;
    private boolean awakenTintedFired = false;
    private int awakenThemeColor = 0xFF00E5FF;
    private float awakenInsetTop = 0f, awakenInsetBottom = 0f;
    private AwakenListener awakenListener;

    /**
     * Starts the awakening. The sphere is placed as it will be on the Home:
     * centred in the area left after removing insetTopPx / insetBottomPx.
     */
    public void startAwakening(int themeColor, float insetTopPx, float insetBottomPx, AwakenListener l) {
        awakenThemeColor = themeColor;
        awakenInsetTop = insetTopPx;
        awakenInsetBottom = insetBottomPx;
        awakenListener = l;
        awakening = true;
        awakenStart = 0L;
        awakenExpandedFired = false;
        awakenTintedFired = false;
        engine.setAccentColor(0xFFFFFFFF);
        engine.setMasterAlpha(0f);
        engine.setState(SphereEngine.STATE_PROCESSING);
        invalidate();
    }

    // ------------------------------------------------------------------
    // handoff (splash -> Home): the Home keeps drawing the very same sphere
    // ------------------------------------------------------------------
    private static SphereEngine sHandoffEngine = null;
    private static float sHandoffOriginX = 0f, sHandoffOriginY = 0f;
    private static final long SETTLE_MS = 450L;

    private boolean settlePending = false;
    private boolean settleActive = false;
    private long settleStart = 0L;
    private float settleFromX, settleFromY, settleFromR;
    private float settleScreenX, settleScreenY, settleScreenR;

    /** Splash side: leaves this view's live sphere (particles, rotation, colour) for the Home to pick up. */
    public void publishForHandoff() {
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        sHandoffOriginX = loc[0];
        sHandoffOriginY = loc[1];
        sHandoffEngine = engine;
    }

    /**
     * Home side: takes the sphere the splash left, so there is no second sphere
     * appearing - the same one simply carries on. If the Home's sphere sits
     * slightly differently from where the splash placed it, it glides there.
     */
    public void adoptHandoff() {
        SphereEngine e = sHandoffEngine;
        sHandoffEngine = null;
        if (e == null) {
            return;
        }
        engine = e;
        settleScreenX = e.getCenterX() + sHandoffOriginX;
        settleScreenY = e.getCenterY() + sHandoffOriginY;
        settleScreenR = e.getRadius();
        settlePending = true;
        settleActive = false;
        // the sphere is already fully lit: no fade, no regrowth
        engine.setMasterAlpha(1f);
    }

    private void stepSettle(long nowNanos) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 1 || h <= 1) {
            return;
        }
        float dens = getResources().getDisplayMetrics().density;
        float toX = w * 0.5f;
        float toY = h * 0.5f;
        float toR = Math.min(w, h) * 0.5f / 1.46f;
        if (settlePending) {
            settlePending = false;
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            settleFromX = settleScreenX - loc[0];
            settleFromY = settleScreenY - loc[1];
            settleFromR = settleScreenR;
            settleStart = nowNanos;
            settleActive = true;
        }
        if (!settleActive) {
            return;
        }
        float t = Math.min(1f, (nowNanos - settleStart) / 1_000_000f / SETTLE_MS);
        float k = t * t * (3f - 2f * t);
        engine.setPlacement(
                settleFromX + (toX - settleFromX) * k,
                settleFromY + (toY - settleFromY) * k,
                settleFromR + (toR - settleFromR) * k,
                dens);
        if (t >= 1f) {
            settleActive = false;
            engine.setViewport(w, h, dens);
        }
    }

    private static float easeOutCubic(float x) {
        float u = 1f - x;
        return 1f - u * u * u;
    }

    private static int mixColor(int a, int b, float t) {
        int r = (int) (((a >> 16) & 0xFF) * (1f - t) + ((b >> 16) & 0xFF) * t);
        int g = (int) (((a >> 8) & 0xFF) * (1f - t) + ((b >> 8) & 0xFF) * t);
        int bl = (int) ((a & 0xFF) * (1f - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private void stepAwakening(long nowNanos) {
        if (awakenStart == 0L) {
            awakenStart = nowNanos;
        }
        float ms = (nowNanos - awakenStart) / 1_000_000f;
        float p = Math.min(1f, ms / AWAKEN_EXPAND_MS);

        int w = getWidth();
        int h = getHeight();
        float areaH = Math.max(1f, h - awakenInsetTop - awakenInsetBottom);
        float fullRad = Math.min(w, areaH) * 0.5f / 1.46f;
        float cx = w * 0.5f;
        float cy = awakenInsetTop + areaH * 0.5f;

        // size: a point of light that blooms outwards, slowing as it reaches full size
        float grow = easeOutCubic(p);
        float scale = 0.04f + 0.96f * grow;
        // brightness: starts from nothing, ignites over the first 55%
        float a = Math.min(1f, p / 0.55f);
        a = a * a * (3f - 2f * a);
        engine.setMasterAlpha(a);
        engine.setPlacement(cx, cy, fullRad * scale, getResources().getDisplayMetrics().density);

        if (p >= 1f) {
            if (!awakenExpandedFired) {
                awakenExpandedFired = true;
                engine.setState(SphereEngine.STATE_IDLE);
                engine.ping();
                if (awakenListener != null) {
                    awakenListener.onExpanded();
                }
            }
            float tt = Math.min(1f, (ms - AWAKEN_EXPAND_MS) / AWAKEN_TINT_MS);
            float k = tt * tt * (3f - 2f * tt);
            engine.setAccentColor(mixColor(0xFFFFFFFF, awakenThemeColor, k));
            if (tt >= 1f && !awakenTintedFired) {
                awakenTintedFired = true;
                engine.setAccentColor(awakenThemeColor);
                if (awakenListener != null) {
                    awakenListener.onTinted();
                }
            }
        }
    }

    public AtlasSphereView(Context context) {
        super(context);
        init(context);
    }

    public AtlasSphereView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public AtlasSphereView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        engine.setViewport(1, 1, context.getResources().getDisplayMetrics().density);
        try {
            sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
            if (sensorManager != null) {
                accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            }
        } catch (RuntimeException e) {
            sensorManager = null;
            accelerometer = null;
        }
    }

    // ------------------------------------------------------------------
    // public API (all main-thread)
    // ------------------------------------------------------------------

    /** The theme's accent colour; every particle, line, glow and wave follows it. */
    public void setAccentColor(int color) {
        engine.setAccentColor(color);
        invalidate();
    }

    /** One of HudStateManager.STATE_* (idle, listening, processing, thinking, speaking, executing, error, offline). */
    public void setState(int hudState) {
        engine.setState(hudState);
    }

    /** Raw microphone loudness (roughly -2..10 dB) from the voice session. */
    public void setAudioLevelDb(float rmsDb) {
        engine.setAudioLevel((rmsDb + 2f) / 12f);
    }

    /** Start/stop the animation (call from onResume / onPause). */
    public void setRunning(boolean run) {
        if (run == running) {
            return;
        }
        running = run;
        if (run) {
            lastFrameNanos = 0L;
            registerSensor();
            postInvalidateOnAnimation();
        } else {
            unregisterSensor();
        }
    }

    // ------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (getWindowVisibility() == View.VISIBLE) {
            setRunning(true);
        }
        if (running) {
            postInvalidateOnAnimation();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        setRunning(false);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        setRunning(visibility == View.VISIBLE && isAttachedToWindow());
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (!awakening && !settlePending && !settleActive) {
            engine.setViewport(w, h, getResources().getDisplayMetrics().density);
        }
    }

    // ------------------------------------------------------------------
    // drawing
    // ------------------------------------------------------------------

    @Override
    protected void onDraw(Canvas canvas) {
        long start = System.nanoTime();
        float dt = 1f / 60f;
        if (lastFrameNanos != 0L) {
            dt = (start - lastFrameNanos) / 1_000_000_000f;
        }
        lastFrameNanos = start;

        if (awakening) {
            stepAwakening(start);
        }
        if (settlePending || settleActive) {
            stepSettle(start);
        }
        engine.update(dt);
        painter.canvas = canvas;
        engine.render(painter);
        painter.canvas = null;

        // adaptive quality (CPU cost of building the frame)
        costNanosSum += System.nanoTime() - start;
        costFrames++;
        if (costFrames >= COST_WINDOW) {
            long avg = costNanosSum / costFrames;
            if (avg > SLOW_NANOS && engine.getQuality() < 2) {
                engine.setQuality(engine.getQuality() + 1);
            }
            costNanosSum = 0L;
            costFrames = 0;
        }

        if (running) {
            postInvalidateOnAnimation();
        }
    }

    // ------------------------------------------------------------------
    // touch: tap = energy wave + burst, drag = rotate with inertia
    // ------------------------------------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (awakening) {
            return true;
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                engine.touchDown(event.getX(), event.getY());
                return true;
            case MotionEvent.ACTION_MOVE:
                engine.touchMove(event.getX(), event.getY());
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                engine.touchUp();
                return true;
            default:
                return true;
        }
    }

    // ------------------------------------------------------------------
    // parallax sensor
    // ------------------------------------------------------------------

    private void registerSensor() {
        if (sensorRegistered || sensorManager == null || accelerometer == null) {
            return;
        }
        try {
            sensorRegistered = sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
        } catch (RuntimeException e) {
            sensorRegistered = false;
        }
    }

    private void unregisterSensor() {
        if (!sensorRegistered || sensorManager == null) {
            return;
        }
        try {
            sensorManager.unregisterListener(this);
        } catch (RuntimeException e) {
            // nothing to do
        }
        sensorRegistered = false;
        sensorSeeded = false;
        engine.setTilt(0f, 0f);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float ax = event.values[0];
        float ay = event.values[1];
        if (!sensorSeeded) {
            fastX = ax; fastY = ay; slowX = ax; slowY = ay;
            sensorSeeded = true;
        }
        // fast low-pass = where the phone is now; slow low-pass = where it has
        // been resting. The difference is "the user moved the phone".
        fastX += (ax - fastX) * 0.18f;
        fastY += (ay - fastY) * 0.18f;
        slowX += (ax - slowX) * 0.006f;
        slowY += (ay - slowY) * 0.006f;
        engine.setTilt(-(fastX - slowX) / 4.5f, (fastY - slowY) / 4.5f);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // not needed
    }
}
