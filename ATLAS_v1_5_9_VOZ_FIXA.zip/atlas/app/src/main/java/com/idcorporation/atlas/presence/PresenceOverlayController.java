package com.idcorporation.atlas.presence;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.idcorporation.atlas.AtlasApplication;
import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.HudStateManager;
import com.idcorporation.atlas.activities.MainActivity;
import com.idcorporation.atlas.utils.PresenceManager;
import com.idcorporation.atlas.utils.SoundManager;
import com.idcorporation.atlas.voice.AtlasVoiceSession;

/**
 * Owns the floating window for the shake gesture: the glass bubble (or the
 * bottom-rising orb, whichever the user picked in Settings) plus a caption
 * pill with what ATLAS heard and answered. There are no buttons -
 * the mic is on the moment the bubble appears (it drives the app-wide
 * AtlasVoiceSession, so it behaves exactly like the app itself), a double
 * tap opens the full app, a tap while ATLAS talks silences him, and
 * touch-and-hold (or a swipe up, or a quiet spell) makes the bubble
 * disappear. Dragging the sphere sideways parks it, small, at that edge of
 * the screen: the call keeps going and the rest of the screen stays touchable
 * (double tap on the parked sphere brings it back, hold closes it).
 */
public class PresenceOverlayController implements PresenceSessionBridge.Host {

    private final Context context;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private WindowManager windowManager;
    private View root;
    private PresenceBubbleView bubble;
    private PresenceCaption caption;
    private PresenceSessionBridge bridge;
    private boolean showing = false;
    private WindowManager.LayoutParams windowParams;
    private boolean docked = false;
    private boolean dockingInProgress = false;
    private ValueAnimator windowMoveAnimator;
    private int dragStartX = 0;
    private int dragStartY = 0;
    private int dragRestX = 0;
    private int layoutInUse = PresenceManager.LAYOUT_GLASS;

    // Lets ScreenshotService find the bubble that is currently on screen (if
    // any) without the two classes knowing about each other directly. Only
    // ever points at a controller whose window is actually up; cleared the
    // moment that window comes down.
    private static java.lang.ref.WeakReference<PresenceOverlayController> activeInstance;

    public PresenceOverlayController(Context context) {
        this.context = context.getApplicationContext();
    }

    public boolean isShowing() {
        return showing;
    }

    /**
     * Hides the bubble's own window for the duration of a screenshot so it
     * never shows up in the captured frame, then restores it right after.
     * Safe to call even when no bubble is currently showing (no-op then).
     * Must be called from the main thread.
     */
    public static void hideForScreenshot() {
        PresenceOverlayController controller = activeInstance != null ? activeInstance.get() : null;
        if (controller != null && controller.root != null) {
            controller.root.setVisibility(View.INVISIBLE);
        }
    }

    public static void restoreAfterScreenshot() {
        PresenceOverlayController controller = activeInstance != null ? activeInstance.get() : null;
        if (controller != null && controller.root != null) {
            controller.root.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Puts the bubble on screen (window + animation + session wiring) but
     * does not open the microphone: the service calls beginCall() when the
     * microphone is really available.
     *
     * @return true only when a NEW bubble was created by this call.
     */
    public boolean show() {
        if (showing) {
            if (bridge != null) {
                bridge.resetIdle();
            }
            return false;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            return false;
        }
        removeWindowNow();
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (windowManager == null) {
            return false;
        }

        // Read the user's choice every time, so changing it in Settings
        // applies on the very next shake without restarting the service.
        layoutInUse = PresenceManager.getLayout(context);
        int layoutRes;
        if (layoutInUse == PresenceManager.LAYOUT_ORB) {
            layoutRes = R.layout.overlay_presence_orb;
        } else if (layoutInUse == PresenceManager.LAYOUT_NUCLEUS) {
            layoutRes = R.layout.overlay_presence_nucleus;
        } else {
            layoutRes = R.layout.overlay_presence;
        }
        root = LayoutInflater.from(context).inflate(layoutRes, null);
        FrameLayout holder = (FrameLayout) root.findViewById(R.id.presence_bubble_holder);
        TextView captionView = (TextView) root.findViewById(R.id.presence_caption);
        caption = new PresenceCaption(captionView);
        bubble = new PresenceBubbleView(context, layoutInUse);
        holder.addView(bubble);
        bridge = new PresenceSessionBridge(context, bubble, caption, this);
        attachTouch();

        docked = false;
        dockingInProgress = false;
        try {
            windowParams = PresenceWindowFactory.build(context, layoutInUse);
            windowManager.addView(root, windowParams);
        } catch (Exception e) {
            removeWindowNow();
            return false;
        }
        showing = true;
        activeInstance = new java.lang.ref.WeakReference<>(this);
        bubble.playOpen();
        SoundManager.playPresenceOpen(context);
        bridge.start();
        return true;
    }

    /** Turns the microphone on for the bubble that is showing. */
    public void beginCall() {
        if (showing && bridge != null) {
            bridge.beginCall();
        }
    }

    /** Restarts the listening turn (the microphone permission of the service arrived late). */
    public void refreshCall() {
        if (showing && bridge != null) {
            bridge.refreshCall();
        }
    }

    /** Normal retract: sound + animation, and the call is closed. */
    public void hide() {
        if (!showing) {
            return;
        }
        showing = false;
        bridge.stop();
        AtlasApplication.voiceSession(context).endPresenceCall();
        SoundManager.playPresenceClose(context);
        caption.hideNow();
        // The close animation ends later. If a new bubble was opened in the
        // meantime, this callback must remove only ITS OWN window - it used
        // to tear down the brand new bubble (call alive, nothing on screen).
        final View closingRoot = root;
        bubble.playClose(new Runnable() {
            @Override
            public void run() {
                if (root == closingRoot) {
                    removeWindowNow();
                }
            }
        });
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!showing && root == closingRoot) {
                    removeWindowNow();
                }
            }
        }, 1100);
    }

    /** Hands the running call to the full app: no close sound, mic keeps listening. */
    public void handOverToApp() {
        if (!showing) {
            return;
        }
        showing = false;
        bridge.stop();
        AtlasApplication.voiceSession(context).detachPresence();
        removeWindowNow();
    }

    /** Service is dying: no animation, just clean everything up. */
    public void destroy() {
        if (showing) {
            showing = false;
            bridge.stop();
            AtlasApplication.voiceSession(context).endPresenceCall();
        }
        removeWindowNow();
    }

    @Override
    public void requestHide() {
        hide();
    }

    @Override
    public void requestHandOver() {
        handOverToApp();
    }

    private void removeWindowNow() {
        cancelWindowMove();
        docked = false;
        dockingInProgress = false;
        windowParams = null;
        if (activeInstance != null && activeInstance.get() == this) {
            activeInstance = null;
        }
        if (bubble != null) {
            bubble.release();
            bubble = null;
        }
        if (root != null && windowManager != null) {
            try {
                windowManager.removeView(root);
            } catch (Exception e) {
                // Window was already detached; nothing else to clean up.
            }
        }
        root = null;
        caption = null;
        bridge = null;
    }

    private void attachTouch() {
        // Orb and nucleus rise from the bottom, so they are dismissed by swiping down.
        boolean dismissDownward = (layoutInUse == PresenceManager.LAYOUT_ORB
            || layoutInUse == PresenceManager.LAYOUT_NUCLEUS);
        root.setOnTouchListener(new PresenceTouchHandler(context, bubble, dismissDownward,
            new PresenceTouchHandler.Callback() {
                @Override
                public void onDoubleTap() {
                    if (docked) {
                        restoreFromDock();
                    } else {
                        openFullApp();
                    }
                }

                @Override
                public void onSingleTap() {
                    handleSingleTap();
                }

                @Override
                public void onLongPress() {
                    hide();
                }

                @Override
                public void onSwipeUp() {
                    hide();
                }

                @Override
                public void onTouched() {
                    if (bridge != null) {
                        bridge.resetIdle();
                    }
                }

                @Override
                public void onDragStart() {
                    beginWindowDrag();
                }

                @Override
                public void onDrag(float dx, float dy) {
                    moveWindowDrag(dx, dy);
                }

                @Override
                public void onDragEnd(float dx, float dy) {
                    endWindowDrag();
                }

                @Override
                public boolean isDocked() {
                    return docked || dockingInProgress;
                }
            }));
    }

    // ---------------------------------------------------------------
    // Parking the sphere at the side of the screen
    // ---------------------------------------------------------------

    private int dp(float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private int screenWidth() {
        return context.getResources().getDisplayMetrics().widthPixels;
    }

    private int screenHeight() {
        return context.getResources().getDisplayMetrics().heightPixels;
    }

    private static int clampInt(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private void updateWindow() {
        if (windowManager == null || root == null || windowParams == null) {
            return;
        }
        try {
            windowManager.updateViewLayout(root, windowParams);
        } catch (Exception e) {
            // The window is already gone; nothing to move.
        }
    }

    private void cancelWindowMove() {
        if (windowMoveAnimator != null) {
            windowMoveAnimator.removeAllListeners();
            windowMoveAnimator.cancel();
            windowMoveAnimator = null;
        }
    }

    /** Slides the window sideways to x (top-left gravity), then runs the callback. */
    private void animateWindowX(int to, long duration, final Runnable onEnd) {
        cancelWindowMove();
        if (windowParams == null) {
            return;
        }
        windowMoveAnimator = ValueAnimator.ofInt(windowParams.x, to);
        windowMoveAnimator.setDuration(duration);
        windowMoveAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
        windowMoveAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                if (windowParams == null || root == null) {
                    animation.cancel();
                    return;
                }
                windowParams.x = ((Integer) animation.getAnimatedValue()).intValue();
                updateWindow();
            }
        });
        windowMoveAnimator.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled = false;

            @Override
            public void onAnimationCancel(Animator animation) {
                cancelled = true;
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (!cancelled && onEnd != null) {
                    onEnd.run();
                }
            }
        });
        windowMoveAnimator.start();
    }

    private void beginWindowDrag() {
        if (!showing || root == null || windowParams == null || dockingInProgress) {
            return;
        }
        cancelWindowMove();
        if (!docked) {
            // Freeze the window where it is on screen, switching to absolute top-left
            // coordinates so it can follow the finger; remember the centred x to spring back to.
            int[] loc = new int[2];
            root.getLocationOnScreen(loc);
            dragRestX = loc[0];
            windowParams.gravity = Gravity.TOP | Gravity.LEFT;
            windowParams.x = loc[0];
            windowParams.y = loc[1];
            updateWindow();
        }
        dragStartX = windowParams.x;
        dragStartY = windowParams.y;
    }

    private void moveWindowDrag(float dx, float dy) {
        if (!showing || root == null || windowParams == null || dockingInProgress) {
            return;
        }
        int rw = Math.max(1, root.getWidth());
        int rh = Math.max(1, root.getHeight());
        windowParams.x = clampInt(dragStartX + Math.round(dx), -rw / 2, screenWidth() - rw / 2);
        if (docked) {
            windowParams.y = clampInt(dragStartY + Math.round(dy), 0, Math.max(0, screenHeight() - rh));
        }
        updateWindow();
    }

    private void endWindowDrag() {
        if (!showing || root == null || windowParams == null || dockingInProgress) {
            return;
        }
        int sw = screenWidth();
        int rw = Math.max(1, root.getWidth());
        if (docked) {
            snapDockedToEdge();
            return;
        }
        float sphereX = windowParams.x + rw / 2f;
        float off = sphereX - sw / 2f;
        if (Math.abs(off) > sw * 0.2f) {
            dockTo(off < 0f);
        } else {
            // Not dragged far enough: glide back to where it was and go back to the normal anchor.
            animateWindowX(dragRestX, 220, new Runnable() {
                @Override
                public void run() {
                    if (showing && root != null && !docked) {
                        windowParams = PresenceWindowFactory.build(context, layoutInUse);
                        updateWindow();
                    }
                }
            });
        }
    }

    /** Phase 1: the sphere contracts to its parked size; phase 2 (finishDock) shrinks the window and slides it to the edge. */
    private void dockTo(final boolean left) {
        if (!showing || bubble == null || dockingInProgress) {
            return;
        }
        dockingInProgress = true;
        if (caption != null) {
            caption.setSuppressed(true);
        }
        bubble.shrinkToDock(new Runnable() {
            @Override
            public void run() {
                finishDock(left);
            }
        });
    }

    private void finishDock(boolean left) {
        if (!showing || root == null || bubble == null || windowParams == null) {
            dockingInProgress = false;
            return;
        }
        int[] bl = new int[2];
        bubble.getLocationOnScreen(bl);
        float sphereX = bl[0] + bubble.getSphereCenterX();
        float sphereY = bl[1] + bubble.getSphereCenterY();
        int mini = dp(PresenceBubbleView.DOCK_VIEW_DP);

        setHolderDocked(true);
        bubble.setDocked(true);
        bubble.setTranslationY(0f);
        windowParams.gravity = Gravity.TOP | Gravity.LEFT;
        windowParams.x = Math.round(sphereX - mini / 2f);
        windowParams.y = clampInt(Math.round(sphereY - mini / 2f), 0, Math.max(0, screenHeight() - mini));
        updateWindow();
        docked = true;
        dockingInProgress = false;
        animateWindowX(edgeX(left, mini), 280, null);
    }

    private int edgeX(boolean left, int mini) {
        return left ? dp(2) : screenWidth() - mini - dp(2);
    }

    private void snapDockedToEdge() {
        if (windowParams == null || root == null) {
            return;
        }
        int mini = Math.max(1, root.getWidth());
        boolean left = (windowParams.x + mini / 2f) < screenWidth() / 2f;
        animateWindowX(edgeX(left, mini), 240, null);
    }

    /** The nucleus holder is a fixed 330x720dp surface; while parked it must wrap the small sphere instead. */
    private void setHolderDocked(boolean dockedNow) {
        if (root == null || layoutInUse != PresenceManager.LAYOUT_NUCLEUS) {
            return;
        }
        View holder = root.findViewById(R.id.presence_bubble_holder);
        if (holder == null) {
            return;
        }
        ViewGroup.LayoutParams lp = holder.getLayoutParams();
        lp.width = dockedNow ? ViewGroup.LayoutParams.WRAP_CONTENT : dp(330);
        lp.height = dockedNow ? ViewGroup.LayoutParams.WRAP_CONTENT : dp(720);
        holder.setLayoutParams(lp);
    }

    /** Brings the parked sphere back to its normal place, with its normal entrance. */
    private void restoreFromDock() {
        if (!showing || !docked || root == null || bubble == null) {
            return;
        }
        cancelWindowMove();
        docked = false;
        setHolderDocked(false);
        bubble.setDocked(false);
        if (caption != null) {
            caption.setSuppressed(false);
        }
        windowParams = PresenceWindowFactory.build(context, layoutInUse);
        updateWindow();
        bubble.playOpen();
    }

    private void handleSingleTap() {
        if (!showing) {
            return;
        }
        bridge.resetIdle();
        AtlasVoiceSession session = AtlasApplication.voiceSession(context);
        int state = session.getCurrentState();
        if (state == HudStateManager.STATE_SPEAKING) {
            session.interruptAndListen();
        } else if (state == HudStateManager.STATE_IDLE || state == HudStateManager.STATE_ERROR) {
            session.forceRestartListening();
        }
        bubble.pingRipple();
    }

    private void openFullApp() {
        if (!showing) {
            return;
        }
        handOverToApp();
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
            | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(intent);
    }
}
