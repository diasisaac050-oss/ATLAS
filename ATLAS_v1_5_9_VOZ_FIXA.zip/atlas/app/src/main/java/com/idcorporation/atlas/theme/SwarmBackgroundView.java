package com.idcorporation.atlas.theme;

import android.content.Context;
import android.graphics.Canvas;

import java.util.Random;

/**
 * SWARM: a flock of glowing agents that orbit two wandering centres, flowing
 * together and apart. Agents that come close are linked by faint lines that
 * brighten as they approach - the node network of the sphere, loose in space.
 */
public class SwarmBackgroundView extends FxBackgroundView {

    private static final int COUNT = 34;
    private static final int CENTRES = 2;

    private final float[] x = new float[COUNT];
    private final float[] y = new float[COUNT];
    private final float[] orbitR = new float[COUNT];
    private final float[] orbitA = new float[COUNT];
    private final float[] orbitW = new float[COUNT];
    private final float[] ph = new float[COUNT];
    private final float[] size = new float[COUNT];
    private final Random rng = new Random(11);
    private float link;

    public SwarmBackgroundView(Context context) {
        super(context);
    }

    @Override
    protected void onSized(int width, int height) {
        float m = Math.min(width, height);
        for (int i = 0; i < COUNT; i++) {
            orbitR[i] = rnd(rng, 0.07f, 0.30f) * m;
            orbitA[i] = rnd(rng, 0f, 6.283f);
            orbitW[i] = rnd(rng, 0.10f, 0.34f) * (rng.nextBoolean() ? 1f : -1f);
            ph[i] = rnd(rng, 0f, 6.283f);
            size[i] = rnd(rng, 0.6f, 1.5f);
            x[i] = rnd(rng, 0f, width);
            y[i] = rnd(rng, 0f, height);
        }
        link = m * 0.26f;
        linePaint.setStrokeWidth(Math.max(1f, 0.9f * dens));
    }

    @Override
    protected void drawFx(Canvas c, float dt) {
        float t = time;
        // two slow wandering centres (no allocation: computed inline)
        float c0x = w * (0.5f + 0.30f * (float) Math.sin(t * 0.17f));
        float c0y = h * (0.46f + 0.24f * (float) Math.sin(t * 0.23f + 1.3f));
        float c1x = w * (0.5f + 0.32f * (float) Math.sin(t * 0.13f + 3.1f));
        float c1y = h * (0.50f + 0.26f * (float) Math.sin(t * 0.19f + 4.4f));

        float follow = Math.min(1f, dt * 1.7f);
        for (int i = 0; i < COUNT; i++) {
            float ang = orbitA[i] + t * orbitW[i];
            float bx = (i % CENTRES == 0) ? c0x : c1x;
            float by = (i % CENTRES == 0) ? c0y : c1y;
            float tx = bx + (float) Math.cos(ang) * orbitR[i];
            float ty = by + (float) Math.sin(ang * 1.3f) * orbitR[i] * 0.8f;
            x[i] += (tx - x[i]) * follow;
            y[i] += (ty - y[i]) * follow;
        }

        // links
        float l2 = link * link;
        for (int i = 0; i < COUNT; i++) {
            for (int j = i + 1; j < COUNT; j++) {
                float dx = x[i] - x[j];
                float dy = y[i] - y[j];
                float d2 = dx * dx + dy * dy;
                if (d2 < l2) {
                    float k = 1f - d2 / l2;
                    linePaint.setAlpha((int) (255f * 0.34f * k * k));
                    c.drawLine(x[i], y[i], x[j], y[j], linePaint);
                }
            }
        }

        // agents
        for (int i = 0; i < COUNT; i++) {
            float pulse = 0.62f + 0.38f * (float) Math.sin(t * 1.5f + ph[i]);
            float r = 3.2f * dens * size[i];
            glow(c, x[i], y[i], r * 4.4f, 0.34f * pulse);
            glow(c, x[i], y[i], r * 1.8f, 0.80f * pulse);
            hotGlow(c, x[i], y[i], r * 0.8f, 0.95f * pulse);
        }
    }
}
