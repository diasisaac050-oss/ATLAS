package com.idcorporation.atlas.commands;

import com.idcorporation.atlas.calendar.DateTimeCommandParser;

public class CommandParser {

    public static boolean containsAny(String text, String[] keywords) {
        for (int i = 0; i < keywords.length; i++) {
            if (text.contains(keywords[i])) {
                return true;
            }
        }
        return false;
    }

    public static String extractAfterKeyword(String text, String keyword) {
        int index = text.indexOf(keyword);
        if (index == -1) {
            return "";
        }
        return text.substring(index + keyword.length()).trim();
    }

    private static final String[] OPEN_APP_PREFIXES = new String[]{
        "open ", "launch ", "start ",
        "abrir ", "abre ", "abra ", "inicie ", "iniciar ", "execute ", "executar ",
        "apri ", "avvia ",
        "ouvrir ", "ouvre ", "ouvrez ", "lance ", "lancer ",
        "abrelo ", "abrime ",
        "offne ", "oeffne ", "starte ",
        "otworz ", "uruchom "
    };

    /** Polite / wake-word openings that are removed before looking for the open trigger. */
    private static final String[] LEAD_INS = new String[]{
        "ei atlas ", "hey atlas ", "ok atlas ", "oi atlas ", "e ai atlas ", "atlas ",
        "por favor ", "please ", "voce pode ", "voce poderia ", "pode ", "poderia ",
        "consegue ", "da pra ", "quero que voce ", "quero que ", "eu quero ", "quero ",
        "gostaria de ", "preciso ", "can you ", "could you ", "would you ",
        "i want to ", "i want you to "
    };

    private static final String[] APP_FILLERS = new String[]{
        "o ", "a ", "os ", "as ", "um ", "uma ",
        "el ", "la ", "los ", "las ",
        "le ", "les ", "l'",
        "il ", "lo ", "i ", "gli ",
        "the ", "der ", "die ", "das ",
        "app ", "aplicativo ", "aplicacao ", "application ", "aplicacion ",
        "do ", "da ", "de ", "no ", "na "
    };

    private static final String[] TRAILING_FILLERS = new String[]{
        " por favor", " please", " para mim", " pra mim", " agora"
    };

    /**
     * Lowercase text with commas and punctuation at the end removed and
     * any polite opening ("atlas, por favor ...") stripped, so
     * "Atlas, por favor abrir o WhatsApp." still starts with "abrir ".
     */
    public static String cleanForOpen(String lowerText) {
        String s = lowerText.replace(",", " ").replaceAll("\\s+", " ").trim();
        while (s.length() > 0 && isTrailingPunctuation(s.charAt(s.length() - 1))) {
            s = s.substring(0, s.length() - 1).trim();
        }
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int i = 0; i < LEAD_INS.length; i++) {
                if (s.startsWith(LEAD_INS[i])) {
                    s = s.substring(LEAD_INS[i].length()).trim();
                    changed = true;
                    break;
                }
            }
        }
        return s;
    }

    private static boolean isTrailingPunctuation(char c) {
        return c == '.' || c == '!' || c == '?' || c == ';' || c == ':';
    }

    public static boolean isOpenAppCommand(String lowerText) {
        String s = cleanForOpen(lowerText);
        for (int i = 0; i < OPEN_APP_PREFIXES.length; i++) {
            if (s.startsWith(OPEN_APP_PREFIXES[i])) {
                return true;
            }
        }
        return false;
    }

    /**
     * Strips the open-app trigger prefix (any supported language), polite
     * openings, articles and words like "app"/"aplicativo", so "abrir o
     * aplicativo do whatsapp por favor", "ouvrir le whatsapp" and "open
     * the whatsapp" all resolve to the bare app name "whatsapp".
     */
    public static String extractAppNameFromOpenCommand(String lowerText) {
        String s = cleanForOpen(lowerText);
        String remainder = "";
        for (int i = 0; i < OPEN_APP_PREFIXES.length; i++) {
            if (s.startsWith(OPEN_APP_PREFIXES[i])) {
                remainder = s.substring(OPEN_APP_PREFIXES[i].length()).trim();
                break;
            }
        }
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int i = 0; i < APP_FILLERS.length; i++) {
                if (remainder.startsWith(APP_FILLERS[i])) {
                    remainder = remainder.substring(APP_FILLERS[i].length()).trim();
                    changed = true;
                    break;
                }
            }
            for (int i = 0; i < TRAILING_FILLERS.length; i++) {
                if (remainder.endsWith(TRAILING_FILLERS[i])) {
                    remainder = remainder.substring(0,
                        remainder.length() - TRAILING_FILLERS[i].length()).trim();
                    changed = true;
                    break;
                }
            }
        }
        return remainder;
    }

    public static boolean isSearchCommand(String lowerText) {
        return lowerText.startsWith("search for ") || lowerText.startsWith("search ") || lowerText.startsWith("google ")
            || lowerText.startsWith("pesquisar ") || lowerText.startsWith("procurar ") || lowerText.startsWith("busca ")
            || lowerText.startsWith("buscar ") || lowerText.startsWith("cerca ");
    }

    public static boolean isCallCommand(String lowerText) {
        return lowerText.startsWith("call ") || lowerText.startsWith("phone ")
            || lowerText.startsWith("ligar para ") || lowerText.startsWith("ligue para ")
            || lowerText.startsWith("llamar a ") || lowerText.startsWith("chiama ");
    }

    public static boolean isTimeRequest(String lowerText) {
        return containsAny(lowerText, new String[]{
            "what time is it", "current time", "que horas sao", "que horas s\u00e3o", "horas sao", "horas s\u00e3o",
            "que hora es", "che ore sono"
        });
    }

    public static boolean isDateRequest(String lowerText) {
        return containsAny(lowerText, new String[]{
            "what is the date", "what's the date", "today's date", "current date",
            "que dia e hoje", "que dia \u00e9 hoje", "data de hoje",
            "que fecha es hoy", "che giorno e oggi", "che giorno \u00e8 oggi"
        });
    }

    public static boolean isBatteryRequest(String lowerText) {
        return containsAny(lowerText, new String[]{"battery", "bateria", "bater\u00eda", "batteria"});
    }

    public static boolean isStorageRequest(String lowerText) {
        return containsAny(lowerText, new String[]{
            "storage", "free space", "armazenamento", "espaco livre", "espa\u00e7o livre",
            "almacenamiento", "espacio libre", "spazio di archiviazione", "spazio libero"
        });
    }

    public static boolean isMemorySaveCommand(String lowerText) {
        return containsAny(lowerText, new String[]{
            "my favorite", "minha cor favorita", "meu favorito", "minha favorita",
            "mi favorito", "mi favorita", "il mio preferito", "la mia preferita"
        }) || lowerText.startsWith("remember my") || lowerText.startsWith("remember i")
            || lowerText.startsWith("lembre que eu") || lowerText.startsWith("recuerda que yo")
            || lowerText.startsWith("ricorda che io");
    }

    public static boolean isMemoryQuestion(String lowerText) {
        return lowerText.startsWith("what is my") || lowerText.startsWith("what's my")
            || lowerText.startsWith("qual e o meu") || lowerText.startsWith("qual \u00e9 o meu")
            || lowerText.startsWith("qual e a minha") || lowerText.startsWith("qual \u00e9 a minha")
            || lowerText.startsWith("cual es mi") || lowerText.startsWith("qual e il mio")
            || lowerText.startsWith("qual \u00e8 il mio");
    }

    public static boolean isMemoryForgetAllCommand(String lowerText) {
        return containsAny(lowerText, new String[]{
            "forget everything", "delete all my memories", "clear my memory",
            "esquecer tudo", "apagar todas as minhas memorias", "apagar todas as minhas mem\u00f3rias",
            "olvida todo", "borrar todos mis recuerdos",
            "dimentica tutto", "cancella tutti i miei ricordi"
        });
    }

    public static boolean isCalculationCommand(String lowerText) {
        return containsAny(lowerText, new String[]{
            "calculate", "percent of", "square root",
            "calcular", "por cento de", "raiz quadrada",
            "porciento de", "raiz cuadrada",
            "calcola", "percento di", "radice quadrata"
        });
    }

    public static boolean isFlashlightOnCommand(String lowerText) {
        boolean mentionsFlashlight = containsAny(lowerText, new String[]{
            "flashlight", "lanterna", "linterna", "torcia"
        });
        boolean mentionsOn = containsAny(lowerText, new String[]{
            "on", "turn on", "ligar", "acender", "encender", "accendi"
        });
        return mentionsFlashlight && mentionsOn;
    }

    public static boolean isFlashlightOffCommand(String lowerText) {
        boolean mentionsFlashlight = containsAny(lowerText, new String[]{
            "flashlight", "lanterna", "linterna", "torcia"
        });
        boolean mentionsOff = containsAny(lowerText, new String[]{
            "off", "turn off", "desligar", "apagar", "apagar la", "spegni"
        });
        return mentionsFlashlight && mentionsOff;
    }

    public static boolean isVolumeUpCommand(String lowerText) {
        return containsAny(lowerText, new String[]{
            "volume up", "increase volume", "louder",
            "aumentar volume", "aumentar o volume", "mais alto",
            "subir volumen", "mas alto",
            "alza il volume", "aumenta il volume", "piu forte", "pi\u00f9 forte"
        });
    }

    public static boolean isVolumeDownCommand(String lowerText) {
        return containsAny(lowerText, new String[]{
            "volume down", "decrease volume", "lower the volume",
            "diminuir volume", "diminuir o volume", "mais baixo",
            "bajar volumen", "mas bajo",
            "abbassa il volume", "diminuisci il volume", "piu piano", "pi\u00f9 piano"
        });
    }

    public static boolean isBrightnessUpCommand(String lowerText) {
        boolean mentionsBrightness = containsAny(lowerText, new String[]{
            "brightness", "brilho", "brillo", "luminosita", "luminosit\u00e0"
        });
        boolean mentionsUp = containsAny(lowerText, new String[]{
            "up", "increase", "brighter", "raise",
            "aumentar", "subir", "mais alto", "mais forte",
            "aumenta", "alza"
        });
        return mentionsBrightness && mentionsUp;
    }

    public static boolean isBrightnessDownCommand(String lowerText) {
        boolean mentionsBrightness = containsAny(lowerText, new String[]{
            "brightness", "brilho", "brillo", "luminosita", "luminosit\u00e0"
        });
        boolean mentionsDown = containsAny(lowerText, new String[]{
            "down", "decrease", "dimmer", "lower",
            "diminuir", "abaixar", "reduzir", "mais baixo", "mais fraco",
            "abbassa", "diminuisci"
        });
        return mentionsBrightness && mentionsDown;
    }

    public static boolean isBluetoothOnCommand(String lowerText) {
        boolean mentionsBluetooth = lowerText.contains("bluetooth");
        boolean mentionsOn = containsAny(lowerText, new String[]{
            "on", "turn on", "enable", "ligar", "ativar", "ligue", "ative",
            "encender", "activar", "accendi", "attiva"
        });
        return mentionsBluetooth && mentionsOn;
    }

    public static boolean isRestartCommand(String lowerText) {
        String normalized = DateTimeCommandParser.stripAccents(lowerText);
        return containsAny(normalized, new String[]{
            "restart the phone", "reboot the phone", "restart the device",
            "reiniciar o celular", "reiniciar o telefone", "reinicie o celular",
            "reinicie o telefone", "reiniciar o aparelho",
            "reiniciar el telefono", "riavvia il telefono"
        });
    }

    public static boolean isMuteCommand(String lowerText) {
        return containsAny(lowerText, new String[]{"mute", "mudo", "silenciar", "silenzia"});
    }

    public static boolean isSetAlarmCommand(String lowerText) {
        return containsAny(lowerText, new String[]{
            "set an alarm", "set alarm", "wake me up",
            "definir um alarme", "colocar um alarme", "me acordar",
            "poner una alarma", "despertarme",
            "imposta una sveglia", "svegliami"
        });
    }

    public static boolean isCalendarReminderCommand(String lowerText) {
        return ReminderIntentDetector.isReminderIntent(lowerText);
    }

    public static boolean isRelativeAlarmCommand(String lowerText) {
        return ReminderIntentDetector.isAlarmIntent(lowerText);
    }

    public static boolean isCalendarOpenCommand(String lowerText) {
        String normalized = DateTimeCommandParser.stripAccents(lowerText);
        return containsAny(normalized, new String[]{
            "abrir calendario", "abrir o calendario", "mostrar calendario", "ver calendario",
            "abrir minha agenda", "mostrar minha agenda", "abre o calendario", "abre a agenda",
            "mostra o calendario", "mostra a agenda"
        });
    }

    public static boolean isOpenCompromissosCommand(String lowerText) {
        String normalized = DateTimeCommandParser.stripAccents(lowerText);
        return containsAny(normalized, new String[]{
            "abrir compromissos", "abrir meus compromissos", "abre os compromissos",
            "mostrar compromissos", "mostra os compromissos", "ver compromissos",
            "ver meus compromissos", "abrir despertadores", "ver despertadores",
            "open appointments"
        });
    }

    public static boolean isOpenThemesCommand(String lowerText) {
        String normalized = DateTimeCommandParser.stripAccents(lowerText);
        return containsAny(normalized, new String[]{
            "abrir temas", "abrir os temas", "abre os temas", "abre o tema", "mostrar temas",
            "mostra os temas", "ver temas", "trocar tema", "trocar de tema", "mudar tema",
            "mudar de tema", "open themes", "open theme"
        });
    }

    public static boolean isOpenModesCommand(String lowerText) {
        String normalized = DateTimeCommandParser.stripAccents(lowerText);
        return containsAny(normalized, new String[]{
            "abrir modos", "abrir os modos", "abre os modos", "mostrar modos", "ver modos",
            "abrir modo", "open modes"
        });
    }

    /** Returns ModeManager.MODE_VOICE / MODE_CHAT for a direct spoken switch, or -1 when none is requested. */
    public static int detectModeSwitchTarget(String lowerText) {
        String normalized = DateTimeCommandParser.stripAccents(lowerText);
        boolean switchWord = containsAny(normalized, new String[]{
            "trocar de modo", "troca de modo", "trocar modo", "mudar de modo", "mudar modo",
            "ativar modo", "ative o modo", "ativa o modo", "colocar no modo", "coloca no modo",
            "switch mode", "switch to mode"
        });
        if (!switchWord) {
            return -1;
        }
        if (containsAny(normalized, new String[]{"chat", "texto"})) {
            return 1;
        }
        if (containsAny(normalized, new String[]{"voz", "voice"})) {
            return 0;
        }
        return -1;
    }

    public static boolean mentionsReminderOrAlarmIntent(String lowerText) {
        return ReminderIntentDetector.mentionsReminderOrAlarm(lowerText);
    }

    public static boolean isJokeCommand(String lowerText) {
        return containsAny(lowerText, new String[]{"joke", "piada", "chiste", "barzelletta"});
    }
}
