package com.idcorporation.atlas.commands;

import android.content.Context;
import android.content.Intent;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.MainActivity;
import com.idcorporation.atlas.calendar.DateTimeCommandParser;
import com.idcorporation.atlas.contacts.CallLauncher;
import com.idcorporation.atlas.contacts.ContactMatch;
import com.idcorporation.atlas.contacts.ContactResolver;
import com.idcorporation.atlas.contacts.WhatsAppMessenger;
import com.idcorporation.atlas.utils.CallConfirmationSettings;
import com.idcorporation.atlas.utils.ContactsPermissionHelper;

import java.util.ArrayList;

/**
 * Handles "ligar para X" (CALL_CONTACT) and "mandar mensagem para X"
 * (SEND_WHATSAPP_MESSAGE) end to end: finds the contact, asks "which
 * one" when the name is ambiguous, asks for the message content when it
 * was not said in the same sentence, and - for messages, and for calls
 * when the confirm-before-call setting is on - asks a plain yes/no
 * before acting on it. All of this rides on the same voice pipeline as
 * every other ATLAS command (CommandManager.process), so it works the
 * same from the main screen, from a headless call, or from the
 * Presenca overlay: a spoken "sim" answers it, no tap required.
 */
public class ContactActionHandler {

    private static final long PENDING_TTL_MS = 45000L;

    private static final int PENDING_NONE = 0;
    private static final int PENDING_CALL_DISAMBIGUATE = 1;
    private static final int PENDING_CALL_CONFIRM = 2;
    private static final int PENDING_MESSAGE_DISAMBIGUATE = 3;
    private static final int PENDING_MESSAGE_CONTENT = 4;
    private static final int PENDING_MESSAGE_CONFIRM = 5;

    private final Context context;

    private int pendingKind = PENDING_NONE;
    private long pendingExpiresAt = 0L;
    private ArrayList<ContactMatch> pendingCandidates = null;
    private ContactMatch pendingContact = null;
    private String pendingMessageContent = null;

    public ContactActionHandler(Context context) {
        this.context = context.getApplicationContext();
    }

    /** Returns the outcome, or null when this sentence is not a call/message command or answer. */
    public synchronized CommandOutcome handle(String text, String lowerText) {
        long now = System.currentTimeMillis();
        if (pendingKind != PENDING_NONE && now > pendingExpiresAt) {
            clearPending();
        }
        if (pendingKind != PENDING_NONE) {
            CommandOutcome answer = handlePendingAnswer(text, now);
            if (answer != null) {
                return answer;
            }
        }
        if (ContactCommandParser.isMessageCommand(text)) {
            return startMessage(text, now);
        }
        if (ContactCommandParser.isCallCommand(text)) {
            return startCall(text, now);
        }
        return null;
    }

    // -----------------------------------------------------------------
    // Calls
    // -----------------------------------------------------------------

    private CommandOutcome startCall(String text, long now) {
        String contactName = ContactCommandParser.extractCallContactName(text);
        if (contactName.length() == 0) {
            return CommandOutcome.handled(context.getString(R.string.resp_who_to_call));
        }
        if (!ContactsPermissionHelper.hasReadContacts(context)) {
            return askForContactsPermission();
        }

        ArrayList<ContactMatch> candidates = ContactResolver.findByName(context, contactName);
        if (candidates.size() == 0) {
            return CommandOutcome.handled(context.getString(R.string.resp_contact_not_found, contactName));
        }
        if (candidates.size() > 1) {
            startPending(PENDING_CALL_DISAMBIGUATE, now);
            pendingCandidates = candidates;
            return CommandOutcome.handled(context.getString(R.string.resp_multiple_contacts,
                describeCandidates(candidates)));
        }

        ContactMatch match = candidates.get(0);
        if (CallConfirmationSettings.isConfirmBeforeCallEnabled(context)) {
            startPending(PENDING_CALL_CONFIRM, now);
            pendingContact = match;
            return CommandOutcome.handled(context.getString(R.string.resp_confirm_call, spoken(match)));
        }
        return performCall(match);
    }

    private CommandOutcome performCall(ContactMatch match) {
        if (!ContactsPermissionHelper.hasCallPhone(context)) {
            // Fire the request in the background: this call still goes through via the
            // ACTION_DIAL fallback below, but next time (once granted) it can dial directly.
            fireContactPermissionRequest();
        }
        CallLauncher.CallMethod method = CallLauncher.callPreferringWhatsapp(context, match);
        if (method == CallLauncher.CallMethod.WHATSAPP_CALL) {
            return CommandOutcome.handled(context.getString(R.string.resp_call_whatsapp, spoken(match)));
        }
        if (method == CallLauncher.CallMethod.WHATSAPP_CHAT_OPENED) {
            return CommandOutcome.handled(context.getString(R.string.resp_call_whatsapp_chat_opened, spoken(match)));
        }
        if (method == CallLauncher.CallMethod.REAL_CALL) {
            return CommandOutcome.handled(context.getString(R.string.resp_call_calling, spoken(match)));
        }
        return CommandOutcome.handled(context.getString(R.string.resp_call_dialer_opened, spoken(match)));
    }

    // -----------------------------------------------------------------
    // WhatsApp messages
    // -----------------------------------------------------------------

    private CommandOutcome startMessage(String text, long now) {
        ContactCommandParser.MessageRequest request = ContactCommandParser.extractMessageRequest(text);
        if (request.contactName.length() == 0) {
            return CommandOutcome.handled(context.getString(R.string.resp_who_to_message));
        }
        if (!WhatsAppMessenger.isInstalled(context)) {
            return CommandOutcome.handled(context.getString(R.string.resp_whatsapp_not_installed));
        }
        if (!ContactsPermissionHelper.hasReadContacts(context)) {
            return askForContactsPermission();
        }

        ArrayList<ContactMatch> candidates = ContactResolver.findByName(context, request.contactName);
        if (candidates.size() == 0) {
            return CommandOutcome.handled(context.getString(R.string.resp_contact_not_found, request.contactName));
        }
        if (candidates.size() > 1) {
            startPending(PENDING_MESSAGE_DISAMBIGUATE, now);
            pendingCandidates = candidates;
            pendingMessageContent = request.content;
            return CommandOutcome.handled(context.getString(R.string.resp_multiple_contacts,
                describeCandidates(candidates)));
        }
        return continueMessage(candidates.get(0), request.content, now);
    }

    private CommandOutcome continueMessage(ContactMatch match, String content, long now) {
        if (content == null || content.trim().length() == 0) {
            startPending(PENDING_MESSAGE_CONTENT, now);
            pendingContact = match;
            return CommandOutcome.handled(context.getString(R.string.resp_message_ask_content, spoken(match)));
        }
        startPending(PENDING_MESSAGE_CONFIRM, now);
        pendingContact = match;
        pendingMessageContent = content.trim();
        return CommandOutcome.handled(context.getString(R.string.resp_message_confirm, spoken(match), content.trim()));
    }

    private CommandOutcome performSendMessage(ContactMatch match, String content) {
        boolean opened = WhatsAppMessenger.openChatWithMessage(context, match, content);
        if (!opened) {
            return CommandOutcome.handled(context.getString(R.string.resp_whatsapp_not_installed));
        }
        return CommandOutcome.handled(context.getString(R.string.resp_message_prepared, spoken(match)));
    }

    // -----------------------------------------------------------------
    // Multi-turn answers
    // -----------------------------------------------------------------

    private CommandOutcome handlePendingAnswer(String text, long now) {
        boolean cancelledByNegative = (pendingKind == PENDING_MESSAGE_CONTENT)
            ? ContactCommandParser.isPureCancel(text)
            : ContactCommandParser.isNegative(text);
        if (cancelledByNegative) {
            clearPending();
            return CommandOutcome.handled(context.getString(R.string.resp_pending_cancelled));
        }

        if (pendingKind == PENDING_CALL_DISAMBIGUATE) {
            ContactMatch selected = pickCandidate(text, pendingCandidates);
            if (selected == null) {
                return null;
            }
            clearPending();
            if (CallConfirmationSettings.isConfirmBeforeCallEnabled(context)) {
                startPending(PENDING_CALL_CONFIRM, now);
                pendingContact = selected;
                return CommandOutcome.handled(context.getString(R.string.resp_confirm_call, spoken(selected)));
            }
            return performCall(selected);
        }

        if (pendingKind == PENDING_CALL_CONFIRM) {
            if (ContactCommandParser.isAffirmative(text)) {
                ContactMatch match = pendingContact;
                clearPending();
                return performCall(match);
            }
            return null;
        }

        if (pendingKind == PENDING_MESSAGE_DISAMBIGUATE) {
            ContactMatch selected = pickCandidate(text, pendingCandidates);
            if (selected == null) {
                return null;
            }
            String content = pendingMessageContent;
            clearPending();
            return continueMessage(selected, content, now);
        }

        if (pendingKind == PENDING_MESSAGE_CONTENT) {
            String content = text.trim();
            ContactMatch match = pendingContact;
            if (content.length() == 0) {
                return null;
            }
            clearPending();
            return continueMessage(match, content, now);
        }

        if (pendingKind == PENDING_MESSAGE_CONFIRM) {
            if (ContactCommandParser.isAffirmative(text)) {
                ContactMatch match = pendingContact;
                String content = pendingMessageContent;
                clearPending();
                return performSendMessage(match, content);
            }
            return null;
        }

        return null;
    }

    /** Matches a spoken answer to "which one?" against an ordinal ("o segundo"), a number, or a candidate's own name/label. */
    private ContactMatch pickCandidate(String text, ArrayList<ContactMatch> candidates) {
        if (candidates == null || candidates.size() == 0) {
            return null;
        }
        String normalized = DateTimeCommandParser.normalize(text);
        int ordinal = ordinalIndex(normalized);
        if (ordinal >= 0 && ordinal < candidates.size()) {
            return candidates.get(ordinal);
        }
        for (int i = 0; i < candidates.size(); i++) {
            ContactMatch candidate = candidates.get(i);
            String normalizedName = DateTimeCommandParser.normalize(candidate.spokenName().length() > 0 ? candidate.spokenName() : candidate.displayName);
            if (normalized.contains(normalizedName)) {
                return candidate;
            }
            if (candidate.numberLabel != null && candidate.numberLabel.length() > 0
                    && normalized.contains(candidate.numberLabel.toLowerCase())) {
                return candidate;
            }
        }
        return null;
    }

    /** Name to say out loud: emojis/decorations dropped; a readable fallback when the saved name is emoji-only. */
    private String spoken(ContactMatch match) {
        return match.spokenName(unnamedContact());
    }

    private String unnamedContact() {
        return context.getString(R.string.contact_unnamed_spoken);
    }

    private int ordinalIndex(String normalizedText) {
        if (containsWord(normalizedText, "primeiro") || containsWord(normalizedText, "primeira")
                || containsWord(normalizedText, "um") || normalizedText.contains(" 1")
                || normalizedText.startsWith("1")) {
            return 0;
        }
        if (containsWord(normalizedText, "segundo") || containsWord(normalizedText, "segunda")
                || containsWord(normalizedText, "dois") || normalizedText.contains(" 2")
                || normalizedText.startsWith("2")) {
            return 1;
        }
        if (containsWord(normalizedText, "terceiro") || containsWord(normalizedText, "terceira")
                || containsWord(normalizedText, "tres") || normalizedText.contains(" 3")
                || normalizedText.startsWith("3")) {
            return 2;
        }
        return -1;
    }

    private boolean containsWord(String text, String word) {
        return (" " + text + " ").contains(" " + word + " ");
    }

    private String describeCandidates(ArrayList<ContactMatch> candidates) {
        StringBuilder builder = new StringBuilder();
        int limit = Math.min(candidates.size(), 3);
        for (int i = 0; i < limit; i++) {
            if (i > 0) {
                builder.append(i == limit - 1 ? " " + context.getString(R.string.word_or) + " " : ", ");
            }
            builder.append(candidates.get(i).describeForSpeech(unnamedContact()));
        }
        return builder.toString();
    }

    private CommandOutcome askForContactsPermission() {
        boolean prompted = ContactsPermissionHelper.shouldPromptForPermissions(context);
        fireContactPermissionRequest();
        if (prompted) {
            return CommandOutcome.handled(context.getString(R.string.resp_contacts_permission_needed));
        }
        return CommandOutcome.handled(context.getString(R.string.resp_contacts_permission_still_needed));
    }

    private void fireContactPermissionRequest() {
        if (!ContactsPermissionHelper.shouldPromptForPermissions(context)) {
            return;
        }
        ContactsPermissionHelper.markPermissionsPrompted(context);
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra(MainActivity.EXTRA_REQUEST_CONTACT_PERMISSIONS, true);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
        } catch (RuntimeException e) {
            // Nothing further to do if even opening ATLAS itself fails here.
        }
    }

    private void startPending(int kind, long now) {
        clearPending();
        pendingKind = kind;
        pendingExpiresAt = now + PENDING_TTL_MS;
    }

    private void clearPending() {
        pendingKind = PENDING_NONE;
        pendingExpiresAt = 0L;
        pendingCandidates = null;
        pendingContact = null;
        pendingMessageContent = null;
    }
}
