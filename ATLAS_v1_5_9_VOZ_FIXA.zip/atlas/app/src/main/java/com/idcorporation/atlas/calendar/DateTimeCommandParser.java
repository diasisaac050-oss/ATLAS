package com.idcorporation.atlas.calendar;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Pattern;

/**
 * Turns spoken sentences into concrete dates and times, no matter how the
 * person words them: "marque no dia 20 de abril como dia do presente da
 * minha mae", "me lembra amanha as 3 de ligar pro Joao", "coloca o
 * despertador meio-dia e 39", "toca um despertador daqui a uma hora e
 * meia". Matching is done on a lower-cased, accent-stripped copy of the
 * text (same length as the original, so the title can be cut out of the
 * original with its accents intact).
 */
public class DateTimeCommandParser {

    /** "me acorda", "quero acordar": a wake-up, so an hour with no am/pm is the morning one. */
    private static final Pattern WAKE_UP = Pattern.compile("\\b(?:acord\\w*|desperta|despertar|desperte)\\b");

    public static class ParsedReminder {
        /** True when a day (and maybe a time) was understood. */
        public boolean found;
        public int year;
        public int month;
        public int day;
        public int hour = -1;
        public int minute = -1;
        /** What the user called it, or null when the sentence gave no title. */
        public String title;
    }

    public static class ParsedAlarm {
        public boolean found;
        public long triggerMillis;
        /** True for "daqui a N minutos" style, false for a clock time. */
        public boolean relative;
        public long delayMillis;
        public int year;
        public int month;
        public int day;
        public int hour;
        public int minute;
        public String label;
        /** When only a day was understood ("amanha"), so a follow-up "as 7" can reuse it: {y, m, d}. */
        public int[] partialDate;
    }

    public static String stripAccents(String text) {
        String result = text;
        result = result.replaceAll("[\u00e1\u00e0\u00e3\u00e2\u00e4]", "a");
        result = result.replaceAll("[\u00e9\u00e8\u00ea\u00eb]", "e");
        result = result.replaceAll("[\u00ed\u00ec\u00ee\u00ef]", "i");
        result = result.replaceAll("[\u00f3\u00f2\u00f5\u00f4\u00f6]", "o");
        result = result.replaceAll("[\u00fa\u00f9\u00fb\u00fc]", "u");
        result = result.replaceAll("\u00e7", "c");
        return result;
    }

    /** Lower-case, no accents, punctuation turned into spaces. Same length as the input. */
    public static String normalize(String text) {
        String s = stripAccents(text.toLowerCase());
        return s.replaceAll("[.,;!?\"()]", " ");
    }

    public static ParsedReminder parseReminder(String originalText) {
        return parseReminder(originalText, System.currentTimeMillis());
    }

    public static ParsedReminder parseReminder(String originalText, long nowMillis) {
        ParsedReminder result = new ParsedReminder();
        String n = normalize(originalText);
        boolean[] mask = new boolean[n.length()];
        Calendar now = calendarAt(nowMillis);

        DurationExpressionParser.DurationResult duration = DurationExpressionParser.parse(n, false);
        if (duration.found) {
            fillReminderFromDuration(result, duration, nowMillis);
            TitleExtractor.markRange(mask, duration.start, duration.end);
        } else {
            DateExpressionParser.DateResult date = DateExpressionParser.parse(n, now);
            ClockExpressionParser.ClockResult clock = ClockExpressionParser.parseClock(n, false);
            if (date.found) {
                TitleExtractor.markRange(mask, date.start, date.end);
            }
            if (clock.found) {
                TitleExtractor.markRange(mask, clock.start, clock.end);
                fillReminder(result, TimeResolver.resolve(clock, date, now, false), true);
            } else if (date.found) {
                result.found = true;
                result.year = date.year;
                result.month = date.month;
                result.day = date.day;
            } else {
                DurationExpressionParser.DurationResult loose = DurationExpressionParser.parse(n, true);
                if (loose.found) {
                    fillReminderFromDuration(result, loose, nowMillis);
                    TitleExtractor.markRange(mask, loose.start, loose.end);
                }
            }
        }
        result.title = TitleExtractor.extract(originalText, n, mask, false);
        return result;
    }

    public static ParsedAlarm parseAlarm(String originalText) {
        return parseAlarm(originalText, System.currentTimeMillis(), null);
    }

    /** forcedDate {y, m, d} (or null) is a day remembered from an earlier turn, used when this text has a time but no day. */
    public static ParsedAlarm parseAlarm(String originalText, long nowMillis, int[] forcedDate) {
        ParsedAlarm result = new ParsedAlarm();
        String n = normalize(originalText);
        boolean[] mask = new boolean[n.length()];
        Calendar now = calendarAt(nowMillis);

        DurationExpressionParser.DurationResult duration = DurationExpressionParser.parse(n, false);
        if (duration.found) {
            fillRelativeAlarm(result, duration, nowMillis);
            TitleExtractor.markRange(mask, duration.start, duration.end);
        } else {
            DateExpressionParser.DateResult date = DateExpressionParser.parse(n, now);
            ClockExpressionParser.ClockResult clock = ClockExpressionParser.parseClock(n, true);
            if (date.found) {
                TitleExtractor.markRange(mask, date.start, date.end);
            }
            if (clock.found) {
                TitleExtractor.markRange(mask, clock.start, clock.end);
                DateExpressionParser.DateResult day = date;
                if (!date.found && forcedDate != null) {
                    day = new DateExpressionParser.DateResult();
                    day.found = true;
                    day.year = forcedDate[0];
                    day.month = forcedDate[1];
                    day.day = forcedDate[2];
                }
                if (clock.ambiguous && WAKE_UP.matcher(n).find()) {
                    clock.ambiguous = false;
                }
                fillAbsoluteAlarm(result, TimeResolver.resolve(clock, day, now, true));
            } else {
                DurationExpressionParser.DurationResult loose = DurationExpressionParser.parse(n, true);
                if (loose.found) {
                    fillRelativeAlarm(result, loose, nowMillis);
                    TitleExtractor.markRange(mask, loose.start, loose.end);
                } else if (date.found) {
                    result.partialDate = new int[]{date.year, date.month, date.day};
                }
            }
        }
        result.label = TitleExtractor.extract(originalText, n, mask, true);
        return result;
    }

    private static void fillReminderFromDuration(ParsedReminder r, DurationExpressionParser.DurationResult d,
            long nowMillis) {
        Calendar t = calendarAt(nowMillis + d.millis);
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= nowMillis) {
            t.add(Calendar.MINUTE, 1);
        }
        fillReminder(r, t, true);
    }

    private static void fillRelativeAlarm(ParsedAlarm r, DurationExpressionParser.DurationResult d, long nowMillis) {
        r.found = true;
        r.relative = true;
        r.delayMillis = d.millis;
        r.triggerMillis = nowMillis + d.millis;
        copyTime(r, calendarAt(r.triggerMillis));
    }

    private static void fillAbsoluteAlarm(ParsedAlarm r, Calendar target) {
        r.found = true;
        r.relative = false;
        r.triggerMillis = target.getTimeInMillis();
        copyTime(r, target);
    }

    private static void copyTime(ParsedAlarm r, Calendar c) {
        r.year = c.get(Calendar.YEAR);
        r.month = c.get(Calendar.MONTH) + 1;
        r.day = c.get(Calendar.DAY_OF_MONTH);
        r.hour = c.get(Calendar.HOUR_OF_DAY);
        r.minute = c.get(Calendar.MINUTE);
    }

    private static void fillReminder(ParsedReminder r, Calendar c, boolean withTime) {
        r.found = true;
        r.year = c.get(Calendar.YEAR);
        r.month = c.get(Calendar.MONTH) + 1;
        r.day = c.get(Calendar.DAY_OF_MONTH);
        if (withTime) {
            r.hour = c.get(Calendar.HOUR_OF_DAY);
            r.minute = c.get(Calendar.MINUTE);
        }
    }

    private static Calendar calendarAt(long millis) {
        Calendar c = new GregorianCalendar();
        c.setTimeInMillis(millis);
        return c;
    }
}
