package com.idcorporation.atlas.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.calendar.CalendarDateUtils;
import com.idcorporation.atlas.utils.LocaleHelper;
import com.idcorporation.atlas.utils.NotificationHelper;
import com.idcorporation.atlas.utils.SoundManager;
import com.idcorporation.atlas.utils.UserProfileManager;

import java.util.Calendar;

/**
 * Runs once a day (see BirthdayScheduler). Sends the "one week left"
 * warning exactly once per year and the "happy birthday" congratulations
 * exactly once per year, tracked by the calendar year so re-running the
 * check later the same day never double-sends.
 */
public class BirthdayCheckReceiver extends BroadcastReceiver {

    private static final String PREFS_NAME = "atlas_birthday_prefs";
    private static final String KEY_LAST_WARNED_YEAR = "last_warned_year";
    private static final String KEY_LAST_CONGRATULATED_YEAR = "last_congratulated_year";
    private static final int WARNING_DAYS_BEFORE = 7;

    @Override
    public void onReceive(Context context, Intent intent) {
        Context localizedContext = LocaleHelper.wrapContext(context);
        UserProfileManager profileManager = new UserProfileManager(context);
        if (!profileManager.hasBirthday()) {
            return;
        }

        int month = profileManager.getBirthMonth();
        int day = profileManager.getBirthDay();
        int daysUntil = CalendarDateUtils.daysUntilNextOccurrence(month, day);
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        if (daysUntil == 0) {
            int lastCongratulatedYear = prefs.getInt(KEY_LAST_CONGRATULATED_YEAR, -1);
            if (lastCongratulatedYear != currentYear) {
                String name = profileManager.getName();
                String title = localizedContext.getString(R.string.notif_birthday_title);
                String message = name != null && name.length() > 0
                    ? localizedContext.getString(R.string.notif_birthday_message_named, name)
                    : localizedContext.getString(R.string.notif_birthday_message);
                NotificationHelper.showBirthdayNotification(
                    context, NotificationHelper.NOTIFICATION_ID_BIRTHDAY_TODAY, title, message);
                SoundManager.playBirthday(context);
                prefs.edit().putInt(KEY_LAST_CONGRATULATED_YEAR, currentYear).apply();
            }
            return;
        }

        if (daysUntil == WARNING_DAYS_BEFORE) {
            int lastWarnedYear = prefs.getInt(KEY_LAST_WARNED_YEAR, -1);
            if (lastWarnedYear != currentYear) {
                String title = localizedContext.getString(R.string.notif_birthday_warning_title);
                String message = localizedContext.getString(R.string.notif_birthday_warning_message,
                    String.valueOf(WARNING_DAYS_BEFORE));
                NotificationHelper.showBirthdayNotification(
                    context, NotificationHelper.NOTIFICATION_ID_BIRTHDAY_WARNING, title, message);
                prefs.edit().putInt(KEY_LAST_WARNED_YEAR, currentYear).apply();
            }
        }
    }
}
