package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;

/**
 * The body of the glass lens: soft ground shadow, icy halo, smoked-glass
 * fill and the light that gathers inside the glass (bottom caustic, top
 * gloss and the dark lens edge). Every gradient is built ONCE at unit size
 * and placed with the canvas matrix, so nothing is allocated per frame.
 */
final class PresenceGlassBody {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix = new Matrix();
    private final RadialGradient shadowUnit;
    private final RadialGradient haloIce;
    private final RadialGradient haloDeep;
    private final LinearGradient fillUnit;
    private final RadialGradient causticUnit;
    private final RadialGradient glossUnit;
    private final RadialGradient edgeUnit;

    PresenceGlassBody() {
        shadowUnit = radial(PresenceBlues.ABYSS, 120, 0.30f);
        haloIce = radial(PresenceBlues.LIGHT, 255, 0.42f);
        haloDeep = radial(PresenceBlues.DEEP, 255, 0.42f);
        causticUnit = radial(PresenceBlues.ICE, 255, 0.0f);
        glossUnit = radial(PresenceBlues.ICE, 255, 0.0f);
        fillUnit = new LinearGradient(0f, -1f, 0f, 1f,
            new int[] {PresenceBlues.alpha(PresenceBlues.SKY, 46),
                       PresenceBlues.alpha(PresenceBlues.NAVY, 72),
                       PresenceBlues.alpha(PresenceBlues.NAVY, 120),
                       PresenceBlues.alpha(PresenceBlues.ABYSS, 178)},
            new float[] {0f, 0.40f, 0.75f, 1f}, Shader.TileMode.CLAMP);
        edgeUnit = new RadialGradient(0f, 0f, 1f,
            new int[] {PresenceBlues.alpha(PresenceBlues.ABYSS, 0),
                       PresenceBlues.alpha(PresenceBlues.ABYSS, 0),
                       PresenceBlues.alpha(PresenceBlues.NAVY, 170)},
            new float[] {0f, 0.58f, 1f}, Shader.TileMode.CLAMP);
    }

    /** Unit radial that stays solid until 'hold' and then fades to nothing at the edge. */
    private static RadialGradient radial(int color, int peakAlpha, float hold) {
        return new RadialGradient(0f, 0f, 1f,
            new int[] {PresenceBlues.alpha(color, peakAlpha), PresenceBlues.alpha(color, 0)},
            new float[] {hold, 1f}, Shader.TileMode.CLAMP);
    }

    /** A dark soft shadow under the lens so it floats above any wallpaper. */
    void drawShadow(Canvas canvas, float cx, float cy, float a, float b, float alpha) {
        paint.setShader(shadowUnit);
        paint.setAlpha(PresenceBlues.a255(alpha * 0.85f));
        canvas.save();
        canvas.translate(cx, cy + b * 0.62f);
        canvas.scale(a * 1.08f, b * 0.60f);
        canvas.drawCircle(0f, 0f, 1f, paint);
        canvas.restore();
    }

    /** Icy glow around the glass; grows with voice and thinking, turns deep blue on error. */
    void drawHalo(Canvas canvas, float cx, float cy, float a, float b,
                  PresenceBubbleState st, float pulse, float alpha) {
        float strength = (0.30f + 0.50f * pulse + 0.22f * st.thinkAmt) * alpha * 0.34f;
        float err = st.errAmt;
        canvas.save();
        canvas.translate(cx, cy);
        canvas.scale(a * 1.45f, b * 1.6f);
        paint.setShader(haloIce);
        paint.setAlpha(PresenceBlues.a255(strength * (1f - err)));
        canvas.drawCircle(0f, 0f, 1f, paint);
        if (err > 0.02f) {
            paint.setShader(haloDeep);
            paint.setAlpha(PresenceBlues.a255(strength * err * 1.4f));
            canvas.drawCircle(0f, 0f, 1f, paint);
        }
        canvas.restore();
    }

    /** Smoked glass: pale ice on top, deep navy at the bottom, clear enough to see through. */
    void drawFill(Canvas canvas, Path body, float cy, float b, float alpha) {
        matrix.setScale(1f, b);
        matrix.postTranslate(0f, cy);
        fillUnit.setLocalMatrix(matrix);
        paint.setShader(fillUnit);
        paint.setAlpha(PresenceBlues.a255(alpha));
        canvas.drawPath(body, paint);
    }

    /** Call inside the body clip: light pooling at the bottom, gloss on top, dark lens edge. */
    void drawInnerLight(Canvas canvas, float cx, float cy, float a, float b,
                        float pulse, float alpha) {
        paint.setShader(causticUnit);
        paint.setAlpha(PresenceBlues.a255(alpha * (0.26f + 0.22f * pulse)));
        canvas.save();
        canvas.translate(cx, cy + b * 0.80f);
        canvas.scale(a * 0.78f, b * 0.46f);
        canvas.drawCircle(0f, 0f, 1f, paint);
        canvas.restore();

        paint.setShader(glossUnit);
        paint.setAlpha(PresenceBlues.a255(alpha * 0.20f));
        canvas.save();
        canvas.translate(cx - a * 0.10f, cy - b * 0.90f);
        canvas.scale(a * 0.62f, b * 0.34f);
        canvas.drawCircle(0f, 0f, 1f, paint);
        canvas.restore();

        paint.setShader(edgeUnit);
        paint.setAlpha(PresenceBlues.a255(alpha));
        canvas.save();
        canvas.translate(cx, cy);
        canvas.scale(a, b);
        canvas.drawRect(-1.3f, -1.3f, 1.3f, 1.3f, paint);
        canvas.restore();
    }
}
