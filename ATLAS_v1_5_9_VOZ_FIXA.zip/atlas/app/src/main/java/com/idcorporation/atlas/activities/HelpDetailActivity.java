package com.idcorporation.atlas.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.idcorporation.atlas.R;

public class HelpDetailActivity extends BaseActivity {

    public static final String EXTRA_TITLE = "extra_title";
    public static final String EXTRA_BODY = "extra_body";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_detail);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        String title = getIntent().getStringExtra(EXTRA_TITLE);
        String body = getIntent().getStringExtra(EXTRA_BODY);

        ((TextView) findViewById(R.id.text_detail_title)).setText(title);
        ((TextView) findViewById(R.id.text_detail_body)).setText(body);
    }
}
