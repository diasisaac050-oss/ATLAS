package com.idcorporation.atlas.theme;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

public class ScanGridBackgroundView extends View implements ThemeBackgroundView {

    private static final float GRID_SPACING = 60f;
    private static final float SCAN_SPEED = 2.5f;

    private int backgroundColor;
    private int lineColor;
    private float scanOffset = 0f;
    private final Paint gridPaint = new Paint();
    private final Paint scanPaint = new Paint();

    public ScanGridBackgroundView(Context context) {
        super(context);
        gridPaint.setStrokeWidth(1f);
        scanPaint.setStrokeWidth(3f);
    }

    @Override
    public void setPalette(ThemePalette palette) {
        this.backgroundColor = palette.getBackgroundColor();
        this.lineColor = palette.getAccentColor();
        gridPaint.setColor(withAlpha(lineColor, 40));
        scanPaint.setColor(withAlpha(lineColor, 130));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();

        canvas.drawColor(backgroundColor);

        for (float x = 0f; x < width; x = x + GRID_SPACING) {
            canvas.drawLine(x, 0f, x, height, gridPaint);
        }
        for (float y = 0f; y < height; y = y + GRID_SPACING) {
            canvas.drawLine(0f, y, width, y, gridPaint);
        }

        scanOffset = scanOffset + SCAN_SPEED;
        if (scanOffset > height + 120f) {
            scanOffset = 0f;
        }
        canvas.drawLine(0f, scanOffset, width, scanOffset, scanPaint);
        canvas.drawLine(0f, scanOffset - 20f, width, scanOffset - 20f, gridPaint);

        invalidate();
    }

    private int withAlpha(int color, int alpha) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    @Override
    public void stopAnimating() {
    }
}
