package com.idcorporation.atlas.control;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import com.idcorporation.atlas.utils.LocaleHelper;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * ATLAS CONSOLE: envia ao painel do administrador dados ANONIMOS de uso:
 *   - "sinal de vida" (versao do app, versao do Android, modelo do aparelho,
 *     idioma e um codigo aleatorio da instalacao), no maximo a cada 3 horas;
 *   - o relatorio do ultimo erro (o mesmo texto da tela de erro), uma vez.
 *
 * NUNCA envia nome, e-mail, conversas, memorias, notas, financas ou contatos.
 * O codigo da instalacao e sorteado no aparelho e nao se liga a nenhuma conta.
 * Falhou (sem internet)? Ignora em silencio e tenta de novo depois.
 */
public final class Telemetry {

    private static final String PREFS = "atlas_console_prefs";
    private static final String K_ID = "install_id";
    private static final String K_FIRST = "first_seen";
    private static final String K_LAST_HB = "last_heartbeat";
    private static final String K_CRASH_SENT = "crash_sent_at";
    private static final long HEARTBEAT_GAP_MS = 3L * 60 * 60 * 1000;
    private static final int MAX_TRACE = 5000;

    private Telemetry() {}

    /** Chamado uma vez no AtlasApplication.onCreate(). */
    public static void start(Context context) {
        heartbeat(context);
        uploadPendingCrash(context);
    }

    public static void heartbeat(Context context) {
        try {
            final Context app = context.getApplicationContext();
            final SharedPreferences p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            long now = System.currentTimeMillis();
            if (now - p.getLong(K_LAST_HB, 0) < HEARTBEAT_GAP_MS) {
                return;
            }
            // Marca ja, pra varias telas abrindo juntas nao dispararem varios envios.
            p.edit().putLong(K_LAST_HB, now).apply();

            String id = p.getString(K_ID, null);
            if (id == null) {
                id = UUID.randomUUID().toString().replace("-", "");
                p.edit().putString(K_ID, id).putLong(K_FIRST, now).apply();
            }
            final String installId = id;
            final long first = p.getLong(K_FIRST, now);

            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject o = base(app);
                        o.put("first", first);
                        o.put("lang", LocaleHelper.getSavedLanguage(app));
                        o.put("lastSeen", new JSONObject().put(".sv", "timestamp"));
                        send("PUT", RemoteControl.DB_URL + "/devices/" + installId + ".json",
                            o.toString());
                    } catch (Throwable t) {
                        // tenta de novo na proxima abertura
                        p.edit().putLong(K_LAST_HB, 0).apply();
                    }
                }
            }).start();
        } catch (Throwable ignored) {
            // telemetria nunca derruba o app
        }
    }

    public static void uploadPendingCrash(Context context) {
        try {
            final Context app = context.getApplicationContext();
            final SharedPreferences p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            final File file = new File(app.getFilesDir(), "last_crash.txt");
            if (!file.exists() || file.lastModified() == p.getLong(K_CRASH_SENT, 0)) {
                return;
            }
            final long modified = file.lastModified();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        FileInputStream in = new FileInputStream(file);
                        byte[] buf = new byte[MAX_TRACE];
                        int n = in.read(buf);
                        in.close();
                        if (n <= 0) {
                            return;
                        }
                        JSONObject o = base(app);
                        o.put("t", modified);
                        o.put("trace", new String(buf, 0, n, StandardCharsets.UTF_8));
                        send("POST", RemoteControl.DB_URL + "/crashes.json", o.toString());
                        p.edit().putLong(K_CRASH_SENT, modified).apply();
                    } catch (Throwable ignored) {
                        // tenta de novo na proxima abertura
                    }
                }
            }).start();
        } catch (Throwable ignored) {
            // telemetria nunca derruba o app
        }
    }

    private static JSONObject base(Context app) throws Exception {
        JSONObject o = new JSONObject();
        o.put("v", RemoteControl.currentVersionCode(app));
        String vn = "";
        try {
            vn = app.getPackageManager().getPackageInfo(app.getPackageName(), 0).versionName;
        } catch (Throwable ignored) {
            // sem nome de versao
        }
        o.put("vn", vn == null ? "" : vn);
        o.put("os", Build.VERSION.SDK_INT);
        String model = (Build.MANUFACTURER + " " + Build.MODEL).trim();
        o.put("model", model.length() > 70 ? model.substring(0, 70) : model);
        return o;
    }

    private static void send(String method, String url, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod(method);
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            OutputStream os = c.getOutputStream();
            os.write(body.getBytes(StandardCharsets.UTF_8));
            os.close();
            int code = c.getResponseCode();
            if (code >= 300) {
                throw new Exception("HTTP " + code);
            }
        } finally {
            c.disconnect();
        }
    }
}
