package com.idcorporation.atlas.agent.tools;

import com.idcorporation.atlas.agent.ToolResult;
import com.idcorporation.atlas.agent.panel.PanelData;
import com.idcorporation.atlas.memory.MemoryManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Locale;

/**
 * Real forecast from Open-Meteo (free, no API key): geocodes the city,
 * then reads current conditions and a 5-day outlook. City comes from the
 * request or from a saved memory ("cidade"/"city"); the app has no
 * location permission, so it never guesses where the user is.
 */
public class WeatherTool extends BaseTool {

    public WeatherTool(ToolEnv env) {
        super(env);
    }

    @Override
    public String name() {
        return "get_weather";
    }

    @Override
    public String description() {
        return "Get the real current weather and 5-day forecast for a city and show it in a panel. "
            + "If no city is given, the city saved in memory is used.";
    }

    @Override
    public JSONObject parameters() {
        return Schema.obj().str("city", "City name, e.g. 'Santos'. Optional if a home city is remembered.", false).build();
    }

    @Override
    public ToolResult execute(JSONObject args) throws Exception {
        String city = arg(args, "city");
        if (city.length() == 0) {
            city = rememberedCity();
        }
        if (city.length() == 0) {
            return ToolResult.needsInfo("No city given and none saved in memory. Ask the user which city.", null);
        }
        String lang = env.isPortuguese() ? "pt" : env.lang();
        String geoRaw = Http.get("https://geocoding-api.open-meteo.com/v1/search?name=" + Http.enc(city)
            + "&count=1&language=" + Http.enc(lang) + "&format=json");
        JSONArray results = new JSONObject(geoRaw).optJSONArray("results");
        if (results == null || results.length() == 0) {
            return ToolResult.failed("City '" + city + "' was not found by the weather service.");
        }
        JSONObject place = results.getJSONObject(0);
        double lat = place.getDouble("latitude");
        double lon = place.getDouble("longitude");
        String placeName = place.optString("name", city);
        String admin = place.optString("admin1", "");
        String country = place.optString("country", "");

        String raw = Http.get("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
            + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,"
            + "wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,"
            + "precipitation_probability_max&timezone=auto&forecast_days=5");
        return buildResult(new JSONObject(raw), placeName, admin, country, env.lang());
    }

    /** Separated from the network call so it can be tested with a canned response. */
    static ToolResult buildResult(JSONObject forecast, String placeName, String admin, String country, String lang)
            throws Exception {
        JSONObject cur = forecast.getJSONObject("current");
        JSONObject daily = forecast.getJSONObject("daily");
        int code = cur.optInt("weather_code", 0);
        String condition = WeatherCodes.describe(code, lang);

        PanelData panel = new PanelData();
        panel.type = PanelData.TYPE_WEATHER;
        panel.title = placeName;
        StringBuilder sub = new StringBuilder();
        if (admin.length() > 0) {
            sub.append(admin);
        }
        if (country.length() > 0) {
            sub.append(sub.length() > 0 ? ", " : "").append(country);
        }
        panel.subtitle = sub.toString();
        panel.heroValue = Math.round(cur.optDouble("temperature_2m", 0)) + "\u00B0";
        panel.heroLabel = condition;
        panel.heroDetail = WeatherCodes.feelsLike(lang) + " " + Math.round(cur.optDouble("apparent_temperature", 0))
            + "\u00B0  \u00B7  " + WeatherCodes.humidity(lang) + " " + Math.round(cur.optDouble("relative_humidity_2m", 0))
            + "%  \u00B7  " + WeatherCodes.wind(lang) + " " + Math.round(cur.optDouble("wind_speed_10m", 0)) + " km/h";
        panel.source = "Open-Meteo";

        JSONArray days = daily.getJSONArray("time");
        JSONArray maxes = daily.getJSONArray("temperature_2m_max");
        JSONArray mins = daily.getJSONArray("temperature_2m_min");
        JSONArray codes = daily.getJSONArray("weather_code");
        JSONArray rain = daily.optJSONArray("precipitation_probability_max");
        JSONArray summary = new JSONArray();
        for (int i = 0; i < days.length(); i++) {
            String label = i == 0 ? WeatherCodes.today(lang) : weekday(days.getString(i), lang);
            String desc = WeatherCodes.describe(codes.optInt(i, 0), lang);
            String temps = Math.round(mins.optDouble(i, 0)) + "\u00B0 / " + Math.round(maxes.optDouble(i, 0)) + "\u00B0";
            String chance = (rain != null && !rain.isNull(i)) ? WeatherCodes.rain(lang) + " " + rain.optInt(i, 0) + "%" : "";
            panel.rows.add(new PanelData.Row(label, desc, temps + (chance.length() > 0 ? "  \u00B7  " + chance : ""), ""));
            JSONObject s = new JSONObject();
            s.put("day", label);
            s.put("condition", desc);
            s.put("min_c", Math.round(mins.optDouble(i, 0)));
            s.put("max_c", Math.round(maxes.optDouble(i, 0)));
            if (rain != null && !rain.isNull(i)) {
                s.put("rain_chance_pct", rain.optInt(i, 0));
            }
            summary.put(s);
        }
        JSONObject data = new JSONObject();
        data.put("place", placeName);
        data.put("now_c", Math.round(cur.optDouble("temperature_2m", 0)));
        data.put("feels_like_c", Math.round(cur.optDouble("apparent_temperature", 0)));
        data.put("condition", condition);
        data.put("humidity_pct", Math.round(cur.optDouble("relative_humidity_2m", 0)));
        data.put("days", summary);
        return ToolResult.ok("Real forecast from Open-Meteo for " + placeName + ". A weather panel is on screen.", data)
            .withPanel(panel);
    }

    private static String weekday(String isoDate, String lang) {
        try {
            String[] p = isoDate.split("-");
            Calendar c = Calendar.getInstance();
            c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]));
            String name = c.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, new Locale(lang));
            return name == null ? isoDate : name;
        } catch (Exception e) {
            return isoDate;
        }
    }

    private String rememberedCity() {
        try {
            MemoryManager mm = new MemoryManager(env.context);
            String[] keys = {"cidade", "city", "ciudad", "moro", "mora"};
            for (int i = 0; i < keys.length; i++) {
                String v = mm.findMemoryValueByKeyword(keys[i]);
                if (v != null && v.trim().length() > 0 && v.trim().length() <= 60) {
                    return v.trim();
                }
            }
        } catch (RuntimeException ignored) {
            // No memory available: the caller will ask the user.
        }
        return "";
    }
}
