package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import com.idcorporation.atlas.sphere.SphereCanvasPainter;
import com.idcorporation.atlas.sphere.SphereEngine;

/**
 * ATLAS ESFERA for the Presence mode: the same 3D particle sphere as the
 * Home, drawn by every Presence layout in its own place and with its own
 * entrance (see PresenceSpherePlacement). It follows the theme colour, the
 * voice state and the microphone level, and a tap ripple sends an energy
 * wave through it. Replaces the old blue glass painters.
 *
 * A small sphere on top of other apps must stay cheap: it starts on the
 * light quality tier (the previews in Settings use the lightest) and steps
 * down by itself if frames keep taking too long to build.
 */
public class PresenceSphereDrawer implements PresenceDrawer {

    private static final long SLOW_NANOS = 9000000L;
    private static final int COST_WINDOW = 60;

    private final int layout;
    private final float d;
    private final SphereEngine engine = new SphereEngine();
    private final SphereCanvasPainter painter = new SphereCanvasPainter();
    private final float[] place = new float[4];
    /** Soft dark backdrop (unit radius, scaled when drawn) so the sphere reads on bright apps too. */
    private final Paint scrim = new Paint(Paint.ANTI_ALIAS_FLAG);

    private long lastNanos = 0L;
    private boolean rippleWasOn = false;
    private long costSum = 0L;
    private int costFrames = 0;
    private int lastHud = -1;

    public PresenceSphereDrawer(float density, int layout, int accentColor, boolean lightweight) {
        this.d = density;
        this.layout = layout;
        engine.setAccentColor(accentColor);
        engine.setQuality(lightweight ? 2 : 1);
        scrim.setShader(new RadialGradient(0f, 0f, 1f,
            new int[]{ 0x8C000000, 0x59000000, 0x00000000 },
            new float[]{ 0f, 0.55f, 1f }, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas canvas, int w, int h, PresenceBubbleState st) {
        if (st.open <= 0.01f) {
            lastNanos = 0L;
            return;
        }
        long start = System.nanoTime();
        float dt = lastNanos == 0L ? 0.016f : (start - lastNanos) / 1000000000f;
        lastNanos = start;

        if (st.hudState != lastHud) {
            lastHud = st.hudState;
            engine.setState(st.hudState);
        }
        boolean rippleOn = st.ripple >= 0f;
        if (rippleOn && !rippleWasOn) {
            engine.ping();
        }
        rippleWasOn = rippleOn;
        // st.level is the smoothed microphone loudness (0..1).
        if (st.level > 0.02f) {
            engine.setAudioLevel(st.level);
        }

        PresenceSpherePlacement.compute(layout, w, h, d, st, place);
        st.sphereCx = place[0];
        st.sphereCy = place[1];
        engine.setPlacement(place[0], place[1], place[2], d);
        engine.setMasterAlpha(place[3]);
        engine.update(dt);
        // Soft dark pool behind the sphere: the sphere is light on dark, and this is a
        // floating window over any app, including white ones.
        scrim.setAlpha(Math.round(255f * place[3]));
        canvas.save();
        canvas.translate(place[0], place[1]);
        canvas.scale(place[2] * 1.45f, place[2] * 1.45f);
        canvas.drawCircle(0f, 0f, 1f, scrim);
        canvas.restore();

        painter.canvas = canvas;
        engine.render(painter);
        painter.canvas = null;

        costSum += System.nanoTime() - start;
        costFrames++;
        if (costFrames >= COST_WINDOW) {
            if (costSum / costFrames > SLOW_NANOS && engine.getQuality() < 2) {
                engine.setQuality(engine.getQuality() + 1);
            }
            costSum = 0L;
            costFrames = 0;
        }
    }
}
