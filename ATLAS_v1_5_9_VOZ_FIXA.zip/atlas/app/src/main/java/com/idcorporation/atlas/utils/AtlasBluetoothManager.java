package com.idcorporation.atlas.utils;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

/**
 * Turns Bluetooth on. Named AtlasBluetoothManager (not BluetoothManager) so
 * it does not collide with android.bluetooth.BluetoothManager.
 *
 * BluetoothAdapter.enable() is deprecated since API 33, but it is still the
 * only programmatic way to flip the radio on without showing the user a
 * system prompt, and it keeps working on devices that have granted
 * BLUETOOTH_CONNECT. Where it is not available (permission missing, or the
 * OEM blocks it), the caller falls back to opening Bluetooth settings.
 */
public class AtlasBluetoothManager {

    private final Context context;
    private final BluetoothAdapter adapter;

    public AtlasBluetoothManager(Context context) {
        this.context = context.getApplicationContext();
        this.adapter = BluetoothAdapter.getDefaultAdapter();
    }

    public boolean isSupported() {
        return adapter != null;
    }

    public boolean isEnabled() {
        return adapter != null && hasConnectPermission() && adapter.isEnabled();
    }

    public boolean hasConnectPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            // Pre-Android 12, the legacy BLUETOOTH/BLUETOOTH_ADMIN
            // permissions declared in the manifest are enough.
            return true;
        }
        return context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
            == PackageManager.PERMISSION_GRANTED;
    }

    /** @return true if Bluetooth was already on or the enable request was accepted. */
    @SuppressWarnings("deprecation")
    public boolean enable() {
        if (adapter == null || !hasConnectPermission()) {
            return false;
        }
        if (adapter.isEnabled()) {
            return true;
        }
        try {
            return adapter.enable();
        } catch (SecurityException e) {
            return false;
        }
    }
}
