package com.idcorporation.atlas.ai;

import android.content.Context;
import android.content.SharedPreferences;

import com.idcorporation.atlas.memory.MemoryManager;
import com.idcorporation.atlas.models.MemoryItem;
import com.idcorporation.atlas.utils.LocaleHelper;
import com.idcorporation.atlas.utils.TextSanitizer;
import com.idcorporation.atlas.utils.UserProfileManager;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/**
 * Spontaneous opening line. The model itself decides - every time - between
 * a short natural greeting and silence, from the time of day, how long ago
 * the last chat was, the remembered facts it was given, and its own recent
 * greetings (which it must not repeat). There is no fixed phrase anywhere:
 * if the request fails or the answer is empty, Atlas simply stays quiet.
 *
 * Code only enforces limits so it is never annoying or costly: a pause
 * between attempts, a daily cap, and one attempt per app opening.
 */
public final class ProactiveGreeter {

    public interface Callback {
        /** Called on the main thread only when there is something to say. */
        void onGreeting(String text);
    }

    private static final String PREFS = "atlas_proactive_prefs";
    private static final String KEY_LAST_ATTEMPT = "last_attempt";
    private static final String KEY_LAST_INTERACTION = "last_interaction";
    private static final String KEY_DAY = "day";
    private static final String KEY_DAY_COUNT = "day_count";
    private static final String KEY_RECENT = "recent";
    static final long MIN_GAP_MS = 6L * 60L * 1000L;
    static final int MAX_PER_DAY = 5;
    private static final int MAX_WORDS = 16;

    private ProactiveGreeter() {
    }

    /** Call whenever the user and Atlas exchange a message, so "minutes since last chat" is real. */
    public static void noteInteraction(Context context) {
        prefs(context).edit().putLong(KEY_LAST_INTERACTION, System.currentTimeMillis()).apply();
    }

    public static void maybeGreet(final Context context, final AIManager ai, final Callback callback) {
        final Context app = context.getApplicationContext();
        final SharedPreferences p = prefs(app);
        UserProfileManager profile = new UserProfileManager(app);
        long now = System.currentTimeMillis();

        if (now - p.getLong(KEY_LAST_ATTEMPT, 0L) < MIN_GAP_MS) {
            return;
        }
        String today = dayKey(now);
        int countToday = today.equals(p.getString(KEY_DAY, "")) ? p.getInt(KEY_DAY_COUNT, 0) : 0;
        if (countToday >= MAX_PER_DAY) {
            return;
        }
        if (!ai.canMakeRequestNow()) {
            return;
        }
        p.edit().putLong(KEY_LAST_ATTEMPT, now).apply();

        long lastInteraction = p.getLong(KEY_LAST_INTERACTION, 0L);
        long minutes = lastInteraction == 0L ? -1L : Math.max(0L, (now - lastInteraction) / 60000L);
        ArrayList<MemoryItem> facts = new MemoryManager(app).getRelevantMemories("", 6);
        String system = PromptManager.buildGreetingPrompt(profile.getName(),
            LocaleHelper.getLanguageNameForPrompt(LocaleHelper.getSavedLanguage(app)),
            profile.getGender(), facts, partOfDay(now), weekday(now), minutes, recent(p));

        final String dayKeyNow = today;
        final int countNow = countToday;
        ai.provider().sendMessage(system, new ArrayList<String>(), "[app_opened]", new AIProvider.AICallback() {
            @Override
            public void onSuccess(String responseText) {
                String greeting = clean(responseText);
                if (greeting == null) {
                    return;
                }
                remember(p, greeting, dayKeyNow, countNow + 1);
                callback.onGreeting(greeting);
            }

            @Override
            public void onError(String errorMessage, int errorCode) {
                // Silence is the right fallback: no canned phrase.
            }
        });
    }

    /** null = stay silent. Package-visible for tests. */
    static String clean(String raw) {
        if (raw == null) {
            return null;
        }
        String t = TextSanitizer.stripMarkdown(raw).trim();
        if (t.length() == 0 || t.toUpperCase(Locale.ROOT).contains("[SILENCIO]") || t.contains("\u00A7")) {
            return null;
        }
        if (t.startsWith("\"") && t.endsWith("\"") && t.length() > 2) {
            t = t.substring(1, t.length() - 1).trim();
        }
        if (t.split("\\s+").length > MAX_WORDS || t.length() > 140) {
            return null;
        }
        return t;
    }

    private static ArrayList<String> recent(SharedPreferences p) {
        ArrayList<String> out = new ArrayList<String>();
        try {
            JSONArray arr = new JSONArray(p.getString(KEY_RECENT, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                out.add(arr.getString(i));
            }
        } catch (Exception ignored) {
            // Start fresh.
        }
        return out;
    }

    private static void remember(SharedPreferences p, String greeting, String day, int count) {
        ArrayList<String> list = recent(p);
        list.add(greeting);
        while (list.size() > 5) {
            list.remove(0);
        }
        JSONArray arr = new JSONArray();
        for (int i = 0; i < list.size(); i++) {
            arr.put(list.get(i));
        }
        p.edit().putString(KEY_RECENT, arr.toString()).putString(KEY_DAY, day).putInt(KEY_DAY_COUNT, count).apply();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String dayKey(long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        return c.get(Calendar.YEAR) + "-" + c.get(Calendar.DAY_OF_YEAR);
    }

    private static String partOfDay(long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        int h = c.get(Calendar.HOUR_OF_DAY);
        if (h < 5) return "deep night";
        if (h < 12) return "morning";
        if (h < 18) return "afternoon";
        if (h < 23) return "evening";
        return "late night";
    }

    private static String weekday(long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        String n = c.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.ENGLISH);
        return n == null ? "today" : n;
    }
}
