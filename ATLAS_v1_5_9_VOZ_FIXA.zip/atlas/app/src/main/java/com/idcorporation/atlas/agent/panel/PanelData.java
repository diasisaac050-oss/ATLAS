package com.idcorporation.atlas.agent.panel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Data for an in-app panel (weather, news, search, places). It only ever
 * carries values a real tool just fetched - the UI draws native Views from
 * it, never an image. Travels to PanelActivity as a JSON string extra.
 */
public final class PanelData {

    public static final String TYPE_WEATHER = "weather";
    public static final String TYPE_NEWS = "news";
    public static final String TYPE_SEARCH = "search";
    public static final String TYPE_PLACES = "places";

    public static final class Row {
        public final String title;
        public final String subtitle;
        public final String meta;
        /** http(s) or geo: link opened on tap; may be empty. */
        public final String url;

        public Row(String title, String subtitle, String meta, String url) {
            this.title = title == null ? "" : title;
            this.subtitle = subtitle == null ? "" : subtitle;
            this.meta = meta == null ? "" : meta;
            this.url = url == null ? "" : url;
        }
    }

    public String type = TYPE_SEARCH;
    public String title = "";
    public String subtitle = "";
    /** Big highlighted value (weather: the temperature). */
    public String heroValue = "";
    public String heroLabel = "";
    public String heroDetail = "";
    public String source = "";
    public final ArrayList<Row> rows = new ArrayList<Row>();

    public String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("title", title);
            o.put("subtitle", subtitle);
            o.put("heroValue", heroValue);
            o.put("heroLabel", heroLabel);
            o.put("heroDetail", heroDetail);
            o.put("source", source);
            JSONArray arr = new JSONArray();
            for (int i = 0; i < rows.size(); i++) {
                Row r = rows.get(i);
                JSONObject ro = new JSONObject();
                ro.put("t", r.title);
                ro.put("s", r.subtitle);
                ro.put("m", r.meta);
                ro.put("u", r.url);
                arr.put(ro);
            }
            o.put("rows", arr);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public static PanelData fromJson(String json) {
        PanelData p = new PanelData();
        try {
            JSONObject o = new JSONObject(json);
            p.type = o.optString("type", TYPE_SEARCH);
            p.title = o.optString("title", "");
            p.subtitle = o.optString("subtitle", "");
            p.heroValue = o.optString("heroValue", "");
            p.heroLabel = o.optString("heroLabel", "");
            p.heroDetail = o.optString("heroDetail", "");
            p.source = o.optString("source", "");
            JSONArray arr = o.optJSONArray("rows");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject ro = arr.getJSONObject(i);
                    p.rows.add(new Row(ro.optString("t", ""), ro.optString("s", ""),
                        ro.optString("m", ""), ro.optString("u", "")));
                }
            }
        } catch (Exception e) {
            // A malformed payload simply shows an empty panel.
        }
        return p;
    }
}
