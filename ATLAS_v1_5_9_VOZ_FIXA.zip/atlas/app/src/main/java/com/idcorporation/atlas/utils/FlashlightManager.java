package com.idcorporation.atlas.utils;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;

public class FlashlightManager {

    private final CameraManager cameraManager;
    private String torchCameraId;

    public FlashlightManager(Context context) {
        this.cameraManager = (CameraManager) context.getApplicationContext()
            .getSystemService(Context.CAMERA_SERVICE);
        resolveTorchCameraId();
    }

    private void resolveTorchCameraId() {
        if (cameraManager == null) {
            return;
        }
        try {
            String[] cameraIds = cameraManager.getCameraIdList();
            for (int i = 0; i < cameraIds.length; i++) {
                String id = cameraIds[i];
                Boolean hasFlash = cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (hasFlash != null && hasFlash.booleanValue()) {
                    torchCameraId = id;
                    return;
                }
            }
        } catch (CameraAccessException e) {
            torchCameraId = null;
        }
    }

    /** @return true if the torch was successfully toggled. */
    public boolean setTorchEnabled(boolean enabled) {
        if (cameraManager == null || torchCameraId == null) {
            return false;
        }
        try {
            cameraManager.setTorchMode(torchCameraId, enabled);
            return true;
        } catch (CameraAccessException e) {
            return false;
        }
    }
}
