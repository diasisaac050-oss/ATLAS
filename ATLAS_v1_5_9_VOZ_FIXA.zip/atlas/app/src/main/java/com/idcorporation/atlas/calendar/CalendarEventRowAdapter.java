package com.idcorporation.atlas.calendar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.models.CalendarEventItem;

import java.util.ArrayList;
import java.util.Locale;

public class CalendarEventRowAdapter extends RecyclerView.Adapter<CalendarEventRowAdapter.EventViewHolder> {

    public interface OnEventDeleteListener {
        void onDelete(long eventId);
    }

    private final ArrayList<CalendarEventItem> items;
    private final OnEventDeleteListener deleteListener;

    public CalendarEventRowAdapter(ArrayList<CalendarEventItem> items, OnEventDeleteListener deleteListener) {
        this.items = items;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_calendar_event_row, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        final CalendarEventItem item = items.get(position);
        holder.title.setText(item.getTitle());
        if (item.hasTime()) {
            holder.time.setText(String.format(Locale.getDefault(), "%02d:%02d", item.getHour(), item.getMinute()));
        } else if (CalendarEventItem.TYPE_BIRTHDAY.equals(item.getEventType())) {
            holder.time.setText(R.string.calendar_label_birthday);
        } else {
            holder.time.setText(R.string.calendar_label_all_day);
        }
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (deleteListener != null) {
                    deleteListener.onDelete(item.getId());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView time;
        ImageButton deleteButton;

        EventViewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.text_event_title);
            time = (TextView) itemView.findViewById(R.id.text_event_time);
            deleteButton = (ImageButton) itemView.findViewById(R.id.button_delete_event);
        }
    }
}
