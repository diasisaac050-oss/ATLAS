package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.StatFs;
import android.text.format.DateFormat;

import java.util.Date;

public class DeviceInfoUtil {

    public static int getBatteryPercent(Context context) {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, filter);
        if (batteryStatus == null) {
            return -1;
        }
        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        if (level < 0 || scale <= 0) {
            return -1;
        }
        return (int) ((level / (float) scale) * 100);
    }

    public static boolean isCharging(Context context) {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, filter);
        if (batteryStatus == null) {
            return false;
        }
        int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        return status == BatteryManager.BATTERY_STATUS_CHARGING
            || status == BatteryManager.BATTERY_STATUS_FULL;
    }

    public static boolean isConnectedToInternet(Context context) {
        ConnectivityManager connectivityManager =
            (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            return false;
        }
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnected();
    }

    public static long getAvailableStorageBytes() {
        StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
        return stat.getAvailableBytes();
    }

    public static String getAvailableStorageFormatted() {
        long bytes = getAvailableStorageBytes();
        double gigabytes = bytes / (1024.0 * 1024.0 * 1024.0);
        return String.valueOf(Math.round(gigabytes * 10.0) / 10.0) + " GB";
    }

    public static String getCurrentTimeSpoken(Context context) {
        return DateFormat.getTimeFormat(context).format(new Date());
    }

    public static String getCurrentDateSpoken(Context context) {
        return DateFormat.getLongDateFormat(context).format(new Date());
    }
}
