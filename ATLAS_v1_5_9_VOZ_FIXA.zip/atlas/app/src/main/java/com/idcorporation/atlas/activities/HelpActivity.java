package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.idcorporation.atlas.R;

public class HelpActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.row_how_to_use).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDetail(getString(R.string.help_how_to_use_title), getString(R.string.help_how_to_use_body));
            }
        });

        findViewById(R.id.row_what_is_atlas).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDetail(getString(R.string.help_what_is_atlas_title), getString(R.string.help_what_is_atlas_body));
            }
        });
    }

    private void openDetail(String title, String body) {
        Intent intent = new Intent(this, HelpDetailActivity.class);
        intent.putExtra(HelpDetailActivity.EXTRA_TITLE, title);
        intent.putExtra(HelpDetailActivity.EXTRA_BODY, body);
        startActivity(intent);
    }
}
