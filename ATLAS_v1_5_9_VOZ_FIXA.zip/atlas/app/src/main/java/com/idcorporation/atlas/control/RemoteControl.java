package com.idcorporation.atlas.control;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.MaintenanceActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * ATLAS CONSOLE: le o painel de controle que o app "Atlas Console" grava
 * no Firebase (/control) e aplica:
 *   - bloqueio total (tela "Aguardar")
 *   - versao minima obrigatoria (tambem usa a tela "Aguardar")
 *   - aviso para os usuarios (dialogo mostrado uma vez por aviso)
 *   - IA ligada/desligada
 *
 * Leitura publica (as regras so deixam o admin ESCREVER): o Atlas nao precisa
 * de login nem de SDK, igual ao GroqProvider - HTTPS puro.
 *
 * Regra de seguranca: se nao conseguir consultar (sem internet, servidor
 * fora), o Atlas NAO bloqueia nada - problema de rede nunca trava o app.
 */
public final class RemoteControl {

    /** Mesmo valor do DB_URL do Atlas Console. Sem barra no final. */
    static final String DB_URL =
        "https://atlas-console-5c65d-default-rtdb.firebaseio.com";

    /** Evita consultar o servidor a cada troca de tela. */
    private static final long MIN_INTERVAL_MS = 4000;

    private static final String PREFS = "atlas_console_prefs";
    private static final String KEY_ANN_SEEN = "ann_seen";

    public interface Callback {
        /**
         * ok=false quando nao deu pra consultar (blocked vem false).
         * blocked/message ja consideram bloqueio manual E versao minima.
         */
        void onResult(boolean ok, boolean blocked, String message);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    // Ultimo estado conhecido (em memoria).
    private static volatile boolean lastBlocked = false;
    private static volatile String lastMessage = "";
    private static volatile long lastCheckAt = 0;
    private static volatile boolean aiEnabled = true;
    private static volatile String aiOffMessage = "";
    private static volatile String annId = "";
    private static volatile String annTitle = "";
    private static volatile String annText = "";
    private static volatile boolean annActive = false;

    private RemoteControl() {}

    /** A IA esta liberada pelo admin? (true se nunca conseguiu consultar) */
    public static boolean isAiEnabled() {
        return aiEnabled;
    }

    /** Mensagem a mostrar quando o admin desligou a IA. */
    public static String aiOffMessage(Context context) {
        String m = aiOffMessage;
        if (m == null || m.trim().isEmpty()) {
            return context.getString(R.string.ai_paused_default);
        }
        return m;
    }

    /** Chamado pelo BaseActivity.onResume(). Nunca lanca excecao. */
    public static void guard(final Activity activity) {
        try {
            Telemetry.heartbeat(activity);
            long now = System.currentTimeMillis();
            if (now - lastCheckAt < MIN_INTERVAL_MS) {
                if (lastBlocked) {
                    open(activity, lastMessage);
                }
                return;
            }
            fetch(activity, new Callback() {
                @Override
                public void onResult(boolean ok, boolean blocked, String message) {
                    if (!ok || activity.isFinishing()) {
                        return;
                    }
                    if (blocked) {
                        open(activity, message);
                    } else {
                        maybeShowAnnouncement(activity);
                    }
                }
            });
        } catch (Throwable ignored) {
            // Nunca deixa o Console derrubar o Atlas.
        }
    }

    /** Consulta o servidor em segundo plano; o callback roda na thread principal. */
    public static void fetch(Context context, final Callback callback) {
        final Context app = context.getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean ok = false;
                boolean blocked = false;
                String message = "";
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(DB_URL + "/control.json").openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(5000);
                    c.setReadTimeout(5000);
                    if (c.getResponseCode() == 200) {
                        StringBuilder sb = new StringBuilder();
                        BufferedReader r = new BufferedReader(
                            new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
                        String line;
                        while ((line = r.readLine()) != null) {
                            sb.append(line);
                        }
                        r.close();
                        String raw = sb.toString().trim();
                        JSONObject o = (raw.isEmpty() || raw.equals("null"))
                            ? new JSONObject() : new JSONObject(raw);

                        boolean manual = o.optBoolean("blocked", false);
                        String manualMsg = o.optString("message", "");
                        long minVersion = o.optLong("minVersionCode", 0);
                        boolean tooOld = minVersion > 0 && currentVersionCode(app) < minVersion;

                        if (manual) {
                            blocked = true;
                            message = manualMsg;
                        } else if (tooOld) {
                            blocked = true;
                            message = o.optString("updateMessage", "");
                            if (message.trim().isEmpty()) {
                                message = app.getString(R.string.maintenance_update_default);
                            }
                        }

                        aiEnabled = o.optBoolean("aiEnabled", true);
                        aiOffMessage = o.optString("aiOffMessage", "");
                        annActive = o.optBoolean("annActive", false);
                        annId = o.optString("annId", "");
                        annTitle = o.optString("annTitle", "");
                        annText = o.optString("annText", "");
                        ok = true;
                    }
                } catch (Throwable ignored) {
                    ok = false;
                } finally {
                    if (c != null) {
                        c.disconnect();
                    }
                }
                final boolean fOk = ok;
                final boolean fBlocked = blocked;
                final String fMessage = message;
                if (fOk) {
                    lastBlocked = fBlocked;
                    lastMessage = fMessage;
                    lastCheckAt = System.currentTimeMillis();
                }
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onResult(fOk, fBlocked, fMessage);
                    }
                });
            }
        }).start();
    }

    @SuppressWarnings("deprecation")
    static long currentVersionCode(Context context) {
        try {
            PackageInfo pi = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Throwable t) {
            return Long.MAX_VALUE; // se nao souber, nunca acusa "versao antiga"
        }
    }

    /** Mostra o aviso do admin uma unica vez por aviso (por id). */
    private static void maybeShowAnnouncement(Activity activity) {
        try {
            if (!annActive || annId.isEmpty() || annText.trim().isEmpty()) {
                return;
            }
            SharedPreferences p = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            if (annId.equals(p.getString(KEY_ANN_SEEN, ""))) {
                return;
            }
            p.edit().putString(KEY_ANN_SEEN, annId).apply();
            AlertDialog.Builder b = new AlertDialog.Builder(activity);
            if (!annTitle.trim().isEmpty()) {
                b.setTitle(annTitle);
            }
            b.setMessage(annText);
            b.setPositiveButton(android.R.string.ok, null);
            b.show();
        } catch (Throwable ignored) {
            // aviso e opcional; nunca quebra o app
        }
    }

    private static void open(Activity from, String message) {
        if (from instanceof MaintenanceActivity) {
            return;
        }
        Intent i = new Intent(from, MaintenanceActivity.class);
        i.putExtra(MaintenanceActivity.EXTRA_MESSAGE, message);
        // Reaproveita a tela se ela ja estiver aberta, so trazendo pra frente.
        i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        from.startActivity(i);
    }
}
