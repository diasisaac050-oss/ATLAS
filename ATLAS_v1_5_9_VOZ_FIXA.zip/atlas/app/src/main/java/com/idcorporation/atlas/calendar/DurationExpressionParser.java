package com.idcorporation.atlas.calendar;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads "how long from now" out of a sentence: "daqui a 5 minutos",
 * "em uma hora e meia", "daqui a 1 hora e 30", "dentro de 2 horas e 15
 * minutos", "meia hora", "uns 10 minutos". Input is normalized text
 * (lower-case, no accents).
 */
public class DurationExpressionParser {

    public static class DurationResult {
        public boolean found;
        public long millis;
        public int start = -1;
        public int end = -1;
    }

    private static final String NUM = PtNumberWords.NUM;
    private static final String AMOUNT = "(" + NUM + "|meia|meio|um\\s+quarto)";
    private static final String UNITS = "(horas?|hrs?|hs|h|minutos?|mins?|segundos?|segs?)";

    private static final Pattern TRIGGER = Pattern.compile(
        "\\b(?:daqui\\s+a|daqui|de\\s+aqui\\s+a|dentro\\s+de|depois\\s+de|apos|em)\\s+"
        + "(?:(?:uns|umas|cerca\\s+de|mais\\s+ou\\s+menos|aproximadamente)\\s+)?");
    private static final Pattern PART = Pattern.compile(
        "(?:e\\s+)?" + AMOUNT + "\\s*(?:de\\s+)?" + UNITS + "\\b");
    private static final Pattern HALF_AFTER_HOURS = Pattern.compile("e\\s+(meia|um\\s+quarto)\\b");
    private static final Pattern BARE_MINUTES_AFTER_HOURS = Pattern.compile(
        "e\\s+(" + NUM + ")\\b(?!\\s*(?:horas?|hrs?|h\\b|dias?|de\\s))");
    private static final Pattern BARE_MINUTES = Pattern.compile(
        "\\b(" + NUM + ")\\s*(minutos?|mins?|segundos?|segs?)\\b");
    private static final Pattern HALF_HOUR = Pattern.compile("\\bmeia\\s+hora\\b");

    /**
     * With allowBare false only phrases introduced by "daqui a / em / dentro de"
     * count, which is safe next to clock times ("as 7 horas e 30 minutos").
     * With allowBare true a loose "10 minutos" or "meia hora" also counts.
     */
    public static DurationResult parse(String n, boolean allowBare) {
        DurationResult r = new DurationResult();
        Matcher trigger = TRIGGER.matcher(n);
        while (trigger.find()) {
            int idx = trigger.end();
            int chainStart = trigger.start();
            double total = 0.0;
            boolean any = false;
            boolean lastWasHours = false;
            while (idx <= n.length()) {
                idx = skipSpaces(n, idx);
                Matcher part = PART.matcher(n);
                part.region(idx, n.length());
                if (part.lookingAt()) {
                    total += amountValue(part.group(1)) * unitMillis(part.group(2));
                    lastWasHours = part.group(2).startsWith("h");
                    idx = part.end();
                    any = true;
                    continue;
                }
                if (any && lastWasHours) {
                    Matcher half = HALF_AFTER_HOURS.matcher(n);
                    half.region(idx, n.length());
                    if (half.lookingAt()) {
                        total += ("meia".equals(half.group(1)) ? 30.0 : 15.0) * 60000.0;
                        idx = half.end();
                        lastWasHours = false;
                        continue;
                    }
                    Matcher bare = BARE_MINUTES_AFTER_HOURS.matcher(n);
                    bare.region(idx, n.length());
                    if (bare.lookingAt()) {
                        int minutes = PtNumberWords.value(bare.group(1));
                        if (minutes >= 1 && minutes <= 59) {
                            total += minutes * 60000.0;
                            idx = bare.end();
                            lastWasHours = false;
                            continue;
                        }
                    }
                }
                break;
            }
            if (any && accept(total)) {
                return fill(r, (long) total, chainStart, idx);
            }
        }
        if (!allowBare) {
            return r;
        }
        Matcher bareMinutes = BARE_MINUTES.matcher(n);
        if (bareMinutes.find()) {
            int amount = PtNumberWords.value(bareMinutes.group(1));
            double total = amount * unitMillis(bareMinutes.group(2));
            if (amount > 0 && accept(total)) {
                return fill(r, (long) total, bareMinutes.start(), bareMinutes.end());
            }
        }
        Matcher halfHour = HALF_HOUR.matcher(n);
        if (halfHour.find()) {
            return fill(r, 30L * 60000L, halfHour.start(), halfHour.end());
        }
        return r;
    }

    private static boolean accept(double totalMillis) {
        return totalMillis >= 1000.0 && totalMillis <= 30.0 * 24.0 * 3600000.0;
    }

    private static DurationResult fill(DurationResult r, long millis, int start, int end) {
        r.found = true;
        r.millis = millis;
        r.start = start;
        r.end = end;
        return r;
    }

    private static int skipSpaces(String n, int from) {
        int i = from;
        while (i < n.length() && n.charAt(i) == ' ') {
            i++;
        }
        return i;
    }

    private static double amountValue(String token) {
        String t = token.trim().replaceAll("\\s+", " ");
        if ("meia".equals(t) || "meio".equals(t)) {
            return 0.5;
        }
        if ("um quarto".equals(t)) {
            return 0.25;
        }
        return (double) PtNumberWords.value(t);
    }

    private static double unitMillis(String unit) {
        if (unit.startsWith("h")) {
            return 3600000.0;
        }
        if (unit.startsWith("s")) {
            return 1000.0;
        }
        return 60000.0;
    }
}
