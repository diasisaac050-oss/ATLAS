package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;
import android.widget.Toast;

import com.idcorporation.atlas.AtlasApplication;
import com.idcorporation.atlas.R;
import com.idcorporation.atlas.chat.ChatStyle;
import com.idcorporation.atlas.chat.ModePreviewView;
import com.idcorporation.atlas.theme.ThemeManager;
import com.idcorporation.atlas.utils.ModeManager;
import com.idcorporation.atlas.utils.PresenceManager;
import com.idcorporation.atlas.utils.ViewAnimUtils;

/**
 * ATLAS MODOS - Settings > Modos. Two big cards, Voice and Chat, each
 * with a live preview. Tapping a card selects it; the bottom button
 * applies the choice and reopens ATLAS in that mode.
 */
public class ModesActivity extends BaseActivity {

    private int accent = 0xFF00E5FF;
    private int currentMode;
    private int selectedMode;
    private boolean applying = false;

    private View cardVoice;
    private View cardChat;
    private TextView badgeVoice;
    private TextView badgeChat;
    private ModePreviewView previewVoice;
    private ModePreviewView previewChat;
    private TextView applyButton;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modes);

        accent = ThemeManager.getSelectedPalette(this).getAccentColor();
        currentMode = ModeManager.getMode(this);
        selectedMode = currentMode;

        cardVoice = findViewById(R.id.card_voice);
        cardChat = findViewById(R.id.card_chat);
        badgeVoice = (TextView) findViewById(R.id.badge_voice);
        badgeChat = (TextView) findViewById(R.id.badge_chat);
        previewVoice = (ModePreviewView) findViewById(R.id.preview_voice);
        previewChat = (ModePreviewView) findViewById(R.id.preview_chat);
        applyButton = (TextView) findViewById(R.id.modes_apply);

        previewVoice.setPreviewStyle(ModePreviewView.STYLE_VOICE);
        previewChat.setPreviewStyle(ModePreviewView.STYLE_CHAT);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        cardVoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                select(ModeManager.MODE_VOICE);
            }
        });
        cardChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                select(ModeManager.MODE_CHAT);
            }
        });
        applyButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (selectedMode == currentMode) {
                    return false;
                }
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90L).start();
                } else if (event.getAction() == MotionEvent.ACTION_UP
                        || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(240L)
                        .setInterpolator(new OvershootInterpolator(2.4f)).start();
                }
                return false;
            }
        });
        applyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applySelectedMode();
            }
        });

        refresh(false);
        ViewAnimUtils.animateEntrance(findViewById(R.id.modes_header), 0);
        ViewAnimUtils.animateEntrance(findViewById(R.id.modes_subtitle), 80);
        ViewAnimUtils.animateEntrance(cardVoice, 160);
        ViewAnimUtils.animateEntrance(cardChat, 260);
        ViewAnimUtils.animateEntrance(findViewById(R.id.modes_footnote), 340);
        ViewAnimUtils.animateEntrance(applyButton, 380);
    }

    private void select(int mode) {
        if (applying || mode == selectedMode) {
            return;
        }
        selectedMode = mode;
        refresh(true);
        View picked = (mode == ModeManager.MODE_CHAT) ? cardChat : cardVoice;
        picked.setScaleX(0.96f);
        picked.setScaleY(0.96f);
        picked.animate().scaleX(1f).scaleY(1f).setDuration(380L)
            .setInterpolator(new OvershootInterpolator(2.6f)).start();
    }

    private void refresh(boolean animate) {
        styleCard(cardVoice, previewVoice, ModeManager.MODE_VOICE, animate);
        styleCard(cardChat, previewChat, ModeManager.MODE_CHAT, animate);
        styleBadge(badgeVoice, currentMode == ModeManager.MODE_VOICE);
        styleBadge(badgeChat, currentMode == ModeManager.MODE_CHAT);
        styleApplyButton();
    }

    private void styleCard(View card, ModePreviewView preview, int mode, boolean animate) {
        boolean selected = (mode == selectedMode);
        int strokeAlpha = selected ? 0xFF : 0x44;
        float strokeDp = selected ? 2f : 1f;
        card.setBackground(ChatStyle.pill(this, ChatStyle.GLASS_FILL,
            ChatStyle.withAlpha(accent, strokeAlpha), strokeDp, 22f));
        preview.setAccent(accent);
        preview.setEnergy(selected ? 1f : 0.35f);
        float targetAlpha = selected ? 1f : 0.72f;
        float targetScale = selected ? 1f : 0.98f;
        if (animate) {
            card.animate().alpha(targetAlpha).scaleX(targetScale).scaleY(targetScale)
                .setDuration(260L).start();
        } else {
            card.setAlpha(targetAlpha);
            card.setScaleX(targetScale);
            card.setScaleY(targetScale);
        }
    }

    private void styleBadge(TextView badge, boolean active) {
        badge.setVisibility(active ? View.VISIBLE : View.GONE);
        badge.setBackground(ChatStyle.pill(this, ChatStyle.withAlpha(accent, 0x33), accent, 1f, 12f));
        badge.setTextColor(accent);
    }

    private void styleApplyButton() {
        boolean changed = (selectedMode != currentMode);
        if (!changed) {
            applyButton.setText(R.string.mode_apply_current);
            applyButton.setTextColor(ChatStyle.TEXT_SECONDARY);
            applyButton.setBackground(ChatStyle.pill(this, ChatStyle.GLASS_FILL,
                ChatStyle.withAlpha(accent, 0x55), 1f, 26f));
            applyButton.setClickable(false);
            applyButton.setAlpha(0.7f);
            return;
        }
        applyButton.setText(selectedMode == ModeManager.MODE_CHAT
            ? R.string.mode_apply_chat : R.string.mode_apply_voice);
        applyButton.setTextColor(ChatStyle.readableOn(accent));
        applyButton.setBackground(ChatStyle.accentPill(this, accent, 26f));
        applyButton.setClickable(true);
        applyButton.setAlpha(1f);
    }

    private void applySelectedMode() {
        if (applying || selectedMode == currentMode) {
            return;
        }
        applying = true;
        final int target = selectedMode;
        ModeManager.setMode(this, target);
        if (target == ModeManager.MODE_CHAT) {
            // Hang up the always-on call: no mic, no speech from now on.
            AtlasApplication.voiceSession(this).suspendForChatMode();
        }
        PresenceManager.syncWithMode(this);
        currentMode = target;
        refresh(true);

        Toast.makeText(this, target == ModeManager.MODE_CHAT
            ? R.string.mode_switched_chat : R.string.mode_switched_voice, Toast.LENGTH_SHORT).show();

        final View picked = (target == ModeManager.MODE_CHAT) ? cardChat : cardVoice;
        picked.animate().scaleX(1.05f).scaleY(1.05f).setDuration(220L)
            .setInterpolator(new OvershootInterpolator(2f)).start();
        applyButton.animate().alpha(0f).setDuration(260L).start();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) {
                    return;
                }
                Intent home = ModeManager.homeIntent(ModesActivity.this);
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(home);
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }
        }, 650L);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
