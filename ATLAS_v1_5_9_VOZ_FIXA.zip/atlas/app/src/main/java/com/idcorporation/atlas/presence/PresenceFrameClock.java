package com.idcorporation.atlas.presence;

import com.idcorporation.atlas.activities.HudStateManager;

/**
 * Advances everything in PresenceBubbleState that changes by itself every
 * frame: the smoothed mode amounts (thinking / speaking / error), the inner
 * light time, the travelling edge light and the glass gleam that sweeps
 * across every few seconds.
 */
final class PresenceFrameClock {

    private static final float SHEEN_PERIOD = 7.0f;
    private static final float SHEEN_LENGTH = 1.3f;

    private float sheenClock = 0f;

    /** Makes the first gleam happen shortly after the bubble finished opening. */
    void primeSheen() {
        sheenClock = SHEEN_PERIOD - 0.5f;
    }

    void step(float dt, int hudState, PresenceBubbleState st) {
        st.phase = st.phase + dt;
        st.level = st.level * (1f - Math.min(1f, dt * 4f));

        float k = Math.min(1f, dt * 6f);
        boolean thinking = (hudState == HudStateManager.STATE_PROCESSING
            || hudState == HudStateManager.STATE_THINKING
            || hudState == HudStateManager.STATE_EXECUTING);
        st.thinkAmt = st.thinkAmt + ((thinking ? 1f : 0f) - st.thinkAmt) * k;
        st.speakAmt = st.speakAmt
            + (((hudState == HudStateManager.STATE_SPEAKING) ? 1f : 0f) - st.speakAmt) * k;
        st.errAmt = st.errAmt
            + (((hudState == HudStateManager.STATE_ERROR) ? 1f : 0f) - st.errAmt) * k;

        st.orbit = st.orbit + dt * (0.45f + 1.6f * st.thinkAmt + 0.9f * st.level + 0.5f * st.speakAmt);
        st.rimAngle = st.rimAngle
            + dt * (18f + 240f * st.thinkAmt + 40f * st.speakAmt + 30f * st.level);
        if (st.rimAngle > 3600f) {
            st.rimAngle = st.rimAngle - 3600f;
        }

        if (st.open > 0.85f) {
            sheenClock = sheenClock + dt;
        }
        if (sheenClock >= SHEEN_PERIOD) {
            float t = (sheenClock - SHEEN_PERIOD) / SHEEN_LENGTH;
            if (t >= 1f) {
                sheenClock = 0f;
                st.sheen = -1f;
            } else {
                st.sheen = t;
            }
        } else {
            st.sheen = -1f;
        }
    }
}
