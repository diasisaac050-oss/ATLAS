package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;

/**
 * The edge of the glass: a hairline with a travelling comet of light (it
 * circles slowly, and whirls while ATLAS thinks), fixed specular lobes from
 * a light at the top left, a thin bevel and a tiny glint. Hairlines are what
 * make it look like real glass instead of a colored blob.
 */
final class PresenceGlassRim {

    private final float d;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix = new Matrix();
    private final SweepGradient cometUnit;
    private final SweepGradient specUnit;
    private final RadialGradient glintUnit;

    PresenceGlassRim(float density) {
        this.d = density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);

        int faint = PresenceBlues.alpha(PresenceBlues.SKY, 46);
        cometUnit = new SweepGradient(0f, 0f,
            new int[] {faint, faint,
                       PresenceBlues.alpha(PresenceBlues.LIGHT, 150),
                       PresenceBlues.alpha(PresenceBlues.WHITE, 255),
                       faint},
            new float[] {0f, 0.50f, 0.82f, 0.985f, 1f});

        int none = PresenceBlues.alpha(PresenceBlues.WHITE, 0);
        specUnit = new SweepGradient(0f, 0f,
            new int[] {none, none,
                       PresenceBlues.alpha(PresenceBlues.SKY, 150), none, none,
                       PresenceBlues.alpha(PresenceBlues.WHITE, 240), none, none},
            new float[] {0f, 0.055f, 0.125f, 0.195f, 0.535f, 0.625f, 0.715f, 1f});

        glintUnit = new RadialGradient(0f, 0f, 1f,
            new int[] {PresenceBlues.alpha(PresenceBlues.WHITE, 255),
                       PresenceBlues.alpha(PresenceBlues.WHITE, 0)},
            new float[] {0f, 1f}, Shader.TileMode.CLAMP);
    }

    void draw(Canvas canvas, Path body, float cx, float cy, float a, float b,
              PresenceBubbleState st, float pulse, float alpha) {
        // Thin dark outline: keeps the glass readable on bright wallpapers.
        line.setShader(null);
        line.setStrokeWidth(1f * d);
        line.setColor(PresenceBlues.alpha(PresenceBlues.NAVY, (int) (95f * alpha)));
        drawScaled(canvas, body, cx, cy, 1.018f);

        // Travelling comet (a second one appears opposite while thinking).
        line.setStrokeWidth((1.1f + 0.45f * st.thinkAmt + 0.4f * pulse) * d);
        comet(canvas, body, cx, cy, st.rimAngle, alpha * (0.78f + 0.22f * pulse));
        if (st.thinkAmt > 0.03f) {
            comet(canvas, body, cx, cy, st.rimAngle + 180f, alpha * st.thinkAmt * 0.85f);
        }

        // Fixed specular lobes (light from the top left).
        matrix.setTranslate(cx, cy);
        specUnit.setLocalMatrix(matrix);
        line.setShader(specUnit);
        line.setAlpha(PresenceBlues.a255(alpha * 0.95f));
        line.setStrokeWidth(1.7f * d);
        canvas.drawPath(body, line);

        // Inner bevel gives the glass thickness.
        line.setShader(null);
        line.setStrokeWidth(0.8f * d);
        line.setColor(PresenceBlues.alpha(PresenceBlues.WHITE, (int) (34f * alpha)));
        drawScaled(canvas, body, cx, cy, 0.962f);

        drawGlint(canvas, cx, cy, a, b, st, alpha);
    }

    private void comet(Canvas canvas, Path body, float cx, float cy, float angle, float amount) {
        matrix.setRotate(angle);
        matrix.postTranslate(cx, cy);
        cometUnit.setLocalMatrix(matrix);
        line.setShader(cometUnit);
        line.setAlpha(PresenceBlues.a255(amount));
        canvas.drawPath(body, line);
    }

    private void drawScaled(Canvas canvas, Path body, float cx, float cy, float scale) {
        canvas.save();
        canvas.scale(scale, scale, cx, cy);
        canvas.drawPath(body, line);
        canvas.restore();
    }

    /** A tiny bright spark on the upper left of the glass that twinkles gently. */
    private void drawGlint(Canvas canvas, float cx, float cy, float a, float b,
                           PresenceBubbleState st, float alpha) {
        float tw = 0.75f + 0.25f * (float) Math.sin((double) (st.phase * 2.2f));
        fill.setShader(glintUnit);
        fill.setAlpha(PresenceBlues.a255(alpha * 0.55f * tw));
        canvas.save();
        canvas.translate(cx - a * 0.64f, cy - b * 0.60f);
        canvas.scale(5f * d, 2.6f * d);
        canvas.drawCircle(0f, 0f, 1f, fill);
        canvas.restore();
    }
}
