package com.idcorporation.atlas.agent;

import org.json.JSONArray;

/** Blocking chat-completion call (always invoked off the main thread). */
public interface ModelClient {

    class ModelException extends Exception {
        public final int code;

        public ModelException(String message, int code) {
            super(message);
            this.code = code;
        }
    }

    /**
     * @param toolsEnabled false means "answer in text now": the tool list is still sent
     *                     (history contains tool calls) but tool_choice is none.
     */
    ModelReply chat(JSONArray messages, JSONArray tools, boolean toolsEnabled) throws ModelException;
}
