package com.idcorporation.atlas.theme;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;

import java.util.Random;

/**
 * SHEEN ("Brilho"): polished-light look. Two soft diagonal beams of light
 * glide across the screen and then rest (like light catching a surface),
 * while small star glints flare with a cross of light, in the same
 * white-hot-over-accent tint as the sphere core.
 */
public class SheenSweepBackgroundView extends FxBackgroundView {

    private static final int GLINTS = 16;
    private static final float TILT_DEG = 20f;

    private final Paint beamPaint = new Paint();
    private float beamWide;
    private float beamThin;
    private final float[] gx = new float[GLINTS];
    private final float[] gy = new float[GLINTS];
    private final float[] gPeriod = new float[GLINTS];
    private final float[] gPhase = new float[GLINTS];
    private final float[] gSize = new float[GLINTS];
    private final Random rng = new Random(23);

    public SheenSweepBackgroundView(Context context) {
        super(context);
        beamPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
    }

    @Override
    protected void onPalette() {
        buildBeamShader();
    }

    @Override
    protected void onSized(int width, int height) {
        beamWide = width * 0.60f;
        beamThin = width * 0.14f;
        for (int i = 0; i < GLINTS; i++) {
            gx[i] = rnd(rng, 0.06f, 0.94f) * width;
            gy[i] = rnd(rng, 0.05f, 0.95f) * height;
            gPeriod[i] = rnd(rng, 3.2f, 7.5f);
            gPhase[i] = rnd(rng, 0f, 1f);
            gSize[i] = rnd(rng, 0.6f, 1.25f);
        }
        buildBeamShader();
    }

    // a horizontal soft-edged band: nothing -> accent-bright -> nothing (the beam is rotated when drawn)
    private void buildBeamShader() {
        if (beamWide <= 0f) {
            return;
        }
        int core = mix(accent, 0xFFFFFFFF, 0.35f);
        int c0 = core & 0x00FFFFFF;
        int c1 = (0x55 << 24) | (core & 0x00FFFFFF);
        beamPaint.setShader(new LinearGradient(-0.5f, 0f, 0.5f, 0f,
                new int[]{c0, c1, c0}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
    }

    private void drawBeam(Canvas c, float width, float cycle, float offset, float strength) {
        float p = ((time / cycle) + offset) % 1f;
        float s = p / 0.64f;
        if (s >= 1f) {
            return;                       // resting part of the cycle
        }
        float e = s * s * (3f - 2f * s);  // ease in/out
        float env = (float) Math.sin(Math.PI * s);
        float cx = -0.35f * w + e * 1.7f * w;
        float cy = h * 0.5f;
        float diag = (float) Math.hypot(w, h);
        beamPaint.setAlpha((int) (255f * Math.min(1f, strength * env)));
        c.save();
        c.translate(cx, cy);
        c.rotate(TILT_DEG);
        c.scale(width, 1f);               // gradient is 1 unit wide: scale it to the beam width
        c.drawRect(-0.5f, -diag, 0.5f, diag, beamPaint);
        c.restore();
    }

    @Override
    protected void drawFx(Canvas c, float dt) {
        // a quiet corner highlight that breathes
        float br = 0.8f + 0.2f * (float) Math.sin(time * 0.5f);
        glowRect(c, w * 0.12f, h * 0.06f, w * 0.75f, h * 0.30f, 0.15f * br);

        drawBeam(c, beamWide, 13f, 0.00f, 0.55f);
        drawBeam(c, beamThin, 13f, 0.07f, 0.85f);
        drawBeam(c, beamWide * 0.7f, 17f, 0.55f, 0.35f);

        for (int i = 0; i < GLINTS; i++) {
            float ph = (time / gPeriod[i] + gPhase[i]) % 1f;
            float f = (float) Math.sin(ph * Math.PI);
            f = f * f * f * f * f * f;       // sharp peak, long rest
            float base = 0.10f;
            float r = 3.0f * dens * gSize[i];
            glow(c, gx[i], gy[i], r * 2.2f, base + 0.35f * f);
            if (f > 0.02f) {
                hotGlow(c, gx[i], gy[i], r * (0.6f + 0.9f * f), 0.9f * f);
                float arm = 26f * dens * gSize[i] * f;
                glowRect(c, gx[i], gy[i], arm, 1.6f * dens, 0.85f * f);
                glowRect(c, gx[i], gy[i], 1.6f * dens, arm * 0.8f, 0.7f * f);
            }
        }
    }
}
