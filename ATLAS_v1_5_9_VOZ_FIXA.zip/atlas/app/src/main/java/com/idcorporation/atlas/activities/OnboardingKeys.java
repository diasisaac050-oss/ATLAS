package com.idcorporation.atlas.activities;

/**
 * Intent extra keys used to carry onboarding answers forward from one
 * step activity to the next, one field at a time.
 */
public final class OnboardingKeys {

    public static final String FULL_NAME = "onboarding_full_name";
    public static final String CALL_NAME = "onboarding_call_name";
    public static final String EMAIL = "onboarding_email";
    public static final String AGE = "onboarding_age";
    public static final String GENDER = "onboarding_gender";
    public static final String BIRTH_YEAR = "onboarding_birth_year";
    public static final String BIRTH_MONTH = "onboarding_birth_month";
    public static final String BIRTH_DAY = "onboarding_birth_day";

    private OnboardingKeys() {
    }
}
