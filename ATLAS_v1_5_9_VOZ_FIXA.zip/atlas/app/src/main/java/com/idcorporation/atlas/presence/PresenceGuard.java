package com.idcorporation.atlas.presence;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.camera2.CameraManager;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import java.util.HashSet;

/**
 * Decides when the shake gesture must be ignored:
 *
 * 1) Screen off: the phone is off/asleep, so shaking it (in a pocket, in
 *    a bag) must never open the bubble or turn the microphone on.
 * 2) Camera in use: while any app has a camera open (camera app, video
 *    call, scanner) the bubble stays away, so it does not appear on top
 *    of the viewfinder and does not fight for the microphone while
 *    a video is being recorded.
 *
 * The flashlight is NOT counted as "camera in use": the ATLAS flashlight
 * command must not block the bubble.
 *
 * No extra permission is needed: CameraManager only reports whether a
 * camera is free or taken, it never opens or sees the camera.
 */
public class PresenceGuard {

    public interface Listener {
        /** Screen turned on (true) or off (false). */
        void onScreenChanged(boolean on);

        /** Some app just opened a camera. */
        void onCameraBusy();
    }

    private final Context appContext;
    private final Listener listener;
    private final PowerManager powerManager;
    private final CameraManager cameraManager;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final HashSet<String> unavailableCameras = new HashSet<String>();
    private final HashSet<String> torchOnCameras = new HashSet<String>();

    private BroadcastReceiver screenReceiver;
    private CameraManager.AvailabilityCallback cameraCallback;
    private CameraManager.TorchCallback torchCallback;
    private boolean started = false;

    public PresenceGuard(Context context, Listener listener) {
        this.appContext = context.getApplicationContext();
        this.listener = listener;
        this.powerManager = (PowerManager) appContext.getSystemService(Context.POWER_SERVICE);
        this.cameraManager = (CameraManager) appContext.getSystemService(Context.CAMERA_SERVICE);
    }

    /** True when the shake is allowed to open the bubble right now. */
    public boolean canActivate() {
        return isScreenOn() && !isCameraBusy();
    }

    public boolean isScreenOn() {
        if (powerManager == null) {
            return true;
        }
        return powerManager.isInteractive();
    }

    public boolean isCameraBusy() {
        for (String id : unavailableCameras) {
            if (!torchOnCameras.contains(id)) {
                return true;
            }
        }
        return false;
    }

    public void start() {
        if (started) {
            return;
        }
        started = true;
        registerScreenReceiver();
        registerCameraCallbacks();
    }

    public void stop() {
        if (!started) {
            return;
        }
        started = false;
        if (screenReceiver != null) {
            try {
                appContext.unregisterReceiver(screenReceiver);
            } catch (RuntimeException e) {
                // Already unregistered.
            }
            screenReceiver = null;
        }
        if (cameraManager != null) {
            try {
                if (cameraCallback != null) {
                    cameraManager.unregisterAvailabilityCallback(cameraCallback);
                }
                if (torchCallback != null) {
                    cameraManager.unregisterTorchCallback(torchCallback);
                }
            } catch (RuntimeException e) {
                // Nothing else to release.
            }
        }
        cameraCallback = null;
        torchCallback = null;
        unavailableCameras.clear();
        torchOnCameras.clear();
    }

    private void registerScreenReceiver() {
        screenReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                    listener.onScreenChanged(false);
                } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                    listener.onScreenChanged(true);
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        appContext.registerReceiver(screenReceiver, filter);
    }

    private void registerCameraCallbacks() {
        if (cameraManager == null) {
            return;
        }
        cameraCallback = new CameraManager.AvailabilityCallback() {
            @Override
            public void onCameraAvailable(String cameraId) {
                unavailableCameras.remove(cameraId);
            }

            @Override
            public void onCameraUnavailable(String cameraId) {
                unavailableCameras.add(cameraId);
                if (isCameraBusy()) {
                    listener.onCameraBusy();
                }
            }
        };
        torchCallback = new CameraManager.TorchCallback() {
            @Override
            public void onTorchModeChanged(String cameraId, boolean enabled) {
                if (enabled) {
                    torchOnCameras.add(cameraId);
                } else {
                    torchOnCameras.remove(cameraId);
                }
            }

            @Override
            public void onTorchModeUnavailable(String cameraId) {
                // Torch cannot be used because a camera app took the camera.
                torchOnCameras.remove(cameraId);
            }
        };
        try {
            cameraManager.registerAvailabilityCallback(cameraCallback, handler);
            cameraManager.registerTorchCallback(torchCallback, handler);
        } catch (RuntimeException e) {
            // If the camera service is not reachable, the guard just keeps
            // the screen-off rule and lets the shake work normally.
        }
    }
}
