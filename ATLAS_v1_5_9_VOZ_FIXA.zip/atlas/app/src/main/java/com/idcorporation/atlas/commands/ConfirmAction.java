package com.idcorporation.atlas.commands;

/**
 * What a Yes/No confirmation bubble runs when the user taps "yes".
 *
 * This used to be a plain Runnable, but ATLAS FASE 3/4's "never fake an
 * action that did not happen" rule means the caller needs to know whether
 * the action actually worked - a reminder whose date could not be parsed,
 * for instance, must not be reported back as "Feito!". run() returns that
 * outcome instead of assuming success.
 */
public interface ConfirmAction {
    boolean run();
}
