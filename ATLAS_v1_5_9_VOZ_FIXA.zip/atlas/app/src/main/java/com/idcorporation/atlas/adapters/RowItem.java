package com.idcorporation.atlas.adapters;

public class RowItem {

    private long id;
    private String primaryText;
    private String secondaryText;

    public RowItem(long id, String primaryText, String secondaryText) {
        this.id = id;
        this.primaryText = primaryText;
        this.secondaryText = secondaryText;
    }

    public long getId() {
        return id;
    }

    public String getPrimaryText() {
        return primaryText;
    }

    public String getSecondaryText() {
        return secondaryText;
    }
}
