package com.idcorporation.atlas.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.presence.PresenceBubbleView;
import com.idcorporation.atlas.utils.PresenceManager;

/**
 * Settings > Presence layout. Two cards, each with a LIVE preview of the
 * look (the same view the shake gesture shows), so the user can watch the
 * animation before choosing. A small fake "conversation" loop cycles the
 * previews through listening, thinking and speaking so every animation
 * layer is visible. Tapping a card saves the choice; it applies on the
 * next shake without restarting anything.
 */
public class PresenceLayoutActivity extends BaseActivity {

    private static final long DEMO_TICK_MS = 90L;
    private static final int TICKS_PER_STEP = 28;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private PresenceBubbleView glassPreview;
    private PresenceBubbleView orbPreview;
    private PresenceBubbleView nucleusPreview;
    private PresenceBubbleView cardPreview;
    private View cardGlass;
    private View cardOrb;
    private View cardNucleus;
    private View cardCard;
    private ImageView checkGlass;
    private ImageView checkOrb;
    private ImageView checkNucleus;
    private ImageView checkCard;
    private View offHint;
    private Runnable demoRunnable;
    private int tick = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_presence_layout);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        cardGlass = findViewById(R.id.card_layout_glass);
        cardOrb = findViewById(R.id.card_layout_orb);
        cardNucleus = findViewById(R.id.card_layout_nucleus);
        cardCard = findViewById(R.id.card_layout_card);
        checkGlass = (ImageView) findViewById(R.id.check_layout_glass);
        checkOrb = (ImageView) findViewById(R.id.check_layout_orb);
        checkNucleus = (ImageView) findViewById(R.id.check_layout_nucleus);
        checkCard = (ImageView) findViewById(R.id.check_layout_card);
        offHint = findViewById(R.id.label_presence_layout_off);

        glassPreview = new PresenceBubbleView(this, PresenceManager.LAYOUT_GLASS, true);
        orbPreview = new PresenceBubbleView(this, PresenceManager.LAYOUT_ORB, true);
        nucleusPreview = new PresenceBubbleView(this, PresenceManager.LAYOUT_NUCLEUS, true);
        cardPreview = new PresenceBubbleView(this, PresenceManager.LAYOUT_CARD, true);
        addPreview((FrameLayout) findViewById(R.id.holder_layout_glass), glassPreview);
        addPreview((FrameLayout) findViewById(R.id.holder_layout_orb), orbPreview);
        addPreview((FrameLayout) findViewById(R.id.holder_layout_nucleus), nucleusPreview);
        addPreview((FrameLayout) findViewById(R.id.holder_layout_card), cardPreview);

        cardGlass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choose(PresenceManager.LAYOUT_GLASS);
            }
        });
        cardOrb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choose(PresenceManager.LAYOUT_ORB);
            }
        });
        cardNucleus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choose(PresenceManager.LAYOUT_NUCLEUS);
            }
        });
        cardCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choose(PresenceManager.LAYOUT_CARD);
            }
        });

        refreshSelection();
        glassPreview.playOpen();
        orbPreview.playOpen();
        nucleusPreview.playOpen();
        cardPreview.playOpen();
    }

    private void addPreview(FrameLayout holder, PresenceBubbleView preview) {
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER);
        holder.addView(preview, params);
        // The card handles the tap, not the preview itself.
        preview.setClickable(false);
    }

    private void choose(int layout) {
        PresenceManager.setLayout(this, layout);
        refreshSelection();
        if (layout == PresenceManager.LAYOUT_ORB) {
            orbPreview.playOpen();
        } else if (layout == PresenceManager.LAYOUT_NUCLEUS) {
            nucleusPreview.playOpen();
        } else if (layout == PresenceManager.LAYOUT_CARD) {
            cardPreview.playOpen();
        } else {
            glassPreview.playOpen();
        }
        Toast.makeText(this, R.string.presence_layout_saved, Toast.LENGTH_SHORT).show();
    }

    private void refreshSelection() {
        int selected = PresenceManager.getLayout(this);
        boolean glassSelected = selected == PresenceManager.LAYOUT_GLASS;
        boolean orbSelected = selected == PresenceManager.LAYOUT_ORB;
        boolean nucleusSelected = selected == PresenceManager.LAYOUT_NUCLEUS;
        boolean cardSelected = selected == PresenceManager.LAYOUT_CARD;
        cardGlass.setBackgroundResource(glassSelected
            ? R.drawable.presence_layout_card_selected_bg : R.drawable.atlas_card_bg);
        cardOrb.setBackgroundResource(orbSelected
            ? R.drawable.presence_layout_card_selected_bg : R.drawable.atlas_card_bg);
        cardNucleus.setBackgroundResource(nucleusSelected
            ? R.drawable.presence_layout_card_selected_bg : R.drawable.atlas_card_bg);
        cardCard.setBackgroundResource(cardSelected
            ? R.drawable.presence_layout_card_selected_bg : R.drawable.atlas_card_bg);
        checkGlass.setVisibility(glassSelected ? View.VISIBLE : View.GONE);
        checkOrb.setVisibility(orbSelected ? View.VISIBLE : View.GONE);
        checkNucleus.setVisibility(nucleusSelected ? View.VISIBLE : View.GONE);
        checkCard.setVisibility(cardSelected ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean presenceOn = PresenceManager.isEnabled(this) && PresenceManager.canDrawOverlays(this);
        offHint.setVisibility(presenceOn ? View.GONE : View.VISIBLE);
        startDemo();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopDemo();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopDemo();
        glassPreview.release();
        orbPreview.release();
        nucleusPreview.release();
        cardPreview.release();
    }

    private void startDemo() {
        stopDemo();
        demoRunnable = new Runnable() {
            @Override
            public void run() {
                stepDemo();
                handler.postDelayed(this, DEMO_TICK_MS);
            }
        };
        handler.post(demoRunnable);
    }

    private void stopDemo() {
        if (demoRunnable != null) {
            handler.removeCallbacks(demoRunnable);
            demoRunnable = null;
        }
    }

    /** Listening (with a fake voice level) -> thinking -> speaking -> listening ... */
    private void stepDemo() {
        tick = tick + 1;
        int step = (tick / TICKS_PER_STEP) % 4;
        int hudState = HudStateManager.STATE_LISTENING;
        if (step == 1) {
            hudState = HudStateManager.STATE_PROCESSING;
        } else if (step == 2) {
            hudState = HudStateManager.STATE_SPEAKING;
        }
        glassPreview.setHudState(hudState);
        orbPreview.setHudState(hudState);
        nucleusPreview.setHudState(hudState);
        cardPreview.setHudState(hudState);
        if (hudState == HudStateManager.STATE_LISTENING) {
            float level = 1f + 5f * (0.5f + 0.5f * (float) Math.sin(tick * 0.55)) + (tick % 5) * 0.4f;
            glassPreview.setAudioLevel(level);
            orbPreview.setAudioLevel(level);
            nucleusPreview.setAudioLevel(level);
            cardPreview.setAudioLevel(level);
        }
        if (tick % TICKS_PER_STEP == 0) {
            glassPreview.pingRipple();
            orbPreview.pingRipple();
            nucleusPreview.pingRipple();
            cardPreview.pingRipple();
        }
    }
}
