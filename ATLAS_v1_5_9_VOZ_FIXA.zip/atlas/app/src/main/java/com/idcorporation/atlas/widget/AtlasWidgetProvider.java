package com.idcorporation.atlas.widget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.widget.RemoteViews;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.MainActivity;

/**
 * ATLAS GENESYS: a 4x4 home screen widget with an animated core.
 *
 * RemoteViews cannot run an AnimationDrawable by itself (it lives in the
 * launcher's process, not ours), so the "animation" is a self-rescheduling
 * alarm that swaps the core image between a handful of frames every
 * TICK_INTERVAL_MS, giving a breathing pulse effect using the same
 * atlas_core_solid / atlas_core_glow / atlas_ring drawables already used
 * elsewhere in the app. The alarm chain starts in onEnabled (first widget
 * placed) and stops in onDisabled (last widget removed), so there is no
 * background cost when no ATLAS widget is on screen.
 */
public class AtlasWidgetProvider extends AppWidgetProvider {

    private static final String ACTION_TICK = "com.idcorporation.atlas.widget.ACTION_TICK";
    private static final long TICK_INTERVAL_MS = 1200L;
    private static final String PREFS_NAME = "atlas_widget_prefs";
    private static final String KEY_FRAME_PREFIX = "frame_";

    // Breathing cycle: dim core -> glowing core -> dim core -> lit ring accent.
    private static final int[] CORE_FRAMES = {
        R.drawable.atlas_core_solid,
        R.drawable.atlas_core_glow,
        R.drawable.atlas_core_solid,
        R.drawable.atlas_ring
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int i = 0; i < appWidgetIds.length; i++) {
            int widgetId = appWidgetIds[i];
            updateWidget(context, appWidgetManager, widgetId, currentFrame(context, widgetId));
        }
        scheduleTick(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_TICK.equals(intent.getAction())) {
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            int[] widgetIds = appWidgetManager.getAppWidgetIds(
                new ComponentName(context, AtlasWidgetProvider.class));
            if (widgetIds.length == 0) {
                cancelTick(context);
                return;
            }
            for (int i = 0; i < widgetIds.length; i++) {
                int widgetId = widgetIds[i];
                int nextFrame = advanceFrame(context, widgetId);
                updateWidget(context, appWidgetManager, widgetId, nextFrame);
            }
            scheduleTick(context);
        }
    }

    @Override
    public void onEnabled(Context context) {
        scheduleTick(context);
    }

    @Override
    public void onDisabled(Context context) {
        cancelTick(context);
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        for (int i = 0; i < appWidgetIds.length; i++) {
            editor.remove(KEY_FRAME_PREFIX + appWidgetIds[i]);
        }
        editor.apply();
    }

    private void updateWidget(Context context, AppWidgetManager appWidgetManager, int widgetId, int frameIndex) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_atlas);
        views.setImageViewResource(R.id.widget_core, CORE_FRAMES[frameIndex]);

        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
            | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, widgetId, openApp, flags);
        views.setOnClickPendingIntent(R.id.widget_core, pendingIntent);
        views.setOnClickPendingIntent(R.id.widget_label, pendingIntent);

        appWidgetManager.updateAppWidget(widgetId, views);
    }

    private int currentFrame(Context context, int widgetId) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_FRAME_PREFIX + widgetId, 0);
    }

    private int advanceFrame(Context context, int widgetId) {
        int next = (currentFrame(context, widgetId) + 1) % CORE_FRAMES.length;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_FRAME_PREFIX + widgetId, next).apply();
        return next;
    }

    private void scheduleTick(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }
        PendingIntent pendingIntent = tickPendingIntent(context);
        long triggerAt = System.currentTimeMillis() + TICK_INTERVAL_MS;
        try {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC, triggerAt, pendingIntent);
        } catch (SecurityException e) {
            alarmManager.set(AlarmManager.RTC, triggerAt, pendingIntent);
        }
    }

    private void cancelTick(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.cancel(tickPendingIntent(context));
        }
    }

    private PendingIntent tickPendingIntent(Context context) {
        Intent intent = new Intent(context, AtlasWidgetProvider.class);
        intent.setAction(ACTION_TICK);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
            | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(context, 0, intent, flags);
    }
}
