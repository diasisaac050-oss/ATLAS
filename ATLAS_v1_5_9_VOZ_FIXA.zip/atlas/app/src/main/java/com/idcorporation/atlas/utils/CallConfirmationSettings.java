package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Whether ATLAS should ask "Ligar para X, confirma?" before placing a
 * voice-requested call, or just call immediately. Defaults to immediate
 * calling, matching how the rest of ATLAS's voice commands behave.
 */
public class CallConfirmationSettings {

    private static final String PREFS_NAME = "atlas_call_prefs";
    private static final String KEY_CONFIRM_BEFORE_CALL = "confirm_before_call";

    public static boolean isConfirmBeforeCallEnabled(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_CONFIRM_BEFORE_CALL, false);
    }

    public static void setConfirmBeforeCallEnabled(Context context, boolean enabled) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_CONFIRM_BEFORE_CALL, enabled).apply();
    }
}
