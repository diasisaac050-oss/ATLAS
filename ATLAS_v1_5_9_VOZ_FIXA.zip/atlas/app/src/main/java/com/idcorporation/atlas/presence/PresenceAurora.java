package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

/**
 * The living light inside the glass: three big soft blue clouds that drift
 * along slow looping paths (faster and brighter while ATLAS thinks or
 * speaks, and swelling with the voice), plus the diagonal gleam that sweeps
 * across every few seconds. Call inside the body clip.
 */
final class PresenceAurora {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RadialGradient midUnit = cloud(PresenceBlues.MID);
    private final RadialGradient lightUnit = cloud(PresenceBlues.LIGHT);
    private final RadialGradient deepUnit = cloud(PresenceBlues.DEEP);
    private final LinearGradient bandUnit = new LinearGradient(-1f, 0f, 1f, 0f,
        new int[] {PresenceBlues.alpha(PresenceBlues.WHITE, 0),
                   PresenceBlues.alpha(PresenceBlues.WHITE, 255),
                   PresenceBlues.alpha(PresenceBlues.WHITE, 0)},
        new float[] {0f, 0.5f, 1f}, Shader.TileMode.CLAMP);

    private static RadialGradient cloud(int color) {
        return new RadialGradient(0f, 0f, 1f,
            new int[] {PresenceBlues.alpha(color, 255),
                       PresenceBlues.alpha(color, 110),
                       PresenceBlues.alpha(color, 0)},
            new float[] {0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
    }

    void draw(Canvas canvas, float cx, float cy, float a, float b,
              PresenceBubbleState st, float pulse, float alpha) {
        float o = st.orbit;
        float k = alpha * (0.85f + 0.30f * st.thinkAmt + 0.50f * pulse);
        float grow = 1f + 0.22f * pulse + 0.10f * st.thinkAmt;

        cloud(canvas, deepUnit,
            cx + a * 0.50f * (float) Math.cos(o * 0.75 + 4.0),
            cy + b * 0.55f * (float) Math.sin(o * 0.50 + 3.0),
            b * 1.45f * grow, 0.55f * k);
        cloud(canvas, midUnit,
            cx + a * 0.55f * (float) Math.sin(o * 0.90 + 0.3),
            cy + b * 0.50f * (float) Math.cos(o * 0.70),
            b * 1.25f * grow, 0.60f * k);
        cloud(canvas, lightUnit,
            cx + a * 0.60f * (float) Math.sin(o * 0.60 + 2.1),
            cy + b * 0.45f * (float) Math.sin(o * 0.85 + 1.0),
            b * 0.95f * grow, 0.30f * k);
    }

    private void cloud(Canvas canvas, RadialGradient unit, float x, float y, float r, float amount) {
        paint.setShader(unit);
        paint.setAlpha(PresenceBlues.a255(amount));
        canvas.save();
        canvas.translate(x, y);
        canvas.scale(r * 1.15f, r * 0.85f);
        canvas.drawCircle(0f, 0f, 1f, paint);
        canvas.restore();
    }

    /** A wide soft band and a thin companion glide across the glass at a slant. */
    void drawSheen(Canvas canvas, float cx, float cy, float a, float b,
                   PresenceBubbleState st, float alpha) {
        if (st.sheen < 0f) {
            return;
        }
        float t = st.sheen;
        float env = (float) Math.sin(Math.PI * (double) t);
        env = env * env;
        float x = cx + (t * 2f - 1f) * a * 1.35f;
        band(canvas, x, cy, a * 0.20f, b * 3.2f, 0.26f * env * alpha);
        band(canvas, x - a * 0.36f, cy, a * 0.05f, b * 3.2f, 0.18f * env * alpha);
    }

    private void band(Canvas canvas, float x, float y, float halfW, float halfH, float amount) {
        paint.setShader(bandUnit);
        paint.setAlpha(PresenceBlues.a255(amount));
        canvas.save();
        canvas.translate(x, y);
        canvas.rotate(-20f);
        canvas.scale(halfW, halfH);
        canvas.drawRect(-1f, -1f, 1f, 1f, paint);
        canvas.restore();
    }
}
