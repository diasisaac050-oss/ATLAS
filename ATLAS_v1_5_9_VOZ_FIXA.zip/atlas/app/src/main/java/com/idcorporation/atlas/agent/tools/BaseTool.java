package com.idcorporation.atlas.agent.tools;

import com.idcorporation.atlas.agent.AgentTool;

import org.json.JSONObject;

/** Common plumbing: safe string argument access and sane defaults. */
public abstract class BaseTool implements AgentTool {

    protected final ToolEnv env;

    protected BaseTool(ToolEnv env) {
        this.env = env;
    }

    @Override
    public boolean returnsUntrustedContent() {
        return false;
    }

    @Override
    public boolean changesState() {
        return false;
    }

    protected static String arg(JSONObject args, String key) {
        if (args == null) {
            return "";
        }
        String v = args.optString(key, "");
        return v == null ? "" : v.trim();
    }

    protected static String clip(String s, int max) {
        if (s == null) {
            return "";
        }
        String t = s.trim();
        return t.length() <= max ? t : t.substring(0, max).trim() + "...";
    }
}
