package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.Path;

/**
 * Draws the "liquid glass" lens under the notch. Layers, back to front:
 * ground shadow, icy halo, smoked-glass fill, then (clipped inside the
 * glass) drifting blue light, light pooling at the edges, the gleam that
 * sweeps across and the sound-wave bars; finally the hairline edge with its
 * travelling comet, and the tap ripple. The lens opens like a spring: first
 * it widens into a pill, then it grows into the full lens. Every color is a
 * shade of blue (see PresenceBlues). Plain Canvas only, no extra libraries.
 */
public class PresenceBubblePainter implements PresenceDrawer {

    private final float d;
    private final Path body = new Path();
    private final PresenceGlassBody glass = new PresenceGlassBody();
    private final PresenceAurora aurora = new PresenceAurora();
    private final PresenceGlassRim rim;
    private final PresenceBubbleEffects effects;

    public PresenceBubblePainter(float density) {
        this.d = density;
        this.rim = new PresenceGlassRim(density);
        this.effects = new PresenceBubbleEffects(density);
    }

    @Override
    public void draw(Canvas canvas, int w, int h, PresenceBubbleState st) {
        float p = st.open;
        if (p <= 0.01f) {
            return;
        }
        float alpha = Math.min(1f, p * 2.4f);
        float pulse = Math.max(st.level, st.speakAmt * (0.45f + 0.35f * (float) Math.sin(st.phase * 9.0)));
        float breathe = 1f + 0.014f * (float) Math.sin(st.phase * 1.5);

        float fullA = 88f * d;
        float fullB = 50f * d;
        // Width leads and height follows: pill first, lens second.
        float heightP = (float) Math.pow((double) p, 1.2);
        float a = fullA * (0.34f + 0.66f * p) * breathe * (1f + 0.03f * pulse);
        float b = fullB * (0.16f + 0.84f * heightP) * breathe * (1f + 0.04f * pulse);
        float cx = w / 2f + (float) Math.sin(st.phase * 38.0) * 2f * d * st.errAmt;
        float cy = h / 2f - 6f * d - fullB * 0.85f * (1f - Math.min(1f, p));

        buildBody(body, cx, cy, a, b, st.phase, pulse);

        glass.drawShadow(canvas, cx, cy, a, b, alpha);
        glass.drawHalo(canvas, cx, cy, a, b, st, pulse, alpha);
        glass.drawFill(canvas, body, cy, b, alpha);

        canvas.save();
        canvas.clipPath(body);
        aurora.draw(canvas, cx, cy, a, b, st, pulse, alpha);
        glass.drawInnerLight(canvas, cx, cy, a, b, pulse, alpha);
        aurora.drawSheen(canvas, cx, cy, a, b, st, alpha);
        effects.drawStreak(canvas, cx, cy, a, b, st, pulse, alpha);
        canvas.restore();

        rim.draw(canvas, body, cx, cy, a, b, st, pulse, alpha);
        effects.drawRipple(canvas, body, cx, cy, st);
    }

    /** A superellipse (squircle) with a very small wobble that only grows with the voice. */
    private void buildBody(Path path, float cx, float cy, float a, float b, float phase, float lvl) {
        path.reset();
        int steps = 96;
        double ex = 2.0 / 2.7;
        for (int i = 0; i <= steps; i++) {
            double t = (2.0 * Math.PI * i) / steps;
            double c = Math.cos(t);
            double s = Math.sin(t);
            double x = Math.signum(c) * Math.pow(Math.abs(c), ex);
            double y = Math.signum(s) * Math.pow(Math.abs(s), ex);
            double wob = 1.0 + 0.005 * Math.sin(3 * t + phase * 1.4)
                + 0.004 * Math.sin(5 * t - phase * 1.0)
                + (double) lvl * 0.030 * Math.sin(2 * t + phase * 3.0);
            float px = (float) (cx + a * wob * x);
            float py = (float) (cy + b * wob * y);
            if (i == 0) {
                path.moveTo(px, py);
            } else {
                path.lineTo(px, py);
            }
        }
        path.close();
    }
}
