package com.idcorporation.atlas.sphere;

import java.util.Random;

/**
 * ATLAS ESFERA - the 3D particle sphere that IS the Atlas on the Home screen.
 *
 * Pure Java (no Android classes) so the maths can be tested off-device.
 * AtlasSphereView feeds it time, touch, audio and tilt, and gives it a
 * SpherePainter to draw with.
 *
 * Layers (each one moves on its own, in real 3D with perspective):
 *  - surface lattice : ~2.4k dots on latitude rings, shown in drifting patches
 *  - node network    : ~120 nodes joined by short links and long chords that
 *                      fade in and out, with pulses travelling along them
 *  - core            : ~950-dot dense cloud plus layered glow, breathes and
 *                      reacts to voice
 *  - orbiters        : ~200 dots on tilted orbits (3 belts + loose ones)
 *  - emitters        : dots that leave the surface, travel out and fall back in
 *  - waves           : energy ripples that run across the surface
 *
 * All colours derive from ONE accent colour (the theme's), plus a temporary
 * tint for error / offline, so the same geometry works in every theme.
 */
public final class SphereEngine {

    // Same numbers as HudStateManager.STATE_*.
    public static final int STATE_IDLE = 0;
    public static final int STATE_LISTENING = 1;
    public static final int STATE_PROCESSING = 2;
    public static final int STATE_THINKING = 3;
    public static final int STATE_SPEAKING = 4;
    public static final int STATE_EXECUTING = 5;
    public static final int STATE_ERROR = 6;
    public static final int STATE_OFFLINE = 7;

    // ---- per-state behaviour profile (eased towards, never snapped) ----
    private static final int P_SPIN = 0;
    private static final int P_ACT = 1;      // how many links / lattice patches are lit
    private static final int P_CORE = 2;     // core intensity
    private static final int P_CSIZE = 3;    // core size
    private static final int P_EMIT = 4;     // fraction of emitters active
    private static final int P_EAMP = 5;     // how far emitted dots travel
    private static final int P_ORBIT = 6;    // orbiter speed multiplier
    private static final int P_WAVE = 7;     // ambient waves per second
    private static final int P_SPOKE = 8;    // core-to-node spokes
    private static final int P_PULSE = 9;    // fraction of link pulses active
    private static final int P_JIT = 10;     // surface vibration from audio
    private static final int P_BRIGHT = 11;
    private static final int P_PHZ = 12;     // core breathing frequency (Hz)
    private static final int P_AGAIN = 13;   // how much audio is heard
    private static final int NPROF = 14;

    private static final float[][] PROFILE = {
        // spin   act    core   csz    emit   eamp   orbit  wave   spoke  pulse  jit    bri    phz    again
        { 0.20f, 0.30f, 0.58f, 1.00f, 0.20f, 0.16f, 0.80f, 0.00f, 0.00f, 0.32f, 0.20f, 0.90f, 0.30f, 0.25f }, // idle
        { 0.34f, 0.66f, 0.80f, 1.05f, 0.42f, 0.22f, 1.30f, 0.35f, 0.15f, 0.55f, 0.60f, 1.00f, 0.55f, 1.00f }, // listening
        { 0.80f, 1.00f, 0.95f, 1.12f, 0.80f, 0.30f, 2.60f, 1.20f, 0.90f, 1.00f, 0.25f, 1.10f, 1.30f, 0.30f }, // processing
        { 0.62f, 0.90f, 0.90f, 1.08f, 0.65f, 0.28f, 2.00f, 0.80f, 0.70f, 0.90f, 0.20f, 1.05f, 0.95f, 0.30f }, // thinking
        { 0.40f, 0.80f, 0.86f, 1.10f, 0.58f, 0.28f, 1.20f, 0.00f, 0.30f, 0.75f, 1.00f, 1.05f, 0.80f, 1.00f }, // speaking
        { 0.65f, 0.95f, 0.90f, 1.08f, 0.70f, 0.28f, 2.00f, 0.90f, 0.80f, 1.00f, 0.25f, 1.08f, 1.10f, 0.30f }, // executing
        { 0.10f, 0.50f, 0.70f, 1.00f, 0.55f, 0.36f, 0.60f, 0.60f, 0.10f, 0.35f, 0.80f, 0.95f, 1.60f, 0.00f }, // error
        { 0.07f, 0.12f, 0.22f, 0.85f, 0.04f, 0.10f, 0.35f, 0.00f, 0.00f, 0.10f, 0.00f, 0.45f, 0.20f, 0.00f }, // offline
    };

    // ---- geometry sizes ----
    private static final int NLAT = 62;
    private static final int NODES = 120;
    private static final int CORE_PTS = 1500;
    private static final int ORBIT_PTS = 200;
    private static final int EMIT_PTS = 160;
    private static final int PULSES = 64;
    private static final int MAX_WAVES = 5;
    private static final int PB = 6;   // brightness buckets for points
    private static final int LB = 5;   // brightness buckets for lines
    private static final float CAM = 4.4f;
    private static final float TWO_PI = (float) (Math.PI * 2.0);

    private static final int CAT_SURF = 0;
    private static final int CAT_CORE = 1;
    private static final int CAT_PART = 2;
    private static final int CAT_NODE = 3;
    private static final int LCAT_EDGE = 0;
    private static final int LCAT_SPOKE = 1;
    private static final int LCAT_TICK = 2;

    // surface lattice (object space, unit sphere)
    private final int surfN;
    private final float[] sx, sy, sz, sph, smask;
    // nodes + links
    private final float[] nx, ny, nz, nph;
    private final int edgeN;
    private final int[] ea, eb;
    private final float[] eph, efq, evis;
    private final float[] npx, npy, nzr;
    // core
    private final float[] cx0, cy0, cz0, crad, cph, cfq;
    // orbiters
    private final float[] ou, ov;   // orbit basis vectors (3 comps each, packed)
    private final float[] orho, ow, oph0, osz;
    // emitters
    private final float[] ex, ey, ez, eage, edur, eamp;
    private final boolean[] eburst;
    // link pulses
    private final int[] pedge;
    private final float[] pt, pspeed;
    private final boolean[] pdir;
    // waves
    private final float[] wx = new float[MAX_WAVES], wy = new float[MAX_WAVES], wz = new float[MAX_WAVES];
    private final float[] wage = new float[MAX_WAVES], wamp = new float[MAX_WAVES];
    private final boolean[] wlive = new boolean[MAX_WAVES];

    // draw buffers
    private final float[][][] pbuf = new float[4][PB][];
    private final int[][] pcnt = new int[4][PB];
    private final float[][][] lbuf = new float[3][LB][];
    private final int[][] lcnt = new int[3][LB];

    private final Random rnd = new Random(20260711L);
    private final float[] cur = new float[NPROF];
    private final float[] mS = new float[9], mN = new float[9], mC = new float[9], mV = new float[9];
    private final float[] tmpA = new float[9], tmpB = new float[9], tmpC = new float[9], tmpD = new float[9];
    private final float[] wcos = new float[MAX_WAVES], wwid = new float[MAX_WAVES], wgain = new float[MAX_WAVES];

    // viewport
    private float width = 1f, height = 1f, cxs = 0.5f, cys = 0.5f, rad = 1f, dens = 1f;
    private int quality = 0;
    private float master = 1f;   // overall opacity (fade in/out); 1 = untouched

    // time / state
    private double time = 0.0;
    private int state = STATE_IDLE;
    private float stateTime = 0f;
    private float errMix = 0f, offMix = 0f;
    private int accent = 0xFF00E5FF;

    // motion
    private float spinS, spinN, spinC, userYaw, userYawVel, userPitch;
    private float orbT, corePhase, kick, waveAcc;
    private float tiltX, tiltY, tiltTX, tiltTY;
    private int frame = 0;

    // audio
    private float audio = 0f, audioPrev = 0f, extLevel = 0f;
    private double extStamp = -10.0;
    private float lastAudioWave = 0f;

    // touch
    private boolean dragging = false;
    private float lastTx, lastTy, dragDX, dragDY, downX, downY, moved;

    public SphereEngine() {
        // ---- surface lattice: latitude rings, odd rings offset (hex-like) ----
        int total = 0;
        int[] ringCount = new int[NLAT];
        for (int i = 0; i < NLAT; i++) {
            float lat = (float) (-Math.PI / 2 + Math.PI * (i + 0.5) / NLAT);
            ringCount[i] = Math.max(1, Math.round(2f * NLAT * (float) Math.cos(lat)));
            total += ringCount[i];
        }
        surfN = total;
        sx = new float[total]; sy = new float[total]; sz = new float[total];
        sph = new float[total]; smask = new float[total];
        int k = 0;
        for (int i = 0; i < NLAT; i++) {
            float lat = (float) (-Math.PI / 2 + Math.PI * (i + 0.5) / NLAT);
            float c = (float) Math.cos(lat), s = (float) Math.sin(lat);
            int n = ringCount[i];
            float off = (i & 1) * 0.5f;
            for (int j = 0; j < n; j++) {
                float lon = TWO_PI * (j + off) / n;
                sx[k] = c * (float) Math.cos(lon);
                sy[k] = s;
                sz[k] = c * (float) Math.sin(lon);
                sph[k] = rnd.nextFloat() * TWO_PI;
                smask[k] = 1f;
                k++;
            }
        }

        // ---- nodes ----
        nx = new float[NODES]; ny = new float[NODES]; nz = new float[NODES]; nph = new float[NODES];
        npx = new float[NODES]; npy = new float[NODES]; nzr = new float[NODES];
        float golden = (float) (Math.PI * (3.0 - Math.sqrt(5.0)));
        for (int i = 0; i < NODES; i++) {
            float y = 1f - 2f * (i + 0.5f) / NODES;
            float r = (float) Math.sqrt(Math.max(0f, 1f - y * y));
            float th = golden * i + (rnd.nextFloat() - 0.5f) * 0.35f;
            float x = r * (float) Math.cos(th);
            float z = r * (float) Math.sin(th);
            // a few nodes float inside the shell so the chords have depth
            float rr = (i % 6 == 0) ? 0.55f + rnd.nextFloat() * 0.3f : 0.97f + rnd.nextFloat() * 0.03f;
            nx[i] = x * rr; ny[i] = y * rr; nz[i] = z * rr;
            nph[i] = rnd.nextFloat() * TWO_PI;
        }
        // links: 2 nearest neighbours each + chords
        int maxEdges = NODES * 3 + 80;
        int[] ta = new int[maxEdges], tb = new int[maxEdges];
        int ec = 0;
        for (int i = 0; i < NODES; i++) {
            int b1 = -1, b2 = -1;
            float d1 = 9f, d2 = 9f;
            for (int j = 0; j < NODES; j++) {
                if (j == i) continue;
                float dx = nx[i] - nx[j], dy = ny[i] - ny[j], dz = nz[i] - nz[j];
                float d = dx * dx + dy * dy + dz * dz;
                if (d < d1) { d2 = d1; b2 = b1; d1 = d; b1 = j; }
                else if (d < d2) { d2 = d; b2 = j; }
            }
            ec = addEdge(ta, tb, ec, i, b1);
            ec = addEdge(ta, tb, ec, i, b2);
        }
        int chords = 0, guard = 0;
        while (chords < 52 && guard < 4000) {
            guard++;
            int i = rnd.nextInt(NODES), j = rnd.nextInt(NODES);
            if (i == j) continue;
            float dx = nx[i] - nx[j], dy = ny[i] - ny[j], dz = nz[i] - nz[j];
            float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            boolean longChord = chords < 16;
            if ((longChord && d > 0.9f) || (!longChord && d > 0.45f && d < 0.9f)) {
                int before = ec;
                ec = addEdge(ta, tb, ec, i, j);
                if (ec > before) chords++;
            }
        }
        edgeN = ec;
        ea = new int[ec]; eb = new int[ec];
        eph = new float[ec]; efq = new float[ec]; evis = new float[ec];
        for (int e = 0; e < ec; e++) {
            ea[e] = ta[e]; eb[e] = tb[e];
            eph[e] = rnd.nextFloat() * TWO_PI;
            efq[e] = 0.25f + rnd.nextFloat() * 0.55f;
        }

        // ---- core cloud ----
        cx0 = new float[CORE_PTS]; cy0 = new float[CORE_PTS]; cz0 = new float[CORE_PTS];
        crad = new float[CORE_PTS]; cph = new float[CORE_PTS]; cfq = new float[CORE_PTS];
        for (int i = 0; i < CORE_PTS; i++) {
            float[] d = randomUnit();
            float g = (rnd.nextFloat() + rnd.nextFloat() + rnd.nextFloat()) / 3f; // bell-ish 0..1
            float r = 0.40f * (float) Math.pow(g, 0.95) * (0.45f + 0.55f * rnd.nextFloat());
            cx0[i] = d[0] * r; cy0[i] = d[1] * r; cz0[i] = d[2] * r;
            crad[i] = r;
            cph[i] = rnd.nextFloat() * TWO_PI;
            cfq[i] = 2f + rnd.nextFloat() * 5f;
        }

        // ---- orbiters ----
        ou = new float[ORBIT_PTS * 3]; ov = new float[ORBIT_PTS * 3];
        orho = new float[ORBIT_PTS]; ow = new float[ORBIT_PTS];
        oph0 = new float[ORBIT_PTS]; osz = new float[ORBIT_PTS];
        float[][] beltN = new float[3][];
        float[] beltRho = { 1.13f, 1.24f, 1.36f };
        float[] beltW = { 0.34f, -0.24f, 0.17f };
        for (int b = 0; b < 3; b++) {
            beltN[b] = randomUnit();
        }
        for (int i = 0; i < ORBIT_PTS; i++) {
            float[] n;
            float rho, w;
            if (i < 120) {
                int b = i / 40;
                n = beltN[b];
                rho = beltRho[b] + (rnd.nextFloat() - 0.5f) * 0.035f;
                w = beltW[b] * (0.92f + rnd.nextFloat() * 0.16f);
            } else {
                n = randomUnit();
                rho = 1.07f + rnd.nextFloat() * 0.36f;
                w = (0.15f + rnd.nextFloat() * 0.55f) * (rnd.nextBoolean() ? 1f : -1f);
            }
            float[] helper = Math.abs(n[1]) < 0.9f ? new float[]{0f, 1f, 0f} : new float[]{1f, 0f, 0f};
            float[] u = cross(n, helper);
            normalize(u);
            float[] v = cross(n, u);
            normalize(v);
            for (int q = 0; q < 3; q++) { ou[i * 3 + q] = u[q]; ov[i * 3 + q] = v[q]; }
            orho[i] = rho;
            ow[i] = w;
            oph0[i] = (i < 120) ? TWO_PI * ((i % 40) / 40f) + (rnd.nextFloat() - 0.5f) * 0.12f : rnd.nextFloat() * TWO_PI;
            osz[i] = 0.5f + rnd.nextFloat() * 0.5f;
        }

        // ---- emitters ----
        ex = new float[EMIT_PTS]; ey = new float[EMIT_PTS]; ez = new float[EMIT_PTS];
        eage = new float[EMIT_PTS]; edur = new float[EMIT_PTS]; eamp = new float[EMIT_PTS];
        eburst = new boolean[EMIT_PTS];
        for (int i = 0; i < EMIT_PTS; i++) {
            respawnEmitter(i, 0.2f);
            eage[i] = rnd.nextFloat() * edur[i];
        }

        // ---- link pulses ----
        pedge = new int[PULSES]; pt = new float[PULSES]; pspeed = new float[PULSES]; pdir = new boolean[PULSES];
        for (int i = 0; i < PULSES; i++) {
            pedge[i] = rnd.nextInt(edgeN);
            pt[i] = rnd.nextFloat();
            pspeed[i] = 0.35f + rnd.nextFloat() * 0.7f;
            pdir[i] = rnd.nextBoolean();
        }

        // ---- draw buffers ----
        int[] pcap = {
            surfN * 2 + 8, CORE_PTS * 2 + 8, (ORBIT_PTS + EMIT_PTS * 2 + PULSES) * 2 + 8, NODES * 2 + 8
        };
        for (int c = 0; c < 4; c++) {
            for (int b = 0; b < PB; b++) {
                pbuf[c][b] = new float[pcap[c]];
            }
        }
        int[] lcap = { edgeN * 4 + 8, NODES * 4 + 8, EMIT_PTS * 4 + 8 };
        for (int c = 0; c < 3; c++) {
            for (int b = 0; b < LB; b++) {
                lbuf[c][b] = new float[lcap[c]];
            }
        }
        System.arraycopy(PROFILE[STATE_IDLE], 0, cur, 0, NPROF);
        buildMatrix(mS, 0f, 0.30f, 0.30f);
    }

    private int addEdge(int[] ta, int[] tb, int count, int a, int b) {
        if (a < 0 || b < 0 || a == b || count >= ta.length) {
            return count;
        }
        for (int e = 0; e < count; e++) {
            if ((ta[e] == a && tb[e] == b) || (ta[e] == b && tb[e] == a)) {
                return count;
            }
        }
        ta[count] = a;
        tb[count] = b;
        return count + 1;
    }

    // ------------------------------------------------------------------
    // public API
    // ------------------------------------------------------------------

    public void setViewport(int w, int h, float density) {
        width = Math.max(1, w);
        height = Math.max(1, h);
        dens = density;
        cxs = width * 0.5f;
        cys = height * 0.5f;
        // leave room for orbiters / emitted dots (they reach ~1.45 R)
        rad = Math.min(width, height) * 0.5f / 1.46f;
    }

    public void setAccentColor(int argb) {
        int r = (argb >> 16) & 0xFF, g = (argb >> 8) & 0xFF, b = argb & 0xFF;
        int mx = Math.max(r, Math.max(g, b));
        if (mx < 235 && mx > 0) {
            float s = 235f / mx;
            r = Math.min(255, Math.round(r * s));
            g = Math.min(255, Math.round(g * s));
            b = Math.min(255, Math.round(b * s));
        }
        accent = 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public void setState(int hudState) {
        int s = (hudState < 0 || hudState >= PROFILE.length) ? STATE_IDLE : hudState;
        if (s != state) {
            state = s;
            stateTime = 0f;
            kick = Math.min(1.2f, kick + 0.45f);
            if (s == STATE_ERROR) {
                spawnWave(0f, 0f, 1f, 1.2f);
            }
        }
    }

    /** Level 0..1 from the microphone. Used while listening; speech is synthesised while speaking. */
    public void setAudioLevel(float level01) {
        extLevel = level01 < 0f ? 0f : (level01 > 1f ? 1f : level01);
        extStamp = time;
    }

    /** Device tilt, each -1..1, for the parallax. */
    public void setTilt(float tx, float ty) {
        tiltTX = tx < -1f ? -1f : (tx > 1f ? 1f : tx);
        tiltTY = ty < -1f ? -1f : (ty > 1f ? 1f : ty);
    }

    /**
     * 0 = full detail, 1 = lighter (half the surface/core dots),
     * 2 = lightest (a third of the dots, half the orbiters, emitters and
     * link pulses) for slow devices and small previews.
     */
    public void setQuality(int q) {
        quality = q < 0 ? 0 : (q > 2 ? 2 : q);
    }

    /** Overall opacity 0..1 (used by the Presence layouts to fade the sphere in and out). */
    public void setMasterAlpha(float a) {
        master = a < 0f ? 0f : (a > 1f ? 1f : a);
    }

    /**
     * Places the sphere explicitly: centre in px and sphere radius in px
     * (the orbiting dots reach about 1.45 x radius). setViewport() does the
     * same thing automatically for a full-view sphere.
     */
    public void setPlacement(float centerX, float centerY, float radiusPx, float density) {
        cxs = centerX;
        cys = centerY;
        rad = radiusPx < 1f ? 1f : radiusPx;
        dens = density;
    }

    /** A single energy wave + core kick, as if the sphere had just been tapped in the middle. */
    public void ping() {
        spawnWave(0f, 0f, 1f, 1.0f);
        kick = Math.min(1.3f, kick + 0.7f);
    }

    public int getQuality() {
        return quality;
    }

    public float getRadius() {
        return rad;
    }

    public float getCenterX() {
        return cxs;
    }

    public float getCenterY() {
        return cys;
    }

    public void touchDown(float x, float y) {
        dragging = true;
        lastTx = x; lastTy = y; downX = x; downY = y;
        dragDX = 0f; dragDY = 0f; moved = 0f;
        userYawVel = 0f;
        tapAt(x, y);
    }

    public void touchMove(float x, float y) {
        if (!dragging) {
            return;
        }
        dragDX += x - lastTx;
        dragDY += y - lastTy;
        moved += Math.abs(x - lastTx) + Math.abs(y - lastTy);
        lastTx = x; lastTy = y;
    }

    public void touchUp() {
        dragging = false;
    }

    // ------------------------------------------------------------------
    // simulation
    // ------------------------------------------------------------------

    public void update(float dt) {
        if (dt > 0.05f) dt = 0.05f;
        if (dt <= 0f) dt = 0.0001f;
        time += dt;
        stateTime += dt;
        frame++;
        float t = (float) time;

        // ease behaviour towards the current state's profile
        float k = 1f - (float) Math.exp(-dt * 3.2f);
        float[] tgt = PROFILE[state];
        for (int i = 0; i < NPROF; i++) {
            cur[i] += (tgt[i] - cur[i]) * k;
        }
        float errT = (state == STATE_ERROR) ? 1f : 0f;
        float offT = (state == STATE_OFFLINE) ? 1f : 0f;
        errMix += (errT - errMix) * (1f - (float) Math.exp(-dt * (errT > errMix ? 9f : 2.2f)));
        offMix += (offT - offMix) * (1f - (float) Math.exp(-dt * 2.5f));

        // audio: microphone while listening, a speech-like envelope while Atlas talks
        float src;
        if (state == STATE_SPEAKING) {
            src = speechEnvelope(t);
        } else if (time - extStamp < 0.35) {
            src = extLevel;
        } else {
            src = 0f;
        }
        audio += (src - audio) * (1f - (float) Math.exp(-dt * (src > audio ? 20f : 6f)));
        float a = audio * cur[P_AGAIN];
        lastAudioWave += dt;
        if (a > 0.5f && a > audioPrev + 0.015f && lastAudioWave > 0.33f) {
            lastAudioWave = 0f;
            float[] d = randomUnit();
            spawnWave(d[0], d[1], Math.abs(d[2]) * 0.8f + 0.2f, 0.55f + a * 0.6f);
        }
        audioPrev = a;

        // ambient waves
        waveAcc += dt * cur[P_WAVE];
        if (waveAcc >= 1f) {
            waveAcc -= 1f;
            float[] d = randomUnit();
            spawnWave(d[0], d[1], d[2], 0.7f);
        }
        for (int i = 0; i < MAX_WAVES; i++) {
            if (wlive[i]) {
                wage[i] += dt;
                if (wage[i] * 1.7f > (float) Math.PI + 0.6f) {
                    wlive[i] = false;
                }
            }
        }

        // drag + inertia
        if (dragging) {
            float dyaw = dragDX / rad * 1.3f;
            userYaw += dyaw;
            float inst = dyaw / dt;
            userYawVel = userYawVel * 0.6f + inst * 0.4f;
            userPitch += dragDY / rad * 0.9f;
            if (userPitch > 0.9f) userPitch = 0.9f;
            if (userPitch < -0.9f) userPitch = -0.9f;
            dragDX = 0f; dragDY = 0f;
        } else {
            userYaw += userYawVel * dt;
            userYawVel *= (float) Math.exp(-dt * 1.4f);
            userPitch *= (float) Math.exp(-dt * 1.3f);
        }

        // layers spin independently
        float spin = cur[P_SPIN] * (1f + 0.5f * a);
        spinS = wrap(spinS + dt * spin);
        spinN = wrap(spinN - dt * spin * 0.55f);
        spinC = wrap(spinC + dt * spin * 1.7f);
        userYaw = wrap(userYaw);
        orbT += dt * cur[P_ORBIT];
        corePhase += dt * cur[P_PHZ] * TWO_PI * (1f + 0.5f * a);
        if (corePhase > TWO_PI) corePhase -= TWO_PI;
        kick *= (float) Math.exp(-dt * 3.2f);
        float tk = 1f - (float) Math.exp(-dt * 6f);
        tiltX += (tiltTX - tiltX) * tk;
        tiltY += (tiltTY - tiltY) * tk;

        // emitters: leave the surface, come back, respawn
        int activeEmit = (int) (EMIT_PTS * cur[P_EMIT]);
        float busy = 0.8f + 0.25f * cur[P_ORBIT];
        for (int i = 0; i < EMIT_PTS; i++) {
            if (eage[i] < edur[i]) {
                eage[i] += dt * busy;
            } else {
                eburst[i] = false;
                if (i < activeEmit) {
                    respawnEmitter(i, cur[P_EAMP]);
                }
            }
        }

        // link pulses
        for (int i = 0; i < PULSES; i++) {
            pt[i] += dt * pspeed[i] * (0.7f + 0.8f * cur[P_ACT]);
            if (pt[i] >= 1f) {
                pt[i] = 0f;
                pedge[i] = rnd.nextInt(edgeN);
                pdir[i] = rnd.nextBoolean();
                pspeed[i] = 0.35f + rnd.nextFloat() * 0.7f;
            }
        }
    }

    private float speechEnvelope(float t) {
        float syl = 0.5f + 0.5f * (float) Math.sin(t * TWO_PI * 3.7f + 1.3f * Math.sin(t * 0.9f));
        float word = 0.5f + 0.5f * (float) Math.sin(t * TWO_PI * 0.62f + 2f * Math.sin(t * 0.37f));
        word = smooth(0.12f, 0.5f, word);
        float flutter = 0.78f + 0.22f * (float) (Math.sin(t * 13.1f) * Math.sin(t * 7.3f));
        float e = word * (0.28f + 0.72f * syl) * flutter;
        return e > 1f ? 1f : e;
    }

    private void respawnEmitter(int i, float amp) {
        float[] d = randomUnit();
        ex[i] = d[0]; ey[i] = d[1]; ez[i] = d[2];
        edur[i] = 2.0f + rnd.nextFloat() * 3.2f;
        eage[i] = 0f;
        eamp[i] = Math.max(0.07f, amp * (0.5f + rnd.nextFloat() * 0.9f));
    }

    private void spawnWave(float dx, float dy, float dz, float amp) {
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-4f) { dx = 0f; dy = 0f; dz = 1f; len = 1f; }
        int slot = -1;
        float oldest = -1f;
        for (int i = 0; i < MAX_WAVES; i++) {
            if (!wlive[i]) { slot = i; break; }
            if (wage[i] > oldest) { oldest = wage[i]; slot = i; }
        }
        wx[slot] = dx / len; wy[slot] = dy / len; wz[slot] = dz / len;
        wage[slot] = 0f;
        wamp[slot] = amp;
        wlive[slot] = true;
    }

    private void tapAt(float x, float y) {
        float dx = (x - cxs) / rad;
        float dy = -(y - cys) / rad;
        float r2 = dx * dx + dy * dy;
        float dz;
        if (r2 < 1f) {
            dz = (float) Math.sqrt(1f - r2);
        } else {
            float inv = 1f / (float) Math.sqrt(r2);
            dx *= inv; dy *= inv; dz = 0.05f;
        }
        spawnWave(dx, dy, dz, 1.15f);
        kick = Math.min(1.3f, kick + 0.8f);
        // a burst of dots thrown off the surface where the finger landed
        float ox = mS[0] * dx + mS[3] * dy + mS[6] * dz;
        float oy = mS[1] * dx + mS[4] * dy + mS[7] * dz;
        float oz = mS[2] * dx + mS[5] * dy + mS[8] * dz;
        int placed = 0;
        for (int i = EMIT_PTS - 1; i >= 0 && placed < 16; i--) {
            if (eage[i] >= edur[i] || i >= (int) (EMIT_PTS * cur[P_EMIT])) {
                float jx = ox + (rnd.nextFloat() - 0.5f) * 0.5f;
                float jy = oy + (rnd.nextFloat() - 0.5f) * 0.5f;
                float jz = oz + (rnd.nextFloat() - 0.5f) * 0.5f;
                float l = (float) Math.sqrt(jx * jx + jy * jy + jz * jz);
                ex[i] = jx / l; ey[i] = jy / l; ez[i] = jz / l;
                edur[i] = 1.1f + rnd.nextFloat() * 1.0f;
                eage[i] = 0f;
                eamp[i] = 0.2f + rnd.nextFloat() * 0.2f;
                eburst[i] = true;
                placed++;
            }
        }
    }

    // ------------------------------------------------------------------
    // rendering
    // ------------------------------------------------------------------

    public void render(SpherePainter p) {
        float t = (float) time;
        float a = audio * cur[P_AGAIN];
        float bright = cur[P_BRIGHT];
        float act = cur[P_ACT];
        int stride = quality + 1;

        // ---- colours ----
        int main = accent;
        if (errMix > 0.001f) main = mixRgb(main, 0xFF4040, errMix);
        if (offMix > 0.001f) main = mixRgb(main, 0x7F93A6, offMix * 0.85f);
        int light = mixRgb(main, 0xFFFFFF, 0.45f);
        int hot = mixRgb(main, 0xFFFFFF, 0.62f);

        // ---- matrices ----
        float pitch = 0.30f + userPitch + tiltY * 0.10f;
        float roll = 0.30f + tiltX * 0.06f;
        buildMatrix(mS, spinS + userYaw, roll, pitch);
        buildMatrix(mN, spinN + userYaw, roll * 0.8f, pitch);
        buildMatrix(mC, spinC + userYaw, roll * 1.4f, pitch);
        buildMatrix(mV, 0f, 0f, pitch);

        float parX = tiltX * rad * 0.07f;
        float parY = tiltY * rad * 0.05f;

        for (int c = 0; c < 4; c++) for (int b = 0; b < PB; b++) pcnt[c][b] = 0;
        for (int c = 0; c < 3; c++) for (int b = 0; b < LB; b++) lcnt[c][b] = 0;

        // core size / intensity
        float breathe = (float) Math.sin(corePhase);
        float cs = cur[P_CSIZE] * (1f + 0.10f * breathe + 0.55f * a + 0.30f * kick);
        float coreInt = cur[P_CORE] * (0.92f + 0.12f * breathe) + 0.35f * a + 0.30f * kick;
        if (coreInt > 1.25f) coreInt = 1.25f;
        float ccx = cxs + parX * -0.3f;
        float ccy = cys + parY * -0.3f;

        // ---- glow behind everything ----
        p.glow(0, cxs, cys, rad * 1.55f, main, (0.10f * bright + 0.06f * a) * master);
        p.glow(1, ccx, ccy, rad * 0.80f * cs, main, Math.min(1f, 0.30f * coreInt) * master);

        // ---- surface lattice ----
        boolean wavesOn = false;
        for (int i = 0; i < MAX_WAVES; i++) if (wlive[i]) { wavesOn = true; break; }
        for (int i = 0; i < MAX_WAVES; i++) {
            if (!wlive[i]) { wgain[i] = 0f; continue; }
            float th = wage[i] * 1.7f;
            wcos[i] = (float) Math.cos(th);
            wwid[i] = Math.max(0.10f, 0.34f * (float) Math.abs(Math.sin(th)));
            float fade = 1f - th / ((float) Math.PI + 0.6f);
            wgain[i] = wamp[i] * (fade < 0f ? 0f : fade);
        }
        float jit = cur[P_JIT] * a;
        boolean vib = jit > 0.02f;
        float th0 = 0.52f - 0.32f * act;
        float mt = t;
        int phase3 = frame % 3;
        float surfGain = 0.95f;
        float rimK = 0.28f;

        for (int i = phase3; i < surfN; i += 3) {
            float x = sx[i], y = sy[i], z = sz[i];
            float s1 = (float) Math.sin(2.3f * x + 1.7f * y + 0.31f * mt);
            float s2 = (float) Math.sin(2.9f * z - 1.3f * x - 0.23f * mt);
            float s3 = (float) Math.sin(3.7f * y + 2.1f * z + 0.17f * mt);
            smask[i] = 0.5f + (s1 * s2 + 0.6f * s3) / 3.2f;
        }

        float[] m = mS;
        for (int i = 0; i < surfN; i += stride) {
            float x = sx[i], y = sy[i], z = sz[i];
            float rx = m[0] * x + m[1] * y + m[2] * z;
            float ry = m[3] * x + m[4] * y + m[5] * z;
            float rz = m[6] * x + m[7] * y + m[8] * z;
            float boost = 0f;
            float disp = 1f;
            if (wavesOn) {
                for (int w = 0; w < MAX_WAVES; w++) {
                    if (wgain[w] <= 0f) continue;
                    float dd = Math.abs(rx * wx[w] + ry * wy[w] + rz * wz[w] - wcos[w]);
                    if (dd < wwid[w]) {
                        float u = 1f - dd / wwid[w];
                        float s = u * u * (3f - 2f * u) * wgain[w];
                        boost += s;
                        disp += s * 0.055f;
                    }
                }
            }
            if (vib) {
                disp += jit * 0.045f * (float) Math.sin(4.2f * x + 3.1f * y + 5.3f * z + t * 9f);
            }
            if (disp != 1f) { rx *= disp; ry *= disp; rz *= disp; }

            float mask = smoothStep(th0, th0 + 0.2f, smask[i]);
            float sb = 0.10f + 0.90f * mask;
            float d01 = (rz + 1f) * 0.5f;
            float depth = 0.18f + 0.82f * d01 * (float) Math.sqrt(d01);
            float rim = rimK * (1f - rz * rz);
            float b = (sb * (depth + rim) * bright + boost * 0.8f) * surfGain;
            if (b < 0.05f) continue;
            float sc = CAM / (CAM - rz);
            float px = cxs + rx * sc * rad + parX * (rz * 0.9f);
            float py = cys - ry * sc * rad + parY * (rz * 0.9f);
            addPt(CAT_SURF, b, px, py);
        }

        // ---- node network ----
        m = mN;
        for (int i = 0; i < NODES; i++) {
            float x = nx[i], y = ny[i], z = nz[i];
            float rx = m[0] * x + m[1] * y + m[2] * z;
            float ry = m[3] * x + m[4] * y + m[5] * z;
            float rz = m[6] * x + m[7] * y + m[8] * z;
            float sc = CAM / (CAM - rz);
            npx[i] = cxs + rx * sc * rad + parX * (rz * 0.9f + 0.1f);
            npy[i] = cys - ry * sc * rad + parY * (rz * 0.9f + 0.1f);
            nzr[i] = rz;
            float d01 = (rz + 1f) * 0.5f;
            float b = (0.38f + 0.62f * d01) * (0.80f + 0.20f * (float) Math.sin(t * 1.8f + nph[i])) * bright;
            addPt(CAT_NODE, b, npx[i], npy[i]);
        }

        // links
        float thr = 1f - act;
        for (int e = 0; e < edgeN; e++) {
            float v = 0.5f + 0.5f * (float) Math.sin(t * efq[e] * (0.8f + cur[P_ACT]) + eph[e]);
            float vis = (v - thr) / 0.35f;
            vis = vis < 0f ? 0f : (vis > 1f ? 1f : vis);
            evis[e] = vis;
            if (vis < 0.04f) continue;
            int i = ea[e], j = eb[e];
            float d01 = ((nzr[i] + nzr[j]) * 0.5f + 1f) * 0.5f;
            float b = vis * (0.22f + 0.60f * d01) * bright;
            addLine(LCAT_EDGE, b, npx[i], npy[i], npx[j], npy[j]);
        }

        // core -> node spokes (processing / thinking: connections made rapidly)
        float spoke = cur[P_SPOKE];
        if (spoke > 0.03f) {
            for (int i = 0; i < NODES; i += 2) {
                float s = (float) Math.sin(t * (2.2f + spoke * 3.2f) + nph[i] * 2f);
                s = s * 1.5f - 0.35f;
                if (s <= 0f) continue;
                if (s > 1f) s = 1f;
                float d01 = (nzr[i] + 1f) * 0.5f;
                addLine(LCAT_SPOKE, s * spoke * (0.35f + 0.5f * d01) * bright, ccx, ccy, npx[i], npy[i]);
            }
        }

        // pulses travelling along links
        int activePulse = (int) (PULSES * cur[P_PULSE]) >> (quality >= 2 ? 1 : 0);
        for (int i = 0; i < activePulse; i++) {
            int e = pedge[i];
            int from = pdir[i] ? ea[e] : eb[e];
            int to = pdir[i] ? eb[e] : ea[e];
            float u = pt[i];
            float px = npx[from] + (npx[to] - npx[from]) * u;
            float py = npy[from] + (npy[to] - npy[from]) * u;
            float vis = Math.max(0.35f, evis[e]);
            float env = (float) Math.sin(u * Math.PI);
            addPt(CAT_PART, vis * env * 1.1f * bright, px, py);
        }

        // ---- core cloud ----
        m = mC;
        for (int i = 0; i < CORE_PTS; i += stride) {
            float f = 1f + 0.10f * (float) Math.sin(t * cfq[i] * 0.6f + cph[i]);
            float x = cx0[i] * cs * f, y = cy0[i] * cs * f, z = cz0[i] * cs * f;
            float rx = m[0] * x + m[1] * y + m[2] * z;
            float ry = m[3] * x + m[4] * y + m[5] * z;
            float rz = m[6] * x + m[7] * y + m[8] * z;
            float sc = CAM / (CAM - rz);
            float px = cxs + rx * sc * rad + parX * (rz * 0.9f - 0.3f);
            float py = cys - ry * sc * rad + parY * (rz * 0.9f - 0.3f);
            float fl = 0.72f + 0.28f * (float) Math.sin(t * cfq[i] + cph[i]);
            float edge = 1f - Math.min(1f, crad[i] / (0.36f * cs));
            float b = (0.30f + 0.85f * edge) * fl * coreInt;
            addPt(CAT_CORE, b, px, py);
        }

        // ---- orbiters ----
        m = mV;
        for (int i = 0; i < ORBIT_PTS; i += (quality >= 2 ? 2 : 1)) {
            float ang = oph0[i] + ow[i] * orbT;
            float c = (float) Math.cos(ang) * orho[i], s = (float) Math.sin(ang) * orho[i];
            int o = i * 3;
            float x = ou[o] * c + ov[o] * s;
            float y = ou[o + 1] * c + ov[o + 1] * s;
            float z = ou[o + 2] * c + ov[o + 2] * s;
            float rx = m[0] * x + m[1] * y + m[2] * z;
            float ry = m[3] * x + m[4] * y + m[5] * z;
            float rz = m[6] * x + m[7] * y + m[8] * z;
            float sc = CAM / (CAM - rz);
            float px = cxs + rx * sc * rad + parX * (rz * 0.9f + 0.45f);
            float py = cys - ry * sc * rad + parY * (rz * 0.9f + 0.45f);
            float d01 = (rz + 1f) * 0.5f;
            float tw = 0.65f + 0.35f * (float) Math.sin(t * 1.3f + oph0[i] * 3f);
            float b = (0.22f + 0.78f * d01) * tw * osz[i] * bright * 1.1f;
            addPt(CAT_PART, b, px, py);
        }

        // ---- emitters: dots that leave the surface and re-enter ----
        m = mS;
        for (int i = 0; i < EMIT_PTS; i += (quality >= 2 ? 2 : 1)) {
            if (eage[i] >= edur[i]) continue;
            float u = eage[i] / edur[i];
            float env = (float) Math.sin(u * Math.PI);
            float rh = 1.0f + eamp[i] * env;
            float trail = 0.03f + eamp[i] * 0.22f;
            float rt = (u < 0.5f) ? rh - trail : rh + trail * 0.6f;
            if (rt < 1.0f) rt = 1.0f;
            float x = ex[i], y = ey[i], z = ez[i];
            float rx = m[0] * x + m[1] * y + m[2] * z;
            float ry = m[3] * x + m[4] * y + m[5] * z;
            float rz = m[6] * x + m[7] * y + m[8] * z;
            float sh = CAM / (CAM - rz * rh);
            float st = CAM / (CAM - rz * rt);
            float hx = cxs + rx * rh * sh * rad + parX * (rz * 0.9f);
            float hy = cys - ry * rh * sh * rad + parY * (rz * 0.9f);
            float tx = cxs + rx * rt * st * rad + parX * (rz * 0.9f);
            float ty = cys - ry * rt * st * rad + parY * (rz * 0.9f);
            float d01 = (rz + 1f) * 0.5f;
            float b = (float) Math.pow(env, 0.7f) * (0.35f + 0.65f * d01) * bright * (eburst[i] ? 1.3f : 1f);
            addPt(CAT_PART, b, hx, hy);
            addLine(LCAT_TICK, b * 0.8f, tx, ty, hx, hy);
        }

        // ---- flush: lines first, then dots, then the hot core glow on top ----
        flushLines(p, main, light, dens);
        flushPoints(p, main, light, hot, dens);
        p.glow(2, ccx, ccy, rad * 0.50f * cs, light, Math.min(1f, 0.70f * coreInt) * master);
        p.glow(3, ccx, ccy, rad * 0.24f * cs, hot, Math.min(1f, 0.80f * coreInt) * master);
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private void addPt(int cat, float b, float x, float y) {
        if (b < 0.03f) return;
        int k = (int) (b * PB);
        if (k >= PB) k = PB - 1;
        float[] arr = pbuf[cat][k];
        int c = pcnt[cat][k];
        if (c + 2 > arr.length) return;
        arr[c] = x;
        arr[c + 1] = y;
        pcnt[cat][k] = c + 2;
    }

    private void addLine(int cat, float b, float x1, float y1, float x2, float y2) {
        if (b < 0.03f) return;
        int k = (int) (b * LB);
        if (k >= LB) k = LB - 1;
        float[] arr = lbuf[cat][k];
        int c = lcnt[cat][k];
        if (c + 4 > arr.length) return;
        arr[c] = x1; arr[c + 1] = y1; arr[c + 2] = x2; arr[c + 3] = y2;
        lcnt[cat][k] = c + 4;
    }

    private void flushPoints(SpherePainter p, int main, int light, int hot, float d) {
        int[] colors = { main, light, light, hot };
        float[] gain = { 0.80f, 0.90f, 1.00f, 1.00f };
        float[] size = { 1.05f, 1.05f, 1.45f, 2.5f };
        for (int c = 0; c < 4; c++) {
            float base = size[c] * d * (c <= 1 ? (quality == 0 ? 1f : (quality == 1 ? 1.3f : 1.6f)) : 1f);
            for (int b = 0; b < PB; b++) {
                int n = pcnt[c][b];
                if (n == 0) continue;
                float al = ((b + 0.6f) / PB) * gain[c] * master;
                float s = base * (0.70f + 0.60f * b / (PB - 1));
                p.points(pbuf[c][b], n, s, argb(colors[c], al));
            }
        }
    }

    private void flushLines(SpherePainter p, int main, int light, float d) {
        int[] colors = { main, light, light };
        float[] gain = { 0.75f, 0.85f, 0.95f };
        float[] width = { 0.85f, 0.9f, 1.0f };
        for (int c = 0; c < 3; c++) {
            for (int b = 0; b < LB; b++) {
                int n = lcnt[c][b];
                if (n == 0) continue;
                float al = ((b + 0.6f) / LB) * gain[c] * master;
                p.lines(lbuf[c][b], n, width[c] * d, argb(colors[c], al));
            }
        }
    }

    private static int argb(int rgb, float alpha) {
        int a = (int) (alpha * 255f);
        if (a < 0) a = 0;
        if (a > 255) a = 255;
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static int mixRgb(int c1, int c2, float t) {
        int r = Math.round(((c1 >> 16) & 0xFF) * (1f - t) + ((c2 >> 16) & 0xFF) * t);
        int g = Math.round(((c1 >> 8) & 0xFF) * (1f - t) + ((c2 >> 8) & 0xFF) * t);
        int b = Math.round((c1 & 0xFF) * (1f - t) + (c2 & 0xFF) * t);
        return (r << 16) | (g << 8) | b;
    }

    private static float smooth(float e0, float e1, float x) {
        float t = (x - e0) / (e1 - e0);
        t = t < 0f ? 0f : (t > 1f ? 1f : t);
        return t * t * (3f - 2f * t);
    }

    private static float smoothStep(float e0, float e1, float x) {
        return smooth(e0, e1, x);
    }

    private static float wrap(float a) {
        if (a > TWO_PI) a -= TWO_PI;
        else if (a < -TWO_PI) a += TWO_PI;
        return a;
    }

    /** out = Rx(pitch) * Rz(roll) * Ry(yaw), row-major 3x3. */
    private void buildMatrix(float[] out, float yaw, float roll, float pitch) {
        float cy = (float) Math.cos(yaw), sy = (float) Math.sin(yaw);
        float cr = (float) Math.cos(roll), sr = (float) Math.sin(roll);
        float cp = (float) Math.cos(pitch), sp = (float) Math.sin(pitch);
        float[] ry = tmpA, rz = tmpB, rx = tmpC;
        ry[0] = cy; ry[1] = 0; ry[2] = sy; ry[3] = 0; ry[4] = 1; ry[5] = 0; ry[6] = -sy; ry[7] = 0; ry[8] = cy;
        rz[0] = cr; rz[1] = -sr; rz[2] = 0; rz[3] = sr; rz[4] = cr; rz[5] = 0; rz[6] = 0; rz[7] = 0; rz[8] = 1;
        rx[0] = 1; rx[1] = 0; rx[2] = 0; rx[3] = 0; rx[4] = cp; rx[5] = -sp; rx[6] = 0; rx[7] = sp; rx[8] = cp;
        // out = rx * (rz * ry)
        mul(rz, ry, tmpD);
        mul(rx, tmpD, out);
    }

    private static void mul(float[] a, float[] b, float[] out) {
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                out[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c];
            }
        }
    }

    private float[] randomUnit() {
        float z = rnd.nextFloat() * 2f - 1f;
        float th = rnd.nextFloat() * TWO_PI;
        float r = (float) Math.sqrt(Math.max(0f, 1f - z * z));
        return new float[]{ r * (float) Math.cos(th), z, r * (float) Math.sin(th) };
    }

    private static float[] cross(float[] a, float[] b) {
        return new float[]{
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0]
        };
    }

    private static void normalize(float[] v) {
        float l = (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        if (l < 1e-6f) return;
        v[0] /= l; v[1] /= l; v[2] /= l;
    }
}
