package com.idcorporation.atlas.agent;

import com.idcorporation.atlas.commands.ConfirmAction;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

/**
 * The plan -> act -> verify -> recover loop.
 *
 * The model plans by choosing tools; this class executes them through a
 * fixed registry, feeds each verified result back, and lets the model
 * decide the next step - so the sequence adapts to every request instead
 * of being hard-coded for examples. Hard limits keep it from looping or
 * burning the API quota:
 *
 *   - at most MAX_MODEL_CALLS model calls and MAX_TOOL_CALLS tool calls
 *   - the exact same tool call (name + arguments) is never executed twice
 *   - a wall-clock budget for the whole run
 *   - once a tool returned untrusted outside text (web, news, maps), every
 *     tool that changes state is BLOCKED for the rest of the run, so text
 *     inside a web page can never trigger a message, a delete or a call
 *   - only one confirmation per run; a confirmation ends the run's actions
 *
 * Pure Java on purpose (no Android classes) so it can be tested on a JVM.
 */
public final class AgentRunner {

    public static final int MAX_MODEL_CALLS = 5;
    public static final int MAX_TOOL_CALLS = 8;
    public static final long MAX_RUN_MS = 70000L;

    private final ModelClient client;
    private final LinkedHashMap<String, AgentTool> tools = new LinkedHashMap<String, AgentTool>();
    private final String partialErrorTemplate;
    /** Shown instead of the generic text when the model fails but a results panel is already on screen. */
    private String panelOnlyText;

    /**
     * @param partialErrorTemplate localized text with one %s, used when the model fails
     *                             after real actions already happened.
     */
    public AgentRunner(ModelClient client, ArrayList<AgentTool> toolList, String partialErrorTemplate) {
        this.client = client;
        for (int i = 0; i < toolList.size(); i++) {
            tools.put(toolList.get(i).name(), toolList.get(i));
        }
        this.partialErrorTemplate = partialErrorTemplate;
    }

    public JSONArray buildToolSchemas() {
        JSONArray arr = new JSONArray();
        for (AgentTool t : tools.values()) {
            try {
                JSONObject fn = new JSONObject();
                fn.put("name", t.name());
                fn.put("description", t.description());
                fn.put("parameters", t.parameters());
                JSONObject wrapper = new JSONObject();
                wrapper.put("type", "function");
                wrapper.put("function", fn);
                arr.put(wrapper);
            } catch (Exception ignored) {
                // A tool with a broken schema is simply not offered.
            }
        }
        return arr;
    }

    public void setPanelOnlyText(String text) {
        this.panelOnlyText = text;
    }

    /**
     * A model call that fails AFTER a tool already ran (rate limit, timeout,
     * dropped connection, 5xx) is retried once after a short pause, because
     * the tool work is done and only the final wording is missing.
     */
    private ModelReply chatWithRetry(JSONArray messages, JSONArray toolSchemas, boolean toolsThisCall,
                                     boolean afterTool) throws ModelClient.ModelException {
        try {
            return client.chat(messages, toolSchemas, toolsThisCall);
        } catch (ModelClient.ModelException e) {
            boolean retryable = afterTool && (e.code == 429 || e.code == -1 || e.code == -2 || e.code >= 500);
            if (!retryable) {
                throw e;
            }
            try {
                Thread.sleep(e.code == 429 ? 4000L : 1500L);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw e;
            }
            return client.chat(messages, toolSchemas, toolsThisCall);
        }
    }

    public AgentResult run(String systemPrompt, ArrayList<String> history, String userMessage,
                           boolean toolsEnabled) throws ModelClient.ModelException {
        AgentResult result = new AgentResult();
        long startedAt = System.currentTimeMillis();
        JSONArray toolSchemas = buildToolSchemas();
        JSONArray messages = new JSONArray();
        try {
            messages.put(msg("system", systemPrompt));
            for (int i = 0; i < history.size(); i++) {
                messages.put(msg(i % 2 == 0 ? "user" : "assistant", history.get(i)));
            }
            messages.put(msg("user", userMessage));
        } catch (Exception e) {
            throw new ModelClient.ModelException("bad request", -3);
        }

        HashSet<String> executed = new HashSet<String>();
        HashMap<String, ToolResult> lastResults = new HashMap<String, ToolResult>();
        ArrayList<String> successNotes = new ArrayList<String>();
        boolean untrustedSeen = false;
        boolean confirmationTaken = false;
        boolean allowTools = toolsEnabled && toolSchemas.length() > 0;
        String finalText = null;

        for (int step = 0; step < MAX_MODEL_CALLS; step++) {
            boolean outOfTime = System.currentTimeMillis() - startedAt > MAX_RUN_MS;
            boolean toolsThisCall = allowTools && !outOfTime && !confirmationTaken
                && result.toolCalls < MAX_TOOL_CALLS && step < MAX_MODEL_CALLS - 1;

            ModelReply reply;
            try {
                result.modelCalls++;
                reply = chatWithRetry(messages, toolSchemas, toolsThisCall, result.toolCalls > 0);
            } catch (ModelClient.ModelException e) {
                if (result.toolCalls == 0) {
                    throw e;
                }
                return degraded(result, successNotes, e.getMessage());
            }

            if (reply.toolCalls.isEmpty() || !toolsThisCall) {
                finalText = reply.content;
                break;
            }

            messages.put(reply.assistantMessage);
            for (int c = 0; c < reply.toolCalls.size(); c++) {
                ModelReply.ToolCall call = reply.toolCalls.get(c);
                ToolResult tr;
                AgentTool tool = tools.get(call.name);
                String key = call.name + "|" + normalizeArgs(call.argumentsJson);

                if (tool == null) {
                    tr = ToolResult.failed("Unknown tool '" + call.name + "'. Use only the listed tools.");
                } else if (result.toolCalls >= MAX_TOOL_CALLS) {
                    tr = ToolResult.failed("Tool-call limit reached for this request. Report what was done.");
                } else if (executed.contains(key)) {
                    tr = ToolResult.failed("This exact call was already made; its result is above. "
                        + "Do not repeat it - use that result or try a different approach.");
                } else if (untrustedSeen && tool.changesState()) {
                    tr = ToolResult.blocked("Blocked for safety: outside content (web/news/maps) was read in "
                        + "this request, so actions that change things are not run automatically. "
                        + "Tell the user what you found and ask them to confirm the action in a new message.");
                } else if (confirmationTaken) {
                    tr = ToolResult.blocked("Only one action needing confirmation is allowed per request. "
                        + "Finish by asking the user to confirm the pending one.");
                } else {
                    executed.add(key);
                    result.toolCalls++;
                    try {
                        JSONObject args = call.argumentsJson.trim().length() == 0
                            ? new JSONObject() : new JSONObject(call.argumentsJson);
                        tr = tool.execute(args);
                        if (tr == null) {
                            tr = ToolResult.failed("Tool returned nothing.");
                        }
                    } catch (Exception e) {
                        tr = ToolResult.failed("Tool error: " + e.getClass().getSimpleName()
                            + (e.getMessage() == null ? "" : " - " + e.getMessage()));
                    }
                    if (tool.returnsUntrustedContent()) {
                        untrustedSeen = true;
                    }
                    if (ToolResult.NEEDS_CONFIRMATION.equals(tr.status) && tr.confirmAction != null) {
                        confirmationTaken = true;
                        result.confirmAction = tr.confirmAction;
                    }
                    if (tr.panel != null) {
                        result.panel = tr.panel;
                    }
                    if (tr.isSuccessLike()) {
                        successNotes.add(tr.message);
                    }
                }
                result.trace.add(call.name + ":" + tr.status);
                lastResults.put(call.name, tr);
                boolean untrustedOut = tool != null && tool.returnsUntrustedContent();
                try {
                    JSONObject toolMsg = new JSONObject();
                    toolMsg.put("role", "tool");
                    toolMsg.put("tool_call_id", call.id);
                    toolMsg.put("content", tr.toModelJson(untrustedOut));
                    messages.put(toolMsg);
                } catch (Exception ignored) {
                    // Cannot happen with plain strings.
                }
            }
        }

        if (finalText == null) {
            // Out of steps while the model still wanted tools: force an honest wrap-up.
            try {
                messages.put(msg("system", "Step limit reached. Do not call tools. Tell the user briefly and "
                    + "honestly what was done, what was not, and what they could do next."));
                result.modelCalls++;
                finalText = chatWithRetry(messages, toolSchemas, false, true).content;
            } catch (ModelClient.ModelException e) {
                return degraded(result, successNotes, e.getMessage());
            } catch (Exception e) {
                return degraded(result, successNotes, "error");
            }
        }
        result.text = finalText == null ? "" : finalText.trim();
        if (result.text.length() == 0) {
            return degraded(result, successNotes, "empty answer");
        }
        return result;
    }

    private AgentResult degraded(AgentResult result, ArrayList<String> notes, String reason) {
        result.degraded = true;
        if (result.panel != null && panelOnlyText != null && panelOnlyText.length() > 0) {
            // The tool did its job and the panel is already on screen; the user does not need
            // the tool's internal English note, only to know the summary did not come.
            result.text = panelOnlyText;
            return result;
        }
        StringBuilder done = new StringBuilder();
        for (int i = 0; i < notes.size(); i++) {
            if (i > 0) {
                done.append(" ");
            }
            done.append(notes.get(i));
        }
        String template = partialErrorTemplate == null ? "%s" : partialErrorTemplate;
        result.text = template.replace("%s", done.length() == 0 ? "-" : done.toString());
        return result;
    }

    private static JSONObject msg(String role, String content) throws org.json.JSONException {
        JSONObject o = new JSONObject();
        o.put("role", role);
        o.put("content", content);
        return o;
    }

    /** Same arguments with different whitespace/key order count as the same call. */
    static String normalizeArgs(String json) {
        try {
            JSONObject o = new JSONObject(json);
            java.util.TreeMap<String, String> sorted = new java.util.TreeMap<String, String>();
            java.util.Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                sorted.put(k, String.valueOf(o.opt(k)).trim().toLowerCase(java.util.Locale.ROOT));
            }
            return sorted.toString();
        } catch (Exception e) {
            return json == null ? "" : json.trim();
        }
    }
}
