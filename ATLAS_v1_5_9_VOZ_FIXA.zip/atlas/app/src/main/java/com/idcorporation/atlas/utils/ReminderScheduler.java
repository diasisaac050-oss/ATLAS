package com.idcorporation.atlas.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import com.idcorporation.atlas.receivers.DailyReminderReceiver;

public class ReminderScheduler {

    private static final String PREFS_NAME = "atlas_reminder_prefs";
    private static final String KEY_ENABLED = "daily_reminder_enabled";
    private static final int REQUEST_CODE = 2001;

    // ==========================================================================
    // Change this single number to control how often ATLAS sends a spontaneous
    // notification (in minutes). This is edited directly here in the code.
    // Examples: 60 = every hour, 180 = every 3 hours, 720 = every 12 hours,
    // 1440 = once a day.
    // ==========================================================================
    public static final long PING_INTERVAL_MINUTES = 180;

    public static boolean isDailyReminderEnabled(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_ENABLED, false);
    }

    public static void setDailyReminderEnabled(Context context, boolean enabled) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply();

        if (enabled) {
            scheduleDailyReminder(context);
        } else {
            cancelDailyReminder(context);
        }
    }

    public static void scheduleDailyReminder(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getApplicationContext()
            .getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }

        long intervalMillis = PING_INTERVAL_MINUTES * 60L * 1000L;
        long firstTriggerMillis = System.currentTimeMillis() + intervalMillis;

        PendingIntent pendingIntent = buildPendingIntent(context);
        try {
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, firstTriggerMillis,
                intervalMillis, pendingIntent);
        } catch (SecurityException e) {
            // Exact alarm permission not granted on this OS version; inexact repeat is fine here.
        }
    }

    public static void cancelDailyReminder(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getApplicationContext()
            .getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }
        alarmManager.cancel(buildPendingIntent(context));
    }

    private static PendingIntent buildPendingIntent(Context context) {
        Intent intent = new Intent(context, DailyReminderReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags | PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getBroadcast(context.getApplicationContext(), REQUEST_CODE, intent, flags);
    }
}
