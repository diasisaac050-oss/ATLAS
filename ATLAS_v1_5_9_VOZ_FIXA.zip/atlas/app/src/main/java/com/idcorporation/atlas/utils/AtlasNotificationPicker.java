package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.res.Resources;

import com.idcorporation.atlas.R;

import java.util.ArrayList;
import java.util.Random;

public class AtlasNotificationPicker {

    public static final int STYLE_TALKING = 1;
    public static final int STYLE_CALLING = 2;
    public static final int STYLE_WELLBEING = 3;

    // ==========================================================================
    // Change this number to control how often a "calling" style notification
    // (instead of a normal "talking" one) is picked. It is a percentage from
    // 0 to 100. Example: 35 means a 35% chance of the call-style notification.
    // ==========================================================================
    public static final int CALLING_STYLE_CHANCE_PERCENT = 35;

    // ATLAS FASE 3/4 item 17 ("lembretes de bem-estar"): a light, occasional
    // nudge (drink water, look away from the screen, stretch) reusing this
    // same spontaneous-notification pipeline instead of a separate one, so
    // it naturally inherits the same "not invasive" cadence (see
    // ReminderScheduler.PING_INTERVAL_MINUTES) rather than firing on its
    // own schedule on top of everything else.
    public static final int WELLBEING_STYLE_CHANCE_PERCENT = 15;

    public static class Pick {

        public final String title;
        public final String message;
        public final int style;

        public Pick(String title, String message, int style) {
            this.title = title;
            this.message = message;
            this.style = style;
        }
    }

    public static Pick pickRandom(Context localizedContext, String name) {
        Resources resources = localizedContext.getResources();

        ArrayList<String> talkingPhrases = new ArrayList<String>();
        String[] dailyArray = resources.getStringArray(R.array.notif_daily_phrases);
        for (int i = 0; i < dailyArray.length; i = i + 1) {
            talkingPhrases.add(dailyArray[i]);
        }
        String[] talkingArray = resources.getStringArray(R.array.notif_phrases_talking);
        for (int i = 0; i < talkingArray.length; i = i + 1) {
            talkingPhrases.add(talkingArray[i]);
        }

        String[] callingArray = resources.getStringArray(R.array.notif_phrases_calling);
        ArrayList<String> callingPhrases = new ArrayList<String>();
        for (int i = 0; i < callingArray.length; i = i + 1) {
            callingPhrases.add(callingArray[i]);
        }

        String[] wellbeingArray = resources.getStringArray(R.array.notif_phrases_wellbeing);
        ArrayList<String> wellbeingPhrases = new ArrayList<String>();
        for (int i = 0; i < wellbeingArray.length; i = i + 1) {
            wellbeingPhrases.add(wellbeingArray[i]);
        }

        Random random = new Random();
        int roll = random.nextInt(100);

        if (roll < CALLING_STYLE_CHANCE_PERCENT) {
            String template = callingPhrases.get(random.nextInt(callingPhrases.size()));
            String message = String.format(template, name);
            String title = localizedContext.getString(R.string.notif_calling_title);
            return new Pick(title, message, STYLE_CALLING);
        } else if (roll < CALLING_STYLE_CHANCE_PERCENT + WELLBEING_STYLE_CHANCE_PERCENT
                && !wellbeingPhrases.isEmpty()) {
            String template = wellbeingPhrases.get(random.nextInt(wellbeingPhrases.size()));
            String message = String.format(template, name);
            String title = localizedContext.getString(R.string.notif_wellbeing_title);
            return new Pick(title, message, STYLE_WELLBEING);
        } else {
            String template = talkingPhrases.get(random.nextInt(talkingPhrases.size()));
            String message = String.format(template, name);
            String title = localizedContext.getString(R.string.notif_daily_title);
            return new Pick(title, message, STYLE_TALKING);
        }
    }
}
