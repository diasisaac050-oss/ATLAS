package com.idcorporation.atlas.theme;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.Random;

/** Exclusive background for the Red Dry theme: rising embers over a slow flickering heat glow. */
public class RedDryEmberBackgroundView extends View implements ThemeBackgroundView {

    private static final int EMBER_COUNT = 24;

    private int backgroundColor;
    private int backgroundColorAlt;
    private int emberColor;
    private float flickerPhase = 0f;

    private final float[] emberX = new float[EMBER_COUNT];
    private final float[] emberY = new float[EMBER_COUNT];
    private final float[] emberRadius = new float[EMBER_COUNT];
    private final float[] emberSpeed = new float[EMBER_COUNT];
    private final float[] emberDrift = new float[EMBER_COUNT];
    private final Random random = new Random();
    private boolean embersInitialized = false;
    private final Paint emberPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public RedDryEmberBackgroundView(Context context) {
        super(context);
    }

    @Override
    public void setPalette(ThemePalette palette) {
        this.backgroundColor = palette.getBackgroundColor();
        this.backgroundColorAlt = palette.getBackgroundColorAlt();
        this.emberColor = palette.getAccentColor();
    }

    private void initEmbersIfNeeded(int width, int height) {
        if (embersInitialized || width <= 0 || height <= 0) {
            return;
        }
        for (int i = 0; i < EMBER_COUNT; i = i + 1) {
            emberX[i] = random.nextFloat() * width;
            emberY[i] = height + random.nextFloat() * height;
            emberRadius[i] = 2f + random.nextFloat() * 5f;
            emberSpeed[i] = 1f + random.nextFloat() * 2.4f;
            emberDrift[i] = (random.nextFloat() - 0.5f) * 0.8f;
        }
        embersInitialized = true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        initEmbersIfNeeded(width, height);

        flickerPhase = flickerPhase + 0.05f;
        float flicker = (float) (Math.sin(flickerPhase) * 0.5 + 0.5);
        int mixedBackground = mixColors(backgroundColor, backgroundColorAlt, flicker * 0.3f);
        canvas.drawColor(mixedBackground);

        emberPaint.setColor(emberColor);
        for (int i = 0; i < EMBER_COUNT; i = i + 1) {
            emberY[i] = emberY[i] - emberSpeed[i];
            emberX[i] = emberX[i] + emberDrift[i];
            if (emberY[i] < -emberRadius[i]) {
                emberY[i] = height + emberRadius[i];
                emberX[i] = random.nextFloat() * width;
            }
            double twinkleInput = (emberY[i] * 0.05) + i;
            float twinkle = 0.5f + 0.5f * (float) Math.sin(twinkleInput);
            emberPaint.setAlpha((int) (210 * twinkle));
            canvas.drawCircle(emberX[i], emberY[i], emberRadius[i], emberPaint);
        }

        invalidate();
    }

    private int mixColors(int colorA, int colorB, float ratio) {
        int aR = (colorA >> 16) & 0xFF;
        int aG = (colorA >> 8) & 0xFF;
        int aB = colorA & 0xFF;
        int bR = (colorB >> 16) & 0xFF;
        int bG = (colorB >> 8) & 0xFF;
        int bB = colorB & 0xFF;
        int r = (int) (aR + (bR - aR) * ratio);
        int g = (int) (aG + (bG - aG) * ratio);
        int b = (int) (aB + (bB - aB) * ratio);
        return (0xFF << 24) | (r << 16) | (g << 8) | b;
    }

    @Override
    public void stopAnimating() {
    }
}
