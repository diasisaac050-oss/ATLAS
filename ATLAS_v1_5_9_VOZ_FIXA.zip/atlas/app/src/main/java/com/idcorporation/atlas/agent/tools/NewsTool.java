package com.idcorporation.atlas.agent.tools;

import com.idcorporation.atlas.agent.ToolResult;
import com.idcorporation.atlas.agent.panel.PanelData;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/** Real headlines from the public Google News RSS feed, in the app's language. */
public class NewsTool extends BaseTool {

    public NewsTool(ToolEnv env) {
        super(env);
    }

    @Override
    public String name() {
        return "get_news";
    }

    @Override
    public String description() {
        return "Get real recent news headlines (top news or about a topic) and show them in a panel.";
    }

    @Override
    public JSONObject parameters() {
        return Schema.obj().str("topic", "Topic to search for. Leave empty for top headlines.", false).build();
    }

    @Override
    public boolean returnsUntrustedContent() {
        return true;
    }

    @Override
    public ToolResult execute(JSONObject args) throws Exception {
        String topic = arg(args, "topic");
        String[] edition = edition(env.lang(), "pt_pt".equals(com.idcorporation.atlas.utils.LocaleHelper.getSavedLanguage(env.context)));
        String base = topic.length() == 0 ? "https://news.google.com/rss?" : "https://news.google.com/rss/search?q="
            + Http.enc(topic) + "&";
        String xml = Http.get(base + "hl=" + edition[0] + "&gl=" + edition[1] + "&ceid=" + edition[2]);
        ArrayList<String[]> items = parseRss(xml, 8);
        if (items.isEmpty()) {
            return ToolResult.failed("The news feed returned no headlines" + (topic.length() > 0 ? " for that topic." : "."));
        }
        PanelData panel = new PanelData();
        panel.type = PanelData.TYPE_NEWS;
        panel.title = topic.length() == 0 ? env.context.getString(com.idcorporation.atlas.R.string.panel_news_top)
            : topic;
        panel.subtitle = env.context.getString(com.idcorporation.atlas.R.string.panel_news_title);
        panel.source = "Google News";
        JSONArray summary = new JSONArray();
        for (int i = 0; i < items.size(); i++) {
            String[] it = items.get(i);
            panel.rows.add(new PanelData.Row(it[0], it[1], it[2], it[3]));
            JSONObject s = new JSONObject();
            s.put("headline", it[0]);
            s.put("source", it[1]);
            s.put("published", it[2]);
            summary.put(s);
        }
        JSONObject data = new JSONObject();
        data.put("headlines", summary);
        return ToolResult.ok("Real headlines from Google News. A news panel is on screen.", data).withPanel(panel);
    }

    /** {hl, gl, ceid} for the app language. */
    static String[] edition(String lang, boolean portugal) {
        if (portugal) return new String[]{"pt-PT", "PT", "PT:pt-150"};
        if ("pt".equals(lang)) return new String[]{"pt-BR", "BR", "BR:pt-419"};
        if ("es".equals(lang)) return new String[]{"es-419", "MX", "MX:es-419"};
        if ("fr".equals(lang)) return new String[]{"fr", "FR", "FR:fr"};
        if ("de".equals(lang)) return new String[]{"de", "DE", "DE:de"};
        if ("it".equals(lang)) return new String[]{"it", "IT", "IT:it"};
        if ("pl".equals(lang)) return new String[]{"pl", "PL", "PL:pl"};
        return new String[]{"en-US", "US", "US:en"};
    }

    /** Each item: {title, source, pubDate, link}. Titles lose the trailing " - Source" Google appends. */
    static ArrayList<String[]> parseRss(String xml, int max) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        try {
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        } catch (Exception ignored) {
            // Not every XML engine knows this feature; entity expansion is also switched off below.
        }
        f.setExpandEntityReferences(false);
        DocumentBuilder b = f.newDocumentBuilder();
        Document doc = b.parse(new ByteArrayInputStream(xml.getBytes(Charset.forName("UTF-8"))));
        NodeList nodes = doc.getElementsByTagName("item");
        ArrayList<String[]> out = new ArrayList<String[]>();
        for (int i = 0; i < nodes.getLength() && out.size() < max; i++) {
            Element item = (Element) nodes.item(i);
            String title = text(item, "title");
            String source = text(item, "source");
            String link = text(item, "link");
            String date = text(item, "pubDate");
            if (source.length() > 0 && title.endsWith(" - " + source)) {
                title = title.substring(0, title.length() - source.length() - 3);
            }
            if (title.length() == 0 || !link.startsWith("https://")) {
                continue;
            }
            out.add(new String[]{title, source, shortDate(date), link});
        }
        return out;
    }

    private static String text(Element parent, String tag) {
        NodeList l = parent.getElementsByTagName(tag);
        if (l.getLength() == 0) {
            return "";
        }
        Node n = l.item(0);
        String t = n.getTextContent();
        return t == null ? "" : t.trim();
    }

    /** "Tue, 06 Oct 2026 14:03:00 GMT" -> "06 Oct 14:03". */
    private static String shortDate(String rfc822) {
        try {
            String[] p = rfc822.split(" ");
            return p[1] + " " + p[2] + " " + p[4].substring(0, 5);
        } catch (Exception e) {
            return rfc822;
        }
    }
}
