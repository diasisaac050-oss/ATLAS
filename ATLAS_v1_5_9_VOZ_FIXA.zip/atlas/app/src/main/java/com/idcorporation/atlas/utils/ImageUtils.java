package com.idcorporation.atlas.utils;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * ATLAS VISAO update: turns a picked image (content:// Uri) into a small
 * JPEG the vision model can read - downscaled so it decodes without an
 * OutOfMemoryError on any device, rotated upright using its EXIF tag (a
 * photo straight from the camera is often stored sideways) and then
 * base64-encoded for the Groq/OpenAI-style multimodal request body.
 *
 * Everything here is meant to run off the main thread: decoding and
 * compressing a full-resolution photo is too slow for the UI thread.
 */
public class ImageUtils {

    /** Longest side after downscaling. Plenty for the model to read text or detail. */
    private static final int MAX_DIMENSION = 1024;
    private static final int JPEG_QUALITY = 82;
    /** Refuses to even try on a wildly oversized source (avoids ANRs on huge scans/panoramas). */
    private static final int MAX_SOURCE_DIMENSION = 8000;
    /** Longest side for the small preview shown above the compose box. */
    private static final int THUMBNAIL_DIMENSION = 384;

    public static final String MIME_JPEG = "image/jpeg";

    /** Result of a successful encode: ready to drop straight into a data: URL. */
    public static class Encoded {
        public final String base64;
        public final String mimeType;
        public final int width;
        public final int height;

        Encoded(String base64, String mimeType, int width, int height) {
            this.base64 = base64;
            this.mimeType = mimeType;
            this.width = width;
            this.height = height;
        }
    }

    private ImageUtils() {
    }

    /**
     * Reads the image at uri, downscales it to fit MAX_DIMENSION, applies
     * its EXIF rotation and returns it base64-encoded as JPEG.
     * Returns null if the Uri cannot be read or is not a decodable image -
     * callers should treat null the same as any other failure and let the
     * user know the image could not be used, rather than crashing.
     */
    public static Encoded loadAndEncode(Context context, Uri uri) {
        if (uri == null) {
            return null;
        }
        ContentResolver resolver = context.getContentResolver();
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream boundsStream = resolver.openInputStream(uri);
            if (boundsStream == null) {
                return null;
            }
            try {
                BitmapFactory.decodeStream(boundsStream, null, bounds);
            } finally {
                boundsStream.close();
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                return null;
            }
            if (bounds.outWidth > MAX_SOURCE_DIMENSION || bounds.outHeight > MAX_SOURCE_DIMENSION) {
                return null;
            }

            int sampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, MAX_DIMENSION);
            BitmapFactory.Options decodeOptions = new BitmapFactory.Options();
            decodeOptions.inSampleSize = sampleSize;
            Bitmap sampled;
            InputStream decodeStream = resolver.openInputStream(uri);
            if (decodeStream == null) {
                return null;
            }
            try {
                sampled = BitmapFactory.decodeStream(decodeStream, null, decodeOptions);
            } finally {
                decodeStream.close();
            }
            if (sampled == null) {
                return null;
            }

            int rotation = readExifRotation(resolver, uri);
            Bitmap upright = applyRotation(sampled, rotation);
            Bitmap fitted = fitToMaxDimension(upright, MAX_DIMENSION);

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            fitted.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out);
            String base64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);

            int finalWidth = fitted.getWidth();
            int finalHeight = fitted.getHeight();
            if (fitted != upright && !upright.isRecycled()) {
                upright.recycle();
            }
            if (upright != sampled && !sampled.isRecycled()) {
                sampled.recycle();
            }
            if (!fitted.isRecycled()) {
                fitted.recycle();
            }

            return new Encoded(base64, MIME_JPEG, finalWidth, finalHeight);
        } catch (IOException ioEx) {
            return null;
        } catch (OutOfMemoryError oom) {
            return null;
        } catch (RuntimeException generalEx) {
            return null;
        }
    }

    /**
     * Decodes uri straight to a small, already-rotated bitmap sized for the
     * chat-compose image preview. A raw camera photo can be 50+ megapixels;
     * handing that to ImageView.setImageURI() decodes it at full resolution
     * and crashes ("Canvas: trying to draw too large bitmap") the moment it
     * tries to draw, since a rendered bitmap this big blows past Android's
     * hardware canvas limit. Downsampling with inSampleSize before decoding
     * (like loadAndEncode does) keeps this cheap and safe at any source
     * resolution. Returns null on any failure - callers should fall back to
     * clearing the ImageView rather than crashing.
     */
    public static Bitmap decodeThumbnail(Context context, Uri uri, int maxDimension) {
        if (uri == null) {
            return null;
        }
        ContentResolver resolver = context.getContentResolver();
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream boundsStream = resolver.openInputStream(uri);
            if (boundsStream == null) {
                return null;
            }
            try {
                BitmapFactory.decodeStream(boundsStream, null, bounds);
            } finally {
                boundsStream.close();
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                return null;
            }

            int sampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, maxDimension);
            BitmapFactory.Options decodeOptions = new BitmapFactory.Options();
            decodeOptions.inSampleSize = sampleSize;
            Bitmap sampled;
            InputStream decodeStream = resolver.openInputStream(uri);
            if (decodeStream == null) {
                return null;
            }
            try {
                sampled = BitmapFactory.decodeStream(decodeStream, null, decodeOptions);
            } finally {
                decodeStream.close();
            }
            if (sampled == null) {
                return null;
            }

            int rotation = readExifRotation(resolver, uri);
            Bitmap upright = applyRotation(sampled, rotation);
            Bitmap fitted = fitToMaxDimension(upright, maxDimension);
            if (fitted != upright && !upright.isRecycled()) {
                upright.recycle();
            }
            if (upright != sampled && sampled != fitted && !sampled.isRecycled()) {
                sampled.recycle();
            }
            return fitted;
        } catch (IOException ioEx) {
            return null;
        } catch (OutOfMemoryError oom) {
            return null;
        } catch (RuntimeException generalEx) {
            return null;
        }
    }

    /** Convenience overload using {@link #THUMBNAIL_DIMENSION}. */
    public static Bitmap decodeThumbnail(Context context, Uri uri) {
        return decodeThumbnail(context, uri, THUMBNAIL_DIMENSION);
    }

    private static int computeSampleSize(int width, int height, int maxDimension) {
        int sample = 1;
        int longest = Math.max(width, height);
        while (longest / (sample * 2) >= maxDimension) {
            sample = sample * 2;
        }
        return sample;
    }

    /** @return degrees the image must be rotated clockwise to be upright, or 0 if unknown/normal. */
    private static int readExifRotation(ContentResolver resolver, Uri uri) {
        InputStream exifStream = null;
        try {
            exifStream = resolver.openInputStream(uri);
            if (exifStream == null) {
                return 0;
            }
            ExifInterface exif = new ExifInterface(exifStream);
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    return 90;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    return 180;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    return 270;
                default:
                    return 0;
            }
        } catch (IOException ioEx) {
            return 0;
        } catch (RuntimeException generalEx) {
            // Some providers throw on exotic formats instead of just
            // failing to find the tag - treat that the same as "no tag".
            return 0;
        } finally {
            if (exifStream != null) {
                try {
                    exifStream.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private static Bitmap applyRotation(Bitmap source, int degrees) {
        if (degrees == 0) {
            return source;
        }
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    private static Bitmap fitToMaxDimension(Bitmap source, int maxDimension) {
        int width = source.getWidth();
        int height = source.getHeight();
        int longest = Math.max(width, height);
        if (longest <= maxDimension) {
            return source;
        }
        float scale = ((float) maxDimension) / ((float) longest);
        int newWidth = Math.max(1, Math.round(width * scale));
        int newHeight = Math.max(1, Math.round(height * scale));
        return Bitmap.createScaledBitmap(source, newWidth, newHeight, true);
    }
}
