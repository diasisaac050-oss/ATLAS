package com.idcorporation.atlas.agent;

import com.idcorporation.atlas.agent.panel.PanelData;
import com.idcorporation.atlas.commands.ConfirmAction;

import java.util.ArrayList;

/** Final outcome of one agent run, handed to the chat or voice session. */
public final class AgentResult {

    public String text = "";
    public PanelData panel;
    public ConfirmAction confirmAction;
    /** True when the final text had to be built by code because the model could not finish. */
    public boolean degraded = false;
    public int modelCalls = 0;
    public int toolCalls = 0;
    /** Human-readable trace ("tool:status") - used by tests and diagnostics, never shown to the user. */
    public final ArrayList<String> trace = new ArrayList<String>();
}
