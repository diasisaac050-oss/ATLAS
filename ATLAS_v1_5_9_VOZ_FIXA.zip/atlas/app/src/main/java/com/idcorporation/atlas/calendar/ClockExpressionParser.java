package com.idcorporation.atlas.calendar;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads a clock time out of a spoken sentence: "meio-dia e 39", "as 7 e meia",
 * "7:30", "19h", "as 6 da manha", "quinze para as 7". Durations from now
 * ("daqui a 5 minutos") live in DurationExpressionParser.
 * Input is normalized text (lower-case, no accents). Positions are returned
 * so the title extractor can leave those words out.
 */
public class ClockExpressionParser {

    public static class ClockResult {
        public boolean found;
        public int hour = -1;
        public int minute;
        /** Hour said as 1-11 with no morning/afternoon word, so it could be am or pm. */
        public boolean ambiguous;
        public int start = -1;
        public int end = -1;
    }

    private static final String NUM = PtNumberWords.NUM;
    private static final String MIN_TOKEN = "(meia|um\\s+quarto|" + NUM + ")";
    private static final String MIN_SUFFIX = "(?:\\s*(?:minutos?|mins?))?";
    private static final String PREFIX_STRICT = "(?:as|pras|para\\s+as|pra\\s+as|por\\s+volta\\s+das|umas)";
    private static final String PREFIX_LENIENT = "(?:as|pras|para\\s+as|pra\\s+as|por\\s+volta\\s+das|umas"
        + "|para|pra|despertador|alarme)";
    private static final String NOT_A_UNIT = "(?!\\s*(?:minutos?|mins?|segundos?|segs?|dias?|semanas?|reais|pessoas"
        + "|vezes|de\\s+" + DateExpressionParser.MONTHS + "|/|:))";

    private static final Pattern NOON = Pattern.compile(
        "\\bmeio[\\s-]?dia\\b(?:\\s+e\\s+" + MIN_TOKEN + MIN_SUFFIX + ")?");
    private static final Pattern MIDNIGHT = Pattern.compile(
        "\\bmeia[\\s-]?noite\\b(?:\\s+e\\s+" + MIN_TOKEN + MIN_SUFFIX + ")?");
    private static final Pattern HH_MM = Pattern.compile("\\b(\\d{1,2})\\s*(?::|h|hs|hrs)\\s*(\\d{2})\\b");
    private static final Pattern QUARTER_TO = Pattern.compile(
        "\\b(quinze|um\\s+quarto|" + NUM + ")\\s+(?:minutos?\\s+)?(?:para\\s+as|pra\\s+as|pras|para|pra)\\s+("
        + NUM + ")\\b" + "(?!\\s*(?:minutos?|horas?))");
    private static final Pattern HOURS_WORD = Pattern.compile(
        "(?:\\b" + PREFIX_STRICT + "\\s+)?\\b(" + NUM + ")\\s*(?:horas?|hrs?|hs|h)\\b"
        + "(?:\\s+e\\s+" + MIN_TOKEN + MIN_SUFFIX + ")?");
    private static final Pattern PERIOD_AFTER = Pattern.compile(
        "^\\s*(?:(?:da|de|do|na|no|a|em)\\s+)?(manha|madrugada|tarde|noite)\\b");
    private static final Pattern AMPM_AFTER = Pattern.compile("^\\s*(am|pm)\\b");
    private static final Pattern PERIOD_ANY = Pattern.compile(
        "\\b(?:da|de|na|no|a|esta|essa)\\s+(manha|madrugada|tarde|noite)\\b");

    public static ClockResult parseClock(String n, boolean lenient) {
        ClockResult r = new ClockResult();
        String prefix = lenient ? PREFIX_LENIENT : PREFIX_STRICT;

        Matcher m = NOON.matcher(n);
        if (m.find()) {
            return finish(r, n, 12, minuteOf(m.group(1)), m.start(), m.end(), true);
        }
        m = MIDNIGHT.matcher(n);
        if (m.find()) {
            return finish(r, n, 0, minuteOf(m.group(1)), m.start(), m.end(), true);
        }
        m = HH_MM.matcher(n);
        while (m.find()) {
            int hour = Integer.parseInt(m.group(1));
            int minute = Integer.parseInt(m.group(2));
            if (hour <= 23 && minute <= 59) {
                boolean leadingZero = m.group(1).length() == 2 && m.group(1).startsWith("0");
                return finish(r, n, hour, minute, m.start(), m.end(), leadingZero);
            }
        }
        m = QUARTER_TO.matcher(n);
        while (m.find()) {
            int minutes = "um quarto".equals(m.group(1).replaceAll("\\s+", " ")) ? 15 : PtNumberWords.value(m.group(1));
            int hour = PtNumberWords.value(m.group(2));
            if (minutes >= 1 && minutes <= 59 && hour >= 1 && hour <= 24) {
                int total = (hour % 24) * 60 - minutes;
                if (total < 0) {
                    total += 24 * 60;
                }
                return finish(r, n, total / 60, total % 60, m.start(), m.end(), false);
            }
        }
        m = HOURS_WORD.matcher(n);
        while (m.find()) {
            int hour = PtNumberWords.value(m.group(1));
            int minute = m.group(2) == null ? 0 : minuteOf(m.group(2));
            if (hour >= 0 && hour <= 23 && minute >= 0) {
                return finish(r, n, hour, minute, m.start(), m.end(), false);
            }
        }
        Pattern andMinutes = Pattern.compile("(?:\\b" + prefix + "\\s+)\\b(" + NUM + ")\\s+e\\s+" + MIN_TOKEN
            + MIN_SUFFIX + "\\b");
        m = andMinutes.matcher(n);
        while (m.find()) {
            int hour = PtNumberWords.value(m.group(1));
            int minute = minuteOf(m.group(2));
            if (hour >= 0 && hour <= 23 && minute >= 0) {
                return finish(r, n, hour, minute, m.start(), m.end(), false);
            }
        }
        Pattern hourOnly = Pattern.compile("(?:\\b" + prefix + "\\s+)\\b(" + NUM + ")\\b" + NOT_A_UNIT);
        m = hourOnly.matcher(n);
        while (m.find()) {
            int hour = PtNumberWords.value(m.group(1));
            if (hour >= 0 && hour <= 23) {
                return finish(r, n, hour, 0, m.start(), m.end(), false);
            }
        }
        return r;
    }

    /** Minutes from "meia" (30), "um quarto" (15) or a number; -1 when missing or out of range. */
    private static int minuteOf(String token) {
        if (token == null) {
            return 0;
        }
        String t = token.trim().replaceAll("\\s+", " ");
        int value;
        if ("meia".equals(t)) {
            value = 30;
        } else if ("um quarto".equals(t)) {
            value = 15;
        } else {
            value = PtNumberWords.value(t);
        }
        return (value >= 0 && value <= 59) ? value : -1;
    }

    private static ClockResult finish(ClockResult r, String n, int hour, int minute, int start, int end,
            boolean exact) {
        r.found = true;
        r.hour = hour;
        r.minute = Math.max(minute, 0);
        r.start = start;
        r.end = end;
        r.ambiguous = false;
        if (exact || hour == 0 || hour >= 13) {
            return r;
        }
        String period = null;
        Matcher after = PERIOD_AFTER.matcher(n.substring(end));
        if (after.find()) {
            period = after.group(1);
            r.end = end + after.end();
        } else {
            Matcher ampm = AMPM_AFTER.matcher(n.substring(end));
            if (ampm.find()) {
                period = "am".equals(ampm.group(1)) ? "manha" : "tarde";
                r.end = end + ampm.end();
            } else {
                Matcher any = PERIOD_ANY.matcher(n);
                if (any.find()) {
                    period = any.group(1);
                }
            }
        }
        if (period == null) {
            r.ambiguous = hour >= 1 && hour <= 11;
            return r;
        }
        if ("manha".equals(period) || "madrugada".equals(period)) {
            r.hour = hour == 12 ? 0 : hour;
        } else if ("tarde".equals(period)) {
            r.hour = hour < 12 ? hour + 12 : hour;
        } else {
            r.hour = hour < 12 ? hour + 12 : (hour == 12 ? 0 : hour);
        }
        return r;
    }
}
