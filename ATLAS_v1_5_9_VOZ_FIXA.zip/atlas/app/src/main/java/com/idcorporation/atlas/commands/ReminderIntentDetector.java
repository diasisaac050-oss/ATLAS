package com.idcorporation.atlas.commands;

import com.idcorporation.atlas.calendar.ClockExpressionParser;
import com.idcorporation.atlas.calendar.DateExpressionParser;
import com.idcorporation.atlas.calendar.DateTimeCommandParser;
import com.idcorporation.atlas.calendar.DurationExpressionParser;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Decides whether a sentence is asking for a reminder (calendar event) or
 * an alarm, without depending on exact trigger phrases. The rule is loose
 * on purpose: any action word ("marque", "coloca", "me lembra", "agende",
 * "me acorda"...) plus something that names a day or a time is enough.
 */
public class ReminderIntentDetector {

    private static final Pattern ALARM_WORDS = Pattern.compile(
        "\\b(?:despertador(?:es)?|alarmes?|alarm)\\b|\\bme\\s+(?:acord\\w*|desperta\\w*)\\b"
        + "|\\b(?:acorda|acorde|desperta|desperte)-me\\b|\\bme\\s+cham[ae]\\s+(?:as|pras|daqui|em)\\b");
    private static final Pattern CANCEL_WORDS = Pattern.compile(
        "\\b(?:cancel\\w*|desativ\\w*|apag\\w*|exclu\\w*|delet\\w*|remov\\w*|desligu?\\w*|tire|tira)\\b");
    private static final Pattern CREATE_WORDS = Pattern.compile(
        "\\b(?:coloc\\w*|cri(?:e|ar|a)|marc\\w*|ponh\\w*|poe|program\\w*|defin\\w*|faca|faz|toc(?:a|ar|que)"
        + "|agend\\w*|ativ\\w*|configur\\w*|me\\s+acord\\w*|me\\s+desperta\\w*)\\b");
    private static final Pattern QUESTION_START = Pattern.compile(
        "^\\s*(?:(?:ei|oi|ok|hey)\\s+)?(?:atlas\\s+)?(?:que|qual|quais|quando|quanto|quantos|tem|existe)\\b");

    private static final Pattern STRONG_PERSONAL = Pattern.compile(
        "\\bme\\s+lembr\\w*|\\blembr\\w*-me\\b|\\blembrete\\b");
    private static final Pattern STRONG_VERB = Pattern.compile(
        "\\b(?:marque|marcar|marca|agende|agendar|agenda|me\\s+avis\\w*|avis[ae]-me|lembr(?:a|e|ar)\\s+(?:de|do|da))\\b");
    private static final Pattern WEAK_VERB = Pattern.compile(
        "\\b(?:coloc\\w*|cri(?:e|ar|a)|adicion\\w*|regist\\w*|cadastr\\w*|anot\\w*|salv\\w*|defin\\w*"
        + "|program\\w*|bot(?:e|ar|a)|ponh\\w*|poe)\\b");
    private static final Pattern NOUN = Pattern.compile(
        "\\blembrete\\b|\\b(?:no|na|em|do|da)\\s+(?:meu\\s+|minha\\s+|o\\s+|a\\s+)?(?:calendario|agenda)\\b"
        + "|\\bcompromisso\\b");
    private static final Pattern MEMORY_QUESTION = Pattern.compile("\\b(?:voce|vc|tu)\\s+(?:se\\s+)?lembra");
    private static final Pattern AGENDA_NOUN_ARTICLES = Pattern.compile("^(?:minha|meu|na|no|da|do|a|o|essa|esta|sua|nossa)$");

    public static boolean isAlarmIntent(String text) {
        String n = DateTimeCommandParser.normalize(text);
        if (!ALARM_WORDS.matcher(n).find() || CANCEL_WORDS.matcher(n).find()) {
            return false;
        }
        if (CommandParser.isOpenAppCommand(text.toLowerCase())) {
            return false;
        }
        if (QUESTION_START.matcher(n).find() && !CREATE_WORDS.matcher(n).find()) {
            return false;
        }
        return true;
    }

    public static boolean isReminderIntent(String text) {
        String n = DateTimeCommandParser.normalize(text);
        if (CANCEL_WORDS.matcher(n).find() || MEMORY_QUESTION.matcher(n).find()) {
            return false;
        }
        if (CommandParser.isCalendarOpenCommand(text.toLowerCase())
                || CommandParser.isOpenAppCommand(text.toLowerCase())) {
            return false;
        }
        boolean personal = STRONG_PERSONAL.matcher(n).find();
        boolean verb = personal || hasVerbNotAfterArticle(n, STRONG_VERB);
        boolean weak = WEAK_VERB.matcher(n).find();
        boolean noun = NOUN.matcher(n).find();
        boolean timeExpression = hasTimeExpression(n);
        if (verb && timeExpression) {
            return true;
        }
        if (noun && (verb || weak || timeExpression)) {
            return true;
        }
        // "me lembra de comprar pao": a reminder with no day yet, the assistant asks for it.
        return personal;
    }

    /** True for anything that reads like a reminder/alarm request, even one that cannot be carried out. */
    public static boolean mentionsReminderOrAlarm(String text) {
        String n = DateTimeCommandParser.normalize(text);
        return ALARM_WORDS.matcher(n).find() || STRONG_PERSONAL.matcher(n).find()
            || NOUN.matcher(n).find();
    }

    public static boolean hasTimeExpression(String normalized) {
        Calendar now = new GregorianCalendar();
        return DateExpressionParser.parse(normalized, now).found
            || ClockExpressionParser.parseClock(normalized, false).found
            || DurationExpressionParser.parse(normalized, false).found;
    }

    /** "agenda"/"marca" are also nouns ("minha agenda"), so they only count as verbs when no article precedes them. */
    private static boolean hasVerbNotAfterArticle(String n, Pattern verb) {
        Matcher m = verb.matcher(n);
        while (m.find()) {
            String before = n.substring(0, m.start()).trim();
            int space = before.lastIndexOf(' ');
            String previous = space >= 0 ? before.substring(space + 1) : before;
            if (previous.length() == 0 || !AGENDA_NOUN_ARTICLES.matcher(previous).find()) {
                return true;
            }
        }
        return false;
    }
}
