package com.idcorporation.atlas.utils;

public class PasswordValidator {

    public static final int MIN_LENGTH = 6;

    public static boolean isValid(String password) {
        if (password == null || password.length() < MIN_LENGTH) {
            return false;
        }
        if (password.contains(" ")) {
            return false;
        }
        if (isFullySequential(password)) {
            return false;
        }
        return true;
    }

    /** Rejects passwords like "123456", "654321", "111111" - all digits, strictly ascending/descending/repeated. */
    private static boolean isFullySequential(String password) {
        boolean allDigits = true;
        for (int i = 0; i < password.length(); i++) {
            if (!Character.isDigit(password.charAt(i))) {
                allDigits = false;
                break;
            }
        }
        if (!allDigits) {
            return false;
        }

        boolean ascending = true;
        boolean descending = true;
        boolean allSame = true;
        for (int i = 1; i < password.length(); i++) {
            int previous = password.charAt(i - 1) - '0';
            int current = password.charAt(i) - '0';
            if (current != previous + 1) {
                ascending = false;
            }
            if (current != previous - 1) {
                descending = false;
            }
            if (current != previous) {
                allSame = false;
            }
        }
        return ascending || descending || allSame;
    }
}
