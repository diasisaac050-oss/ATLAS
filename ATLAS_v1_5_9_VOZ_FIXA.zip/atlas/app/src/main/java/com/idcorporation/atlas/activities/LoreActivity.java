package com.idcorporation.atlas.activities;

import android.os.Bundle;
import android.view.View;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.SecretUnlockManager;

public class LoreActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lore);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Viewing it once locks it away forever, even if the secret code is typed again.
        SecretUnlockManager.markPermanentlyViewed(this);
    }
}
