package com.idcorporation.atlas.activities;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.idcorporation.atlas.R;

/**
 * Shown by CrashReporter (in the separate ":crash" process) after ATLAS
 * crashes: the full error text, selectable, with a Copy button. It is a
 * plain Activity built in code on purpose, so it depends on nothing that
 * could itself be the thing that crashed.
 */
public class CrashReportActivity extends Activity {

    public static final String EXTRA_TRACE = "trace";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String stored = getIntent().getStringExtra(EXTRA_TRACE);
        final String trace = (stored == null) ? "(no details)" : stored;
        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (16 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0A0E14);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText(R.string.crash_title);
        title.setTextColor(0xFFFF5252);
        title.setTextSize(18f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText(R.string.crash_hint);
        hint.setTextColor(0xFF8FA6B8);
        hint.setTextSize(12f);
        hint.setPadding(0, (int) (6 * d), 0, (int) (10 * d));
        root.addView(hint);

        ScrollView scroll = new ScrollView(this);
        TextView body = new TextView(this);
        body.setText(trace);
        body.setTextColor(0xFFE8F6FF);
        body.setTextSize(11f);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setPadding(0, (int) (10 * d), 0, 0);

        Button copy = new Button(this);
        copy.setText(R.string.crash_copy);
        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    clipboard.setPrimaryClip(ClipData.newPlainText("ATLAS crash", trace));
                    Toast.makeText(CrashReportActivity.this, R.string.crash_copied, Toast.LENGTH_SHORT).show();
                }
            }
        });
        buttons.addView(copy, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button close = new Button(this);
        close.setText(R.string.crash_close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        buttons.addView(close, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(buttons);
        setContentView(root);
    }
}
