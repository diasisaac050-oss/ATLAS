package com.idcorporation.atlas.security;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Patterns;

import androidx.core.content.ContextCompat;

/**
 * Central helper for permission checks and basic input validation.
 * Keeping this logic in one class avoids duplicated, inconsistent
 * checks scattered across activities.
 */
public class SecurityManager {

    public static boolean hasPermission(Context context, String permission) {
        int result = ContextCompat.checkSelfPermission(context, permission);
        return result == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().length() == 0) {
            return false;
        }
        return Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches();
    }

    public static boolean isValidName(String name) {
        return name != null && name.trim().length() >= 2;
    }

    public static boolean isValidAge(String ageText) {
        if (ageText == null || ageText.trim().length() == 0) {
            return false;
        }
        try {
            int age = Integer.parseInt(ageText.trim());
            return age > 0 && age < 130;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Sanitizes free-text before it is stored (notes, memories, custom
     * command phrases). Strips control characters and caps length.
     */
    public static String sanitizeText(String input, int maxLength) {
        if (input == null) {
            return "";
        }
        String cleaned = input.replaceAll("[\\x00-\\x09\\x0B\\x0C\\x0E-\\x1F]", "");
        if (cleaned.length() > maxLength) {
            cleaned = cleaned.substring(0, maxLength);
        }
        return cleaned.trim();
    }
}
