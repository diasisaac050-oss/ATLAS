package com.idcorporation.atlas.presence;

import android.animation.TimeInterpolator;

/**
 * A damped spring curve for the open animation. Unlike the bouncy
 * OvershootInterpolator it only overshoots a little (about 5 percent) and
 * settles smoothly, which is what makes the glass feel expensive instead
 * of cartoonish.
 */
public class PresenceSpring implements TimeInterpolator {

    private static final float DECAY = 5.2f;

    private final float damped;

    /** @param damping 0.5 = lively, 0.7 = calm with a tiny overshoot, 1 = no overshoot. */
    public PresenceSpring(float damping) {
        float z = Math.max(0.3f, Math.min(0.99f, damping));
        float omega = DECAY / z;
        this.damped = omega * (float) Math.sqrt(1.0 - (double) (z * z));
    }

    @Override
    public float getInterpolation(float t) {
        if (t <= 0f) {
            return 0f;
        }
        if (t >= 1f) {
            return 1f;
        }
        double env = Math.exp((double) (-DECAY * t));
        double wave = Math.cos((double) (damped * t)) + (double) (DECAY / damped) * Math.sin((double) (damped * t));
        return (float) (1.0 - env * wave);
    }
}
