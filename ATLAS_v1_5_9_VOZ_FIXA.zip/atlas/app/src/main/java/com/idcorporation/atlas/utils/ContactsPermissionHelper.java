package com.idcorporation.atlas.utils;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

import androidx.core.content.ContextCompat;

/**
 * Read-only checks for the two dangerous permissions the voice call /
 * WhatsApp message feature needs (READ_CONTACTS to find a number,
 * CALL_PHONE to place a call directly instead of only opening the
 * dialer). The actual runtime request has to happen from an Activity
 * (Android requirement), so this only answers "do we have it right
 * now" - see MainActivity.requestContactActionPermissionsIfNeeded for
 * where the request itself happens.
 */
public class ContactsPermissionHelper {

    private static final String PREFS_NAME = "atlas_contact_permission_prefs";
    private static final String KEY_ASKED = "asked_contact_action_permissions";

    public static boolean hasReadContacts(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean hasCallPhone(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE)
            == PackageManager.PERMISSION_GRANTED;
    }

    public static String[] missingPermissions(Context context) {
        java.util.ArrayList<String> missing = new java.util.ArrayList<String>();
        if (!hasReadContacts(context)) {
            missing.add(Manifest.permission.READ_CONTACTS);
        }
        if (!hasCallPhone(context)) {
            missing.add(Manifest.permission.CALL_PHONE);
        }
        return missing.toArray(new String[missing.size()]);
    }

    /**
     * The Android permission dialog itself only shows a limited number
     * of times before the OS silently auto-denies it, and re-opening
     * ATLAS on top of whatever the user is doing (the dialer included)
     * every single time a call/message command runs without the
     * permission yet granted would be disruptive. So this nudge - jump
     * to ATLAS and show the system dialog - fires once; after that the
     * feature just keeps working through its no-permission fallback
     * (ACTION_DIAL) and the user can still grant it manually from
     * Settings > Apps > ATLAS at any time.
     */
    public static boolean shouldPromptForPermissions(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return !prefs.getBoolean(KEY_ASKED, false);
    }

    public static void markPermissionsPrompted(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_ASKED, true).apply();
    }
}
