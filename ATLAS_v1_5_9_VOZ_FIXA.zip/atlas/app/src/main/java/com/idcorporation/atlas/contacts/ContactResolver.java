package com.idcorporation.atlas.contacts;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;

import com.idcorporation.atlas.calendar.DateTimeCommandParser;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Finds contacts on the device by a spoken name, using only the standard
 * ContactsContract provider (no third-party contact APIs, nothing cached
 * locally). Matching is accent/case-insensitive so "joao", "Joao" and
 * "Joao" (typed with the accent) all find the same "Joao" contact, and
 * a nickname the user saved as the contact's own name (e.g. a contact
 * literally named "minha princesa") matches the same way as any other
 * name.
 */
public class ContactResolver {

    /**
     * Returns every distinct contact whose display name matches the
     * spoken name, one entry per person (not per phone number - a
     * contact with two numbers still comes back as a single match with
     * the best number chosen for it). Never returns null.
     */
    public static ArrayList<ContactMatch> findByName(Context context, String spokenName) {
        ArrayList<ContactMatch> results = new ArrayList<ContactMatch>();
        String query = normalize(spokenName);
        if (query.length() == 0) {
            return results;
        }

        ContentResolver resolver = context.getContentResolver();
        String[] projection = new String[]{
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE
        };

        HashMap<Long, ContactMatch> bestPerContact = new HashMap<Long, ContactMatch>();
        Cursor cursor = null;
        try {
            cursor = resolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection, null, null, null);
            if (cursor == null) {
                return results;
            }
            int idIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID);
            int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
            int numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            int typeIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE);

            while (cursor.moveToNext()) {
                String rawName = nameIndex >= 0 ? cursor.getString(nameIndex) : null;
                String rawNumber = numberIndex >= 0 ? cursor.getString(numberIndex) : null;
                if (rawName == null || rawNumber == null || rawNumber.length() == 0) {
                    continue;
                }
                // Match on the readable part of the name so decorations ("Minha Princesa" +
                // emojis) never get in the way; the raw name is kept as saved.
                String readable = com.idcorporation.atlas.utils.SpeechText.contactName(rawName);
                String normalizedName = normalize(readable.length() > 0 ? readable : rawName);
                if (!matches(normalizedName, query)) {
                    continue;
                }
                long contactId = idIndex >= 0 ? cursor.getLong(idIndex) : 0L;
                int type = typeIndex >= 0 ? cursor.getInt(typeIndex) : -1;
                String label = labelForType(type);

                ContactMatch candidate = new ContactMatch(contactId, rawName.trim(), rawNumber, label);
                ContactMatch existing = bestPerContact.get(contactId);
                if (existing == null || isBetterNumber(type, existing)) {
                    bestPerContact.put(contactId, candidate);
                }
            }
        } catch (SecurityException e) {
            // No READ_CONTACTS permission - caller checks this before calling in,
            // but a race (permission revoked mid-call) must not crash ATLAS.
            return results;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        results.addAll(bestPerContact.values());
        return results;
    }

    /** Mobile numbers are preferred when a contact has more than one phone number saved. */
    private static boolean isBetterNumber(int newType, ContactMatch existing) {
        boolean newIsMobile = newType == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE;
        boolean existingIsMobile = ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
            == typeForLabel(existing.numberLabel);
        return newIsMobile && !existingIsMobile;
    }

    private static int typeForLabel(String label) {
        if (label == null) {
            return -1;
        }
        if (label.equals("Mobile")) {
            return ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE;
        }
        return -1;
    }

    private static String labelForType(int type) {
        if (type == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE) {
            return "Mobile";
        }
        if (type == ContactsContract.CommonDataKinds.Phone.TYPE_HOME) {
            return "Home";
        }
        if (type == ContactsContract.CommonDataKinds.Phone.TYPE_WORK) {
            return "Work";
        }
        return "";
    }

    /**
     * A contact name matches a spoken query if the query is fully
     * contained in it (handles both "joao" matching "Joao Silva" and a
     * full nickname like "minha princesa" matching a contact literally
     * saved with that name).
     */
    private static boolean matches(String normalizedContactName, String normalizedQuery) {
        return normalizedContactName.contains(normalizedQuery);
    }

    private static String normalize(String text) {
        if (text == null) {
            return "";
        }
        return DateTimeCommandParser.normalize(text).trim().replaceAll("\\s+", " ");
    }
}
