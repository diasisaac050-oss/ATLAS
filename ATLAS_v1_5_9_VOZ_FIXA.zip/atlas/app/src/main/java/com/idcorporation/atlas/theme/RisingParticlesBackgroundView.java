package com.idcorporation.atlas.theme;

import android.content.Context;
import android.graphics.Canvas;

import java.util.Random;

/**
 * PARTICLES: motes of light rising from a glowing floor. Three depth layers
 * (far = tiny, dim, slow; near = bigger, brighter, faster), each mote a soft
 * halo with a white-hot centre, swaying and twinkling - the same dots the
 * sphere is made of.
 */
public class RisingParticlesBackgroundView extends FxBackgroundView {

    private static final int COUNT = 46;

    private final float[] px = new float[COUNT];
    private final float[] py = new float[COUNT];
    private final float[] depth = new float[COUNT];   // 0.15 far .. 1 near
    private final float[] phase = new float[COUNT];
    private final float[] twk = new float[COUNT];
    private final Random rng = new Random(7);

    public RisingParticlesBackgroundView(Context context) {
        super(context);
    }

    @Override
    protected void onSized(int width, int height) {
        for (int i = 0; i < COUNT; i++) {
            depth[i] = rnd(rng, 0.15f, 1f);
            px[i] = rnd(rng, 0f, width);
            py[i] = rnd(rng, 0f, height);
            phase[i] = rnd(rng, 0f, 6.283f);
            twk[i] = rnd(rng, 0.7f, 1.8f);
        }
    }

    @Override
    protected void drawFx(Canvas c, float dt) {
        // light welling up from the bottom
        float breathe = 0.85f + 0.15f * (float) Math.sin(time * 0.6f);
        glowRect(c, w * 0.5f, h * 1.02f, w * 0.95f, h * 0.34f, 0.20f * breathe);
        glowRect(c, w * 0.5f, h * 1.04f, w * 0.45f, h * 0.16f, 0.16f * breathe);

        for (int i = 0; i < COUNT; i++) {
            float z = depth[i];
            py[i] -= (12f + 44f * z) * dens * dt;
            float sway = (float) Math.sin(time * 0.45f * twk[i] + phase[i]) * (8f + 18f * z) * dens;
            float x = px[i] + sway;
            if (py[i] < -20f * dens) {
                py[i] = h + 20f * dens;
                px[i] = rnd(rng, 0f, w);
            }
            float y = py[i];

            // fade in/out near the edges, twinkle, and be dimmer when far
            float edge = Math.min(1f, Math.min(y / (h * 0.14f), (h - y) / (h * 0.10f)));
            if (edge <= 0f) {
                continue;
            }
            float tw = 0.65f + 0.35f * (float) Math.sin(time * 1.9f * twk[i] + phase[i] * 2f);
            float a = edge * tw * (0.22f + 0.78f * z);

            float r = (2.2f + 5.5f * z) * dens;
            glow(c, x, y, r * 4.2f, a * 0.42f);
            glow(c, x, y, r * 1.7f, a * 0.85f);
            hotGlow(c, x, y, r * 0.8f, a);
        }
    }
}
