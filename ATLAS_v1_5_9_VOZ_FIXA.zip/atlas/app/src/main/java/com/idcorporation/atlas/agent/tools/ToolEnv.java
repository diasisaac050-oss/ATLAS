package com.idcorporation.atlas.agent.tools;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.idcorporation.atlas.commands.CommandManager;
import com.idcorporation.atlas.utils.LocaleHelper;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Shared context for tools: app context, the session's CommandManager, and main-thread hopping. */
public final class ToolEnv {

    public final Context context;
    public final CommandManager commandManager;
    private final Handler main = new Handler(Looper.getMainLooper());

    public ToolEnv(Context context, CommandManager commandManager) {
        this.context = context.getApplicationContext();
        this.commandManager = commandManager;
    }

    /** Runs on the main thread (startActivity, CommandManager) and waits for the answer. */
    public <T> T onMain(final Callable<T> job, long timeoutMs) throws Exception {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return job.call();
        }
        final AtomicReference<T> value = new AtomicReference<T>();
        final AtomicReference<Exception> error = new AtomicReference<Exception>();
        final CountDownLatch latch = new CountDownLatch(1);
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    value.set(job.call());
                } catch (Exception e) {
                    error.set(e);
                } finally {
                    latch.countDown();
                }
            }
        });
        if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) {
            throw new java.util.concurrent.TimeoutException("main thread busy");
        }
        if (error.get() != null) {
            throw error.get();
        }
        return value.get();
    }

    /** Short language code of the app ("pt", "en", ...). */
    public String lang() {
        String saved = LocaleHelper.getSavedLanguage(context);
        if (saved == null) {
            return "en";
        }
        if (saved.startsWith("pt")) {
            return "pt";
        }
        int us = saved.indexOf('_');
        return us > 0 ? saved.substring(0, us) : saved;
    }

    public boolean isPortuguese() {
        return "pt".equals(lang());
    }
}
