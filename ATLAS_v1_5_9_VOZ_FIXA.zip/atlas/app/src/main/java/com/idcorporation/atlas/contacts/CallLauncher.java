package com.idcorporation.atlas.contacts;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import com.idcorporation.atlas.utils.ContactsPermissionHelper;

/**
 * Starts a phone call through the two standard, publicly supported
 * Android call intents. Nothing here bypasses Android's permission
 * model: with CALL_PHONE granted the call is placed directly
 * (ACTION_CALL); without it, the dialer opens with the number already
 * filled in and the user taps the call button themselves (ACTION_DIAL,
 * which needs no dangerous permission at all).
 */
public class CallLauncher {

    /**
     * CHAMIZO INTELLIGENCE: WhatsApp has no official, documented Intent to
     * start a voice call, so this uses the same mechanism the stock
     * Contacts/Dialer app uses for the "WhatsApp call" quick-action chip -
     * a Data row WhatsApp itself writes for a contact once the contact is
     * synced with WhatsApp. This only works when that row exists (WhatsApp
     * installed, contact synced); when it does not, ATLAS falls back to
     * simply opening the WhatsApp chat so the user can tap the call button
     * there with one tap - still no phone credit spent - and only calls
     * the real phone number as a last resort if WhatsApp is not installed
     * at all.
     */
    private static final String MIME_WHATSAPP_VOICE_CALL = "vnd.android.cursor.item/vnd.com.whatsapp.voip.call";

    public enum CallMethod {
        WHATSAPP_CALL,
        WHATSAPP_CHAT_OPENED,
        REAL_CALL,
        DIALER_OPENED
    }

    /** Tries WhatsApp first (no credit spent); only reaches for the real phone call as a last resort. */
    public static CallMethod callPreferringWhatsapp(Context context, ContactMatch contact) {
        if (WhatsAppMessenger.isInstalled(context)) {
            if (tryWhatsappVoiceCall(context, contact)) {
                return CallMethod.WHATSAPP_CALL;
            }
            if (WhatsAppMessenger.openChatWithMessage(context, contact, "")) {
                return CallMethod.WHATSAPP_CHAT_OPENED;
            }
        }
        boolean calledDirectly = call(context, contact);
        return calledDirectly ? CallMethod.REAL_CALL : CallMethod.DIALER_OPENED;
    }

    private static boolean tryWhatsappVoiceCall(Context context, ContactMatch contact) {
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = null;
        try {
            cursor = resolver.query(
                ContactsContract.Data.CONTENT_URI,
                new String[]{ContactsContract.Data._ID},
                ContactsContract.Data.CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?",
                new String[]{String.valueOf(contact.contactId), MIME_WHATSAPP_VOICE_CALL},
                null);
            if (cursor == null || !cursor.moveToFirst()) {
                return false;
            }
            long dataId = cursor.getLong(0);
            Uri dataUri = ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, dataId);
            Intent callIntent = new Intent(Intent.ACTION_VIEW);
            callIntent.setDataAndType(dataUri, MIME_WHATSAPP_VOICE_CALL);
            callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(callIntent);
            return true;
        } catch (SecurityException e) {
            return false;
        } catch (RuntimeException e) {
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /** @return true if the call was placed directly (ACTION_CALL); false if only the dialer was opened. */
    public static boolean call(Context context, ContactMatch contact) {
        Uri telUri = Uri.parse("tel:" + Uri.encode(contact.phoneNumber));
        if (ContactsPermissionHelper.hasCallPhone(context)) {
            try {
                Intent callIntent = new Intent(Intent.ACTION_CALL, telUri);
                callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(callIntent);
                return true;
            } catch (SecurityException e) {
                // Permission was granted a moment ago but revoked before this ran through -
                // fall through to the dialer instead of crashing the voice pipeline.
            } catch (RuntimeException e) {
                // No app can handle ACTION_CALL on this device/OEM skin.
            }
        }
        openDialerWithNumber(context, telUri);
        return false;
    }

    private static void openDialerWithNumber(Context context, Uri telUri) {
        Intent dialIntent = new Intent(Intent.ACTION_DIAL, telUri);
        dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(dialIntent);
        } catch (RuntimeException e) {
            // No dialer app available at all - nothing further ATLAS can do here.
        }
    }
}
