package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

/**
 * Adjusts system screen brightness. Writing Settings.System.SCREEN_BRIGHTNESS
 * requires the WRITE_SETTINGS app-op, which Android will not grant through a
 * normal runtime permission dialog - the user has to flip it on in a system
 * screen. requestPermission() opens that screen; canAdjust() tells the caller
 * whether it is already on.
 */
public class BrightnessManager {

    private static final int STEP = 26; // roughly 10% of the 0-255 range
    private static final int MIN_BRIGHTNESS = 10;
    private static final int MAX_BRIGHTNESS = 255;

    private final Context context;

    public BrightnessManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public boolean canAdjust() {
        return Settings.System.canWrite(context);
    }

    /** Sends the user to the "Modify system settings" screen to grant the permission. */
    public void requestPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
        intent.setData(Uri.parse("package:" + context.getPackageName()));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
        } catch (Exception e) {
            // Some OEM skins hide this screen; nothing more we can do here.
        }
    }

    /** @return true if the brightness was actually changed. */
    public boolean increase() {
        return adjust(STEP);
    }

    public boolean decrease() {
        return adjust(-STEP);
    }

    private boolean adjust(int delta) {
        if (!canAdjust()) {
            return false;
        }
        try {
            // Turn off adaptive/automatic brightness first, otherwise the
            // system immediately overwrites the manual value we set below.
            Settings.System.putInt(context.getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);

            int current = Settings.System.getInt(context.getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS, 128);
            int updated = Math.max(MIN_BRIGHTNESS, Math.min(MAX_BRIGHTNESS, current + delta));
            Settings.System.putInt(context.getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS, updated);
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }
}
