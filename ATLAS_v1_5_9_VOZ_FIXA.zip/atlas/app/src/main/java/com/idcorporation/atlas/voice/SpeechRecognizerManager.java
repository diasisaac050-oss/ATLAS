package com.idcorporation.atlas.voice;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import com.idcorporation.atlas.utils.LocaleHelper;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Wraps Android's SpeechRecognizer and keeps it healthy.
 *
 * Fixes the "the bubble appears but ATLAS hears nothing" family of bugs:
 *  - one recognizer instance living forever goes stale (OEM recognizer
 *    services drop it, or a cancel() racing a startListening() leaves it
 *    deaf). After any cancel or hard error the NEXT turn now gets a brand
 *    new recognizer instead of reusing the broken one.
 *  - a start that never reaches onReadyForSpeech used to sit silent
 *    forever. A watchdog now rebuilds the recognizer and retries.
 *  - two start requests arriving together (every screen asks on resume)
 *    caused ERROR_RECOGNIZER_BUSY loops; duplicates are now ignored.
 *  - callbacks from an already destroyed recognizer are ignored.
 * Everything runs on the main thread, which is the only thread
 * SpeechRecognizer accepts.
 */
public class SpeechRecognizerManager {

    public interface RecognitionCallback {
        void onReadyForSpeech();
        void onResult(String recognizedText);
        void onError(String errorMessage, int errorCode);
        void onRmsChanged(float rmsDb);
        void onPartial(String partialText);
    }

    private static final long READY_TIMEOUT_MS = 3500L;
    private static final long DUPLICATE_START_MS = 1200L;
    private static final int MAX_STARTUP_RETRIES = 2;

    private final Context appContext;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private SpeechRecognizer speechRecognizer;
    private RecognitionCallback callback;
    private int recognizerGeneration = 0;
    private int watchdogToken = 0;
    private boolean active = false;
    private boolean ready = false;
    private boolean needsFreshRecognizer = true;
    private long lastStartMs = 0L;
    private int startupRetries = 0;

    public SpeechRecognizerManager(Context context) {
        this.appContext = context.getApplicationContext();
    }

    public void setCallback(RecognitionCallback recognitionCallback) {
        this.callback = recognitionCallback;
    }

    /** Errors that mean the recognizer itself is in a bad state (not just "nobody spoke"). */
    public static boolean isHardError(int errorCode) {
        return errorCode != SpeechRecognizer.ERROR_NO_MATCH
            && errorCode != SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            && errorCode != SpeechRecognizer.ERROR_NETWORK
            && errorCode != SpeechRecognizer.ERROR_NETWORK_TIMEOUT;
    }

    public void startListening() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    startListening();
                }
            });
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (active && (now - lastStartMs) < DUPLICATE_START_MS) {
            return;
        }
        if (active) {
            // A turn is still open: close it and start over on a clean recognizer.
            needsFreshRecognizer = true;
        }
        active = true;
        ready = false;
        lastStartMs = now;
        startupRetries = 0;
        beginRecognition();
    }

    public void stopListening() {
        if (speechRecognizer != null) {
            try {
                speechRecognizer.stopListening();
            } catch (RuntimeException e) {
                needsFreshRecognizer = true;
            }
        }
    }

    /** Cancels an in-progress listening session without delivering a result or an error callback. */
    public void cancelListening() {
        active = false;
        ready = false;
        watchdogToken = watchdogToken + 1;
        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
            } catch (RuntimeException e) {
                // Already dead; the next start builds a new one anyway.
            }
        }
        // cancel() followed at once by startListening() on the same instance
        // is the classic way to end up deaf, so never reuse it after a cancel.
        needsFreshRecognizer = true;
    }

    public void destroy() {
        active = false;
        watchdogToken = watchdogToken + 1;
        destroyRecognizer();
    }

    private void beginRecognition() {
        if (needsFreshRecognizer || speechRecognizer == null) {
            recreateRecognizer();
        }
        try {
            speechRecognizer.startListening(buildRecognizerIntent());
        } catch (RuntimeException first) {
            recreateRecognizer();
            try {
                speechRecognizer.startListening(buildRecognizerIntent());
            } catch (RuntimeException second) {
                failTurn(SpeechRecognizer.ERROR_CLIENT);
                return;
            }
        }
        armReadyWatchdog();
    }

    private void armReadyWatchdog() {
        watchdogToken = watchdogToken + 1;
        final int token = watchdogToken;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (token != watchdogToken || !active || ready) {
                    return;
                }
                if (startupRetries < MAX_STARTUP_RETRIES) {
                    startupRetries = startupRetries + 1;
                    needsFreshRecognizer = true;
                    beginRecognition();
                } else {
                    failTurn(SpeechRecognizer.ERROR_CLIENT);
                }
            }
        }, READY_TIMEOUT_MS);
    }

    private void failTurn(int errorCode) {
        active = false;
        ready = false;
        watchdogToken = watchdogToken + 1;
        needsFreshRecognizer = true;
        if (callback != null) {
            callback.onError(mapErrorCode(errorCode), errorCode);
        }
    }

    private Intent buildRecognizerIntent() {
        Locale currentLocale = LocaleHelper.getLocaleForLanguage(LocaleHelper.getSavedLanguage(appContext));
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        // EXTRA_LANGUAGE must be a language TAG string (e.g. "pt-BR"), not a Locale object.
        String languageTag = currentLocale.toLanguageTag();
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.getPackageName());
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L);
        return intent;
    }

    private void recreateRecognizer() {
        destroyRecognizer();
        recognizerGeneration = recognizerGeneration + 1;
        final int generation = recognizerGeneration;
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                if (generation != recognizerGeneration || !active) {
                    return;
                }
                ready = true;
                watchdogToken = watchdogToken + 1;
                if (callback != null) {
                    callback.onReadyForSpeech();
                }
            }

            @Override
            public void onRmsChanged(float rmsdB) {
                if (generation == recognizerGeneration && active && callback != null) {
                    callback.onRmsChanged(rmsdB);
                }
            }

            @Override
            public void onResults(Bundle results) {
                if (generation != recognizerGeneration || !active) {
                    return;
                }
                active = false;
                ready = false;
                watchdogToken = watchdogToken + 1;
                ArrayList<String> matches = (results == null) ? null
                    : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (callback == null) {
                    return;
                }
                if (matches != null && matches.size() > 0) {
                    callback.onResult(matches.get(0));
                } else {
                    callback.onError("No speech recognized.", SpeechRecognizer.ERROR_NO_MATCH);
                }
            }

            @Override
            public void onError(int errorCode) {
                if (generation != recognizerGeneration || !active) {
                    return;
                }
                if (isHardError(errorCode)) {
                    needsFreshRecognizer = true;
                }
                failTurnKeepFlag(errorCode);
            }

            @Override
            public void onBeginningOfSpeech() {
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
            }

            @Override
            public void onEndOfSpeech() {
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                if (generation != recognizerGeneration || !active
                        || partialResults == null || callback == null) {
                    return;
                }
                ArrayList<String> partial = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (partial != null && partial.size() > 0) {
                    callback.onPartial(partial.get(0));
                }
            }
        });
        needsFreshRecognizer = false;
    }

    /** Ends the turn and reports the error without touching needsFreshRecognizer (already decided). */
    private void failTurnKeepFlag(int errorCode) {
        boolean keep = needsFreshRecognizer;
        failTurn(errorCode);
        needsFreshRecognizer = keep;
    }

    private void destroyRecognizer() {
        if (speechRecognizer != null) {
            recognizerGeneration = recognizerGeneration + 1;
            try {
                speechRecognizer.setRecognitionListener(null);
                speechRecognizer.destroy();
            } catch (RuntimeException e) {
                // Nothing left to release.
            }
            speechRecognizer = null;
        }
    }

    private String mapErrorCode(int errorCode) {
        switch (errorCode) {
            case SpeechRecognizer.ERROR_NETWORK:
                return "Network error during speech recognition.";
            case SpeechRecognizer.ERROR_NO_MATCH:
                return "I did not catch that.";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                return "No speech detected.";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                return "Microphone permission is required.";
            default:
                return "Speech recognition error.";
        }
    }
}
