package com.idcorporation.atlas.theme;

import android.content.Context;
import android.graphics.Canvas;

import java.util.Random;

/**
 * GLACIAL: cold, still light. Slow pale glows drift like light under ice,
 * fine frost crystals sink and sway (some flare with a tiny cross of light),
 * and faint facet lines catch a shimmer that travels across the glass.
 */
public class GlacialShimmerBackgroundView extends FxBackgroundView {

    private static final int CRYSTALS = 40;
    private static final int FACETS = 7;

    private final float[] cx = new float[CRYSTALS];
    private final float[] cy = new float[CRYSTALS];
    private final float[] cz = new float[CRYSTALS];
    private final float[] cph = new float[CRYSTALS];
    // each facet = 3 segments (4 points)
    private final float[] fx = new float[FACETS * 4];
    private final float[] fy = new float[FACETS * 4];
    private final Random rng = new Random(31);

    public GlacialShimmerBackgroundView(Context context) {
        super(context);
    }

    @Override
    protected void onSized(int width, int height) {
        for (int i = 0; i < CRYSTALS; i++) {
            cz[i] = rnd(rng, 0.2f, 1f);
            cx[i] = rnd(rng, 0f, width);
            cy[i] = rnd(rng, 0f, height);
            cph[i] = rnd(rng, 0f, 6.283f);
        }
        for (int f = 0; f < FACETS; f++) {
            float x = rnd(rng, -0.1f, 1.1f) * width;
            float y = rnd(rng, 0f, 1f) * height;
            float ang = rnd(rng, -0.9f, -0.2f);           // rising diagonals
            if (rng.nextBoolean()) {
                ang = 3.1416f - ang;
            }
            for (int k = 0; k < 4; k++) {
                fx[f * 4 + k] = x;
                fy[f * 4 + k] = y;
                float len = rnd(rng, 0.10f, 0.26f) * Math.max(width, height);
                ang += rnd(rng, -0.35f, 0.35f);
                x += (float) Math.cos(ang) * len;
                y += (float) Math.sin(ang) * len;
            }
        }
        linePaint.setStrokeWidth(Math.max(1f, 1.1f * dens));
    }

    @Override
    protected void drawFx(Canvas c, float dt) {
        float t = time;

        // pale light drifting under the ice
        glowRect(c, w * (0.30f + 0.18f * (float) Math.sin(t * 0.11f)), h * (0.30f + 0.10f * (float) Math.sin(t * 0.17f)),
                w * 0.85f, h * 0.30f, 0.15f);
        glowRect(c, w * (0.72f + 0.16f * (float) Math.sin(t * 0.09f + 2f)), h * (0.68f + 0.12f * (float) Math.sin(t * 0.13f + 1f)),
                w * 0.80f, h * 0.28f, 0.13f);
        glowRect(c, w * 0.5f, h * (0.5f + 0.05f * (float) Math.sin(t * 0.2f)), w * 0.60f, h * 0.20f, 0.07f);

        // facet lines with a shimmer travelling across
        float span = w + h;
        for (int f = 0; f < FACETS; f++) {
            for (int k = 0; k < 3; k++) {
                int a = f * 4 + k;
                float mx = (fx[a] + fx[a + 1]) * 0.5f;
                float my = (fy[a] + fy[a + 1]) * 0.5f;
                float wave = (float) Math.sin(t * 0.55f - (mx + my) / span * 6.283f * 1.2f);
                wave = wave > 0f ? wave * wave * wave : 0f;
                linePaint.setAlpha((int) (255f * (0.05f + 0.20f * wave)));
                c.drawLine(fx[a], fy[a], fx[a + 1], fy[a + 1], linePaint);
            }
        }

        // frost crystals sinking slowly
        for (int i = 0; i < CRYSTALS; i++) {
            float z = cz[i];
            cy[i] += (5f + 15f * z) * dens * dt;
            if (cy[i] > h + 12f * dens) {
                cy[i] = -12f * dens;
                cx[i] = rnd(rng, 0f, w);
            }
            float x = cx[i] + (float) Math.sin(t * 0.35f + cph[i]) * (6f + 10f * z) * dens;
            float y = cy[i];
            float edge = Math.min(1f, Math.min(y / (h * 0.10f), (h - y) / (h * 0.10f)));
            if (edge <= 0f) {
                continue;
            }
            float tw = 0.55f + 0.45f * (float) Math.sin(t * 1.2f + cph[i] * 3f);
            float a = edge * tw * (0.25f + 0.75f * z);
            float r = (1.6f + 3.2f * z) * dens;
            glow(c, x, y, r * 3.2f, a * 0.40f);
            hotGlow(c, x, y, r, a * 0.95f);
            // every few crystals catches the light and flares
            if (i % 4 == 0) {
                float fl = (float) Math.sin(t * 0.9f + cph[i] * 5f);
                fl = fl > 0.82f ? (fl - 0.82f) / 0.18f : 0f;
                if (fl > 0f) {
                    float arm = 15f * dens * z * fl;
                    glowRect(c, x, y, arm, 1.2f * dens, 0.9f * fl * edge);
                    glowRect(c, x, y, 1.2f * dens, arm, 0.9f * fl * edge);
                }
            }
        }
    }
}
