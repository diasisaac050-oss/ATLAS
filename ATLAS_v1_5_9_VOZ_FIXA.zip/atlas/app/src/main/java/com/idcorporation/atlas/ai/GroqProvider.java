package com.idcorporation.atlas.ai;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

/**
 * Envia requisicoes de chat direto para a API da Groq, usando a
 * chave definida em ApiKeyConfig. Nao depende de nenhum backend
 * externo.
 *
 * ATLAS VISAO update: sendMessageWithImage() switches to a vision-capable
 * model (Llama 4 Scout) and sends the current turn as an OpenAI-style
 * multimodal content array (text + image_url with a base64 data: URL),
 * exactly like every other request otherwise - same endpoint, same
 * headers, same error handling.
 */
public class GroqProvider implements AIProvider {

    static final String GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";
    static final String GROQ_MODEL = "openai/gpt-oss-120b";
    private static final String GROQ_VISION_MODEL = "qwen/qwen3.8-27b";
    // meta-llama/llama-4-scout-17b-16e-instruct was Groq's vision model when
    // this feature was first built, but Groq deprecated it (shut down
    // 07/17/26) for free/developer-tier accounts, which is why it started
    // returning 404. The next attempt used "qwen/qwen3.6-27b", which also
    // 404'd ("model_not_found") - that ID never existed on Groq. Per
    // Groq's current vision docs (console.groq.com/docs/vision),
    // qwen/qwen3.8-27b is the one real supported vision model right now,
    // and it caps requests at 3 images instead of the 5 llama-4-scout
    // allowed. Same request shape otherwise (image_url + base64 data:
    // URL), so nothing else here needed to change.

    private static final int MAX_RESPONSE_CHARS = 200000;

    private static final int CONNECT_TIMEOUT_MS = 15000;
    private static final int READ_TIMEOUT_MS = 25000;
    // An image upload is a heavier request on slower connections than a
    // plain text turn, so it gets more room before timing out.
    private static final int IMAGE_CONNECT_TIMEOUT_MS = 20000;
    private static final int IMAGE_READ_TIMEOUT_MS = 40000;

    private final Handler mainHandler;

    public GroqProvider() {
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    @Override
    public boolean isConfigured() {
        return ApiKeyConfig.isConfigured();
    }

    @Override
    public String getProviderName() {
        return "Groq";
    }

    @Override
    public void sendMessage(final String systemPrompt, final ArrayList<String> conversationHistory,
                             final String userMessage, final AIProvider.AICallback callback) {

        if (!isConfigured()) {
            postError(callback, "Chave da Groq nao configurada em ApiKeyConfig.", 401);
            return;
        }
        String body = buildRequestBody(systemPrompt, conversationHistory, userMessage);
        postChatCompletion(body, callback, CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
    }

    @Override
    public void sendMessageWithImage(final String systemPrompt, final ArrayList<String> conversationHistory,
                                      final String userMessage, final String imageBase64,
                                      final String imageMimeType, final AIProvider.AICallback callback) {

        if (!isConfigured()) {
            postError(callback, "Chave da Groq nao configurada em ApiKeyConfig.", 401);
            return;
        }
        if (imageBase64 == null || imageBase64.length() == 0) {
            postError(callback, "Empty image.", -105);
            return;
        }
        String body = buildRequestBodyWithImage(systemPrompt, conversationHistory, userMessage,
            imageBase64, imageMimeType);
        postChatCompletion(body, callback, IMAGE_CONNECT_TIMEOUT_MS, IMAGE_READ_TIMEOUT_MS);
    }

    /** Shared HTTP plumbing for both the text-only and the image request bodies. */
    private void postChatCompletion(final String body, final AIProvider.AICallback callback,
                                     final int connectTimeoutMs, final int readTimeoutMs) {
        Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(GROQ_ENDPOINT);
                    if (!"https".equals(url.getProtocol())) {
                        postError(callback, "Insecure endpoint blocked.", -4);
                        return;
                    }
                    connection = (HttpURLConnection) url.openConnection();
                    // Never follow a redirect: the Authorization header must only
                    // ever go to api.groq.com and nowhere else.
                    connection.setInstanceFollowRedirects(false);
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(connectTimeoutMs);
                    connection.setReadTimeout(readTimeoutMs);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setRequestProperty("Authorization", "Bearer " + ApiKeyConfig.GROQ_API_KEY);
                    connection.setRequestProperty("X-Atlas-Client", "ATLAS by ID | CORPORATION");

                    OutputStream out = connection.getOutputStream();
                    out.write(body.getBytes(Charset.forName("UTF-8")));
                    out.flush();
                    out.close();

                    int status = connection.getResponseCode();

                    if (status == 200) {
                        String raw = readStream(connection.getInputStream());
                        String text = extractText(raw);
                        postSuccess(callback, text);
                    } else {
                        // TEMPORARIO (diagnostico ATLAS VISAO round 2): lendo
                        // e anexando o corpo real da resposta de erro da
                        // Groq. Normalmente isso e descartado (pode conter
                        // detalhes da requisicao que nao interessam ao
                        // usuario) - so esta aqui pra descobrirmos por que a
                        // analise de imagem esta dando 404 mesmo depois de
                        // trocar o modelo.
                        String rawError = readStream(connection.getErrorStream());
                        String debugSnippet = rawError.length() > 400
                            ? rawError.substring(0, 400) : rawError;
                        String reason;
                        if (status == 401 || status == 403) {
                            reason = "Chave da Groq invalida ou sem permissao.";
                        } else if (status == 429) {
                            reason = "Limite de requisicoes da Groq atingido, tente novamente em instantes.";
                        } else if (status == 413) {
                            reason = "A imagem e grande demais para a Groq.";
                        } else {
                            reason = "Groq retornou um erro.";
                        }
                        postError(callback, reason + " | corpo: " + debugSnippet, status);
                    }

                } catch (java.net.SocketTimeoutException timeoutEx) {
                    postError(callback, "A requisicao demorou demais e expirou.", -1);
                } catch (java.io.IOException ioEx) {
                    postError(callback, "Nao foi possivel conectar com a Groq.", -2);
                } catch (Exception generalEx) {
                    postError(callback, "Erro inesperado.", -3);
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        });
        worker.start();
    }

    private String buildRequestBody(String systemPrompt, ArrayList<String> history, String userMessage) {
        try {
            JSONObject root = new JSONObject();
            root.put("model", GROQ_MODEL);
            root.put("temperature", 0.7);
            root.put("max_tokens", 1024);

            JSONArray messages = new JSONArray();
            messages.put(systemMessageJson(systemPrompt));
            appendHistory(messages, history);

            JSONObject userMsg = new JSONObject();
            userMsg.put("role", "user");
            userMsg.put("content", userMessage);
            messages.put(userMsg);

            root.put("messages", messages);
            return root.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    /**
     * Same shape as buildRequestBody, but the model and the final user
     * turn change: the model becomes the vision-capable one, and that
     * turn's content becomes an array of parts (text + image_url) instead
     * of a plain string, exactly like the OpenAI/Groq multimodal format.
     * History before it stays plain text - only the newest turn carries
     * the image.
     */
    private String buildRequestBodyWithImage(String systemPrompt, ArrayList<String> history,
                                              String userMessage, String imageBase64, String imageMimeType) {
        try {
            JSONObject root = new JSONObject();
            root.put("model", GROQ_VISION_MODEL);
            root.put("temperature", 0.7);
            // Groq's free/on-demand tier caps qwen/qwen3.8-27b at 1000
            // output tokens per minute (OTPM). Asking for 1024 in a single
            // request already exceeds that ceiling and gets rejected with
            // a 429 before anything is generated, so this has to stay
            // under 1000 - 900 leaves a safety margin.
            root.put("max_tokens", 900);

            JSONArray messages = new JSONArray();
            messages.put(systemMessageJson(systemPrompt));
            appendHistory(messages, history);

            String mime = (imageMimeType == null || imageMimeType.length() == 0)
                ? "image/jpeg" : imageMimeType;
            String dataUrl = "data:" + mime + ";base64," + imageBase64;
            String safeText = (userMessage == null || userMessage.length() == 0)
                ? "What do you see in this image?" : userMessage;

            JSONArray contentParts = new JSONArray();
            JSONObject textPart = new JSONObject();
            textPart.put("type", "text");
            textPart.put("text", safeText);
            contentParts.put(textPart);

            JSONObject imagePart = new JSONObject();
            imagePart.put("type", "image_url");
            JSONObject imageUrlObject = new JSONObject();
            imageUrlObject.put("url", dataUrl);
            imagePart.put("image_url", imageUrlObject);
            contentParts.put(imagePart);

            JSONObject userMsg = new JSONObject();
            userMsg.put("role", "user");
            userMsg.put("content", contentParts);
            messages.put(userMsg);

            root.put("messages", messages);
            return root.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    private JSONObject systemMessageJson(String systemPrompt) throws org.json.JSONException {
        JSONObject systemMessage = new JSONObject();
        systemMessage.put("role", "system");
        systemMessage.put("content", systemPrompt);
        return systemMessage;
    }

    private void appendHistory(JSONArray messages, ArrayList<String> history) throws org.json.JSONException {
        for (int i = 0; i < history.size(); i++) {
            String role = (i % 2 == 0) ? "user" : "assistant";
            JSONObject historyMessage = new JSONObject();
            historyMessage.put("role", role);
            historyMessage.put("content", history.get(i));
            messages.put(historyMessage);
        }
    }

    private String extractText(String rawJson) {
        try {
            JSONObject root = new JSONObject(rawJson);
            JSONArray choices = root.optJSONArray("choices");
            if (choices != null && choices.length() > 0) {
                JSONObject firstChoice = choices.getJSONObject(0);
                JSONObject message = firstChoice.optJSONObject("message");
                if (message != null) {
                    return message.optString("content", "");
                }
            }
            return "";
        } catch (Exception e) {
            return "";
        }
    }

    private String readStream(InputStream inputStream) throws java.io.IOException {
        if (inputStream == null) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, Charset.forName("UTF-8")));
        String line = reader.readLine();
        while (line != null) {
            builder.append(line);
            if (builder.length() > MAX_RESPONSE_CHARS) {
                // Absurdly large answer: stop reading instead of filling memory.
                break;
            }
            line = reader.readLine();
        }
        reader.close();
        return builder.toString();
    }

    private void postSuccess(final AIProvider.AICallback callback, final String text) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                callback.onSuccess(text);
            }
        });
    }

    private void postError(final AIProvider.AICallback callback, final String message, final int code) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                callback.onError(message, code);
            }
        });
    }
}
