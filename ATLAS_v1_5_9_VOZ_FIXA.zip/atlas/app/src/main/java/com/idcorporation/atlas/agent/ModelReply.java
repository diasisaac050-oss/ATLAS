package com.idcorporation.atlas.agent;

import org.json.JSONObject;

import java.util.ArrayList;

/** One assistant turn: either final text, or a list of tool calls (or both). */
public final class ModelReply {

    public static final class ToolCall {
        public final String id;
        public final String name;
        public final String argumentsJson;

        public ToolCall(String id, String name, String argumentsJson) {
            this.id = id;
            this.name = name;
            this.argumentsJson = argumentsJson == null ? "{}" : argumentsJson;
        }
    }

    public final String content;
    /** The raw assistant message, appended to the conversation verbatim before tool results. */
    public final JSONObject assistantMessage;
    public final ArrayList<ToolCall> toolCalls = new ArrayList<ToolCall>();

    public ModelReply(String content, JSONObject assistantMessage) {
        this.content = content == null ? "" : content;
        this.assistantMessage = assistantMessage;
    }
}
