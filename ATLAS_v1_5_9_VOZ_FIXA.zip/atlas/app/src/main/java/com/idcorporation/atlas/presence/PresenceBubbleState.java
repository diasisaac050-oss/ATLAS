package com.idcorporation.atlas.presence;

/**
 * Plain data holder describing one animation frame of the Presence
 * bubble. PresenceFrameClock and the view fill it in every frame and the
 * painter only reads it, so drawing code never has to know about timers
 * or voice states.
 */
public class PresenceBubbleState {

    /** 0 = fully retracted (a tiny pill under the notch), 1 = fully open. May overshoot above 1. */
    public float open = 0f;
    /** Seconds since the bubble appeared - drives every idle breathing/shimmer. */
    public float phase = 0f;
    /** Smoothed microphone loudness, 0..1. */
    public float level = 0f;
    /** 0..1 how much the "thinking" mode is showing. */
    public float thinkAmt = 0f;
    /** 0..1 how much the "speaking" pulse is showing. */
    public float speakAmt = 0f;
    /** 0..1 how much the error tint is showing. */
    public float errAmt = 0f;
    /** 0..1 how much the sound-wave line has ignited (grows after the bubble opens). */
    public float ignite = 0f;
    /** 0..1 progress of the expanding ripple ring, or -1 when there is no ripple. */
    public float ripple = -1f;
    /** Time for the inner light; runs faster while thinking or talking. */
    public float orbit = 0f;
    /** Degrees: where the travelling light on the glass edge is right now. */
    public float rimAngle = 0f;
    /** 0..1 progress of the glass gleam sweeping across, or -1 when idle. */
    public float sheen = -1f;
    /** The app's current HudStateManager.STATE_* (the sphere layouts follow it directly). */
    public int hudState = 0;
    /** 0..1 how far the sphere has shrunk toward its docked size while it is being parked at the screen edge. */
    public float dock = 0f;
    /** True once the window itself was shrunk to the small docked square (sphere drawn centred in it). */
    public boolean docked = false;
    /** Where the sphere was drawn last frame, in the view's own pixels (written by the sphere drawer). */
    public float sphereCx = 0f;
    public float sphereCy = 0f;
}
