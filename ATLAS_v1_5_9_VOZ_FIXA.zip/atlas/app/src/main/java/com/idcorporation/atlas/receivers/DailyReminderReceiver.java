package com.idcorporation.atlas.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.idcorporation.atlas.utils.AtlasNotificationPicker;
import com.idcorporation.atlas.utils.LocaleHelper;
import com.idcorporation.atlas.utils.NotificationHelper;
import com.idcorporation.atlas.utils.UserProfileManager;

public class DailyReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Context localizedContext = LocaleHelper.wrapContext(context);
        UserProfileManager profileManager = new UserProfileManager(context);
        String name = profileManager.getName();
        if (name == null || name.length() == 0) {
            name = "";
        }

        NotificationHelper.createNotificationChannel(context);

        AtlasNotificationPicker.Pick pick = AtlasNotificationPicker.pickRandom(localizedContext, name);

        if (pick.style == AtlasNotificationPicker.STYLE_CALLING) {
            NotificationHelper.showCallStyleNotification(
                context, NotificationHelper.NOTIFICATION_ID_DAILY_GREETING, pick.title, pick.message);
        } else {
            NotificationHelper.showNotification(
                context, NotificationHelper.NOTIFICATION_ID_DAILY_GREETING, pick.title, pick.message);
        }
    }
}
