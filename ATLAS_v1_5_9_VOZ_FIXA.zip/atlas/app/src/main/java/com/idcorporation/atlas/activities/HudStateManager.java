package com.idcorporation.atlas.activities;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.sphere.AtlasSphereView;
import com.idcorporation.atlas.utils.ViewAnimUtils;

/**
 * Owns the visual "core" of the ATLAS HUD: pulsing glow, rotating ring,
 * center ball and the state label. Kept separate from MainActivity so the
 * activity itself stays focused on command/voice/AI orchestration.
 *
 * Each HUD state gets its own combination of: glow alpha rhythm, ring
 * rotation speed and a subtle scale "breathing" on the center ball, so the
 * core visibly feels different when idle, listening, thinking, speaking,
 * acting or erroring - without ever using flashes, particles or motion
 * fast enough to be distracting. All colors flow from setAccentColor(),
 * so the same animations automatically work with every theme.
 *
 * ATLAS ESFERA: the Home screen now drives a 3D particle sphere
 * (AtlasSphereView) instead of the glow/ring/ball images. Build this with the
 * (sphere, label) constructor and every state, colour and label goes to the
 * sphere; the glow/ring/ball constructors still work for any other caller.
 */
public class HudStateManager {

    public static final int STATE_IDLE = 0;
    public static final int STATE_LISTENING = 1;
    public static final int STATE_PROCESSING = 2;
    public static final int STATE_THINKING = 3;
    public static final int STATE_SPEAKING = 4;
    public static final int STATE_EXECUTING = 5;
    public static final int STATE_ERROR = 6;
    public static final int STATE_OFFLINE = 7;

    private static final long RING_SPEED_CALM_MS = 9000;
    private static final long RING_SPEED_BUSY_MS = 3600;

    private final ImageView glowView;
    private final ImageView ringView;
    private final ImageView solidView;
    private final TextView stateLabel;
    private final AtlasSphereView sphere;

    private ObjectAnimator ringRotationAnimator;
    private long currentRingSpeedMs = RING_SPEED_CALM_MS;

    private ObjectAnimator glowPulseAnimator;
    private ObjectAnimator solidPulseAnimator;

    private int currentState = STATE_IDLE;
    private int accentColor = 0xFF00E5FF;

    public HudStateManager(ImageView glowView, ImageView ringView, TextView stateLabel) {
        this(glowView, ringView, null, stateLabel);
    }

    /**
     * solidView is the small filled "ball" at the very center of the orb
     * (atlas_core_solid) - pass it so the ball itself also picks up the
     * current theme's accent color, not just the ring/glow around it.
     * Pass null where no such view exists (kept for callers that only
     * have glow+ring).
     */
    public HudStateManager(ImageView glowView, ImageView ringView, ImageView solidView, TextView stateLabel) {
        this.glowView = glowView;
        this.ringView = ringView;
        this.solidView = solidView;
        this.stateLabel = stateLabel;
        this.sphere = null;
        startRingRotation(RING_SPEED_CALM_MS);
        setState(STATE_IDLE);
    }

    /** ATLAS ESFERA: the sphere is the core; the label below it reports the state. */
    public HudStateManager(AtlasSphereView sphere, TextView stateLabel) {
        this.glowView = null;
        this.ringView = null;
        this.solidView = null;
        this.stateLabel = stateLabel;
        this.sphere = sphere;
        setState(STATE_IDLE);
    }

    /** Applies the current theme's accent color to the core ring/glow/ball and idle label. */
    public void setAccentColor(int color) {
        this.accentColor = color;
        if (sphere != null) {
            sphere.setAccentColor(color);
            stateLabel.setTextColor(sphereLabelColor(currentState));
            return;
        }
        applyRingColor(color);
        applyGlowGradient(color);
        applySolidGradient(color);
        if (currentState == STATE_IDLE) {
            stateLabel.setTextColor(color);
        }
    }

    /**
     * atlas_ring is a plain stroke-only oval (no gradient), so a tint
     * would normally be safe here - but we rebuild it fresh too, for the
     * same "mutated drawable doesn't always repaint" reason as the ball
     * and the glow, so the whole core recolors reliably together.
     */
    private void applyRingColor(int color) {
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setStroke(dpToPx(ringView, 1.5f), color);
        ringView.setImageDrawable(ring);
    }

    /**
     * The center "ball" (atlas_core_solid) is a radial gradient (bright
     * accent center fading to the dark surface color at the edge) - that
     * sheen is what makes it look like a glowing orb instead of a flat
     * dot. A plain setTint() replaces every RGB pixel with one solid
     * color and destroys that gradient.
     *
     * Mutating and re-coloring the XML-inflated instance in place
     * (drawable.mutate() + setColors()) is not reliable on every device -
     * some OEM skins don't repaint a mutated GradientDrawable's shader
     * until something else forces a full relayout, so the change can
     * silently not show up. To sidestep that entirely, we build a brand
     * new GradientDrawable from scratch every time the theme changes and
     * swap it in with setImageDrawable(), instead of touching whatever
     * drawable happens to already be attached to the view.
     */
    private void applySolidGradient(int color) {
        if (solidView == null) {
            return;
        }
        solidView.setImageDrawable(buildCoreSolidDrawable(solidView, color));
    }

    /**
     * Builds the same glowing-orb radial gradient used for the central
     * core ball, for any other view that should also match the current
     * theme's accent color (e.g. the big microphone button). Public and
     * static so callers outside the HUD core (MainActivity, other
     * screens) can reuse it without needing a HudStateManager instance.
     */
    public static GradientDrawable buildCoreSolidDrawable(View anchor, int color) {
        int surfaceColor = ContextCompat.getColor(anchor.getContext(), R.color.atlas_surface);
        GradientDrawable gradient = new GradientDrawable();
        gradient.setShape(GradientDrawable.OVAL);
        gradient.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        gradient.setGradientRadius(dpToPx(anchor, 60f));
        gradient.setColors(new int[]{color, surfaceColor});
        gradient.setStroke(dpToPx(anchor, 2f), color);
        return gradient;
    }

    /**
     * Same idea for the soft halo behind the ring (atlas_core_glow): it's
     * a 3-stop radial gradient where the alpha itself fades out towards
     * the edge (center ~33% opaque, edge fully transparent). We rebuild
     * it from scratch too, for the same reason as applySolidGradient.
     */
    private void applyGlowGradient(int color) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        int startColor = Color.argb(0x88, r, g, b);
        int centerColor = Color.argb(0x33, r, g, b);
        int endColor = Color.argb(0x00, r, g, b);
        GradientDrawable gradient = new GradientDrawable();
        gradient.setShape(GradientDrawable.OVAL);
        gradient.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        gradient.setGradientRadius(dpToPx(glowView, 120f));
        gradient.setColors(new int[]{startColor, centerColor, endColor});
        glowView.setImageDrawable(gradient);
    }

    private static int dpToPx(View anchor, float dp) {
        float density = anchor.getContext().getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private void startRingRotation(long durationMs) {
        currentRingSpeedMs = durationMs;
        ringRotationAnimator = ObjectAnimator.ofFloat(ringView, "rotation", 0f, 360f);
        ringRotationAnimator.setDuration(durationMs);
        ringRotationAnimator.setRepeatCount(ValueAnimator.INFINITE);
        ringRotationAnimator.start();
    }

    /**
     * Changes how fast the ring spins without a visible jump: it restarts
     * the rotation from the ring's current on-screen angle instead of
     * snapping back to 0, so "busy" states feel like the core sped up
     * rather than resetting.
     */
    private void setRingSpeed(long durationMs) {
        if (durationMs == currentRingSpeedMs) {
            return;
        }
        float currentAngle = ringView.getRotation() % 360f;
        if (ringRotationAnimator != null) {
            ringRotationAnimator.cancel();
        }
        ringView.setRotation(currentAngle);
        ringRotationAnimator = ObjectAnimator.ofFloat(ringView, "rotation", currentAngle, currentAngle + 360f);
        ringRotationAnimator.setDuration(durationMs);
        ringRotationAnimator.setRepeatCount(ValueAnimator.INFINITE);
        ringRotationAnimator.start();
        currentRingSpeedMs = durationMs;
    }

    public void setState(int newState) {
        if (sphere != null) {
            applySphereState(newState);
            return;
        }
        boolean isRealChange = (newState != currentState);
        this.currentState = newState;
        stopAmbientAnimators();

        if (isRealChange) {
            ViewAnimUtils.animateGlacialPulse(ringView);
        }

        switch (newState) {
            case STATE_LISTENING:
                stateLabel.setText(R.string.state_listening);
                stateLabel.setTextColor(0xFF00E5FF);
                setRingSpeed(RING_SPEED_CALM_MS);
                startGlowPulse(0.5f, 1.0f, 620);
                startSolidPulse(1f, 1.07f, 460);
                break;
            case STATE_PROCESSING:
                stateLabel.setText(R.string.state_processing);
                stateLabel.setTextColor(0xFF2979FF);
                setRingSpeed(RING_SPEED_BUSY_MS);
                startGlowPulse(0.45f, 0.95f, 420);
                break;
            case STATE_THINKING:
                stateLabel.setText(R.string.state_thinking);
                stateLabel.setTextColor(0xFF2979FF);
                setRingSpeed(RING_SPEED_BUSY_MS);
                startGlowPulse(0.45f, 0.9f, 620);
                break;
            case STATE_SPEAKING:
                stateLabel.setText(R.string.state_speaking);
                stateLabel.setTextColor(0xFF00E5FF);
                setRingSpeed(RING_SPEED_CALM_MS);
                startGlowPulse(0.55f, 1.0f, 320);
                startSolidPulse(1f, 1.1f, 300);
                break;
            case STATE_EXECUTING:
                stateLabel.setText(R.string.state_executing);
                stateLabel.setTextColor(0xFF00E676);
                setRingSpeed(RING_SPEED_BUSY_MS);
                startGlowPulse(0.5f, 1.0f, 280);
                break;
            case STATE_ERROR:
                stateLabel.setText(R.string.state_error);
                stateLabel.setTextColor(0xFFFF5252);
                setRingSpeed(RING_SPEED_CALM_MS);
                playErrorBlink();
                break;
            case STATE_OFFLINE:
                stateLabel.setText(R.string.state_offline);
                stateLabel.setTextColor(0xFF8FA6B8);
                setRingSpeed(RING_SPEED_CALM_MS);
                glowView.setAlpha(0.3f);
                break;
            case STATE_IDLE:
            default:
                stateLabel.setText(R.string.state_idle);
                stateLabel.setTextColor(accentColor);
                setRingSpeed(RING_SPEED_CALM_MS);
                startGlowPulse(0.55f, 0.78f, 3200);
                startSolidPulse(1f, 1.035f, 2600);
                break;
        }
    }

    /**
     * Sphere mode: hands the state to the sphere (which eases its whole
     * behaviour towards it) and updates the line of text under it. The label
     * wears the theme colour; only error and offline override it.
     */
    private void applySphereState(int newState) {
        boolean isRealChange = (newState != currentState);
        this.currentState = newState;
        sphere.setState(newState);
        int textRes;
        switch (newState) {
            case STATE_LISTENING:
                textRes = R.string.state_listening;
                break;
            case STATE_PROCESSING:
                textRes = R.string.state_processing;
                break;
            case STATE_THINKING:
                textRes = R.string.state_thinking;
                break;
            case STATE_SPEAKING:
                textRes = R.string.state_speaking;
                break;
            case STATE_EXECUTING:
                textRes = R.string.state_executing;
                break;
            case STATE_ERROR:
                textRes = R.string.state_error;
                break;
            case STATE_OFFLINE:
                textRes = R.string.state_offline;
                break;
            case STATE_IDLE:
            default:
                textRes = R.string.state_ready;
                break;
        }
        stateLabel.setText(textRes);
        stateLabel.setTextColor(sphereLabelColor(newState));
        if (isRealChange) {
            stateLabel.setAlpha(0.35f);
            stateLabel.animate().alpha(1f).setDuration(240).start();
        }
    }

    private int sphereLabelColor(int state) {
        if (state == STATE_ERROR) {
            return 0xFFFF5252;
        }
        if (state == STATE_OFFLINE) {
            return 0xFF8FA6B8;
        }
        return accentColor;
    }

    /** Simple looping alpha pulse on the glow, shared by every "alive" state. */
    private void startGlowPulse(float from, float to, long durationMs) {
        glowPulseAnimator = ObjectAnimator.ofFloat(glowView, "alpha", from, to);
        glowPulseAnimator.setDuration(durationMs);
        glowPulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        glowPulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
        glowPulseAnimator.start();
    }

    /** Subtle looping scale "breathing" on the center ball. No-op if there is no solid ball view. */
    private void startSolidPulse(float from, float to, long durationMs) {
        if (solidView == null) {
            return;
        }
        PropertyValuesHolder scaleX = PropertyValuesHolder.ofFloat(View.SCALE_X, from, to);
        PropertyValuesHolder scaleY = PropertyValuesHolder.ofFloat(View.SCALE_Y, from, to);
        solidPulseAnimator = ObjectAnimator.ofPropertyValuesHolder(solidView, scaleX, scaleY);
        solidPulseAnimator.setDuration(durationMs);
        solidPulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        solidPulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
        solidPulseAnimator.start();
    }

    /**
     * Error state gets its own short, finite cue instead of a looping
     * pulse: two calm alpha dips (never a hard 0-to-1 flash) and then the
     * glow settles at a steady, dim red so the screen doesn't keep
     * drawing attention to itself while the error message is read.
     */
    private void playErrorBlink() {
        glowPulseAnimator = ObjectAnimator.ofFloat(glowView, "alpha", 0.85f, 0.4f);
        glowPulseAnimator.setDuration(240);
        glowPulseAnimator.setRepeatCount(3);
        glowPulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
        glowPulseAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                glowView.setAlpha(0.5f);
            }
        });
        glowPulseAnimator.start();
    }

    private void stopAmbientAnimators() {
        if (glowPulseAnimator != null) {
            glowPulseAnimator.cancel();
        }
        if (solidView != null) {
            if (solidPulseAnimator != null) {
                solidPulseAnimator.cancel();
            }
            solidView.setScaleX(1f);
            solidView.setScaleY(1f);
        }
    }

    public int getCurrentState() {
        return currentState;
    }

    public void release() {
        if (ringRotationAnimator != null) {
            ringRotationAnimator.cancel();
        }
        stopAmbientAnimators();
    }
}
