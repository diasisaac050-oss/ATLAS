package com.idcorporation.atlas.utils;

import java.util.regex.Pattern;

/**
 * Cleans raw text coming back from the AI provider before it is shown
 * in the transcript, logged to history or sent to text-to-speech.
 *
 * The model occasionally answers using markdown (bold, italics, code
 * fences, headers) even when instructed not to, and it can slip into
 * using "*" for multiplication or "**" for exponents when solving
 * math problems. None of that reads well out loud or in a plain chat
 * bubble, so everything markdown-related is stripped here as a safety
 * net on top of the system prompt instructions.
 */
public final class TextSanitizer {

    private static final Pattern CODE_FENCE = Pattern.compile("```[a-zA-Z]*\\n?");
    private static final Pattern INLINE_CODE = Pattern.compile("`([^`]*)`");
    private static final Pattern BOLD_DOUBLE_STAR = Pattern.compile("\\*\\*(.*?)\\*\\*", Pattern.DOTALL);
    private static final Pattern BOLD_DOUBLE_UNDERSCORE = Pattern.compile("__(.*?)__", Pattern.DOTALL);
    private static final Pattern ITALIC_STAR = Pattern.compile("\\*(.*?)\\*", Pattern.DOTALL);
    private static final Pattern HEADER_LINE = Pattern.compile("(?m)^\\s{0,3}#{1,6}\\s*");
    private static final Pattern BULLET_LINE = Pattern.compile("(?m)^\\s*[-*]\\s+");
    private static final Pattern LEFTOVER_ASTERISKS = Pattern.compile("\\*+");
    private static final Pattern LEFTOVER_UNDERSCORE_RUNS = Pattern.compile("_{2,}");
    private static final Pattern EXTRA_SPACES = Pattern.compile("[ \\t]{2,}");
    private static final Pattern EXTRA_BLANK_LINES = Pattern.compile("\\n{3,}");

    private TextSanitizer() {
    }

    public static String stripMarkdown(String rawText) {
        if (rawText == null) {
            return "";
        }

        String text = rawText;

        text = CODE_FENCE.matcher(text).replaceAll("");
        text = INLINE_CODE.matcher(text).replaceAll("$1");
        text = HEADER_LINE.matcher(text).replaceAll("");
        text = BULLET_LINE.matcher(text).replaceAll("");
        text = BOLD_DOUBLE_STAR.matcher(text).replaceAll("$1");
        text = BOLD_DOUBLE_UNDERSCORE.matcher(text).replaceAll("$1");
        text = ITALIC_STAR.matcher(text).replaceAll("$1");

        // Anything left over (unmatched or malformed markers, like a run
        // of stray asterisks the model produced while doing math) is
        // simply dropped rather than read out loud.
        text = LEFTOVER_ASTERISKS.matcher(text).replaceAll("");
        text = LEFTOVER_UNDERSCORE_RUNS.matcher(text).replaceAll("");

        text = EXTRA_SPACES.matcher(text).replaceAll(" ");
        text = EXTRA_BLANK_LINES.matcher(text).replaceAll("\n\n");

        return text.trim();
    }
}
