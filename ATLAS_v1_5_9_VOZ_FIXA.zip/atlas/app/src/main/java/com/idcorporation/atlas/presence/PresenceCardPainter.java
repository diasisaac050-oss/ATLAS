package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.Path;

/**
 * CHAMIZO INTELLIGENCE: a fourth Presence look, requested to feel clearly
 * different from Glass/Orb/Nucleus while staying in the exact same
 * transparent liquid-glass visual language. Where Glass is a small lens
 * pinned under the notch, Card is a taller glass panel that blooms open
 * in the middle of the screen - same smoked-glass fill, drifting light,
 * sweeping gleam, sound-wave bars and hairline comet-edge as Glass (all
 * borrowed as-is from PresenceGlassBody / PresenceAurora / PresenceGlassRim
 * / PresenceBubbleEffects), just in a taller shape, centered instead of
 * edge-anchored, and opening with a uniform bloom instead of a pill-first
 * spring.
 */
public class PresenceCardPainter implements PresenceDrawer {

    private final float d;
    private final Path body = new Path();
    private final PresenceGlassBody glass = new PresenceGlassBody();
    private final PresenceAurora aurora = new PresenceAurora();
    private final PresenceGlassRim rim;
    private final PresenceBubbleEffects effects;

    public PresenceCardPainter(float density) {
        this.d = density;
        this.rim = new PresenceGlassRim(density);
        this.effects = new PresenceBubbleEffects(density);
    }

    @Override
    public void draw(Canvas canvas, int w, int h, PresenceBubbleState st) {
        float p = st.open;
        if (p <= 0.01f) {
            return;
        }
        float alpha = Math.min(1f, p * 2.2f);
        float pulse = Math.max(st.level, st.speakAmt * (0.45f + 0.35f * (float) Math.sin(st.phase * 9.0)));
        float breathe = 1f + 0.012f * (float) Math.sin(st.phase * 1.3);

        // Bloom: both dimensions grow together from the center, instead of
        // width leading height the way the top-anchored Glass lens does.
        float bloom = (float) Math.pow((double) p, 0.82);

        float fullA = 78f * d;
        float fullB = 118f * d;
        float a = fullA * (0.4f + 0.6f * bloom) * breathe * (1f + 0.03f * pulse);
        float b = fullB * (0.4f + 0.6f * bloom) * breathe * (1f + 0.03f * pulse);
        float cx = w / 2f + (float) Math.sin(st.phase * 30.0) * 1.5f * d * st.errAmt;
        float cy = h / 2f;

        buildBody(body, cx, cy, a, b, st.phase, pulse);

        glass.drawShadow(canvas, cx, cy, a, b, alpha);
        glass.drawHalo(canvas, cx, cy, a, b, st, pulse, alpha);
        glass.drawFill(canvas, body, cy, b, alpha);

        canvas.save();
        canvas.clipPath(body);
        aurora.draw(canvas, cx, cy, a, b, st, pulse, alpha);
        glass.drawInnerLight(canvas, cx, cy, a, b, pulse, alpha);
        aurora.drawSheen(canvas, cx, cy, a, b, st, alpha);
        effects.drawStreak(canvas, cx, cy, a, b, st, pulse, alpha);
        canvas.restore();

        rim.draw(canvas, body, cx, cy, a, b, st, pulse, alpha);
        effects.drawRipple(canvas, body, cx, cy, st);
    }

    /** Same squircle construction as the Glass lens, just given a taller a/b ratio by the caller. */
    private void buildBody(Path path, float cx, float cy, float a, float b, float phase, float lvl) {
        path.reset();
        int steps = 96;
        double ex = 2.0 / 2.7;
        for (int i = 0; i <= steps; i++) {
            double t = (2.0 * Math.PI * i) / steps;
            double c = Math.cos(t);
            double s = Math.sin(t);
            double x = Math.signum(c) * Math.pow(Math.abs(c), ex);
            double y = Math.signum(s) * Math.pow(Math.abs(s), ex);
            double wob = 1.0 + 0.005 * Math.sin(3 * t + phase * 1.4)
                + 0.004 * Math.sin(5 * t - phase * 1.0)
                + (double) lvl * 0.026 * Math.sin(2 * t + phase * 3.0);
            float px = (float) (cx + a * wob * x);
            float py = (float) (cy + b * wob * y);
            if (i == 0) {
                path.moveTo(px, py);
            } else {
                path.lineTo(px, py);
            }
        }
        path.close();
    }
}
