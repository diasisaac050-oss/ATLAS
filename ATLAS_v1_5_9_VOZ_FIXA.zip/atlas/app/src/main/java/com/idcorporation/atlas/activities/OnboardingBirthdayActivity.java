package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.calendar.CalendarDateUtils;
import com.idcorporation.atlas.calendar.CalendarEventManager;
import com.idcorporation.atlas.utils.BirthdayScheduler;
import com.idcorporation.atlas.utils.UserProfileManager;

/**
 * Final onboarding step. ATLAS does not use a login/password screen -
 * instead it asks for the user's birthday here, once, so it can mark
 * it on the calendar every year, warn a week ahead and send a
 * congratulations notification on the day itself.
 */
public class OnboardingBirthdayActivity extends OnboardingStepActivity {

    private static final int STEP_INDEX = 4;
    private static final int TOTAL_STEPS = 5;

    private EditText dayInput;
    private EditText monthInput;
    private EditText yearInput;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_birthday);

        View backButton = findViewById(R.id.button_step_back);
        ViewGroup dotsContainer = (ViewGroup) findViewById(R.id.container_step_dots);
        View badge = findViewById(R.id.badge_birthday);
        View title = findViewById(R.id.text_birthday_question);
        dayInput = (EditText) findViewById(R.id.input_birth_day);
        monthInput = (EditText) findViewById(R.id.input_birth_month);
        yearInput = (EditText) findViewById(R.id.input_birth_year);
        errorText = (TextView) findViewById(R.id.text_birthday_error);
        final View continueButton = findViewById(R.id.button_birthday_continue);

        renderProgressDots(dotsContainer, STEP_INDEX, TOTAL_STEPS);
        animateEntrance(badge, title, null, dayInput, continueButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bounceButton(continueButton);
                attemptFinish();
            }
        });
    }

    private void attemptFinish() {
        int day = parseOrMinusOne(dayInput.getText().toString());
        int month = parseOrMinusOne(monthInput.getText().toString());
        int year = parseOrMinusOne(yearInput.getText().toString());

        if (!CalendarDateUtils.isValidDate(year, month, day)) {
            showFieldError(errorText, getString(R.string.error_birthday_invalid));
            return;
        }

        Bundle data = getIntent().getExtras();
        String fullName = data != null ? data.getString(OnboardingKeys.FULL_NAME, "") : "";
        String callName = data != null ? data.getString(OnboardingKeys.CALL_NAME, "") : "";
        String email = data != null ? data.getString(OnboardingKeys.EMAIL, "") : "";
        int age = data != null ? data.getInt(OnboardingKeys.AGE, 0) : 0;
        String gender = data != null
            ? data.getString(OnboardingKeys.GENDER, UserProfileManager.GENDER_UNSPECIFIED)
            : UserProfileManager.GENDER_UNSPECIFIED;

        UserProfileManager profileManager = new UserProfileManager(this);
        profileManager.saveProfileWithBirthday(fullName, callName, email, age, gender, year, month, day);

        String birthdayTitle = getString(R.string.default_birthday_title);
        CalendarEventManager eventManager = new CalendarEventManager(this);
        eventManager.setBirthday(year, month, day, birthdayTitle);
        BirthdayScheduler.scheduleDailyCheck(this);

        Intent intent = com.idcorporation.atlas.utils.ModeManager.homeIntent(this);
        startActivity(intent);
        finish();
    }

    private int parseOrMinusOne(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
