package com.idcorporation.atlas.commands;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import com.idcorporation.atlas.calendar.DateTimeCommandParser;

import java.util.ArrayList;
import java.util.List;

/**
 * Finds an installed app from what the user SAID ("whatsapp", "abrir o
 * youtube", "tik tok"). It reads the phone's real list of launchable apps
 * (needs the <queries> block in the manifest on Android 11+, otherwise
 * the phone hides every other app from ATLAS) and matches the spoken name
 * against the app labels, ignoring accents, case and spaces.
 */
public class InstalledAppFinder {

    public static final int STRONG = 80;
    public static final int WEAK = 50;

    private static final long CACHE_MS = 30000L;

    private static final ArrayList<LaunchableApp> CACHE = new ArrayList<LaunchableApp>();
    private static long cacheTime = 0L;

    /** One app that has a launcher icon. */
    public static class LaunchableApp {
        public String label;
        public String normalizedLabel;
        public String labelNoSpace;
        public String packageName;
        public String activityName;
    }

    /** Lowercase, no accents, only letters and digits, single spaces. */
    public static String normalize(String raw) {
        if (raw == null) {
            return "";
        }
        String s = DateTimeCommandParser.stripAccents(raw.toLowerCase());
        StringBuilder builder = new StringBuilder();
        boolean lastWasSpace = true;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
                builder.append(c);
                lastWasSpace = false;
            } else if (!lastWasSpace) {
                builder.append(' ');
                lastWasSpace = true;
            }
        }
        return builder.toString().trim();
    }

    /** Loads the app list on a background thread so the first voice command is not slow. */
    public static void warmUp(final Context context) {
        final Context appContext = context.getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    loadApps(appContext);
                } catch (Throwable ignored) {
                    // Warm-up is only an optimization; find() loads the list again if needed.
                }
            }
        }).start();
    }

    /** @return the best app whose score is at least minScore, or null. */
    public static LaunchableApp find(Context context, String normalizedSpoken, int minScore) {
        if (normalizedSpoken.length() == 0) {
            return null;
        }
        ArrayList<LaunchableApp> apps = loadApps(context.getApplicationContext());
        String spokenNoSpace = normalizedSpoken.replace(" ", "");
        String ownPackage = context.getPackageName();
        LaunchableApp best = null;
        int bestScore = 0;
        for (int i = 0; i < apps.size(); i++) {
            LaunchableApp app = apps.get(i);
            if (ownPackage.equals(app.packageName)) {
                continue;
            }
            int score = score(normalizedSpoken, spokenNoSpace, app);
            boolean better = score > bestScore;
            if (!better && score == bestScore && best != null
                    && app.normalizedLabel.length() < best.normalizedLabel.length()) {
                better = true;
            }
            if (score >= minScore && better) {
                best = app;
                bestScore = score;
            }
        }
        return best;
    }

    /** Starts the app's launcher screen. @return false if Android refused. */
    public static boolean launch(Context context, LaunchableApp app) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setComponent(new ComponentName(app.packageName, app.activityName));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            context.startActivity(intent);
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static int score(String spoken, String spokenNoSpace, LaunchableApp app) {
        String label = app.normalizedLabel;
        if (label.length() == 0) {
            return 0;
        }
        if (label.equals(spoken)) {
            return 100;
        }
        if (app.labelNoSpace.equals(spokenNoSpace)) {
            return 98;
        }
        if (label.startsWith(spoken + " ")) {
            return 85;
        }
        if (spokenNoSpace.length() >= 3 && app.labelNoSpace.startsWith(spokenNoSpace)) {
            return 80;
        }
        if (label.length() >= 3 && spoken.startsWith(label + " ")) {
            return 78;
        }
        if (spokenNoSpace.length() >= 4 && hasPackageSegment(app.packageName, spokenNoSpace)) {
            return 72;
        }
        if ((" " + label + " ").contains(" " + spoken + " ")) {
            return 65;
        }
        if (allWordsInside(spoken, label)) {
            return 60;
        }
        if (spokenNoSpace.length() >= 4 && app.labelNoSpace.contains(spokenNoSpace)) {
            return 55;
        }
        return 0;
    }

    private static boolean hasPackageSegment(String packageName, String word) {
        String[] parts = packageName.toLowerCase().split("\\.");
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].equals(word)) {
                return true;
            }
        }
        return false;
    }

    private static boolean allWordsInside(String spoken, String label) {
        String[] words = spoken.split(" ");
        String padded = " " + label + " ";
        for (int i = 0; i < words.length; i++) {
            if (words[i].length() < 2 || !padded.contains(" " + words[i] + " ")) {
                return false;
            }
        }
        return words.length > 0;
    }

    private static synchronized ArrayList<LaunchableApp> loadApps(Context appContext) {
        long now = System.currentTimeMillis();
        if (CACHE.size() > 0 && (now - cacheTime) < CACHE_MS) {
            return new ArrayList<LaunchableApp>(CACHE);
        }
        ArrayList<LaunchableApp> fresh = new ArrayList<LaunchableApp>();
        try {
            PackageManager pm = appContext.getPackageManager();
            Intent query = new Intent(Intent.ACTION_MAIN, null);
            query.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> infos = pm.queryIntentActivities(query, 0);
            for (int i = 0; i < infos.size(); i++) {
                ResolveInfo info = infos.get(i);
                if (info.activityInfo == null) {
                    continue;
                }
                LaunchableApp app = new LaunchableApp();
                app.label = String.valueOf(info.loadLabel(pm));
                app.normalizedLabel = normalize(app.label);
                app.labelNoSpace = app.normalizedLabel.replace(" ", "");
                app.packageName = info.activityInfo.packageName;
                app.activityName = info.activityInfo.name;
                fresh.add(app);
            }
        } catch (RuntimeException e) {
            // Package manager unavailable: fall back to the old cache (maybe empty).
            return new ArrayList<LaunchableApp>(CACHE);
        }
        CACHE.clear();
        CACHE.addAll(fresh);
        cacheTime = now;
        return fresh;
    }
}
