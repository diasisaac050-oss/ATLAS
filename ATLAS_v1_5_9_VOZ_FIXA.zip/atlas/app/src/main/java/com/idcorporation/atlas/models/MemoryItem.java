package com.idcorporation.atlas.models;

public class MemoryItem {

    private long id;
    private String key;
    private String value;
    private String category;
    private long createdAt;

    public MemoryItem(long id, String key, String value, String category, long createdAt) {
        this.id = id;
        this.key = key;
        this.value = value;
        this.category = category;
        this.createdAt = createdAt;
    }

    public long getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public String getCategory() {
        return category;
    }

    public long getCreatedAt() {
        return createdAt;
    }
}
