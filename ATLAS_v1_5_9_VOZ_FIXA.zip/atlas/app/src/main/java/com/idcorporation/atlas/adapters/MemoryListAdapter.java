package com.idcorporation.atlas.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.models.MemoryItem;

import java.util.ArrayList;

/**
 * ATLAS FASE 3/4 item 4: groups what ATLAS actually has stored into simple,
 * readable sections (Identity / Preferences / General) instead of one flat
 * list - reusing the same section-header layout and style ThemeActivity
 * already uses for its own category headers. Kept separate from
 * GenericListAdapter, which History and Compromissos also use for their own
 * flat lists - this one is specific to the Memory screen's grouped layout,
 * so nothing else changes behavior.
 *
 * A section with no memories in it is simply not shown - this never
 * fabricates a header for an empty category.
 */
public class MemoryListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;

    public interface OnRowDeleteListener {
        void onDelete(long memoryId);
    }

    public interface OnRowClickListener {
        void onRowClick(long memoryId);
    }

    private static class Row {
        final String headerTitle;
        final MemoryItem item;

        Row(String headerTitle) {
            this.headerTitle = headerTitle;
            this.item = null;
        }

        Row(MemoryItem item) {
            this.headerTitle = null;
            this.item = item;
        }

        boolean isHeader() {
            return headerTitle != null;
        }
    }

    private final ArrayList<Row> rows = new ArrayList<Row>();
    private final OnRowDeleteListener deleteListener;
    private final OnRowClickListener clickListener;

    public MemoryListAdapter(String identityHeader, ArrayList<MemoryItem> identityItems,
                              String preferencesHeader, ArrayList<MemoryItem> preferencesItems,
                              String generalHeader, ArrayList<MemoryItem> generalItems,
                              OnRowDeleteListener deleteListener, OnRowClickListener clickListener) {
        this.deleteListener = deleteListener;
        this.clickListener = clickListener;
        addSection(identityHeader, identityItems);
        addSection(preferencesHeader, preferencesItems);
        addSection(generalHeader, generalItems);
    }

    private void addSection(String header, ArrayList<MemoryItem> items) {
        if (items == null || items.isEmpty()) {
            return;
        }
        rows.add(new Row(header));
        for (int i = 0; i < items.size(); i++) {
            rows.add(new Row(items.get(i)));
        }
    }

    @Override
    public int getItemViewType(int position) {
        return rows.get(position).isHeader() ? TYPE_HEADER : TYPE_ITEM;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_HEADER) {
            View view = inflater.inflate(R.layout.item_theme_category_header, parent, false);
            return new HeaderViewHolder(view);
        }
        View view = inflater.inflate(R.layout.item_list_row, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Row row = rows.get(position);
        if (holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).title.setText(row.headerTitle);
            return;
        }
        final MemoryItem item = row.item;
        ItemViewHolder itemHolder = (ItemViewHolder) holder;
        itemHolder.primaryText.setText(item.getKey());
        itemHolder.secondaryText.setText(item.getValue());
        itemHolder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (deleteListener != null) {
                    deleteListener.onDelete(item.getId());
                }
            }
        });
        itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (clickListener != null) {
                    clickListener.onRowClick(item.getId());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    private static class HeaderViewHolder extends RecyclerView.ViewHolder {
        final TextView title;

        HeaderViewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView;
        }
    }

    private static class ItemViewHolder extends RecyclerView.ViewHolder {
        final TextView primaryText;
        final TextView secondaryText;
        final ImageButton deleteButton;

        ItemViewHolder(View itemView) {
            super(itemView);
            primaryText = (TextView) itemView.findViewById(R.id.text_line_primary);
            secondaryText = (TextView) itemView.findViewById(R.id.text_line_secondary);
            deleteButton = (ImageButton) itemView.findViewById(R.id.button_delete_row);
        }
    }
}
