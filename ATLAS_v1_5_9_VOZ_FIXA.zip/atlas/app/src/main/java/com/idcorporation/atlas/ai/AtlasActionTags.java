package com.idcorporation.atlas.ai;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ATLAS FASE 3/4: lets the AI attach machine-readable directives to the end
 * of its natural-language reply without ever showing them to the user or
 * having them read aloud by TTS. Two directives exist today (see
 * PromptManager for the exact instructions given to the model):
 *
 *   \u00a7MEM\u00a7chave::valor\u00a7
 *       A fact worth remembering about the user. Handled by AIManager,
 *       which upserts it through MemoryManager - so it works the same way
 *       whether the user is in Chat mode or Voice mode.
 *
 *   \u00a7SUGERIR\u00a7lembrete::titulo::quando\u00a7
 *       The AI just asked, in its visible reply, whether to create a
 *       reminder. This carries what is needed to actually create it if the
 *       user taps "yes" - see ChatSession, which turns it into the same
 *       Yes/No confirmation bubble already used for other commands.
 *
 * Parsing is deliberately forgiving: a missing or malformed tag simply
 * means "nothing to extract" rather than an error, since a parsing miss
 * must never surface as a broken reply to the user.
 */
public final class AtlasActionTags {

    public static class MemoryFact {
        public final String key;
        public final String value;

        public MemoryFact(String key, String value) {
            this.key = key;
            this.value = value;
        }
    }

    public static class SuggestionFact {
        public final String type;
        public final String title;
        public final String when;

        public SuggestionFact(String type, String title, String when) {
            this.type = type;
            this.title = title;
            this.when = when;
        }
    }

    public static class MemoryExtractResult {
        public String cleanText;
        public ArrayList<MemoryFact> memories = new ArrayList<MemoryFact>();
    }

    public static class SuggestionExtractResult {
        public String cleanText;
        public SuggestionFact suggestion;
    }

    private static final int MAX_KEY_LENGTH = 60;
    private static final int MAX_VALUE_LENGTH = 300;

    private static final Pattern MEM_TAG = Pattern.compile("\\s*\u00a7MEM\u00a7(.*?)\u00a7", Pattern.DOTALL);
    private static final Pattern SUGGEST_TAG = Pattern.compile("\\s*\u00a7SUGERIR\u00a7(.*?)\u00a7", Pattern.DOTALL);

    private AtlasActionTags() {
    }

    /** Strips every \u00a7MEM\u00a7...\u00a7 directive out of the text and returns the facts they carried. */
    public static MemoryExtractResult extractMemoryTags(String rawText) {
        MemoryExtractResult result = new MemoryExtractResult();
        if (rawText == null) {
            result.cleanText = "";
            return result;
        }
        Matcher m = MEM_TAG.matcher(rawText);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String inner = m.group(1);
            int sep = inner.indexOf("::");
            if (sep > 0 && sep < inner.length() - 2) {
                String key = inner.substring(0, sep).trim();
                String value = inner.substring(sep + 2).trim();
                if (isUsableFact(key, value)) {
                    result.memories.add(new MemoryFact(key, value));
                }
            }
            m.appendReplacement(sb, "");
        }
        m.appendTail(sb);
        result.cleanText = sb.toString().trim();
        return result;
    }

    /** Strips the (at most one meaningful) \u00a7SUGERIR\u00a7...\u00a7 directive and returns what it offered. */
    public static SuggestionExtractResult extractSuggestionTag(String text) {
        SuggestionExtractResult result = new SuggestionExtractResult();
        if (text == null) {
            result.cleanText = "";
            return result;
        }
        Matcher m = SUGGEST_TAG.matcher(text);
        StringBuffer sb = new StringBuffer();
        boolean captured = false;
        while (m.find()) {
            if (!captured) {
                String[] parts = m.group(1).split("::", 3);
                if (parts.length == 3) {
                    String type = parts[0].trim();
                    String title = parts[1].trim();
                    String when = parts[2].trim();
                    if (title.length() > 0 && title.length() <= MAX_VALUE_LENGTH
                            && when.length() > 0 && when.length() <= MAX_VALUE_LENGTH) {
                        result.suggestion = new SuggestionFact(type, title, when);
                        captured = true;
                    }
                }
            }
            m.appendReplacement(sb, "");
        }
        m.appendTail(sb);
        result.cleanText = sb.toString().trim();
        return result;
    }

    private static boolean isUsableFact(String key, String value) {
        return key.length() > 0 && key.length() <= MAX_KEY_LENGTH
            && value.length() > 0 && value.length() <= MAX_VALUE_LENGTH;
    }
}
