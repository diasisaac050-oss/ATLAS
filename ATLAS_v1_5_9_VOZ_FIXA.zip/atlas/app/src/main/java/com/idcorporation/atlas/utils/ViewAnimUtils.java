package com.idcorporation.atlas.utils;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/**
 * ATLAS GLACIAL "Glacial UI" animation pack.
 *
 * A small, consistent set of motion primitives used across the app so
 * interactions feel deliberately designed and noticeably alive, instead
 * of the flat, generic feel of a stock app. Everything here is cheap and
 * self-contained (no new dependencies), which matters on the Code Assist
 * build target.
 */
public class ViewAnimUtils {

    private static final float PRESS_SCALE = 0.92f;
    private static final long PRESS_DURATION_MS = 90;
    private static final long RELEASE_DURATION_MS = 220;

    private static final OvershootInterpolator OVERSHOOT = new OvershootInterpolator(2.4f);
    private static final DecelerateInterpolator DECELERATE = new DecelerateInterpolator();

    /**
     * Adds press-scale feedback without interfering with the view's own
     * OnClickListener - attach this first, then setOnClickListener as usual.
     * Glacial pack: the release now springs back past 1.0 before settling,
     * which reads as far more tactile than a plain linear scale-back.
     */
    public static void applyPressFeedback(final View view) {
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        animateScale(view, PRESS_SCALE, PRESS_DURATION_MS, DECELERATE);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        animateScale(view, 1f, RELEASE_DURATION_MS, OVERSHOOT);
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    private static void animateScale(View view, float targetScale, long duration,
                                      android.view.animation.Interpolator interpolator) {
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(view, "scaleX", targetScale);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(view, "scaleY", targetScale);
        scaleX.setDuration(duration);
        scaleY.setDuration(duration);
        scaleX.setInterpolator(interpolator);
        scaleY.setInterpolator(interpolator);
        scaleX.start();
        scaleY.start();
    }

    /**
     * Fade + rise entrance used for list rows and screen content. Glacial
     * pack: adds a slight scale-in with overshoot so content feels like it
     * settles into place rather than simply appearing.
     */
    public static void animateEntrance(View view, long delayMs) {
        view.setAlpha(0f);
        view.setTranslationY(28f);
        view.setScaleX(0.96f);
        view.setScaleY(0.96f);

        ObjectAnimator fade = ObjectAnimator.ofFloat(view, "alpha", 0f, 1f);
        ObjectAnimator rise = ObjectAnimator.ofFloat(view, "translationY", 28f, 0f);
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(view, "scaleX", 0.96f, 1f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(view, "scaleY", 0.96f, 1f);

        fade.setStartDelay(delayMs);
        rise.setStartDelay(delayMs);
        scaleX.setStartDelay(delayMs);
        scaleY.setStartDelay(delayMs);

        fade.setDuration(300);
        rise.setDuration(340);
        scaleX.setDuration(340);
        scaleY.setDuration(340);

        rise.setInterpolator(OVERSHOOT);
        scaleX.setInterpolator(OVERSHOOT);
        scaleY.setInterpolator(OVERSHOOT);

        fade.start();
        rise.start();
        scaleX.start();
        scaleY.start();
    }

    /**
     * New in the Glacial UI pack: a sharp, perceptible pulse used to mark a
     * moment (a HUD state change, a saved note, a confirmed reminder). The
     * view briefly punches outward past its normal size and eases back,
     * reading as a clear "beat" instead of a subtle, easy-to-miss change.
     */
    public static void animateGlacialPulse(final View view) {
        ObjectAnimator scaleUpX = ObjectAnimator.ofFloat(view, "scaleX", 1f, 1.18f);
        ObjectAnimator scaleUpY = ObjectAnimator.ofFloat(view, "scaleY", 1f, 1.18f);
        scaleUpX.setDuration(140);
        scaleUpY.setDuration(140);
        scaleUpX.setInterpolator(DECELERATE);
        scaleUpY.setInterpolator(DECELERATE);

        scaleUpX.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(view, "scaleX", 1.18f, 1f);
                ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(view, "scaleY", 1.18f, 1f);
                scaleDownX.setDuration(260);
                scaleDownY.setDuration(260);
                scaleDownX.setInterpolator(OVERSHOOT);
                scaleDownY.setInterpolator(OVERSHOOT);
                scaleDownX.start();
                scaleDownY.start();
            }
        });

        scaleUpX.start();
        scaleUpY.start();
    }

    /** Quick attention flash (alpha dip) for a view that just updated, e.g. a text bubble. */
    public static void animateUpdateFlash(View view) {
        ObjectAnimator flashOut = ObjectAnimator.ofFloat(view, "alpha", 1f, 0.45f);
        ObjectAnimator flashIn = ObjectAnimator.ofFloat(view, "alpha", 0.45f, 1f);
        flashOut.setDuration(90);
        flashIn.setDuration(180);
        flashIn.setStartDelay(90);
        flashOut.start();
        flashIn.start();
    }
}
