package com.idcorporation.atlas.models;

/**
 * Summary of one saved conversation, used to render a row in the History
 * screen without loading every message. The conversationTitle is the
 * internal identifier stored in the history table (see HistoryManager) -
 * it is not shown to the user directly; the UI derives a friendly label
 * from firstMessage/lastMessage instead.
 */
public class ConversationSummary {

    private final String conversationTitle;
    private final String firstMessage;
    private final String lastMessage;
    private final long lastTimestamp;
    private final int messageCount;

    public ConversationSummary(String conversationTitle, String firstMessage, String lastMessage,
                                long lastTimestamp, int messageCount) {
        this.conversationTitle = conversationTitle;
        this.firstMessage = firstMessage;
        this.lastMessage = lastMessage;
        this.lastTimestamp = lastTimestamp;
        this.messageCount = messageCount;
    }

    public String getConversationTitle() {
        return conversationTitle;
    }

    public String getFirstMessage() {
        return firstMessage;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public long getLastTimestamp() {
        return lastTimestamp;
    }

    public int getMessageCount() {
        return messageCount;
    }
}
