package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.security.SecurityManager;

/**
 * Second onboarding question: the name ATLAS should use to address the
 * user (may differ from their full legal name).
 */
public class OnboardingCallNameActivity extends OnboardingStepActivity {

    private static final int STEP_INDEX = 2;
    private static final int TOTAL_STEPS = 6;

    private EditText callNameInput;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_callname);

        View backButton = findViewById(R.id.button_step_back);
        ViewGroup dotsContainer = (ViewGroup) findViewById(R.id.container_step_dots);
        View badge = findViewById(R.id.badge_callname);
        View title = findViewById(R.id.text_callname_question);
        callNameInput = (EditText) findViewById(R.id.input_call_name);
        errorText = (TextView) findViewById(R.id.text_callname_error);
        final View continueButton = findViewById(R.id.button_callname_continue);

        renderProgressDots(dotsContainer, STEP_INDEX, TOTAL_STEPS);
        animateEntrance(badge, title, null, callNameInput, continueButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bounceButton(continueButton);
                attemptContinue();
            }
        });
    }

    private void attemptContinue() {
        String callName = callNameInput.getText().toString();

        if (!SecurityManager.isValidName(callName)) {
            showFieldError(errorText, getString(R.string.error_name_required));
            return;
        }

        Intent next = buildForwardIntent(OnboardingEmailActivity.class);
        next.putExtra(OnboardingKeys.CALL_NAME, callName.trim());
        goToNext(next);
    }
}
