package com.idcorporation.atlas.ai;

import java.util.ArrayList;

/**
 * Contract every AI backend must implement.
 * Lets ATLAS swap providers without changing any calling code.
 */
public interface AIProvider {

    interface AICallback {
        void onSuccess(String responseText);
        void onError(String errorMessage, int errorCode);
    }

    /**
     * Sends a prompt with the running conversation context.
     * Implementations must call back on the main thread.
     */
    void sendMessage(String systemPrompt, ArrayList<String> conversationHistory,
                      String userMessage, AICallback callback);

    /**
     * Same as sendMessage, but attaches one image to the new user turn for
     * a vision-capable model to look at. The image travels only on this
     * turn - conversationHistory stays plain text, same as sendMessage.
     *
     * @param imageBase64   the image already encoded as base64 (no data: prefix)
     * @param imageMimeType e.g. "image/jpeg"
     */
    void sendMessageWithImage(String systemPrompt, ArrayList<String> conversationHistory,
                               String userMessage, String imageBase64, String imageMimeType,
                               AICallback callback);

    /** Human readable provider name, e.g. "Groq". */
    String getProviderName();

    /** Whether this provider currently has the configuration it needs (API key, etc). */
    boolean isConfigured();
}
