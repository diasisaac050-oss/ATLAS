package com.idcorporation.atlas.utils;

import android.content.Context;
import android.media.AudioManager;

public class VolumeManager {

    private final AudioManager audioManager;

    public VolumeManager(Context context) {
        this.audioManager = (AudioManager) context.getApplicationContext()
            .getSystemService(Context.AUDIO_SERVICE);
    }

    public void increaseVolume() {
        if (audioManager != null) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE,
                AudioManager.FLAG_SHOW_UI);
        }
    }

    public void decreaseVolume() {
        if (audioManager != null) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI);
        }
    }

    public void mute() {
        if (audioManager != null) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE,
                AudioManager.FLAG_SHOW_UI);
        }
    }
}
