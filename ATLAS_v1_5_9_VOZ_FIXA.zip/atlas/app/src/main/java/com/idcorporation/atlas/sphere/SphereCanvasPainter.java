package com.idcorporation.atlas.sphere;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;

/**
 * Draws SphereEngine's output on an Android Canvas with additive blending, so
 * the glow adds up over whatever is behind it. Shared by the Home sphere
 * (AtlasSphereView) and the Presence layouts (PresenceSphereDrawer).
 */
public final class SphereCanvasPainter implements SpherePainter {
    /** Set by the owner right before engine.render(); never kept after. */
    public Canvas canvas;
    private final Paint pointPaint = new Paint();
    private final Paint linePaint = new Paint();
    private final Paint glowPaint = new Paint();
    private final RadialGradient[] glowShader = new RadialGradient[4];
    private final int[] glowRgb = new int[4];

    public SphereCanvasPainter() {
        PorterDuffXfermode add = new PorterDuffXfermode(PorterDuff.Mode.ADD);
        pointPaint.setAntiAlias(true);
        pointPaint.setStyle(Paint.Style.STROKE);
        pointPaint.setStrokeCap(Paint.Cap.ROUND);
        pointPaint.setXfermode(add);
        linePaint.setAntiAlias(true);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setXfermode(add);
        glowPaint.setAntiAlias(true);
        glowPaint.setStyle(Paint.Style.FILL);
        glowPaint.setXfermode(add);
        for (int i = 0; i < 4; i++) {
            glowRgb[i] = -1;
        }
    }

    @Override
    public void points(float[] xy, int count, float sizePx, int argb) {
        pointPaint.setColor(argb);
        pointPaint.setStrokeWidth(sizePx);
        canvas.drawPoints(xy, 0, count, pointPaint);
    }

    @Override
    public void lines(float[] xyxy, int count, float widthPx, int argb) {
        linePaint.setColor(argb);
        linePaint.setStrokeWidth(widthPx);
        canvas.drawLines(xyxy, 0, count, linePaint);
    }

    @Override
    public void glow(int slot, float cx, float cy, float radiusPx, int rgb, float alpha) {
        if (alpha <= 0.003f) {
            return;
        }
        int key = rgb & 0xFFFFFF;
        if (glowShader[slot] == null || glowRgb[slot] != key) {
            // unit-radius gradient: full colour in the middle, softly gone at the edge
            glowShader[slot] = new RadialGradient(0f, 0f, 1f,
                new int[]{ 0xFF000000 | key, 0x66000000 | key, 0x00000000 | key },
                new float[]{ 0f, 0.35f, 1f },
                Shader.TileMode.CLAMP);
            glowRgb[slot] = key;
        }
        glowPaint.setShader(glowShader[slot]);
        glowPaint.setAlpha(Math.round(Math.max(0f, Math.min(1f, alpha)) * 255f));
        canvas.save();
        canvas.translate(cx, cy);
        canvas.scale(radiusPx, radiusPx);
        canvas.drawCircle(0f, 0f, 1f, glowPaint);
        canvas.restore();
    }
}
