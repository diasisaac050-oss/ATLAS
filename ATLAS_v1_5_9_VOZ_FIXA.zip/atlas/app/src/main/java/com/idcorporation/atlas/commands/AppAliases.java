package com.idcorporation.atlas.commands;

import android.content.Intent;
import android.provider.AlarmClock;
import android.provider.MediaStore;

import java.util.HashMap;

/**
 * Two small lookup tables that help the voice command "open <app>" find
 * the right app even when the spoken word is not the app's label:
 *
 * 1) NICKNAMES: how people really say it ("zap" for WhatsApp, "insta"
 *    for Instagram, "loja" for Play Store).
 * 2) CATEGORIES: system apps whose label changes with the phone brand
 *    and language (Camera, Gallery, Calculator, Clock ...). For those the
 *    standard Android category/action is launched, which opens whatever
 *    app the phone uses for that job.
 *
 * All keys are already normalized: lowercase, no accents, letters and
 * digits only, single spaces.
 */
public class AppAliases {

    public static final int NONE = 0;
    public static final int CAMERA = 1;
    public static final int GALLERY = 2;
    public static final int CALCULATOR = 3;
    public static final int CONTACTS = 4;
    public static final int MESSAGES = 5;
    public static final int MAPS = 6;
    public static final int MUSIC = 7;
    public static final int EMAIL = 8;
    public static final int CLOCK = 9;
    public static final int PHONE = 10;

    private static final HashMap<String, String> NICKNAMES = new HashMap<String, String>();
    private static final HashMap<String, Integer> CATEGORIES = new HashMap<String, Integer>();

    static {
        NICKNAMES.put("zap", "whatsapp");
        NICKNAMES.put("zap zap", "whatsapp");
        NICKNAMES.put("whats", "whatsapp");
        NICKNAMES.put("whats app", "whatsapp");
        NICKNAMES.put("insta", "instagram");
        NICKNAMES.put("face", "facebook");
        NICKNAMES.put("iutube", "youtube");
        NICKNAMES.put("you tube", "youtube");
        NICKNAMES.put("tik tok", "tiktok");
        NICKNAMES.put("g mail", "gmail");
        NICKNAMES.put("loja", "play store");
        NICKNAMES.put("google play", "play store");
        NICKNAMES.put("loja de aplicativos", "play store");
        NICKNAMES.put("loja de apps", "play store");
        NICKNAMES.put("app store", "play store");
        NICKNAMES.put("i food", "ifood");
        NICKNAMES.put("cap cut", "capcut");
        NICKNAMES.put("google chrome", "chrome");

        put(CAMERA, new String[]{"camera", "camara", "cam", "fotografia", "kamera", "appareil photo",
            "fotocamera", "aparat"});
        put(GALLERY, new String[]{"galeria", "gallery", "galeria de fotos", "fotos", "photos", "galleria",
            "galerie", "galeria de imagens"});
        put(CALCULATOR, new String[]{"calculadora", "calculator", "calcolatrice", "calculatrice",
            "rechner", "kalkulator", "calculo"});
        put(CONTACTS, new String[]{"contatos", "contactos", "contacts", "contatti", "kontakte", "kontakty",
            "agenda de contatos", "lista de contatos"});
        put(MESSAGES, new String[]{"mensagens", "mensajes", "messages", "sms", "messaggi", "nachrichten",
            "wiadomosci", "mensagem"});
        put(MAPS, new String[]{"mapas", "mapa", "maps", "mappe", "cartes", "karten", "mapy"});
        put(MUSIC, new String[]{"musica", "musicas", "music", "musique", "musik", "muzyka"});
        put(EMAIL, new String[]{"email", "e mail", "correio", "correio eletronico", "emails", "posta",
            "courriel"});
        put(CLOCK, new String[]{"relogio", "reloj", "clock", "orologio", "horloge", "uhr", "zegar",
            "despertador", "alarmes"});
        put(PHONE, new String[]{"telefone", "telefono", "phone", "discador", "dialer", "telephone",
            "telefon"});
    }

    private static void put(int category, String[] words) {
        for (int i = 0; i < words.length; i++) {
            CATEGORIES.put(words[i], Integer.valueOf(category));
        }
    }

    /** Turns a nickname into the real app name, or returns the same text if it is not a nickname. */
    public static String resolveNickname(String normalizedSpoken) {
        String real = NICKNAMES.get(normalizedSpoken);
        if (real != null) {
            return real;
        }
        return normalizedSpoken;
    }

    /** @return one of the category constants above, or NONE. */
    public static int categoryFor(String normalizedSpoken) {
        Integer found = CATEGORIES.get(normalizedSpoken);
        if (found == null) {
            return NONE;
        }
        return found.intValue();
    }

    /** Standard Android intent that opens the phone's default app for the category, or null. */
    public static Intent buildIntent(int category) {
        if (category == CAMERA) {
            return new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
        }
        if (category == CLOCK) {
            return new Intent(AlarmClock.ACTION_SHOW_ALARMS);
        }
        if (category == PHONE) {
            return new Intent(Intent.ACTION_DIAL);
        }
        String selector = null;
        if (category == GALLERY) {
            selector = Intent.CATEGORY_APP_GALLERY;
        } else if (category == CALCULATOR) {
            selector = Intent.CATEGORY_APP_CALCULATOR;
        } else if (category == CONTACTS) {
            selector = Intent.CATEGORY_APP_CONTACTS;
        } else if (category == MESSAGES) {
            selector = Intent.CATEGORY_APP_MESSAGING;
        } else if (category == MAPS) {
            selector = Intent.CATEGORY_APP_MAPS;
        } else if (category == MUSIC) {
            selector = Intent.CATEGORY_APP_MUSIC;
        } else if (category == EMAIL) {
            selector = Intent.CATEGORY_APP_EMAIL;
        }
        if (selector == null) {
            return null;
        }
        return Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, selector);
    }
}
