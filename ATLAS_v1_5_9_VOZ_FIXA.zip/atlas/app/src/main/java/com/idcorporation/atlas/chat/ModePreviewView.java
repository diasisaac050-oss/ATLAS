package com.idcorporation.atlas.chat;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.idcorporation.atlas.theme.ThemeManager;

/**
 * Living preview used on the Modes screen. In VOICE style it draws a
 * sound wave that breathes; in CHAT style it plays a tiny looping
 * conversation: your bubble pops in, ATLAS shows bouncing dots, then
 * "writes" two lines of text. Both follow the current theme accent.
 */
public class ModePreviewView extends View {

    public static final int STYLE_VOICE = 0;
    public static final int STYLE_CHAT = 1;

    private static final int BAR_COUNT = 13;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private int style = STYLE_VOICE;
    private int accent = 0xFF00E5FF;
    private float phase = 0f;
    private float energy = 1f;
    private ValueAnimator animator;

    public ModePreviewView(Context context) {
        super(context);
        init(context);
    }

    public ModePreviewView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        if (!isInEditMode()) {
            accent = ThemeManager.getSelectedPalette(context).getAccentColor();
        }
    }

    public void setPreviewStyle(int newStyle) {
        this.style = newStyle;
        invalidate();
    }

    public void setAccent(int color) {
        this.accent = color;
        rebuildGlow();
        invalidate();
    }

    /** 1 = fully alive (selected card), lower = calmer (card not selected). */
    public void setEnergy(float value) {
        this.energy = value;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuildGlow();
    }

    private void rebuildGlow() {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) {
            return;
        }
        float radius = Math.max(w, h) * 0.5f;
        glowPaint.setShader(new RadialGradient(w / 2f, h / 2f, radius,
            new int[]{ChatStyle.withAlpha(accent, 0x44), ChatStyle.withAlpha(accent, 0x00)},
            new float[]{0f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (animator == null) {
            animator = ValueAnimator.ofFloat(0f, 1f);
            animator.setDuration(3600L);
            animator.setRepeatCount(ValueAnimator.INFINITE);
            animator.setInterpolator(new LinearInterpolator());
            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    phase = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                    invalidate();
                }
            });
            animator.start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) {
            return;
        }
        canvas.drawRect(0f, 0f, w, h, glowPaint);
        if (style == STYLE_CHAT) {
            drawChat(canvas, w, h);
        } else {
            drawVoice(canvas, w, h);
        }
    }

    // -----------------------------------------------------------------
    // Voice: a breathing sound wave
    // -----------------------------------------------------------------

    private void drawVoice(Canvas canvas, int w, int h) {
        float barWidth = h * 0.085f;
        float gap = barWidth * 1.9f;
        float total = BAR_COUNT * barWidth + (BAR_COUNT - 1) * gap;
        float startX = (w - total) / 2f;
        double angle = phase * Math.PI * 2.0;
        float maxHeight = h * 0.86f;

        for (int i = 0; i < BAR_COUNT; i++) {
            float centerBias = 1f - Math.abs(i - (BAR_COUNT - 1) / 2f) / ((BAR_COUNT - 1) / 2f);
            float envelope = 0.22f + 0.78f * centerBias;
            double wave = 0.5 + 0.5 * Math.sin(angle * 2.0 - i * 0.62)
                * Math.sin(angle * 3.0 + i * 0.35 + 1.0);
            float amount = 0.16f + (float) wave * 0.84f * energy;
            float barHeight = Math.max(barWidth, maxHeight * envelope * amount);
            float left = startX + i * (barWidth + gap);
            float cy = h / 2f;
            rect.set(left, cy - barHeight / 2f, left + barWidth, cy + barHeight / 2f);
            int alpha = 120 + (int) (135f * envelope);
            paint.setColor(ChatStyle.withAlpha(ChatStyle.lighten(accent, 0.35f * centerBias), alpha));
            canvas.drawRoundRect(rect, barWidth / 2f, barWidth / 2f, paint);
        }
    }

    // -----------------------------------------------------------------
    // Chat: a tiny looping conversation
    // -----------------------------------------------------------------

    private static float segment(float t, float from, float to) {
        if (t <= from) {
            return 0f;
        }
        if (t >= to) {
            return 1f;
        }
        return (t - from) / (to - from);
    }

    private static float ease(float x) {
        return x * x * (3f - 2f * x);
    }

    private void drawChat(Canvas canvas, int w, int h) {
        float t = phase;
        float fadeOut = 1f - ease(segment(t, 0.9f, 0.99f));
        float unit = h / 100f;

        // Your bubble (right), pops in first.
        float userIn = ease(segment(t, 0.04f, 0.16f));
        float userW = w * 0.46f;
        float userH = unit * 34f;
        float userRight = w - w * 0.14f;
        float userTop = unit * 10f;
        drawBubble(canvas, userRight - userW, userTop, userRight, userTop + userH, userIn * fadeOut,
            true, unit);
        if (userIn > 0.4f) {
            drawLine(canvas, userRight - userW + unit * 9f, userTop + userH * 0.5f,
                userW * 0.62f * userIn, unit, 0xFFFFFFFF, 0.85f * userIn * fadeOut);
        }

        // ATLAS bubble (left), first with bouncing dots, then two lines of text.
        float atlasIn = ease(segment(t, 0.28f, 0.40f));
        float atlasLeft = w * 0.14f;
        float atlasW = w * 0.52f;
        float atlasTop = unit * 52f;
        float atlasH = unit * 38f;
        drawBubble(canvas, atlasLeft, atlasTop, atlasLeft + atlasW, atlasTop + atlasH,
            atlasIn * fadeOut, false, unit);

        float dotsPhase = segment(t, 0.40f, 0.70f);
        float textPhase = ease(segment(t, 0.70f, 0.82f));
        if (atlasIn > 0.5f && textPhase < 1f) {
            float dotsAlpha = (1f - textPhase) * fadeOut;
            for (int i = 0; i < 3; i++) {
                double a = (dotsPhase * 3.0 - i * 0.16) * Math.PI * 2.0;
                float lift = (float) Math.max(0.0, Math.sin(a));
                float cx = atlasLeft + atlasW / 2f + (i - 1) * unit * 8f;
                float cy = atlasTop + atlasH / 2f - lift * unit * 6f;
                paint.setColor(ChatStyle.withAlpha(accent, (int) ((110 + 145 * lift) * dotsAlpha)));
                canvas.drawCircle(cx, cy, unit * (3.2f + lift * 0.8f), paint);
            }
        }
        if (textPhase > 0f) {
            float lineLeft = atlasLeft + unit * 9f;
            drawLine(canvas, lineLeft, atlasTop + atlasH * 0.36f, atlasW * 0.78f * textPhase,
                unit, 0xFFE8F6FF, 0.9f * fadeOut);
            drawLine(canvas, lineLeft, atlasTop + atlasH * 0.66f, atlasW * 0.48f * textPhase,
                unit, 0xFFE8F6FF, 0.9f * fadeOut);
        }
    }

    private void drawBubble(Canvas canvas, float left, float top, float right, float bottom,
                            float amount, boolean isUser, float unit) {
        if (amount <= 0.01f) {
            return;
        }
        float cx = isUser ? right : left;
        float cy = bottom;
        float scale = 0.7f + 0.3f * amount;
        canvas.save();
        canvas.scale(scale, scale, cx, cy);
        rect.set(left, top, right, bottom);
        float radius = unit * 12f;
        if (isUser) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(ChatStyle.withAlpha(accent, (int) (235 * amount)));
            canvas.drawRoundRect(rect, radius, radius, paint);
        } else {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(ChatStyle.withAlpha(0xFF101826, (int) (235 * amount)));
            canvas.drawRoundRect(rect, radius, radius, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1f, unit * 0.9f));
            paint.setColor(ChatStyle.withAlpha(accent, (int) (150 * amount)));
            canvas.drawRoundRect(rect, radius, radius, paint);
            paint.setStyle(Paint.Style.FILL);
        }
        canvas.restore();
    }

    private void drawLine(Canvas canvas, float left, float centerY, float length, float unit,
                          int color, float alphaAmount) {
        if (length <= 0f || alphaAmount <= 0.01f) {
            return;
        }
        float half = unit * 1.9f;
        rect.set(left, centerY - half, left + length, centerY + half);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(ChatStyle.withAlpha(color, (int) (255 * Math.min(1f, alphaAmount))));
        canvas.drawRoundRect(rect, half, half, paint);
    }
}
