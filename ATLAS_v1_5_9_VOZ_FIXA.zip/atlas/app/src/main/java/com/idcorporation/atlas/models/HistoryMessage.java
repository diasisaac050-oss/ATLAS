package com.idcorporation.atlas.models;

public class HistoryMessage {

    public static final String ROLE_USER = "user";
    public static final String ROLE_ATLAS = "atlas";

    private long id;
    private String conversationTitle;
    private String role;
    private String message;
    private long timestamp;

    public HistoryMessage(long id, String conversationTitle, String role, String message, long timestamp) {
        this.id = id;
        this.conversationTitle = conversationTitle;
        this.role = role;
        this.message = message;
        this.timestamp = timestamp;
    }

    public long getId() {
        return id;
    }

    public String getConversationTitle() {
        return conversationTitle;
    }

    public String getRole() {
        return role;
    }

    public String getMessage() {
        return message;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
