package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * What the user wants to see on the Home screen (Settings > Home screen).
 * Everything is visible by default, so nothing changes until the user chooses.
 */
public final class HomeLayoutPrefs {

    private static final String PREFS_NAME = "atlas_home_layout_prefs";
    private static final String KEY_SHOW_MODES = "show_modes_button";
    private static final String KEY_SHOW_HISTORY = "show_history_button";
    private static final String KEY_MIC_INVISIBLE = "mic_button_invisible";
    private static final String KEY_SHOW_CAPTION = "show_caption";
    private static final String KEY_SHOW_SYSINFO = "show_time_battery";

    private HomeLayoutPrefs() {
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static boolean isModesButtonShown(Context context) {
        return prefs(context).getBoolean(KEY_SHOW_MODES, true);
    }

    public static void setModesButtonShown(Context context, boolean shown) {
        prefs(context).edit().putBoolean(KEY_SHOW_MODES, shown).apply();
    }

    public static boolean isHistoryButtonShown(Context context) {
        return prefs(context).getBoolean(KEY_SHOW_HISTORY, true);
    }

    public static void setHistoryButtonShown(Context context, boolean shown) {
        prefs(context).edit().putBoolean(KEY_SHOW_HISTORY, shown).apply();
    }

    /** When true the microphone button is drawn invisible and the whole bottom strip acts as the microphone. */
    public static boolean isMicInvisible(Context context) {
        return prefs(context).getBoolean(KEY_MIC_INVISIBLE, false);
    }

    public static void setMicInvisible(Context context, boolean invisible) {
        prefs(context).edit().putBoolean(KEY_MIC_INVISIBLE, invisible).apply();
    }

    /** The caption line under the sphere (what was heard / what Atlas answered). */
    public static boolean isCaptionShown(Context context) {
        return prefs(context).getBoolean(KEY_SHOW_CAPTION, true);
    }

    public static void setCaptionShown(Context context, boolean shown) {
        prefs(context).edit().putBoolean(KEY_SHOW_CAPTION, shown).apply();
    }

    /** The clock and battery readout under the ATLAS name. */
    public static boolean isTimeBatteryShown(Context context) {
        return prefs(context).getBoolean(KEY_SHOW_SYSINFO, true);
    }

    public static void setTimeBatteryShown(Context context, boolean shown) {
        prefs(context).edit().putBoolean(KEY_SHOW_SYSINFO, shown).apply();
    }
}
