package com.idcorporation.atlas.services;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.AlarmScheduler;
import com.idcorporation.atlas.utils.NotificationHelper;

/**
 * Keeps the alarm actually ringing (looping tone + vibration) while
 * AlarmRingActivity is on screen, independent of notification sound
 * settings. Started by AlarmReceiver, stopped either by the user
 * hitting Stop/Snooze in AlarmRingActivity or by the safety timeout
 * below.
 */
public class AlarmSoundService extends Service {

    public static final String ACTION_STOP = "com.idcorporation.atlas.ACTION_STOP_ALARM";
    public static final int NOTIFICATION_ID = 5001;
    private static final long MAX_RING_MILLIS = 3L * 60L * 1000L;

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private Handler timeoutHandler;
    private Runnable timeoutRunnable;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopRinging();
            stopSelf();
            return START_NOT_STICKY;
        }

        String title = intent != null ? intent.getStringExtra(AlarmScheduler.EXTRA_TITLE) : null;
        if (title == null) {
            title = getString(R.string.alarm_default_title);
        }

        NotificationHelper.createAlarmNotificationChannel(this);
        Notification notification = NotificationHelper.buildAlarmForegroundNotification(this, title);
        startForeground(NOTIFICATION_ID, notification);

        startSound();
        startVibration();
        armSafetyTimeout();

        return START_NOT_STICKY;
    }

    private void startSound() {
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.alarm_ring);
            if (mediaPlayer == null) {
                return;
            }
            AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
            mediaPlayer.setAudioAttributes(attributes);
            mediaPlayer.setLooping(true);
            mediaPlayer.start();
        } catch (Exception e) {
            mediaPlayer = null;
        }
    }

    private void startVibration() {
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) {
            return;
        }
        long[] pattern = new long[]{0, 500, 300, 500, 300};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            VibrationEffect effect = VibrationEffect.createWaveform(pattern, 0);
            vibrator.vibrate(effect);
        } else {
            vibrator.vibrate(pattern, 0);
        }
    }

    private void armSafetyTimeout() {
        timeoutHandler = new Handler();
        timeoutRunnable = new Runnable() {
            @Override
            public void run() {
                stopRinging();
                stopSelf();
            }
        };
        timeoutHandler.postDelayed(timeoutRunnable, MAX_RING_MILLIS);
    }

    private void stopRinging() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
            } catch (Exception e) {
                // Already released or never started; nothing to clean up.
            }
            mediaPlayer = null;
        }
        if (vibrator != null) {
            vibrator.cancel();
        }
        if (timeoutHandler != null && timeoutRunnable != null) {
            timeoutHandler.removeCallbacks(timeoutRunnable);
        }
    }

    @Override
    public void onDestroy() {
        stopRinging();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void stop(Context context) {
        Intent intent = new Intent(context, AlarmSoundService.class);
        intent.setAction(ACTION_STOP);
        context.startService(intent);
    }

    public static PendingIntent buildStopPendingIntent(Context context) {
        Intent intent = new Intent(context, AlarmSoundService.class);
        intent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags | PendingIntent.FLAG_IMMUTABLE;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return PendingIntent.getForegroundService(context, NOTIFICATION_ID, intent, flags);
        }
        return PendingIntent.getService(context, NOTIFICATION_ID, intent, flags);
    }
}
