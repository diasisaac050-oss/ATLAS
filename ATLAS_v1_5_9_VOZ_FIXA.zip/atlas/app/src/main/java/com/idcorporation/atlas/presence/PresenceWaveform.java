package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.Random;

/**
 * The middle line of the Presence bubble: a row of 15 slim rounded vertical
 * bars (tall in the center, small dots at the edges) that moves like a
 * sound line.
 *
 * - While YOU talk, the bars follow the real microphone loudness. The
 *   newest loudness shows in the center bar and travels outward, so it
 *   looks like the sound spreading from the middle.
 * - While ATLAS talks, Android does not tell apps how loud the text to
 *   speech is, so a speech-like rhythm (short syllables, small pauses
 *   between words) is simulated. It starts and stops exactly with the
 *   real speaking state.
 * - While ATLAS thinks, a slow wave runs across the bars.
 * - When nobody talks, the bars rest in the reference shape and only
 *   breathe a little.
 */
public class PresenceWaveform {

    private static final int STEPS = 8;
    private static final float STEP_SECONDS = 0.05f;
    // Height weight of each bar, center first. Same bell shape as the reference image.
    private static final float[] BELL = {1.00f, 0.92f, 0.82f, 0.71f, 0.60f, 0.50f, 0.42f, 0.35f};

    private final float d;
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RadialGradient haloUnit = new RadialGradient(0f, 0f, 1f,
        new int[] {PresenceBlues.alpha(PresenceBlues.SKY, 255), PresenceBlues.alpha(PresenceBlues.SKY, 0)},
        new float[] {0f, 1f}, Shader.TileMode.CLAMP);
    private final Random random = new Random(7L);

    private final float[] history = new float[STEPS];
    private final float[] shown = new float[STEPS];

    private float lastPhase = 0f;
    private float stepClock = 0f;
    private float speechEnv = 0f;
    private float speechTarget = 0f;
    private float speechClock = 0f;
    private float drive = 0f;

    public PresenceWaveform(float density) {
        this.d = density;
        bar.setStyle(Paint.Style.STROKE);
        bar.setStrokeCap(Paint.Cap.ROUND);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
    }

    /** Draws the bars centered on (cx, y0). ig (0..1) fades/grows them in after the bubble opens. */
    void draw(Canvas canvas, float cx, float y0, float a, PresenceBubbleState st, float ig) {
        float dt = st.phase - lastPhase;
        lastPhase = st.phase;
        if (dt < 0f || dt > 0.1f) {
            dt = 0.016f;
        }
        update(dt, st);

        drawHalo(canvas, cx, y0, a, ig);

        float barW = 2.5f * d;
        float spacing = 8.6f * d;
        float minH = 3.0f * d;
        float maxH = 40.0f * d;
        int core = (st.errAmt > 0.5f) ? PresenceBlues.MID : PresenceBlues.WHITE;

        bar.setStrokeWidth(barW);
        glow.setStrokeWidth(barW * 2.2f);

        for (int k = 0; k < STEPS; k++) {
            float rest = 0.13f + 0.05f * (float) Math.sin(st.phase * 2.0f - k * 0.55f);
            float amp = rest + (1f - rest) * shown[k];
            float top = maxH * BELL[k];
            float h = (minH + (top - minH) * amp) * ig;
            float len = Math.max(0f, h - barW);
            float edge = 1f - 0.42f * (float) Math.pow((double) k / (double) (STEPS - 1), 1.4);
            int glowAlpha = (int) ((18f + 46f * amp) * ig * edge);
            glow.setColor(PresenceBlues.alpha(PresenceBlues.SKY, glowAlpha));
            bar.setColor(PresenceBlues.alpha(core, (int) (255f * ig * edge)));

            float xr = cx + k * spacing;
            drawBar(canvas, xr, y0, len);
            if (k > 0) {
                drawBar(canvas, cx - k * spacing, y0, len);
            }
        }
    }

    private void drawBar(Canvas canvas, float x, float y0, float len) {
        float half = len / 2f;
        canvas.drawLine(x, y0 - half, x, y0 + half, glow);
        canvas.drawLine(x, y0 - half, x, y0 + half, bar);
    }

    /** Very soft light behind the bars; a little brighter while sound is running. */
    private void drawHalo(Canvas canvas, float cx, float y0, float a, float ig) {
        float radius = a * 0.85f;
        halo.setShader(haloUnit);
        halo.setAlpha((int) ((30f + 60f * drive) * ig));
        canvas.save();
        canvas.translate(cx, y0);
        canvas.scale(radius, radius * 0.38f);
        canvas.drawCircle(0f, 0f, 1f, halo);
        canvas.restore();
    }

    private void update(float dt, PresenceBubbleState st) {
        float mic = gate(st.level);

        // Simulated speech rhythm for ATLAS: new loudness every 70-180 ms,
        // with a small dip now and then (the pause between two words).
        speechClock = speechClock - dt;
        if (speechClock <= 0f) {
            speechClock = 0.07f + random.nextFloat() * 0.11f;
            if (random.nextFloat() < 0.16f) {
                speechTarget = 0.06f;
            } else {
                speechTarget = 0.30f + random.nextFloat() * 0.70f;
            }
        }
        speechEnv = speechEnv + (speechTarget - speechEnv) * Math.min(1f, dt * 14f);

        float target = Math.max(mic, speechEnv * st.speakAmt);
        float rate = (target > drive) ? 22f : 9f;
        drive = drive + (target - drive) * Math.min(1f, dt * rate);

        // Every step the older loudness moves one bar outward.
        stepClock = stepClock + dt;
        while (stepClock >= STEP_SECONDS) {
            stepClock = stepClock - STEP_SECONDS;
            for (int i = STEPS - 1; i > 0; i--) {
                history[i] = history[i - 1];
            }
            history[0] = drive;
        }
        history[0] = drive;

        for (int i = 0; i < STEPS; i++) {
            float want = history[i];
            float wave = st.thinkAmt * (0.22f + 0.16f * (float) Math.sin(st.phase * 6.0f - i * 0.9f));
            want = Math.max(want, wave);
            want = want * (1f - 0.7f * st.errAmt);
            float r = (want > shown[i]) ? 26f : 11f;
            shown[i] = shown[i] + (want - shown[i]) * Math.min(1f, dt * r);
        }
    }

    /** Ignores room noise: only real voice loudness moves the bars. */
    private float gate(float level) {
        float v = (level - 0.26f) / 0.74f;
        if (v < 0f) {
            v = 0f;
        }
        if (v > 1f) {
            v = 1f;
        }
        return (float) Math.pow(v, 0.8);
    }
}
