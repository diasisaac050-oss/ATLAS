package com.idcorporation.atlas.commands;

import com.idcorporation.atlas.calendar.DateTimeCommandParser;

import java.util.regex.Pattern;

/**
 * Recognises spoken requests to call a contact or send them a WhatsApp
 * message, in whatever natural phrasing the user says it in (PT/EN/ES/IT),
 * and pulls the contact name (and, for messages, the message content)
 * out of the sentence. Trigger phrases are matched against an
 * accent-stripped, lower-cased copy of the text; because every
 * substitution DateTimeCommandParser.normalize() makes is one character
 * for one character, that normalized copy stays the exact same length
 * as the original, so an index found in it can be used to slice the
 * original (accented, correctly-cased) text for the piece we hand back.
 */
public class ContactCommandParser {

    private static final String[] CALL_TRIGGERS = new String[]{
        "ligar para ", "ligue para ", "liga para ", "liga pra ", "ligar pra ", "ligue pra ",
        "telefone para ", "telefonar para ", "telefona para ", "telefonar pra ", "telefona pra ",
        "fazer uma ligacao para ", "faca uma ligacao para ", "faz uma ligacao para ",
        "fazer uma ligacao pra ", "faca uma ligacao pra ", "faz uma ligacao pra ",
        "quero falar com ", "preciso falar com ",
        "quero ligar para ", "quero ligar pra ",
        "pode ligar para ", "pode ligar pra ", "poderia ligar para ", "poderia ligar pra ",
        "call ", "phone ", "llamar a ", "chiama "
    };

    private static final String[] MESSAGE_TRIGGERS = new String[]{
        "mandar mensagem para ", "manda mensagem para ", "mandar mensagem pra ", "manda mensagem pra ",
        "mandar uma mensagem para ", "manda uma mensagem para ",
        "mandar uma mensagem pra ", "manda uma mensagem pra ",
        "enviar mensagem para ", "envia mensagem para ", "enviar mensagem pra ", "envia mensagem pra ",
        "mandar whatsapp para ", "manda whatsapp para ", "mandar whatsapp pra ", "manda whatsapp pra ",
        "mandar um whatsapp para ", "manda um whatsapp para ",
        "mandar um whatsapp pra ", "manda um whatsapp pra ",
        "enviar um whatsapp para ", "envia um whatsapp para ",
        "enviar um whatsapp pra ", "envia um whatsapp pra ",
        "whatsapp para ", "whatsapp pra ", "mandar pra ", "mandar para "
    };

    /** Where the content starts, e.g. "...para joao dizendo que ja estou indo". */
    private static final String[] CONTENT_DELIMITERS = new String[]{
        ": ", " dizendo que ", " dizendo ", " falando que ", " avisando que ", " avisar que ", " avisando "
    };

    private static final String[] TRAILING_FILLERS = new String[]{
        " por favor", " please", " agora", " pra mim", " para mim"
    };

    private static final Pattern AFFIRMATIVE = Pattern.compile(
        "^\\s*(?:sim|isso|isso mesmo|pode|pode sim|confirmo|confirma|manda|envia|liga|ok|okay|certo|"
        + "claro|afirmativo|isso ai|isso a[iy]|yes|yeah|yep|si)\\b");

    private static final Pattern NEGATIVE = Pattern.compile(
        "^\\s*(?:nao|não|cancela\\w*|cancele\\w*|deixa|deixe|esquece\\w*|para|calma|"
        + "nao precisa|nao quero|no|nope)\\b");

    /** A short, stand-alone cancel word with nothing else - used where the answer is otherwise
     * taken as free-form content (a message body), so a real message starting with "nao" is not
     * mistaken for a cancellation. */
    private static final Pattern PURE_CANCEL = Pattern.compile(
        "^\\s*(?:nao|não|cancela\\w*|cancele\\w*|esquece\\w*|deixa pra la|deixa)\\s*[.!]?\\s*$");

    public static boolean isCallCommand(String text) {
        String normalized = DateTimeCommandParser.normalize(text);
        return findTrigger(normalized, CALL_TRIGGERS) != null;
    }

    public static boolean isMessageCommand(String text) {
        String normalized = DateTimeCommandParser.normalize(text);
        return findTrigger(normalized, MESSAGE_TRIGGERS) != null;
    }

    /** Extracted contact name (original casing/accents), trimmed of trailing filler words. */
    public static String extractCallContactName(String text) {
        String normalized = DateTimeCommandParser.normalize(text);
        int[] hit = findTrigger(normalized, CALL_TRIGGERS);
        if (hit == null) {
            return "";
        }
        return cleanTail(sliceOriginal(text, normalized, hit[0] + hit[1], normalized.length()));
    }

    /** Result of parsing a message command: who to message and what to say (content may be empty). */
    public static class MessageRequest {
        public String contactName = "";
        public String content = "";
    }

    public static MessageRequest extractMessageRequest(String text) {
        MessageRequest result = new MessageRequest();
        String normalized = DateTimeCommandParser.normalize(text);
        int[] hit = findTrigger(normalized, MESSAGE_TRIGGERS);
        if (hit == null) {
            return result;
        }
        int remainderStart = hit[0] + hit[1];
        String normalizedRemainder = normalized.substring(remainderStart);

        int delimiterIndex = -1;
        int delimiterLength = 0;
        for (int i = 0; i < CONTENT_DELIMITERS.length; i++) {
            int idx = normalizedRemainder.indexOf(CONTENT_DELIMITERS[i]);
            if (idx != -1 && (delimiterIndex == -1 || idx < delimiterIndex)) {
                delimiterIndex = idx;
                delimiterLength = CONTENT_DELIMITERS[i].length();
            }
        }

        if (delimiterIndex == -1) {
            String name = sliceOriginal(text, normalized, remainderStart, normalized.length());
            result.contactName = cleanTail(name);
            return result;
        }

        int nameEnd = remainderStart + delimiterIndex;
        int contentStart = remainderStart + delimiterIndex + delimiterLength;
        result.contactName = cleanTail(sliceOriginal(text, normalized, remainderStart, nameEnd));
        result.content = sliceOriginal(text, normalized, contentStart, normalized.length()).trim();
        return result;
    }

    public static boolean isAffirmative(String text) {
        return AFFIRMATIVE.matcher(DateTimeCommandParser.normalize(text)).find();
    }

    public static boolean isNegative(String text) {
        return NEGATIVE.matcher(DateTimeCommandParser.normalize(text)).find();
    }

    /** Stricter cancel check for use where the answer is otherwise read as free-form content. */
    public static boolean isPureCancel(String text) {
        return PURE_CANCEL.matcher(DateTimeCommandParser.normalize(text)).matches();
    }

    /** @return {startIndex, triggerLength} of the earliest matching trigger, or null. */
    private static int[] findTrigger(String normalizedText, String[] triggers) {
        int bestIndex = -1;
        int bestLength = 0;
        for (int i = 0; i < triggers.length; i++) {
            int idx = normalizedText.indexOf(triggers[i]);
            if (idx != -1 && (bestIndex == -1 || idx < bestIndex)) {
                bestIndex = idx;
                bestLength = triggers[i].length();
            }
        }
        if (bestIndex == -1) {
            return null;
        }
        return new int[]{bestIndex, bestLength};
    }

    /** Same-length guarantee of DateTimeCommandParser.normalize lets us slice the original text by index. */
    private static String sliceOriginal(String originalText, String normalizedText, int start, int end) {
        int safeStart = Math.max(0, Math.min(start, originalText.length()));
        int safeEnd = Math.max(safeStart, Math.min(end, originalText.length()));
        return originalText.substring(safeStart, safeEnd).trim();
    }

    private static String cleanTail(String value) {
        String result = value;
        while (result.length() > 0 && isTrailingPunctuation(result.charAt(result.length() - 1))) {
            result = result.substring(0, result.length() - 1).trim();
        }
        boolean changed = true;
        while (changed) {
            changed = false;
            String lower = result.toLowerCase();
            for (int i = 0; i < TRAILING_FILLERS.length; i++) {
                if (lower.endsWith(TRAILING_FILLERS[i])) {
                    result = result.substring(0, result.length() - TRAILING_FILLERS[i].length()).trim();
                    changed = true;
                    break;
                }
            }
        }
        return result;
    }

    private static boolean isTrailingPunctuation(char c) {
        return c == '.' || c == '!' || c == '?' || c == ';' || c == ':';
    }
}
