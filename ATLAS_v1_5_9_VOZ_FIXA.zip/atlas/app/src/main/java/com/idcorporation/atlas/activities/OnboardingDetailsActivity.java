package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.security.SecurityManager;
import com.idcorporation.atlas.utils.UserProfileManager;

/**
 * Fourth onboarding step: age and how ATLAS should refer to the user.
 * These two quick-pick fields share one screen since neither needs
 * free typing beyond a short number, unlike the previous steps.
 */
public class OnboardingDetailsActivity extends OnboardingStepActivity {

    private static final int STEP_INDEX = 4;
    private static final int TOTAL_STEPS = 6;

    private EditText ageInput;
    private RadioGroup genderGroup;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_details);

        View backButton = findViewById(R.id.button_step_back);
        ViewGroup dotsContainer = (ViewGroup) findViewById(R.id.container_step_dots);
        View badge = findViewById(R.id.badge_details);
        View title = findViewById(R.id.text_details_title);
        ageInput = (EditText) findViewById(R.id.input_age);
        genderGroup = (RadioGroup) findViewById(R.id.radio_group_gender);
        errorText = (TextView) findViewById(R.id.text_details_error);
        final View continueButton = findViewById(R.id.button_details_continue);

        renderProgressDots(dotsContainer, STEP_INDEX, TOTAL_STEPS);
        animateEntrance(badge, title, null, ageInput, continueButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bounceButton(continueButton);
                attemptContinue();
            }
        });
    }

    private void attemptContinue() {
        String ageText = ageInput.getText().toString();

        if (!SecurityManager.isValidAge(ageText)) {
            showFieldError(errorText, getString(R.string.error_age_invalid));
            return;
        }

        int age = Integer.parseInt(ageText.trim());
        String gender = resolveGender();

        Intent next = buildForwardIntent(OnboardingBirthdayActivity.class);
        next.putExtra(OnboardingKeys.AGE, age);
        next.putExtra(OnboardingKeys.GENDER, gender);
        goToNext(next);
    }

    private String resolveGender() {
        int checkedId = genderGroup.getCheckedRadioButtonId();
        if (checkedId == R.id.radio_gender_male) {
            return UserProfileManager.GENDER_MALE;
        }
        if (checkedId == R.id.radio_gender_female) {
            return UserProfileManager.GENDER_FEMALE;
        }
        return UserProfileManager.GENDER_UNSPECIFIED;
    }
}
