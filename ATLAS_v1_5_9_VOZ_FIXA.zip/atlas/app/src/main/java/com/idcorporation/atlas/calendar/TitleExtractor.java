package com.idcorporation.atlas.calendar;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Finds the label of a reminder or alarm by elimination: everything that
 * is only command wording ("marque", "crie um lembrete", "no calendario",
 * "com o titulo"), or the date/time itself, is thrown away, and what is
 * left is the title ("marque no dia 20 de abril como dia do presente da
 * minha mae" -> "Dia do presente da minha mae"). It works on the original
 * text so accents and capital letters the user spoke are kept; the
 * normalized copy (same length) is only used to find what to remove.
 */
public class TitleExtractor {

    private static final String[] NOISE = new String[]{
        "\\b(?:ei|oi|ok|hey|e\\s+ai)\\s+atlas\\b", "\\batlas\\b",
        "\\bpor\\s+favor\\b", "\\b(?:voce|vc)\\s+(?:pode|poderia|consegue)\\b",
        "\\b(?:pode|poderia|consegue)\\b", "\\bda\\s+pra\\b",
        "\\bquero\\s+que\\s+(?:voce\\s+)?", "\\b(?:eu\\s+)?quero\\b", "\\bgostaria\\s+de\\b",
        "\\bpreciso\\s+que\\s+(?:voce\\s+)?",
        "\\b(?:marque|marcar|marca|agende|agendar|agenda|anote|anotar|anota|coloque|colocar|coloca"
            + "|crie|criar|cria|adicione|adicionar|adiciona|registre|registrar|cadastre|cadastrar"
            + "|programe|programar|defina|definir|define|configure|configurar|bote|botar|bota"
            + "|ponha|poe|salve|salvar|salva)\\b",
        "\\b(?:me\\s+)?(?:lembre|lembra|lembrar)(?:-me)?\\b(?:\\s+(?:de|do|da|que))?",
        "\\b(?:me\\s+)?(?:avise|avisa|avisar)(?:-me)?\\b(?:\\s+(?:de|do|da|que))?",
        "\\b(?:um|uma|o|a)?\\s*(?:lembrete|compromisso|evento|despertador|alarme)\\b",
        "\\b(?:no|na|em|do|da|de)\\s+(?:meu\\s+|minha\\s+|o\\s+|a\\s+)?(?:calendario|agenda)\\b",
        "\\b(?:meu|minha)\\s+(?:calendario|agenda)\\b", "\\b(?:calendario|agenda)\\b",
        "\\bcom\\s+(?:o\\s+)?(?:titulo|nome|rotulo|legenda)\\b",
        "\\b(?:chamado|chamada|intitulado|intitulada)\\b",
        "\\b(?:chame|chama|chamar)\\s+de\\b", "\\bpode\\s+ser\\b", "\\bseria\\b",
        "\\bo\\s+(?:nome|titulo)\\s+e\\b", "\\b(?:o\\s+)?(?:titulo|rotulo)\\b",
        "\\b(?:da|de|na|no|a|esta|essa)\\s+(?:manha|tarde|noite|madrugada)\\b",
        "\\b(?:isso|isto|ai)\\b", "\\b(?:pra|para)\\s+mim\\b",
        "\\bem\\s+ponto\\b", "\\b(?:hoje|amanha)\\b", "\\b(?:am|pm)\\b"
    };

    private static final Pattern ALARM_LABEL_MARKER = Pattern.compile(
        "\\b(?:chamad[oa]|(?:com|de)\\s+(?:o\\s+|a\\s+)?(?:nome|titulo|rotulo|mensagem)|escrito|dizendo)\\b");

    private static final String[] STOP_WORDS = new String[]{
        "de", "do", "da", "dos", "das", "para", "pra", "pro", "o", "a", "os", "as", "um", "uma",
        "no", "na", "em", "que", "como", "e", "ser", "com", "por", "me", "eu", "ai"
    };

    private static final Pattern[] NOISE_PATTERNS = compile(NOISE);

    private static Pattern[] compile(String[] sources) {
        Pattern[] result = new Pattern[sources.length];
        for (int i = 0; i < sources.length; i++) {
            result[i] = Pattern.compile(sources[i]);
        }
        return result;
    }

    /** mask marks characters (same positions as the normalized text) already used by date/time words. */
    public static String extract(String original, String normalized, boolean[] mask, boolean alarmMode) {
        String source = original;
        boolean[] work = mask;
        if (original.length() != normalized.length()) {
            source = normalized;
        }
        if (work.length != source.length()) {
            work = new boolean[source.length()];
        }
        int from = 0;
        if (alarmMode) {
            // An alarm is only labelled when the user says so ("chamado academia",
            // "com o nome remedio"); leftover words alone would give silly labels.
            Matcher marker = ALARM_LABEL_MARKER.matcher(normalized);
            if (!marker.find()) {
                return null;
            }
            from = marker.end();
        }
        markAll(NOISE_PATTERNS, normalized, work);
        StringBuilder rest = new StringBuilder();
        for (int i = from; i < source.length(); i++) {
            rest.append(work[i] ? ' ' : source.charAt(i));
        }
        return finishTitle(rest.toString());
    }

    public static void markRange(boolean[] mask, int start, int end) {
        if (start < 0) {
            return;
        }
        for (int i = start; i < end && i < mask.length; i++) {
            mask[i] = true;
        }
    }

    private static void markAll(Pattern[] patterns, String normalized, boolean[] mask) {
        for (int p = 0; p < patterns.length; p++) {
            Matcher m = patterns[p].matcher(normalized);
            while (m.find()) {
                markRange(mask, m.start(), m.end());
            }
        }
    }

    private static String finishTitle(String raw) {
        String[] tokens = raw.trim().split("\\s+");
        int from = 0;
        int to = tokens.length;
        while (from < to && isFiller(tokens[from])) {
            from++;
        }
        while (to > from && isFiller(tokens[to - 1])) {
            to--;
        }
        StringBuilder title = new StringBuilder();
        for (int i = from; i < to; i++) {
            if (title.length() > 0) {
                title.append(' ');
            }
            title.append(tokens[i]);
        }
        String result = trimEdgePunctuation(title.toString());
        if (result.length() < 2) {
            return null;
        }
        if (result.length() > 80) {
            result = result.substring(0, 80).trim();
        }
        return Character.toUpperCase(result.charAt(0)) + result.substring(1);
    }

    private static boolean isFiller(String token) {
        String plain = trimEdgePunctuation(DateTimeCommandParser.stripAccents(token.toLowerCase()));
        if (plain.length() == 0) {
            return true;
        }
        for (int i = 0; i < STOP_WORDS.length; i++) {
            if (STOP_WORDS[i].equals(plain)) {
                return true;
            }
        }
        return false;
    }

    private static String trimEdgePunctuation(String text) {
        int start = 0;
        int end = text.length();
        while (start < end && isEdgePunctuation(text.charAt(start))) {
            start++;
        }
        while (end > start && isEdgePunctuation(text.charAt(end - 1))) {
            end--;
        }
        return text.substring(start, end);
    }

    private static boolean isEdgePunctuation(char c) {
        return c == '.' || c == ',' || c == ';' || c == ':' || c == '!' || c == '?'
            || c == '-' || c == '"' || c == '\'';
    }
}
