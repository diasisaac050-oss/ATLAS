package com.idcorporation.atlas.memory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.idcorporation.atlas.models.HistoryMessage;

import java.util.ArrayList;

public class HistoryManager {

    private final AtlasDatabase dbHelper;

    public HistoryManager(Context context) {
        this.dbHelper = AtlasDatabase.getInstance(context);
    }

    public void saveMessage(String conversationTitle, String role, String message) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("conversation_title", conversationTitle);
        values.put("role", role);
        values.put("message", message);
        values.put("timestamp", System.currentTimeMillis());
        db.insert(AtlasDatabase.TABLE_HISTORY, null, values);
    }

    public ArrayList<HistoryMessage> getAllHistory() {
        ArrayList<HistoryMessage> results = new ArrayList<HistoryMessage>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(AtlasDatabase.TABLE_HISTORY, null, null, null, null, null, "timestamp DESC");

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
            String title = cursor.getString(cursor.getColumnIndexOrThrow("conversation_title"));
            String role = cursor.getString(cursor.getColumnIndexOrThrow("role"));
            String message = cursor.getString(cursor.getColumnIndexOrThrow("message"));
            long timestamp = cursor.getLong(cursor.getColumnIndexOrThrow("timestamp"));
            results.add(new HistoryMessage(id, title, role, message, timestamp));
        }
        cursor.close();
        return results;
    }

    public void deleteAllHistory() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(AtlasDatabase.TABLE_HISTORY, null, null);
    }

    public void deleteConversation(String conversationTitle) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(AtlasDatabase.TABLE_HISTORY, "conversation_title=?", new String[]{conversationTitle});
    }

    /**
     * One row per distinct conversation, most recently active first.
     * limit caps how many are returned (History shows the 15 most
     * recent) but never deletes or otherwise touches anything beyond
     * that - older conversations stay in the database and can still be
     * reached with getConversation(title) if the limit is ever raised
     * or removed.
     */
    public ArrayList<com.idcorporation.atlas.models.ConversationSummary> getRecentConversations(int limit) {
        ArrayList<com.idcorporation.atlas.models.ConversationSummary> results =
            new ArrayList<com.idcorporation.atlas.models.ConversationSummary>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String query = "SELECT conversation_title, MAX(timestamp) AS last_ts, COUNT(*) AS cnt "
            + "FROM " + AtlasDatabase.TABLE_HISTORY
            + " GROUP BY conversation_title ORDER BY last_ts DESC";
        if (limit > 0) {
            query = query + " LIMIT " + limit;
        }

        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            String conversationTitle = cursor.getString(cursor.getColumnIndexOrThrow("conversation_title"));
            long lastTimestamp = cursor.getLong(cursor.getColumnIndexOrThrow("last_ts"));
            int count = cursor.getInt(cursor.getColumnIndexOrThrow("cnt"));

            String firstMessage = queryEdgeMessage(db, conversationTitle, true);
            String lastMessage = count > 1 ? queryEdgeMessage(db, conversationTitle, false) : firstMessage;

            results.add(new com.idcorporation.atlas.models.ConversationSummary(
                conversationTitle, firstMessage, lastMessage, lastTimestamp, count));
        }
        cursor.close();
        return results;
    }

    private String queryEdgeMessage(SQLiteDatabase db, String conversationTitle, boolean oldest) {
        String order = oldest ? "timestamp ASC, id ASC" : "timestamp DESC, id DESC";
        Cursor cursor = db.query(AtlasDatabase.TABLE_HISTORY, new String[]{"message"},
            "conversation_title=?", new String[]{conversationTitle}, null, null, order, "1");
        String message = "";
        if (cursor.moveToFirst()) {
            message = cursor.getString(cursor.getColumnIndexOrThrow("message"));
        }
        cursor.close();
        return message == null ? "" : message;
    }

    /** All messages of one conversation, oldest first (used to restore the Chat mode screen). */
    public ArrayList<HistoryMessage> getConversation(String conversationTitle) {
        ArrayList<HistoryMessage> results = new ArrayList<HistoryMessage>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(AtlasDatabase.TABLE_HISTORY, null, "conversation_title=?",
            new String[]{conversationTitle}, null, null, "timestamp ASC, id ASC");

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
            String title = cursor.getString(cursor.getColumnIndexOrThrow("conversation_title"));
            String role = cursor.getString(cursor.getColumnIndexOrThrow("role"));
            String message = cursor.getString(cursor.getColumnIndexOrThrow("message"));
            long timestamp = cursor.getLong(cursor.getColumnIndexOrThrow("timestamp"));
            results.add(new HistoryMessage(id, title, role, message, timestamp));
        }
        cursor.close();
        return results;
    }
}
