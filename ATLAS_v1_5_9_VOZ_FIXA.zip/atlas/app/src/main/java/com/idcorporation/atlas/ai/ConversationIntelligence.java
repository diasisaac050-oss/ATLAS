package com.idcorporation.atlas.ai;

/**
 * Lightweight local intent detector used to give the language model explicit
 * behavioral context before it generates a reply. It does not execute actions
 * and does not replace the existing AI/provider architecture.
 */
public final class ConversationIntelligence {

    public enum Intent {
        QUESTION,
        COMMAND,
        CONVERSATION,
        CALCULATION,
        EXPLANATION,
        CREATIVE,
        APP_ACTION,
        UNKNOWN
    }

    /**
     * The emotional register of a message. Separate from Intent: Intent says
     * WHAT the person wants done, Tone says HOW they are talking, which is
     * what decides between a short friendly reply and a long structured one.
     */
    public enum Tone {
        NEUTRAL,
        CASUAL,
        VENT,
        SERIOUS,
        HELP_REQUEST
    }

    private ConversationIntelligence() {
    }

    /**
     * Local, cheap first read of the tone. It only gives the model a hint
     * (the prompt tells it to correct the hint from context) and decides
     * whether the tool list is worth sending at all.
     */
    public static Tone detectTone(String message) {
        if (message == null) {
            return Tone.NEUTRAL;
        }
        String text = normalizeLoose(message);
        if (text.length() == 0) {
            return Tone.NEUTRAL;
        }
        if (containsAny(text,
                "suicid", "me matar", "quero morrer", "nao quero mais viver", "tirar minha vida",
                "morreu", "faleceu", "falecimento", "luto", "velorio", "enterro", "depressao",
                "me cortar", "automutil", "abuso", "violencia", "fui assaltad", "acidente grave",
                "cancer", "diagnostico", "internad", "hospital", "kill myself", "want to die",
                "passed away", "funeral")) {
            return Tone.SERIOUS;
        }
        if (hasActionCue(text)) {
            return Tone.NEUTRAL;
        }
        if (containsAny(text,
                "me ajuda", "me ajude", "pode me ajudar", "preciso de ajuda", "me da dicas", "me de dicas",
                "me da uma dica", "monta um plano", "monte um plano", "cria um plano", "crie um plano",
                "me explica", "me explique", "como eu faco", "como faco", "como posso", "o que eu faco",
                "help me", "can you help", "give me tips", "make a plan", "how do i")) {
            return Tone.HELP_REQUEST;
        }
        if (containsAny(text,
                "meu dia foi", "to cansad", "estou cansad", "to mal", "estou mal", "to triste", "estou triste",
                "to estressad", "estou estressad", "to ansios", "estou ansios", "que saco", "nao aguento",
                "to de saco cheio", "to puto", "to puta", "odeio", "me sinto", "to desanimad", "estou desanimad",
                "preciso tirar", "preciso passar", "vou reprovar", "vou repetir", "tirei nota", "fui mal na",
                "briguei", "terminei com", "terminou comigo", "me deixou", "fui demitid", "perdi o emprego",
                "que dia", "ninguem me", "to sozinho", "to sozinha", "i hate", "my day was", "i'm so tired",
                "i feel", "so stressed", "i failed", "i need to get")) {
            return Tone.VENT;
        }
        if (containsAny(text, "kkk", "haha", "rsrs", "brincadeira", "piada", "engracad", "zoeira", "lol")) {
            return Tone.CASUAL;
        }
        return Tone.NEUTRAL;
    }

    /** True when the sentence clearly asks the phone to DO or FETCH something. */
    public static boolean hasActionCue(String message) {
        String text = normalizeLoose(message);
        return containsAny(text,
            "abre ", "abra ", "abrir ", "manda ", "mande ", "envia ", "envie ", "liga ", "ligue ", "chama ",
            "pesquisa ", "pesquise ", "procura ", "procure ", "busca ", "busque ", "checa ", "checar ",
            "confere ", "confira ", "verifica ", "verifique ", "mostra ", "mostre ", "me mostra ",
            "previsao", "clima", "temperatura", "noticia", "onde fica", "perto de mim", "perto daqui",
            "e-mail", "email", "gmail", "whatsapp", "zap ", "mensagem para", "mensagem pra",
            "lembra ", "lembre ", "alarme", "agenda", "calendario", "anota ", "anote ",
            "open ", "send ", "call ", "search ", "look up", "check my", "show me", "weather", "news",
            "near me", "remind me");
    }

    private static String normalizeLoose(String value) {
        return java.text.Normalizer.normalize(value.toLowerCase(java.util.Locale.ROOT),
            java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+", "").replaceAll("\\s+", " ").trim() + " ";
    }

    public static Intent detect(String message) {
        if (message == null) {
            return Intent.UNKNOWN;
        }

        String text = normalize(message);
        if (text.length() == 0) {
            return Intent.UNKNOWN;
        }

        if (isCalculation(text)) {
            return Intent.CALCULATION;
        }

        if (isAppAction(text)) {
            return Intent.APP_ACTION;
        }

        if (isCommand(text)) {
            return Intent.COMMAND;
        }

        if (isExplanation(text)) {
            return Intent.EXPLANATION;
        }

        if (isCreative(text)) {
            return Intent.CREATIVE;
        }

        if (isConversation(text)) {
            return Intent.CONVERSATION;
        }

        if (looksLikeQuestion(text)) {
            return Intent.QUESTION;
        }

        return Intent.UNKNOWN;
    }

    private static boolean isCalculation(String text) {
        if (text.matches(".*\\d+\\s*[+\\-x×*/÷]\\s*\\d+.*")) {
            return true;
        }
        return containsAny(text,
            "quanto e", "quanto é", "calcule", "calcula", "calcular",
            "resultado de", "raiz quadrada de", "delta de", "bhaskara",
            "what is", "calculate", "how much is");
    }

    private static boolean isAppAction(String text) {
        return containsAny(text,
            "abra ", "abrir ", "abre ", "feche ", "fechar ",
            "inicie ", "iniciar ", "execute ", "executar ",
            "mande uma mensagem", "ligue para ", "envie uma mensagem",
            "open ", "close ", "start ", "launch ", "send a message",
            "call ");
    }

    private static boolean isCommand(String text) {
        return containsAny(text,
            "faça ", "faca ", "faz ", "crie ", "criar ", "adicione ",
            "adicionar ", "remova ", "remover ", "apague ", "apagar ",
            "mude ", "mudar ", "troque ", "trocar ", "configure ",
            "configurar ", "mostre ", "mostrar ", "lembre ", "anote ",
            "salve ", "salvar ", "defina ", "definir ",
            "do ", "create ", "add ", "remove ", "delete ", "change ",
            "set ", "show ", "save ");
    }

    private static boolean isExplanation(String text) {
        return containsAny(text,
            "como funciona", "como funciona", "por que", "por quê",
            "porque ", "explique", "explica", "explique me", "me explique",
            "qual a diferença", "qual é a diferença", "o que significa",
            "como fazer", "how does", "why ", "explain", "what does",
            "how to");
    }

    private static boolean isCreative(String text) {
        return containsAny(text,
            "crie uma historia", "crie uma história", "escreva uma historia",
            "escreva uma história", "invente", "roteiro", "poema",
            "nome para", "ideias para", "imagina", "imagine",
            "write a story", "creative", "poem", "script", "ideas for");
    }

    private static boolean isConversation(String text) {
        return containsAny(text,
            "valeu", "obrigado", "obrigada", "obg", "entendi", "beleza",
            "blz", "consegui", "boa", "show", "perfeito", "sim", "nao",
            "não", "kk", "kkkk", "oi", "olá", "ola", "bom dia",
            "boa tarde", "boa noite", "tudo bem", "thanks", "thank you",
            "got it", "okay", "ok", "great", "hello", "hi");
    }

    private static boolean looksLikeQuestion(String text) {
        return text.endsWith("?") || containsAny(text,
            "o que ", "qual ", "quando ", "onde ", "quem ", "como ",
            "por que ", "por quê", "quanto ", "which ", "what ",
            "when ", "where ", "who ", "how ", "why ");
    }

    private static boolean containsAny(String text, String... values) {
        for (String value : values) {
            if (text.contains(value)) {
                return true;
            }
        }
        return false;
    }

    private static String normalize(String value) {
        return value.trim().toLowerCase(java.util.Locale.ROOT)
            .replaceAll("\\s+", " ");
    }
}
