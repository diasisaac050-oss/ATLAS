package com.idcorporation.atlas.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.ViewAnimUtils;

import java.util.ArrayList;

public class TrashRowAdapter extends RecyclerView.Adapter<TrashRowAdapter.TrashViewHolder> {

    public static class TrashEntry {
        public final long id;
        public final String title;

        public TrashEntry(long id, String title) {
            this.id = id;
            this.title = title;
        }
    }

    public interface Listener {
        void onRestoreClicked(TrashEntry entry);
        void onDeleteForeverClicked(TrashEntry entry);
    }

    private final ArrayList<TrashEntry> items;
    private final Listener listener;

    public TrashRowAdapter(ArrayList<TrashEntry> items, Listener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TrashViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_trash_row, parent, false);
        ViewAnimUtils.applyPressFeedback(view);
        return new TrashViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TrashViewHolder holder, int position) {
        final TrashEntry entry = items.get(position);
        holder.titleView.setText(entry.title);
        holder.restoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onRestoreClicked(entry);
            }
        });
        holder.deleteForeverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onDeleteForeverClicked(entry);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class TrashViewHolder extends RecyclerView.ViewHolder {
        TextView titleView;
        ImageButton restoreButton;
        ImageButton deleteForeverButton;

        TrashViewHolder(View itemView) {
            super(itemView);
            titleView = (TextView) itemView.findViewById(R.id.text_trash_title);
            restoreButton = (ImageButton) itemView.findViewById(R.id.button_restore);
            deleteForeverButton = (ImageButton) itemView.findViewById(R.id.button_delete_forever);
        }
    }
}
