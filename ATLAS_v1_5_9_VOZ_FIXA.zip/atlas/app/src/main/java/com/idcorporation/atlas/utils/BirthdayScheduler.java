package com.idcorporation.atlas.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.idcorporation.atlas.receivers.BirthdayCheckReceiver;

import java.util.Calendar;

/**
 * Schedules one repeating daily alarm (around 9 AM local time) that
 * checks how many days remain until the user's birthday, so the
 * "7 days left" warning and the "happy birthday" congratulations both
 * fire without needing the app open.
 */
public class BirthdayScheduler {

    private static final int REQUEST_CODE = 3001;
    private static final int CHECK_HOUR = 9;

    public static void scheduleDailyCheck(Context context) {
        Context appContext = context.getApplicationContext();
        AlarmManager alarmManager = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }

        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, CHECK_HOUR);
        next.set(Calendar.MINUTE, 0);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) {
            next.add(Calendar.DAY_OF_YEAR, 1);
        }

        PendingIntent pendingIntent = buildPendingIntent(appContext);
        try {
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY, pendingIntent);
        } catch (SecurityException e) {
            // Inexact repeating alarms do not need the exact-alarm permission; nothing to fall back to here.
        }
    }

    public static void cancelDailyCheck(Context context) {
        Context appContext = context.getApplicationContext();
        AlarmManager alarmManager = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }
        alarmManager.cancel(buildPendingIntent(appContext));
    }

    private static PendingIntent buildPendingIntent(Context context) {
        Intent intent = new Intent(context, BirthdayCheckReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags | PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
    }
}
