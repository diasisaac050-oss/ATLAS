package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;

import java.util.Locale;

/**
 * ATLAS's language is a user choice inside the app, independent of the
 * phone's system language. This keeps the selected Locale, wraps
 * Context/Configuration with it, and is the single place TTS, speech
 * recognition and the AI prompt all read the current language from.
 */
public class LocaleHelper {

    public static final String LANGUAGE_ENGLISH = "en";
    public static final String LANGUAGE_PORTUGUESE_BR = "pt";
    public static final String LANGUAGE_PORTUGUESE_PT = "pt_pt";
    public static final String LANGUAGE_SPANISH = "es";
    public static final String LANGUAGE_ITALIAN = "it";
    public static final String LANGUAGE_FRENCH = "fr";
    public static final String LANGUAGE_GERMAN = "de";
    public static final String LANGUAGE_POLISH = "pl";

    private static final String PREFS_NAME = "atlas_language_prefs";
    private static final String KEY_LANGUAGE = "selected_language";
    private static final String DEFAULT_LANGUAGE = LANGUAGE_PORTUGUESE_BR;

    public static String getSavedLanguage(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_LANGUAGE, DEFAULT_LANGUAGE);
    }

    public static void setSavedLanguage(Context context, String languageCode) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_LANGUAGE, languageCode).apply();
    }

    public static Locale getLocaleForLanguage(String languageCode) {
        if (LANGUAGE_PORTUGUESE_BR.equals(languageCode)) {
            return new Locale("pt", "BR");
        }
        if (LANGUAGE_PORTUGUESE_PT.equals(languageCode)) {
            return new Locale("pt", "PT");
        }
        if (LANGUAGE_SPANISH.equals(languageCode)) {
            return new Locale("es", "ES");
        }
        if (LANGUAGE_ITALIAN.equals(languageCode)) {
            return new Locale("it", "IT");
        }
        if (LANGUAGE_FRENCH.equals(languageCode)) {
            return new Locale("fr", "FR");
        }
        if (LANGUAGE_GERMAN.equals(languageCode)) {
            return new Locale("de", "DE");
        }
        if (LANGUAGE_POLISH.equals(languageCode)) {
            return new Locale("pl", "PL");
        }
        return Locale.ENGLISH;
    }

    public static String getLanguageDisplayName(String languageCode) {
        if (LANGUAGE_PORTUGUESE_BR.equals(languageCode)) {
            return "Portugues (Brasil)";
        }
        if (LANGUAGE_PORTUGUESE_PT.equals(languageCode)) {
            return "Portugues (Portugal)";
        }
        if (LANGUAGE_SPANISH.equals(languageCode)) {
            return "Espanol";
        }
        if (LANGUAGE_ITALIAN.equals(languageCode)) {
            return "Italiano";
        }
        if (LANGUAGE_FRENCH.equals(languageCode)) {
            return "Francais";
        }
        if (LANGUAGE_GERMAN.equals(languageCode)) {
            return "Deutsch";
        }
        if (LANGUAGE_POLISH.equals(languageCode)) {
            return "Polski";
        }
        return "English";
    }

    public static String[] getSupportedLanguageCodes() {
        return new String[]{
            LANGUAGE_PORTUGUESE_BR, LANGUAGE_PORTUGUESE_PT, LANGUAGE_ENGLISH, LANGUAGE_SPANISH,
            LANGUAGE_ITALIAN, LANGUAGE_FRENCH, LANGUAGE_GERMAN, LANGUAGE_POLISH};
    }

    /** Wraps a Context so its resources/strings resolve using the saved app language. */
    public static Context wrapContext(Context context) {
        String languageCode = getSavedLanguage(context);
        Locale locale = getLocaleForLanguage(languageCode);
        Locale.setDefault(locale);

        Configuration configuration = new Configuration(context.getResources().getConfiguration());
        configuration.setLocale(locale);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return context.createConfigurationContext(configuration);
        }
        context.getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());
        return context;
    }

    /** Human-readable language name the AI is told to answer in (used in the system prompt). */
    public static String getLanguageNameForPrompt(String languageCode) {
        if (LANGUAGE_PORTUGUESE_BR.equals(languageCode)) {
            return "Brazilian Portuguese";
        }
        if (LANGUAGE_PORTUGUESE_PT.equals(languageCode)) {
            return "European Portuguese";
        }
        if (LANGUAGE_SPANISH.equals(languageCode)) {
            return "Spanish";
        }
        if (LANGUAGE_ITALIAN.equals(languageCode)) {
            return "Italian";
        }
        if (LANGUAGE_FRENCH.equals(languageCode)) {
            return "French";
        }
        if (LANGUAGE_GERMAN.equals(languageCode)) {
            return "German";
        }
        if (LANGUAGE_POLISH.equals(languageCode)) {
            return "Polish";
        }
        return "English";
    }
}
