package com.idcorporation.atlas.presence;

import android.content.Context;
import android.view.GestureDetector;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/**
 * Touch rules for the buttonless bubble: double tap, single tap, long
 * press (touch and hold makes the bubble disappear), and a swipe toward
 * the edge it came from (the bubble follows the finger, then either
 * retracts or springs back). The glass layout comes from the top so it is
 * dismissed by swiping up; the orb comes from the bottom so it is
 * dismissed by swiping down. Callback.onSwipeUp is used for both.
 *
 * Sideways drag: grabbing the sphere and dragging it horizontally is reported
 * through onDragStart / onDrag / onDragEnd so the controller can move the
 * window and park the sphere at the side of the screen. Once it is parked
 * (Callback.isDocked) any drag moves it around and the vertical swipe-to-dismiss
 * is off, because the parked sphere is a small window of its own.
 */
public class PresenceTouchHandler implements View.OnTouchListener {

    public interface Callback {
        void onDoubleTap();
        void onSingleTap();
        void onLongPress();
        void onSwipeUp();
        void onTouched();

        /** The finger started dragging the sphere sideways (or any way, when parked). */
        void onDragStart();

        /** Finger offset from where it went down, in px. */
        void onDrag(float dx, float dy);

        /** Finger lifted (or the gesture was cancelled) after a drag. */
        void onDragEnd(float dx, float dy);

        /** True while the sphere is parked (or being parked) at the side of the screen. */
        boolean isDocked();
    }

    private final Callback callback;
    private final GestureDetector detector;
    private final float dismissDistance;
    private final float touchSlop;
    private final boolean dismissDownward;
    private final PresenceBubbleView bubbleProvider;
    private float downX = 0f;
    private float downY = 0f;
    private boolean longPressed = false;
    private boolean dragging = false;

    public PresenceTouchHandler(Context context, PresenceBubbleView bubble, Callback cb) {
        this(context, bubble, false, cb);
    }

    public PresenceTouchHandler(Context context, PresenceBubbleView bubble,
                                boolean dismissDownward, Callback cb) {
        this.dismissDownward = dismissDownward;
        this.callback = cb;
        this.bubbleProvider = bubble;
        this.dismissDistance = 46f * context.getResources().getDisplayMetrics().density;
        this.touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.detector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                callback.onDoubleTap();
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                callback.onSingleTap();
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                longPressed = true;
                bubbleProvider.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                callback.onLongPress();
            }
        });
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getActionMasked();

        if (dragging) {
            // The gesture detector was cancelled when the drag began; the drag owns the rest.
            float dx = event.getRawX() - downX;
            float dy = event.getRawY() - downY;
            if (action == MotionEvent.ACTION_MOVE) {
                callback.onDrag(dx, dy);
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                dragging = false;
                callback.onDragEnd(dx, dy);
            }
            return true;
        }

        detector.onTouchEvent(event);
        boolean docked = callback.isDocked();

        if (action == MotionEvent.ACTION_DOWN) {
            downX = event.getRawX();
            downY = event.getRawY();
            longPressed = false;
            callback.onTouched();
        } else if (action == MotionEvent.ACTION_MOVE) {
            float dx = event.getRawX() - downX;
            float dy = event.getRawY() - downY;
            if (!longPressed && startsDrag(docked, dx, dy)) {
                dragging = true;
                MotionEvent cancel = MotionEvent.obtain(event);
                cancel.setAction(MotionEvent.ACTION_CANCEL);
                detector.onTouchEvent(cancel);
                cancel.recycle();
                bubbleProvider.animate().cancel();
                bubbleProvider.setTranslationY(0f);
                callback.onDragStart();
                callback.onDrag(dx, dy);
                return true;
            }
            if (!docked) {
                float toward = dismissDownward ? dy : -dy;
                if (toward > 0f && !longPressed) {
                    bubbleProvider.setTranslationY(dy * 0.6f);
                }
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            if (longPressed || docked) {
                return true;
            }
            float dy = event.getRawY() - downY;
            float toward = dismissDownward ? dy : -dy;
            if (toward > dismissDistance) {
                callback.onSwipeUp();
            } else {
                bubbleProvider.animate().translationY(0f).setDuration(180).start();
            }
        }
        return true;
    }

    private boolean startsDrag(boolean docked, float dx, float dy) {
        if (docked) {
            return Math.hypot(dx, dy) > touchSlop;
        }
        // Not parked: only a clearly sideways move grabs the sphere, so the vertical
        // swipe that retires it keeps working exactly as before.
        return Math.abs(dx) > touchSlop * 1.5f && Math.abs(dx) > Math.abs(dy) * 1.3f;
    }
}
