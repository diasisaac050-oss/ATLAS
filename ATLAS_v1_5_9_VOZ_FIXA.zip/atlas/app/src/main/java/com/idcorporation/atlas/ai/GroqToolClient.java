package com.idcorporation.atlas.ai;

import com.idcorporation.atlas.agent.ModelClient;
import com.idcorporation.atlas.agent.ModelReply;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

/**
 * Tool-calling (function calling) transport for the SAME Groq model the
 * app already uses - nothing about the model changed. Blocking: the agent
 * loop calls it from a worker thread. Same endpoint, same key, same rules
 * as GroqProvider (https only, no redirects, key only ever sent to Groq).
 */
public class GroqToolClient implements ModelClient {

    private static final int CONNECT_TIMEOUT_MS = 15000;
    private static final int READ_TIMEOUT_MS = 30000;
    private static final int MAX_RESPONSE_CHARS = 200000;
    // Kept under the on-demand token-per-minute ceilings of Groq's free tier.
    private static final int MAX_TOKENS = 900;

    /** Overridable for tests / future provider swap. */
    protected String endpoint() {
        return GroqProvider.GROQ_ENDPOINT;
    }

    protected String model() {
        return GroqProvider.GROQ_MODEL;
    }

    protected String apiKey() {
        return ApiKeyConfig.GROQ_API_KEY;
    }

    @Override
    public ModelReply chat(JSONArray messages, JSONArray tools, boolean toolsEnabled) throws ModelException {
        boolean useTools = tools != null && tools.length() > 0;
        // First try with a low reasoning effort (fast, cheap); if the API rejects that
        // parameter for any reason, retry once without it.
        try {
            return doChat(messages, tools, useTools, toolsEnabled, true);
        } catch (ModelException e) {
            if (e.code == 400 && e.getMessage() != null && e.getMessage().contains("reasoning")) {
                return doChat(messages, tools, useTools, toolsEnabled, false);
            }
            throw e;
        }
    }

    private ModelReply doChat(JSONArray messages, JSONArray tools, boolean useTools, boolean toolsEnabled,
                              boolean withReasoningEffort) throws ModelException {
        String body;
        try {
            JSONObject root = new JSONObject();
            root.put("model", model());
            root.put("temperature", 0.6);
            root.put("max_tokens", MAX_TOKENS);
            if (withReasoningEffort) {
                root.put("reasoning_effort", "low");
            }
            root.put("messages", messages);
            if (useTools) {
                root.put("tools", tools);
                root.put("tool_choice", toolsEnabled ? "auto" : "none");
            }
            body = root.toString();
        } catch (Exception e) {
            throw new ModelException("Could not build request.", -3);
        }

        HttpURLConnection connection = null;
        try {
            URL url = new URL(endpoint());
            if (!"https".equals(url.getProtocol())) {
                throw new ModelException("Insecure endpoint blocked.", -4);
            }
            connection = (HttpURLConnection) url.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Authorization", "Bearer " + apiKey());
            connection.setRequestProperty("X-Atlas-Client", "ATLAS by ID | CORPORATION");
            OutputStream out = connection.getOutputStream();
            out.write(body.getBytes(Charset.forName("UTF-8")));
            out.flush();
            out.close();

            int status = connection.getResponseCode();
            if (status != 200) {
                String err = readStream(connection.getErrorStream());
                String snippet = err.length() > 300 ? err.substring(0, 300) : err;
                throw new ModelException("HTTP " + status + " " + snippet, status);
            }
            return parse(readStream(connection.getInputStream()));
        } catch (ModelException e) {
            throw e;
        } catch (java.net.SocketTimeoutException e) {
            throw new ModelException("timeout", -1);
        } catch (java.io.IOException e) {
            throw new ModelException("network", -2);
        } catch (Exception e) {
            throw new ModelException("unexpected", -3);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    /** Package-visible so the parsing can be tested without a network. */
    static ModelReply parse(String rawJson) throws ModelException {
        try {
            JSONObject root = new JSONObject(rawJson);
            JSONArray choices = root.optJSONArray("choices");
            if (choices == null || choices.length() == 0) {
                throw new ModelException("no choices", -3);
            }
            JSONObject message = choices.getJSONObject(0).optJSONObject("message");
            if (message == null) {
                throw new ModelException("no message", -3);
            }
            String content = message.isNull("content") ? "" : message.optString("content", "");
            JSONObject clean = new JSONObject();
            clean.put("role", "assistant");
            clean.put("content", content);
            JSONArray rawCalls = message.optJSONArray("tool_calls");
            if (rawCalls != null && rawCalls.length() > 0) {
                clean.put("tool_calls", rawCalls);
            }
            ModelReply reply = new ModelReply(content, clean);
            if (rawCalls != null) {
                for (int i = 0; i < rawCalls.length(); i++) {
                    JSONObject call = rawCalls.getJSONObject(i);
                    JSONObject fn = call.optJSONObject("function");
                    if (fn == null) {
                        continue;
                    }
                    String name = fn.optString("name", "");
                    if (name.length() == 0) {
                        continue;
                    }
                    reply.toolCalls.add(new ModelReply.ToolCall(call.optString("id", "call_" + i),
                        name, fn.optString("arguments", "{}")));
                }
            }
            return reply;
        } catch (ModelException e) {
            throw e;
        } catch (Exception e) {
            throw new ModelException("bad response", -3);
        }
    }

    private static String readStream(InputStream in) throws java.io.IOException {
        if (in == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, Charset.forName("UTF-8")));
        String line = reader.readLine();
        while (line != null) {
            sb.append(line);
            if (sb.length() > MAX_RESPONSE_CHARS) {
                break;
            }
            line = reader.readLine();
        }
        reader.close();
        return sb.toString();
    }
}
