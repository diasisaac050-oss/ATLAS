package com.idcorporation.atlas.activities;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Toast;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.services.ScreenshotService;

/**
 * Invisible activity whose only purpose is to show Android's own
 * screen-capture consent dialog (MediaProjection). This dialog can only
 * be triggered from an Activity, and by platform design the user must
 * see and accept it fresh every single time - there is no way for ATLAS
 * (or any app) to skip it, since that is exactly the protection Android
 * puts on screen recording. As soon as a result comes back, this hands
 * off to ScreenshotService and closes itself; nothing is drawn on
 * screen the user would notice.
 */
public class ScreenshotActivity extends Activity {

    private static final int REQUEST_CODE_CAPTURE = 9001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MediaProjectionManager projectionManager =
            (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (projectionManager == null) {
            finish();
            return;
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CODE_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CODE_CAPTURE) {
            finish();
            return;
        }
        if (resultCode != Activity.RESULT_OK || data == null) {
            Toast.makeText(this, R.string.screenshot_permission_denied, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Intent serviceIntent = new Intent(this, ScreenshotService.class);
        serviceIntent.putExtra(ScreenshotService.EXTRA_RESULT_CODE, resultCode);
        serviceIntent.putExtra(ScreenshotService.EXTRA_RESULT_DATA, data);
        androidx.core.content.ContextCompat.startForegroundService(this, serviceIntent);
        finish();
    }
}
