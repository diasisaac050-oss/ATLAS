package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.security.SecurityManager;

/**
 * First onboarding question: the user's full name.
 */
public class OnboardingNameActivity extends OnboardingStepActivity {

    private static final int STEP_INDEX = 1;
    private static final int TOTAL_STEPS = 6;

    private EditText fullNameInput;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_name);

        View backButton = findViewById(R.id.button_step_back);
        ViewGroup dotsContainer = (ViewGroup) findViewById(R.id.container_step_dots);
        View badge = findViewById(R.id.badge_name);
        View title = findViewById(R.id.text_name_question);
        fullNameInput = (EditText) findViewById(R.id.input_full_name);
        errorText = (TextView) findViewById(R.id.text_name_error);
        final View continueButton = findViewById(R.id.button_name_continue);

        renderProgressDots(dotsContainer, STEP_INDEX, TOTAL_STEPS);
        animateEntrance(badge, title, null, fullNameInput, continueButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bounceButton(continueButton);
                attemptContinue();
            }
        });
    }

    private void attemptContinue() {
        String fullName = fullNameInput.getText().toString();

        if (!SecurityManager.isValidName(fullName)) {
            showFieldError(errorText, getString(R.string.error_full_name_required));
            return;
        }

        Intent next = buildForwardIntent(OnboardingCallNameActivity.class);
        next.putExtra(OnboardingKeys.FULL_NAME, fullName.trim());
        goToNext(next);
    }
}
