package com.idcorporation.atlas.activities;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.calendar.CalendarDateUtils;
import com.idcorporation.atlas.calendar.CalendarEventManager;
import com.idcorporation.atlas.calendar.CalendarEventRowAdapter;
import com.idcorporation.atlas.models.CalendarEventItem;
import com.idcorporation.atlas.utils.AlarmScheduler;
import com.idcorporation.atlas.utils.SoundManager;

import java.util.ArrayList;
import java.util.Locale;

public class DayEventsActivity extends BaseActivity {

    public static final String EXTRA_YEAR = "extra_year";
    public static final String EXTRA_MONTH = "extra_month";
    public static final String EXTRA_DAY = "extra_day";

    private int year;
    private int month;
    private int day;
    private int pickedHour = -1;
    private int pickedMinute = -1;

    private CalendarEventManager eventManager;
    private CalendarEventRowAdapter adapter;
    private final ArrayList<CalendarEventItem> items = new ArrayList<CalendarEventItem>();

    private TextView emptyView;
    private RecyclerView recyclerView;
    private TextView timePickerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_events);
        forceLightBackground();

        year = getIntent().getIntExtra(EXTRA_YEAR, CalendarDateUtils.ANCHOR_YEAR);
        month = getIntent().getIntExtra(EXTRA_MONTH, CalendarDateUtils.ANCHOR_MONTH);
        day = getIntent().getIntExtra(EXTRA_DAY, 1);
        eventManager = new CalendarEventManager(this);

        TextView titleView = (TextView) findViewById(R.id.text_day_events_title);
        titleView.setText(day + " de " + CalendarDateUtils.monthNamePt(month) + " de " + year);

        emptyView = (TextView) findViewById(R.id.text_day_events_empty);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_day_events);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CalendarEventRowAdapter(items, new CalendarEventRowAdapter.OnEventDeleteListener() {
            @Override
            public void onDelete(long eventId) {
                eventManager.deleteEvent(eventId);
                reloadEvents();
            }
        });
        recyclerView.setAdapter(adapter);

        timePickerButton = (TextView) findViewById(R.id.button_pick_time);
        final EditText titleInput = (EditText) findViewById(R.id.input_new_event_title);

        findViewById(R.id.button_day_events_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        timePickerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePicker();
            }
        });

        findViewById(R.id.button_add_event).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleInput.getText().toString().trim();
                if (title.length() == 0) {
                    title = getString(R.string.default_reminder_title);
                }
                addEvent(title);
                titleInput.setText("");
                pickedHour = -1;
                pickedMinute = -1;
                timePickerButton.setText(R.string.calendar_pick_time);
            }
        });

        reloadEvents();
    }

    private void showTimePicker() {
        TimePickerDialog dialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                pickedHour = hourOfDay;
                pickedMinute = minute;
                timePickerButton.setText(String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute));
            }
        }, 9, 0, true);
        dialog.show();
    }

    private void addEvent(String title) {
        eventManager.addEvent(year, month, day, pickedHour, pickedMinute, title,
            CalendarEventItem.TYPE_REMINDER, false);
        SoundManager.playEventMarked(this);

        if (pickedHour >= 0 && pickedMinute >= 0) {
            long triggerMillis = CalendarDateUtils.toEpochMillis(year, month, day, pickedHour, pickedMinute);
            if (triggerMillis > System.currentTimeMillis()) {
                int requestCode = (int) (triggerMillis % Integer.MAX_VALUE);
                AlarmScheduler.scheduleAlarm(this, triggerMillis, requestCode, title,
                    getString(R.string.alarm_reminder_message));
            }
        }

        reloadEvents();
    }

    private void reloadEvents() {
        items.clear();
        items.addAll(eventManager.getEventsForDate(year, month, day));
        adapter.notifyDataSetChanged();
        boolean empty = items.isEmpty();
        emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        forceLightBackground();
    }

    private void forceLightBackground() {
        View root = findViewById(R.id.day_events_root);
        if (root != null) {
            root.setBackgroundColor(Color.WHITE);
        }
        ViewGroup contentRoot = (ViewGroup) findViewById(android.R.id.content);
        if (contentRoot != null) {
            View animatedBg = contentRoot.findViewWithTag("atlas_animated_bg");
            if (animatedBg != null) {
                animatedBg.setVisibility(View.GONE);
            }
        }
    }
}
