package com.idcorporation.atlas.agent;

import org.json.JSONObject;

/**
 * One real capability the agent can use. Tools are the ONLY way the model
 * touches the phone: the model emits a tool name + JSON arguments, this
 * code validates and runs a fixed, reviewed implementation. Nothing the
 * model writes is ever executed as code.
 */
public interface AgentTool {

    String name();

    /** One or two short sentences - these are sent with every request, so keep them lean. */
    String description();

    /** JSON-schema "parameters" object. */
    JSONObject parameters();

    /** True when the result contains text from outside (web pages, news, map data). */
    boolean returnsUntrustedContent();

    /**
     * True when the tool changes state outside the app (messages, notes,
     * reminders, calls, any device command). Such tools are blocked after
     * untrusted content was read in the same run - see AgentRunner.
     */
    boolean changesState();

    ToolResult execute(JSONObject args) throws Exception;
}
