package com.idcorporation.atlas.calendar;

import android.content.Context;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Backs the horizontal month pager. Position CENTER_POSITION always
 * corresponds to the current real-world month; every other position is
 * an offset from it, in both directions, going back and forward
 * thousands of years - effectively infinite for anything a person
 * would actually scroll to.
 */
public class CalendarMonthAdapter extends RecyclerView.Adapter<CalendarMonthAdapter.MonthViewHolder> {

    public static final int CENTER_POSITION = 60000;
    private static final int ITEM_COUNT = 120001;

    private final Context context;
    private final CalendarEventManager eventManager;
    private final MonthGridView.OnDayClickListener dayClickListener;

    public CalendarMonthAdapter(Context context, CalendarEventManager eventManager,
            MonthGridView.OnDayClickListener dayClickListener) {
        this.context = context;
        this.eventManager = eventManager;
        this.dayClickListener = dayClickListener;
    }

    public static int offsetForPosition(int position) {
        return position - CENTER_POSITION;
    }

    @NonNull
    @Override
    public MonthViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MonthGridView gridView = new MonthGridView(context);
        gridView.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.MATCH_PARENT));
        return new MonthViewHolder(gridView);
    }

    @Override
    public void onBindViewHolder(@NonNull MonthViewHolder holder, int position) {
        int offset = offsetForPosition(position);
        int[] yearMonth = CalendarDateUtils.positionToYearMonth(offset);
        int year = yearMonth[0];
        int month = yearMonth[1];

        java.util.HashSet<Integer> eventDays = eventManager.getEventDaysForMonth(year, month);

        Integer birthdayDay = null;
        com.idcorporation.atlas.models.CalendarEventItem birthday = eventManager.getBirthday();
        if (birthday != null && birthday.getMonth() == month) {
            birthdayDay = Integer.valueOf(birthday.getDay());
        }

        holder.gridView.bind(year, month, eventDays, birthdayDay, dayClickListener);
    }

    @Override
    public int getItemCount() {
        return ITEM_COUNT;
    }

    public int[] yearMonthForPosition(int position) {
        return CalendarDateUtils.positionToYearMonth(offsetForPosition(position));
    }

    static class MonthViewHolder extends RecyclerView.ViewHolder {
        final MonthGridView gridView;

        MonthViewHolder(MonthGridView itemView) {
            super(itemView);
            this.gridView = itemView;
        }
    }
}
