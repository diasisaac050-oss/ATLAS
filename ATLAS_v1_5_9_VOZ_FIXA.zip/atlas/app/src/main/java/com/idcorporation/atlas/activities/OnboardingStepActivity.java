package com.idcorporation.atlas.activities;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import com.idcorporation.atlas.R;

/**
 * Shared behaviour for every individual onboarding question screen:
 * staggered entrance animation, a top progress-dot row, a shake-to-warn
 * error style and a helper to carry the data collected so far forward
 * to the next screen via Intent extras.
 */
public abstract class OnboardingStepActivity extends BaseActivity {

    @Override
    protected boolean isVoiceCallScreen() {
        return false;
    }


    protected void renderProgressDots(ViewGroup container, int currentStep, int totalSteps) {
        container.removeAllViews();
        for (int i = 0; i < totalSteps; i++) {
            ImageView dot = new ImageView(this);
            boolean isDone = i <= currentStep;
            dot.setImageResource(isDone ? R.drawable.onboarding_dot_active : R.drawable.onboarding_dot_inactive);
            ViewGroup.MarginLayoutParams params = new ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(4, 0, 4, 0);
            dot.setLayoutParams(params);
            container.addView(dot);
        }
    }

    protected void animateEntrance(View badge, View title, View subtitle, View inputArea, View button) {
        View[] sequence = new View[] { badge, title, subtitle, inputArea, button };
        long delay = 0L;
        for (int i = 0; i < sequence.length; i++) {
            View target = sequence[i];
            if (target == null) {
                continue;
            }
            target.setAlpha(0f);
            target.setTranslationY(24f);
            ObjectAnimator fade = ObjectAnimator.ofFloat(target, "alpha", 0f, 1f);
            ObjectAnimator slide = ObjectAnimator.ofFloat(target, "translationY", 24f, 0f);
            fade.setStartDelay(delay);
            slide.setStartDelay(delay);
            fade.setDuration(420);
            slide.setDuration(420);
            slide.setInterpolator(new AccelerateDecelerateInterpolator());
            fade.start();
            slide.start();
            delay += 110L;
        }
    }

    protected void bounceButton(View button) {
        ObjectAnimator shrink = ObjectAnimator.ofFloat(button, "scaleX", 1f, 0.94f, 1f);
        ObjectAnimator shrinkY = ObjectAnimator.ofFloat(button, "scaleY", 1f, 0.94f, 1f);
        shrink.setDuration(180);
        shrinkY.setDuration(180);
        shrink.start();
        shrinkY.start();
    }

    protected void showFieldError(TextView errorView, String message) {
        errorView.setText(message);
        errorView.setVisibility(View.VISIBLE);
        errorView.setAlpha(0f);
        errorView.animate().alpha(1f).setDuration(200).start();

        ObjectAnimator shake = ObjectAnimator.ofFloat(errorView, "translationX",
            0f, -12f, 12f, -8f, 8f, -4f, 4f, 0f);
        shake.setDuration(420);
        shake.start();
    }

    protected Intent buildForwardIntent(Class<?> nextActivityClass) {
        Intent next = new Intent(this, nextActivityClass);
        if (getIntent().getExtras() != null) {
            next.putExtras(getIntent().getExtras());
        }
        return next;
    }

    protected void goToNext(Intent next) {
        startActivity(next);
        finish();
    }

    protected void fadeOutThenRun(View root, final Runnable action) {
        root.animate().alpha(0f).setDuration(180).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                action.run();
            }
        }).start();
    }
}
