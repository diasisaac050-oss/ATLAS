package com.idcorporation.atlas.contacts;

/**
 * WhatsApp's officially supported "click to chat" link (https://wa.me/)
 * needs the phone number as digits only, with the country code and no
 * leading zero or plus sign. Numbers saved locally on a Brazilian
 * user's phone are usually stored without the country code, so this
 * fills in 55 when the shape of the number looks like a bare Brazilian
 * number and nothing else was given.
 */
public class PhoneNumberUtils {

    private static final String DEFAULT_COUNTRY_CODE = "55";

    public static String toWhatsappDigits(String rawNumber) {
        if (rawNumber == null) {
            return "";
        }
        String digits = rawNumber.replaceAll("[^0-9]", "");
        if (digits.length() == 0) {
            return digits;
        }
        if (digits.startsWith("00")) {
            digits = digits.substring(2);
        }
        if (digits.length() > 2 && digits.startsWith("0") && !digits.startsWith("00")) {
            digits = digits.substring(1);
        }
        if (digits.startsWith(DEFAULT_COUNTRY_CODE)) {
            return digits;
        }
        // A bare Brazilian number is 10 or 11 digits (area code + number,
        // 9-digit mobile or 8-digit landline). Anything already longer is
        // assumed to include its own country code.
        if (digits.length() == 10 || digits.length() == 11) {
            return DEFAULT_COUNTRY_CODE + digits;
        }
        return digits;
    }
}
