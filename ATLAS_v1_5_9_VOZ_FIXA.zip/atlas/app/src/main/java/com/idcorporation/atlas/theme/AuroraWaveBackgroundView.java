package com.idcorporation.atlas.theme;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public class AuroraWaveBackgroundView extends View implements ThemeBackgroundView {

    private static final int BAND_COUNT = 3;

    private int backgroundColor;
    private int waveColor;
    private float phase = 0f;
    private final Paint wavePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public AuroraWaveBackgroundView(Context context) {
        super(context);
        wavePaint.setStyle(Paint.Style.STROKE);
        wavePaint.setStrokeWidth(6f);
    }

    @Override
    public void setPalette(ThemePalette palette) {
        this.backgroundColor = palette.getBackgroundColor();
        this.waveColor = palette.getBackgroundColorAlt();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();

        canvas.drawColor(backgroundColor);

        phase = phase + 0.04f;

        for (int band = 0; band < BAND_COUNT; band = band + 1) {
            Path path = new Path();
            float baseY = height * (0.3f + band * 0.22f);
            float amplitude = 40f + band * 12f;
            int alpha = 90 - band * 20;
            if (alpha < 25) {
                alpha = 25;
            }
            wavePaint.setColor(withAlpha(waveColor, alpha));

            path.moveTo(0f, baseY);
            for (float x = 0f; x <= width; x = x + 12f) {
                double sinInput = (x * 0.015) + phase + band;
                float y = baseY + (float) Math.sin(sinInput) * amplitude;
                path.lineTo(x, y);
            }
            canvas.drawPath(path, wavePaint);
        }

        invalidate();
    }

    private int withAlpha(int color, int alpha) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    @Override
    public void stopAnimating() {
    }
}
