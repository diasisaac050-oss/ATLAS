package com.idcorporation.atlas.presence;

import com.idcorporation.atlas.utils.PresenceManager;

/**
 * Where the 3D sphere sits, how big it is and how opaque, for each Presence
 * layout, frame by frame. Pure maths (no Android classes). Every layout keeps
 * its own anchor, and in every layout the sphere is born SMALL and grows while
 * it travels in; on the way out the very same curve runs backwards, so it
 * contracts and goes back where it came from (nothing pops in or out):
 *  - GLASS   : drops from the top edge, small, growing as it falls (calm spring)
 *  - ORB     : rises from the bottom, small, growing, with a little overshoot
 *  - NUCLEUS : glides up from below into the middle and only blooms to full size
 *              near the middle; leaving, it contracts first and then sinks
 *  - CARD    : blooms open from a tiny point in the centre of its panel
 * It also handles the "docked" look: the sphere parked small at the side of
 * the screen (st.dock while it shrinks, st.docked once the window is the small square).
 */
final class PresenceSpherePlacement {

    /** Smallest size a sphere has when it is born / gone, as a fraction of its full radius. */
    private static final float MIN_SCALE = 0.05f;
    /** Radius of the parked sphere, in dp. */
    static final float DOCK_RADIUS_DP = 28f;

    private static float clamp01(float x) {
        return x < 0f ? 0f : (x > 1f ? 1f : x);
    }

    private static float smooth(float x) {
        float t = clamp01(x);
        return t * t * (3f - 2f * t);
    }

    /** out = { centerX, centerY, radius, opacity } in px. */
    static void compute(int layout, float w, float h, float d, PresenceBubbleState st, float[] out) {
        float p = st.open;
        float shake = (float) Math.sin(st.phase * 38.0) * 2f * d * st.errAmt;
        float cx = w / 2f + shake;
        float cy;
        float r;
        float alpha;

        if (st.docked) {
            // The window is the small docked square: sphere centred, constant size.
            // Opening/closing (p) still scales it so retiring it from the side contracts it too.
            float e = smooth(p);
            out[0] = w / 2f;
            out[1] = h / 2f;
            out[2] = Math.max(1f, DOCK_RADIUS_DP * d * e);
            out[3] = clamp01(p * 2.2f);
            return;
        }

        if (layout == PresenceManager.LAYOUT_ORB) {
            float full = 55f * d;
            float restY = 95f * d;
            float travel = full * 2f + 60f * d;
            cy = restY + (1f - p) * travel;
            r = full * (MIN_SCALE + (1f - MIN_SCALE) * Math.min(p, 1.12f));
            alpha = smooth(p / 0.45f);
        } else if (layout == PresenceManager.LAYOUT_NUCLEUS) {
            float posT = clamp01(p);
            float glide = smooth(posT);
            cy = (800f + (400f - 800f) * glide) * d;
            // Size lags behind the travel: it is a small spark while it climbs and
            // swells as it reaches the middle (and, leaving, it contracts first).
            float grow = (float) Math.pow(posT, 1.6);
            r = 96f * d * (MIN_SCALE + (1f - MIN_SCALE) * grow);
            alpha = smooth(posT / 0.4f);
        } else if (layout == PresenceManager.LAYOUT_CARD) {
            float bloom = (float) Math.pow(Math.max(0f, p), 0.82);
            cy = h / 2f;
            r = 84f * d * (MIN_SCALE + (1f - MIN_SCALE) * Math.min(1.1f, bloom));
            alpha = smooth(p / 0.4f);
        } else {
            float full = 54f * d;
            float restY = 84f * d;
            float travel = restY + full * 0.6f;
            cy = restY - (1f - p) * travel;
            r = full * (MIN_SCALE + (1f - MIN_SCALE) * Math.min(p, 1.1f));
            alpha = smooth(p / 0.45f);
        }

        // Shrinking toward the docked size (before the window itself is resized).
        if (st.dock > 0f) {
            float e = smooth(st.dock);
            r = r + (DOCK_RADIUS_DP * d - r) * e;
        }

        out[0] = cx;
        out[1] = cy;
        out[2] = r;
        out[3] = clamp01(alpha);
    }

    private PresenceSpherePlacement() {
    }
}
