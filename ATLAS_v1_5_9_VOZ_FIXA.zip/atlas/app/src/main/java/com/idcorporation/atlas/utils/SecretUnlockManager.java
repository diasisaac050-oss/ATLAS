package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SecretUnlockManager {

    public static final String SECRET_CODE = "0112201112";

    private static final String PREFS_NAME = "atlas_secret_prefs";
    private static final String KEY_UNLOCKED = "lore_unlocked";
    private static final String KEY_VIEWED = "lore_viewed";

    public static boolean matchesSecretCode(String rawText) {
        if (rawText == null) {
            return false;
        }
        String digitsOnly = rawText.replaceAll("[^0-9]", "");
        return SECRET_CODE.equals(digitsOnly);
    }

    public static void unlock(Context context) {
        if (isPermanentlyViewed(context)) {
            return;
        }
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_UNLOCKED, true).apply();
    }

    /** True only between being unlocked and being viewed once - this is when the Settings row should show. */
    public static boolean shouldShowInSettings(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean unlocked = prefs.getBoolean(KEY_UNLOCKED, false);
        boolean viewed = prefs.getBoolean(KEY_VIEWED, false);
        return unlocked && !viewed;
    }

    public static boolean isPermanentlyViewed(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_VIEWED, false);
    }

    /** Call once the lore screen has actually been shown - locks it away forever after this. */
    public static void markPermanentlyViewed(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_VIEWED, true).apply();
    }
}
