package com.idcorporation.atlas.agent.tools;

import com.idcorporation.atlas.agent.AgentTool;

import java.util.ArrayList;

/** The fixed list of tools the agent may use. Adding a capability means adding a class here, nothing else. */
public final class ToolRegistry {

    private ToolRegistry() {
    }

    public static ArrayList<AgentTool> build(ToolEnv env) {
        ArrayList<AgentTool> list = new ArrayList<AgentTool>();
        list.add(new RunDeviceCommandTool(env));
        list.add(new OpenAppTool(env));
        AgentTool[] contacts = ContactTools.all(env);
        for (int i = 0; i < contacts.length; i++) {
            list.add(contacts[i]);
        }
        list.add(new WeatherTool(env));
        list.add(new NewsTool(env));
        list.add(new SearchTool(env));
        list.add(new PlacesTool(env));
        AgentTool[] web = OpenUrlAndEmailTools.all(env);
        for (int i = 0; i < web.length; i++) {
            list.add(web[i]);
        }
        return list;
    }
}
