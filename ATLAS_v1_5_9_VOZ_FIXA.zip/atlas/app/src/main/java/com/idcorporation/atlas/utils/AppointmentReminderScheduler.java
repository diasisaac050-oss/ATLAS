package com.idcorporation.atlas.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.receivers.AppointmentReminderReceiver;

import java.util.Random;

/**
 * ATLAS GENESYS - Compromissos: schedules the exact-time notification for a
 * compromisso the user asked ATLAS to note down. Deliberately separate from
 * AlarmScheduler: a compromisso should only nudge the user with a
 * notification, never ring like a despertador.
 */
public class AppointmentReminderScheduler {

    public static final String EXTRA_TITLE = "atlas_appointment_title";
    public static final String EXTRA_MESSAGE = "atlas_appointment_message";
    public static final String EXTRA_NOTIFICATION_ID = "atlas_appointment_notification_id";
    // ATLAS FASE 3/4 item 21: carried so AppointmentReminderReceiver can look the
    // event back up and, if it is a recurring compromisso, roll it forward to its
    // next occurrence once this one has fired. -1 means "not tied to a stored event".
    public static final String EXTRA_EVENT_ID = "atlas_appointment_event_id";

    private static final Random RANDOM = new Random();

    /**
     * Builds the message ATLAS sends when a compromisso comes due. Picks
     * one of several natural phrasings (see notif_compromisso_messages)
     * instead of always repeating the exact same sentence - ATLAS FASE 3/4
     * item 16 ("lembretes humanos"). Falls back to the single legacy
     * string if, for any reason, the array comes back empty.
     */
    public static String buildMessage(Context context, String userName, String appointmentTitle, String time) {
        String name = (userName == null || userName.length() == 0)
            ? context.getString(R.string.default_user_name_fallback) : userName;

        Resources resources = context.getResources();
        String[] templates = resources.getStringArray(R.array.notif_compromisso_messages);
        if (templates.length == 0) {
            return context.getString(R.string.compromisso_notification_message, name, appointmentTitle, time);
        }
        String template = templates[RANDOM.nextInt(templates.length)];
        return String.format(template, name, appointmentTitle, time);
    }

    public static void scheduleAppointment(Context context, long triggerMillis, int requestCode,
            String title, String message, long eventId) {
        Context appContext = context.getApplicationContext();
        AlarmManager alarmManager = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }

        Intent intent = new Intent(appContext, AppointmentReminderReceiver.class);
        intent.putExtra(EXTRA_TITLE, title);
        intent.putExtra(EXTRA_MESSAGE, message);
        intent.putExtra(EXTRA_NOTIFICATION_ID, requestCode);
        intent.putExtra(EXTRA_EVENT_ID, eventId);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags | PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getBroadcast(appContext, requestCode, intent, flags);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent);
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent);
            }
        } catch (SecurityException e) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent);
        }
    }

    public static void cancelAppointment(Context context, int requestCode) {
        Context appContext = context.getApplicationContext();
        AlarmManager alarmManager = (AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }
        Intent intent = new Intent(appContext, AppointmentReminderReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags | PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getBroadcast(appContext, requestCode, intent, flags);
        alarmManager.cancel(pendingIntent);
    }
}
