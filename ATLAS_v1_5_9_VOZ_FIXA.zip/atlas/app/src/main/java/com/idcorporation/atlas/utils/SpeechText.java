package com.idcorporation.atlas.utils;

import java.util.ArrayList;

/**
 * Text clean-up that exists ONLY for what is spoken aloud. Nothing here
 * changes what is stored, shown in the chat, or used to find a contact:
 * the original name/text always stays untouched, this just produces the
 * string handed to text-to-speech.
 *
 * Without it the TTS engine reads emojis out loud ("red heart", "ribbon")
 * and decorated contact names such as "Minha Princesa" followed by a
 * ribbon and a heart turn into a long list of emoji names.
 */
public final class SpeechText {

    private static final int DEGREE_SIGN = 0x00B0;
    private static final int ZWJ = 0x200D;
    private static final int VS15 = 0xFE0E;
    private static final int VS16 = 0xFE0F;
    private static final int KEYCAP = 0x20E3;

    private SpeechText() {
    }

    /** True for emoji, pictographs, dingbats, regional-indicator flags, skin-tone modifiers and joiners. */
    private static boolean isEmojiLike(int cp, int type) {
        if (cp == DEGREE_SIGN) {
            return false; // "27 degrees" must keep its degree sign
        }
        if (cp == ZWJ || cp == VS15 || cp == VS16 || cp == KEYCAP) {
            return true;
        }
        if (cp >= 0xE0020 && cp <= 0xE007F) {
            return true; // tag characters used by subdivision flags
        }
        if (cp >= 0x1F3FB && cp <= 0x1F3FF) {
            return true; // skin tone modifiers
        }
        return type == Character.OTHER_SYMBOL || type == Character.MODIFIER_SYMBOL;
    }

    /**
     * Removes emojis and decorative symbols from any text before TTS.
     * Letters, digits, punctuation, math signs and currency stay.
     */
    public static String forSpeech(String text) {
        if (text == null) {
            return "";
        }
        StringBuilder out = new StringBuilder(text.length());
        int i = 0;
        while (i < text.length()) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            if (isEmojiLike(cp, Character.getType(cp))) {
                continue;
            }
            out.appendCodePoint(cp);
        }
        return collapse(out.toString());
    }

    /**
     * What to say for a saved contact name: the readable text only.
     * "Minha Princesa" + ribbon + heart -> "Minha Princesa".
     * Returns "" when nothing readable is left (emoji-only contact) so
     * the caller can ask / use a spoken fallback instead of reading
     * a string of emoji names. Letters of every script are kept.
     */
    public static String contactName(String savedName) {
        if (savedName == null) {
            return "";
        }
        StringBuilder out = new StringBuilder(savedName.length());
        boolean lastKeptWasLetter = false;
        int i = 0;
        while (i < savedName.length()) {
            int cp = savedName.codePointAt(i);
            i += Character.charCount(cp);
            int type = Character.getType(cp);
            if (isEmojiLike(cp, type)) {
                continue;
            }
            if (Character.isLetterOrDigit(cp)) {
                out.appendCodePoint(cp);
                lastKeptWasLetter = true;
            } else if (type == Character.NON_SPACING_MARK || type == Character.COMBINING_SPACING_MARK) {
                // Accents / vowel signs belong to the letter before them (needed for e.g. Hindi, Thai).
                if (lastKeptWasLetter) {
                    out.appendCodePoint(cp);
                }
            } else if (Character.isWhitespace(cp) || Character.isSpaceChar(cp)) {
                out.append(' ');
                lastKeptWasLetter = false;
            } else if (cp == '\'' || cp == 0x2019 || cp == '-' || cp == '.' || cp == '&') {
                out.appendCodePoint(cp);
                lastKeptWasLetter = false;
            } else {
                // Decorative leftovers: * ~ _ | bullets, arrows, hearts-as-text and so on.
                out.append(' ');
                lastKeptWasLetter = false;
            }
        }
        String cleaned = collapse(out.toString());
        cleaned = trimEdgePunctuation(cleaned);
        boolean hasReadable = false;
        for (int k = 0; k < cleaned.length(); ) {
            int cp = cleaned.codePointAt(k);
            k += Character.charCount(cp);
            if (Character.isLetterOrDigit(cp)) {
                hasReadable = true;
                break;
            }
        }
        return hasReadable ? cleaned : "";
    }

    private static String trimEdgePunctuation(String s) {
        int start = 0;
        int end = s.length();
        while (start < end && isEdgeJunk(s.charAt(start))) {
            start++;
        }
        while (end > start && isEdgeJunk(s.charAt(end - 1))) {
            end--;
        }
        return s.substring(start, end).trim();
    }

    private static boolean isEdgeJunk(char c) {
        return c == '-' || c == '.' || c == '&' || c == '\'' || c == 0x2019 || Character.isWhitespace(c);
    }

    private static String collapse(String s) {
        return s.replaceAll("[ \\t\\u00A0]{2,}", " ").trim();
    }

    /**
     * Splits long text into sentence-sized pieces for the TTS queue, so one
     * stop command can flush the queue immediately and Android's per-call
     * text limit (about 4000 characters) is never hit.
     */
    public static ArrayList<String> splitForTts(String text, int maxChars) {
        ArrayList<String> chunks = new ArrayList<String>();
        if (text == null) {
            return chunks;
        }
        String trimmed = text.trim();
        if (trimmed.length() == 0) {
            return chunks;
        }
        StringBuilder current = new StringBuilder();
        int n = trimmed.length();
        for (int i = 0; i < n; i++) {
            char c = trimmed.charAt(i);
            current.append(c);
            boolean sentenceEnd = (c == '.' || c == '!' || c == '?' || c == '\u2026' || c == '\n')
                && (i + 1 >= n || Character.isWhitespace(trimmed.charAt(i + 1)));
            if (sentenceEnd || current.length() >= maxChars) {
                flush(chunks, current, maxChars);
            }
        }
        flush(chunks, current, maxChars);
        // Merge tiny neighbours so the voice does not stutter between 3-word pieces.
        ArrayList<String> merged = new ArrayList<String>();
        for (int i = 0; i < chunks.size(); i++) {
            String piece = chunks.get(i);
            if (merged.size() > 0 && merged.get(merged.size() - 1).length() + piece.length() + 1 <= 160) {
                merged.set(merged.size() - 1, merged.get(merged.size() - 1) + " " + piece);
            } else {
                merged.add(piece);
            }
        }
        return merged;
    }

    private static void flush(ArrayList<String> chunks, StringBuilder current, int maxChars) {
        String piece = current.toString().trim();
        current.setLength(0);
        if (piece.length() == 0) {
            return;
        }
        while (piece.length() > maxChars) {
            int cut = piece.lastIndexOf(' ', maxChars);
            if (cut < maxChars / 2) {
                cut = maxChars;
            }
            chunks.add(piece.substring(0, cut).trim());
            piece = piece.substring(cut).trim();
        }
        if (piece.length() > 0) {
            chunks.add(piece);
        }
    }
}
