package com.idcorporation.atlas.contacts;

/**
 * One phone contact that matched a spoken name: display name as saved on
 * the device, the phone number to dial or message, and a short label
 * (Mobile/Home/Work) used only to tell duplicates apart when ATLAS has
 * to ask "which one".
 */
public class ContactMatch {

    public final long contactId;
    public final String displayName;
    public final String phoneNumber;
    public final String numberLabel;

    public ContactMatch(long contactId, String displayName, String phoneNumber, String numberLabel) {
        this.contactId = contactId;
        this.displayName = displayName;
        this.phoneNumber = phoneNumber;
        this.numberLabel = numberLabel;
    }

    /** Two matches are the "same contact" for de-duplication when id and number agree. */
    public boolean sameAs(ContactMatch other) {
        if (other == null) {
            return false;
        }
        if (this.contactId != other.contactId) {
            return false;
        }
        return this.phoneNumber.equals(other.phoneNumber);
    }

    /**
     * The name as it should be SPOKEN: decorative emojis and symbols removed
     * ("Minha Princesa" + ribbon + heart -> "Minha Princesa"). displayName
     * itself is never changed, so the right contact is still found and
     * shown exactly as saved. Empty when the saved name is emoji-only.
     */
    public String spokenName() {
        return com.idcorporation.atlas.utils.SpeechText.contactName(displayName);
    }

    /** Spoken name, or the given fallback (e.g. "a contact with no readable name") when it is emoji-only. */
    public String spokenName(String unnamedFallback) {
        String spoken = spokenName();
        return spoken.length() == 0 ? unnamedFallback : spoken;
    }

    /** Short spoken description used in a disambiguation question, e.g. "Joao (Mobile)". */
    public String describeForSpeech(String unnamedFallback) {
        String name = spokenName(unnamedFallback);
        if (numberLabel == null || numberLabel.length() == 0) {
            return name;
        }
        return name + " (" + numberLabel + ")";
    }

    public String describeForSpeech() {
        return describeForSpeech("?");
    }
}
