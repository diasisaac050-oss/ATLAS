package com.idcorporation.atlas.contacts;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;

/**
 * Opens a WhatsApp conversation with the message already typed in, using
 * WhatsApp's own officially documented "click to chat" link
 * (https://wa.me/<number>?text=<message>). This is deliberately not an
 * automatic send: WhatsApp does not offer a public, supported API to
 * send a message without the user tapping send themselves, so ATLAS
 * prepares everything and hands control to the user for the final tap -
 * no Accessibility Service taps, no coordinate clicking, no screen
 * hacks of any kind.
 */
public class WhatsAppMessenger {

    private static final String PACKAGE_CONSUMER = "com.whatsapp";
    private static final String PACKAGE_BUSINESS = "com.whatsapp.w4b";

    public static boolean isInstalled(Context context) {
        return isPackageInstalled(context, PACKAGE_CONSUMER) || isPackageInstalled(context, PACKAGE_BUSINESS);
    }

    /** @return true if the chat was opened (message still needs the user's own tap to send). */
    public static boolean openChatWithMessage(Context context, ContactMatch contact, String message) {
        String digits = PhoneNumberUtils.toWhatsappDigits(contact.phoneNumber);
        if (digits.length() == 0) {
            return false;
        }
        Uri chatUri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(message));
        String preferredPackage = isPackageInstalled(context, PACKAGE_CONSUMER) ? PACKAGE_CONSUMER
            : (isPackageInstalled(context, PACKAGE_BUSINESS) ? PACKAGE_BUSINESS : null);

        if (preferredPackage != null) {
            Intent targeted = new Intent(Intent.ACTION_VIEW, chatUri);
            targeted.setPackage(preferredPackage);
            targeted.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                context.startActivity(targeted);
                return true;
            } catch (ActivityNotFoundException e) {
                // Falls through to the untargeted attempt below.
            }
        }

        try {
            Intent generic = new Intent(Intent.ACTION_VIEW, chatUri);
            generic.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(generic);
            return true;
        } catch (ActivityNotFoundException e) {
            return false;
        }
    }

    public static final String METHOD_CONTACT_CARD = "contact_card";
    public static final String METHOD_WA_ME = "wa_me_link";
    public static final String METHOD_WA_ME_ANY = "wa_me_link_any_app";

    private static final String MIME_PROFILE = "vnd.android.cursor.item/vnd.com.whatsapp.profile";
    private static final String MIME_PROFILE_BUSINESS = "vnd.android.cursor.item/vnd.com.whatsapp.w4b.profile";

    /**
     * Opens the conversation with this contact (no message text). Tries the
     * most reliable route first and falls back:
     *   1) WhatsApp's own contact-card row - it exists only when the contact
     *      really has WhatsApp, so a hit also proves that;
     *   2) the official click-to-chat link (wa.me) aimed at the WhatsApp app;
     *   3) the same link with any app able to handle it.
     *
     * @return the method that Android accepted, or null when nothing worked.
     *         Accepted means the launch intent was delivered - the app cannot
     *         look at WhatsApp's screen to see which chat is showing.
     */
    public static String openChat(Context context, ContactMatch contact) {
        String preferred = isPackageInstalled(context, PACKAGE_CONSUMER) ? PACKAGE_CONSUMER
            : (isPackageInstalled(context, PACKAGE_BUSINESS) ? PACKAGE_BUSINESS : null);

        if (preferred != null) {
            String mime = PACKAGE_BUSINESS.equals(preferred) ? MIME_PROFILE_BUSINESS : MIME_PROFILE;
            Uri card = findProfileRow(context, contact.contactId, mime);
            if (card != null) {
                Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(card, mime);
                view.setPackage(preferred);
                view.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    context.startActivity(view);
                    return METHOD_CONTACT_CARD;
                } catch (RuntimeException e) {
                    // Falls through to the link.
                }
            }
        }

        String digits = PhoneNumberUtils.toWhatsappDigits(contact.phoneNumber);
        if (digits.length() == 0) {
            return null;
        }
        Uri link = Uri.parse("https://wa.me/" + digits);
        if (preferred != null) {
            Intent targeted = new Intent(Intent.ACTION_VIEW, link);
            targeted.setPackage(preferred);
            targeted.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                context.startActivity(targeted);
                return METHOD_WA_ME;
            } catch (RuntimeException e) {
                // Falls through to the untargeted attempt.
            }
        }
        try {
            Intent generic = new Intent(Intent.ACTION_VIEW, link);
            generic.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(generic);
            return METHOD_WA_ME_ANY;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static Uri findProfileRow(Context context, long contactId, String mime) {
        android.database.Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(
                android.provider.ContactsContract.Data.CONTENT_URI,
                new String[]{android.provider.ContactsContract.Data._ID},
                android.provider.ContactsContract.Data.CONTACT_ID + "=? AND "
                    + android.provider.ContactsContract.Data.MIMETYPE + "=?",
                new String[]{String.valueOf(contactId), mime}, null);
            if (cursor != null && cursor.moveToFirst()) {
                long dataId = cursor.getLong(0);
                return android.content.ContentUris.withAppendedId(
                    android.provider.ContactsContract.Data.CONTENT_URI, dataId);
            }
        } catch (RuntimeException e) {
            // No permission or provider hiccup: just use the link route.
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return null;
    }

    private static boolean isPackageInstalled(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
