package com.idcorporation.atlas.agent.tools;

import android.content.Intent;
import android.net.Uri;

import com.idcorporation.atlas.agent.ToolResult;
import com.idcorporation.atlas.agent.panel.PanelData;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Places from OpenStreetMap's Nominatim search (free, no key). It is a
 * geocoder, so it is best with a named place or a clear "type in city"
 * query; it is not a full business directory. The panel rows open the
 * place in the user's map app. The app has no location permission, so
 * "near me" needs a city from the user or from memory.
 */
public class PlacesTool extends BaseTool {

    public PlacesTool(ToolEnv env) {
        super(env);
    }

    @Override
    public String name() {
        return "find_places";
    }

    @Override
    public String description() {
        return "Find places or businesses (e.g. 'pizzaria') in a city and show them in a panel. "
            + "Set open_in_maps to 'true' to also open the map app.";
    }

    @Override
    public JSONObject parameters() {
        return Schema.obj()
            .str("query", "What to look for, e.g. 'farmacia' or 'Ibirapuera park'.", true)
            .str("city", "City or area to search in.", false)
            .str("open_in_maps", "'true' to open the query in the maps app as well.", false).build();
    }

    @Override
    public boolean returnsUntrustedContent() {
        return true;
    }

    @Override
    public ToolResult execute(JSONObject args) throws Exception {
        String query = arg(args, "query");
        String city = arg(args, "city");
        if (query.length() == 0) {
            return ToolResult.failed("Missing query.");
        }
        if (city.length() == 0) {
            return ToolResult.needsInfo("No city or area given. The app has no location permission, so ask the "
                + "user which city to search in.", null);
        }
        String raw = Http.get("https://nominatim.openstreetmap.org/search?q=" + Http.enc(query + " " + city)
            + "&format=jsonv2&limit=8&addressdetails=0&accept-language=" + Http.enc(env.lang()));
        JSONArray arr = new JSONArray(raw);
        PanelData panel = new PanelData();
        panel.type = PanelData.TYPE_PLACES;
        panel.title = query;
        panel.subtitle = city;
        panel.source = "OpenStreetMap";
        JSONArray summary = new JSONArray();
        for (int i = 0; i < arr.length() && panel.rows.size() < 8; i++) {
            JSONObject p = arr.getJSONObject(i);
            String display = p.optString("display_name", "");
            if (display.length() == 0) continue;
            String name = p.optString("name", "");
            int comma = display.indexOf(',');
            String title = name.length() > 0 ? name : (comma > 0 ? display.substring(0, comma) : display);
            String rest = comma > 0 && name.length() > 0 ? display.substring(comma + 1).trim() : display;
            String lat = p.optString("lat", "");
            String lon = p.optString("lon", "");
            String geo = "geo:" + lat + "," + lon + "?q=" + lat + "," + lon + "(" + Uri.encode(title) + ")";
            panel.rows.add(new PanelData.Row(title, clip(rest, 140), p.optString("type", ""), geo));
            JSONObject s = new JSONObject();
            s.put("name", title);
            s.put("address", clip(rest, 120));
            summary.put(s);
        }
        boolean openMaps = "true".equalsIgnoreCase(arg(args, "open_in_maps"));
        String mapsNote = "";
        if (openMaps) {
            Intent geo = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(query + " " + city)));
            geo.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                env.context.startActivity(geo);
                mapsNote = " The map app was also opened (Android accepted the launch).";
            } catch (RuntimeException e) {
                mapsNote = " No map app could be opened.";
            }
        }
        if (panel.rows.isEmpty()) {
            return ToolResult.failed("OpenStreetMap found nothing for '" + query + "' in " + city
                + ". It works best with specific names; you can offer to open the maps app instead." + mapsNote);
        }
        JSONObject data = new JSONObject();
        data.put("places", summary);
        return ToolResult.ok("Real places from OpenStreetMap. A places panel is on screen. Opening times, "
            + "ratings and distance are not available from this source." + mapsNote, data).withPanel(panel);
    }
}
