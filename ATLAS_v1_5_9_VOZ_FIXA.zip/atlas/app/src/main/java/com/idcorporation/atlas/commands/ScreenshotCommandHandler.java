package com.idcorporation.atlas.commands;

import android.content.Context;
import android.content.Intent;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.ScreenshotActivity;
import com.idcorporation.atlas.calendar.DateTimeCommandParser;

/**
 * CHAMIZO INTELLIGENCE "Presenca integrada ao celular": lets the user say
 * something like "tire um print da tela" and have ATLAS actually capture
 * and save the screen, instead of that only being possible through the
 * physical button combo. Android requires a fresh on-screen consent for
 * screen capture every time (MediaProjection), so ScreenshotActivity is a
 * transparent activity whose only job is to show that one system prompt
 * and hand off to ScreenshotService - see those classes for the rest of
 * the flow.
 */
public class ScreenshotCommandHandler {

    private static final String[] TRIGGERS = new String[]{
        "tire um print", "tira um print", "tirar um print", "tira uma print",
        "tire uma print", "faca um print", "fazer um print", "print da tela",
        "print de tela", "captura de tela", "capturar a tela", "capturar tela",
        "capture a tela", "screenshot", "take a screenshot", "capture the screen"
    };

    private final Context context;

    public ScreenshotCommandHandler(Context context) {
        this.context = context.getApplicationContext();
    }

    /** @return a response if this was a screenshot request, or null if it was not. */
    public CommandOutcome handle(String rawText, String lowerText) {
        String normalized = DateTimeCommandParser.normalize(lowerText);
        boolean matched = false;
        for (int i = 0; i < TRIGGERS.length; i++) {
            if (normalized.contains(TRIGGERS[i])) {
                matched = true;
                break;
            }
        }
        if (!matched) {
            return null;
        }

        Intent intent = new Intent(context, ScreenshotActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        return CommandOutcome.handled(context.getString(R.string.resp_screenshot_taking));
    }
}
