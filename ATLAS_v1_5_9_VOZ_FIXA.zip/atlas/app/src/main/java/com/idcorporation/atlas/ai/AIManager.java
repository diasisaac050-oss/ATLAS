package com.idcorporation.atlas.ai;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.idcorporation.atlas.memory.MemoryManager;
import com.idcorporation.atlas.models.MemoryItem;

import java.util.ArrayList;

/**
 * Single entry point the rest of the app uses to talk to the AI.
 * The Groq API key lives in ApiKeyConfig - see that file to configure it.
 *
 * ATLAS GLACIAL update: every request now automatically carries the
 * user's stored memories and the assistant's last reply into the system
 * prompt, so ATLAS actually uses what it has been told to remember and
 * avoids repeating itself turn after turn.
 */
public class AIManager {

    public static final int MAX_HISTORY_TURNS = 16;
    private static final int MAX_USER_MESSAGE_CHARS = 2000;
    private static final int MAX_REQUESTS_PER_MINUTE = 30;
    private static final long WINDOW_MS = 60000L;
    // Timestamps of recent requests (shared by voice, chat and the bubble).
    private static final ArrayList<Long> recentRequests = new ArrayList<Long>();

    private final Context appContext;
    private final AIProvider activeProvider;
    private final MemoryManager memoryManager;

    // Set right before the wrapped callback's onSuccess() runs, and consumed
    // by the caller (ChatSession) in the very same callback turn - see
    // consumeLastSuggestion(). Not meant to survive past that.
    private volatile AtlasActionTags.SuggestionFact lastSuggestion;

    public AIManager(Context context) {
        this.appContext = context.getApplicationContext();
        this.activeProvider = new GroqProvider();
        this.memoryManager = new MemoryManager(this.appContext);
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager =
            (ConnectivityManager) appContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            return false;
        }
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnected();
    }

    public void ask(String userName, ArrayList<String> conversationHistory,
                     String userMessage, AIProvider.AICallback callback) {

        if (userMessage == null) {
            callback.onError("Empty message.", -103);
            return;
        }
        if (userMessage.length() > MAX_USER_MESSAGE_CHARS) {
            userMessage = userMessage.substring(0, MAX_USER_MESSAGE_CHARS);
        }

        if (!isNetworkAvailable()) {
            callback.onError("No internet connection.", -100);
            return;
        }

        // ATLAS CONSOLE: o admin pode desligar a IA para todos.
        if (!com.idcorporation.atlas.control.RemoteControl.isAiEnabled()) {
            callback.onError(
                com.idcorporation.atlas.control.RemoteControl.aiOffMessage(appContext), -104);
            return;
        }

        // Guards the API key (and the user's quota) against a runaway loop
        // or someone spamming the assistant: at most N questions a minute.
        if (!allowRequestNow()) {
            callback.onError("Too many requests, slow down.", -102);
            return;
        }

        if (!activeProvider.isConfigured()) {
            callback.onError("Backend is not configured yet.", -101);
            return;
        }

        ArrayList<MemoryItem> knownFacts = memoryManager.getRelevantMemories(userMessage, 25);
        String lastAssistantReply = extractLastAssistantReply(conversationHistory);

        String systemPrompt = buildPrompt(userName, userMessage, knownFacts, lastAssistantReply, false);

        ArrayList<String> trimmedHistory = trimHistory(conversationHistory);
        activeProvider.sendMessage(systemPrompt, trimmedHistory, userMessage, wrapCallback(callback));
    }

    /**
     * Same contract as ask(), but forwards one already-encoded image to a
     * vision-capable model along with the text. userMessage may be empty
     * (an image sent with no caption) - the provider fills in a generic
     * "describe this" prompt in that case.
     */
    public void askWithImage(String userName, ArrayList<String> conversationHistory,
                              String userMessage, String imageBase64, String imageMimeType,
                              AIProvider.AICallback callback) {

        if (imageBase64 == null || imageBase64.length() == 0) {
            callback.onError("Empty image.", -105);
            return;
        }
        String safeMessage = (userMessage == null) ? "" : userMessage;
        if (safeMessage.length() > MAX_USER_MESSAGE_CHARS) {
            safeMessage = safeMessage.substring(0, MAX_USER_MESSAGE_CHARS);
        }

        if (!isNetworkAvailable()) {
            callback.onError("No internet connection.", -100);
            return;
        }

        if (!allowRequestNow()) {
            callback.onError("Too many requests, slow down.", -102);
            return;
        }

        if (!activeProvider.isConfigured()) {
            callback.onError("Backend is not configured yet.", -101);
            return;
        }

        ArrayList<MemoryItem> knownFacts = memoryManager.getRelevantMemories(safeMessage, 25);
        String lastAssistantReply = extractLastAssistantReply(conversationHistory);

        String systemPrompt = buildPrompt(userName, safeMessage, knownFacts, lastAssistantReply, false);

        ArrayList<String> trimmedHistory = trimHistory(conversationHistory);
        activeProvider.sendMessageWithImage(systemPrompt, trimmedHistory, safeMessage,
            imageBase64, imageMimeType, wrapCallback(callback));
    }

    private String buildPrompt(String userName, String message, ArrayList<MemoryItem> knownFacts,
                               String lastAssistantReply, boolean agentMode) {
        ConversationIntelligence.Intent detectedIntent = ConversationIntelligence.detect(message);
        ConversationIntelligence.Tone tone = ConversationIntelligence.detectTone(message);
        com.idcorporation.atlas.utils.UserProfileManager userProfile =
            new com.idcorporation.atlas.utils.UserProfileManager(appContext);
        return PromptManager.buildSystemPrompt(userName,
            com.idcorporation.atlas.utils.LocaleHelper.getLanguageNameForPrompt(
                com.idcorporation.atlas.utils.LocaleHelper.getSavedLanguage(appContext)),
            userProfile.getGender(), userProfile.getAge(),
            knownFacts, lastAssistantReply, detectedIntent, tone, agentMode);
    }

    /**
     * ATLAS AGENT CORE entry point. Same safeguards as ask() (network, admin
     * switch, rate limit, key), then runs the plan -> act -> verify loop with
     * the real tools. Emotional or serious messages with no action in them
     * skip the tools entirely and get a plain, short, friend-like reply.
     * If the tool-calling request itself is rejected (HTTP 400/404/422)
     * before anything ran, it falls back to the old plain chat path.
     */
    public void askAgent(final String userName, final ArrayList<String> conversationHistory,
                         final String userMessage, final com.idcorporation.atlas.commands.CommandManager commands,
                         final com.idcorporation.atlas.agent.AgentCallback callback) {
        if (userMessage == null) {
            callback.onError("Empty message.", -103);
            return;
        }
        final String message = userMessage.length() > MAX_USER_MESSAGE_CHARS
            ? userMessage.substring(0, MAX_USER_MESSAGE_CHARS) : userMessage;

        ConversationIntelligence.Tone tone = ConversationIntelligence.detectTone(message);
        boolean wantsTools = tone != ConversationIntelligence.Tone.VENT
            && tone != ConversationIntelligence.Tone.SERIOUS;
        if (!wantsTools) {
            plainAsAgent(userName, conversationHistory, message, callback);
            return;
        }

        if (!isNetworkAvailable()) {
            callback.onError("No internet connection.", -100);
            return;
        }
        if (!com.idcorporation.atlas.control.RemoteControl.isAiEnabled()) {
            callback.onError(com.idcorporation.atlas.control.RemoteControl.aiOffMessage(appContext), -104);
            return;
        }
        if (!allowRequestNow()) {
            callback.onError("Too many requests, slow down.", -102);
            return;
        }
        if (!activeProvider.isConfigured()) {
            callback.onError("Backend is not configured yet.", -101);
            return;
        }

        ArrayList<MemoryItem> knownFacts = memoryManager.getRelevantMemories(message, 25);
        final String prompt = buildPrompt(userName, message, knownFacts,
            extractLastAssistantReply(conversationHistory), true);
        final ArrayList<String> agentHistory = new ArrayList<String>();
        int from = Math.max(0, conversationHistory.size() - 12);
        from = from - (from % 2);
        for (int i = from; i < conversationHistory.size(); i++) {
            agentHistory.add(conversationHistory.get(i));
        }

        final android.os.Handler main = new android.os.Handler(android.os.Looper.getMainLooper());
        Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final com.idcorporation.atlas.agent.tools.ToolEnv env =
                        new com.idcorporation.atlas.agent.tools.ToolEnv(appContext, commands);
                    final com.idcorporation.atlas.agent.ModelClient limited = new com.idcorporation.atlas.agent.ModelClient() {
                        private int calls = 0;

                        @Override
                        public com.idcorporation.atlas.agent.ModelReply chat(org.json.JSONArray messages,
                                org.json.JSONArray tools, boolean toolsEnabled) throws ModelException {
                            calls++;
                            // The first call was already counted by the pre-check above.
                            if (calls > 1 && !allowRequestNow()) {
                                throw new ModelException("rate limit", -102);
                            }
                            return new GroqToolClient().chat(messages, tools, toolsEnabled);
                        }
                    };
                    com.idcorporation.atlas.agent.AgentRunner runner = new com.idcorporation.atlas.agent.AgentRunner(
                        limited, com.idcorporation.atlas.agent.tools.ToolRegistry.build(env),
                        appContext.getString(com.idcorporation.atlas.R.string.agent_partial_error));
                    runner.setPanelOnlyText(appContext.getString(
                        com.idcorporation.atlas.R.string.agent_partial_panel));
                    final com.idcorporation.atlas.agent.AgentResult result =
                        runner.run(prompt, agentHistory, message, true);
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            result.text = applyTags(result.text);
                            callback.onResult(result);
                        }
                    });
                } catch (final com.idcorporation.atlas.agent.ModelClient.ModelException e) {
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            if (e.code == 400 || e.code == 404 || e.code == 422) {
                                plainAsAgent(userName, conversationHistory, message, callback);
                            } else {
                                callback.onError("Agent error.", e.code);
                            }
                        }
                    });
                } catch (final RuntimeException e) {
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            callback.onError("Unexpected error.", -3);
                        }
                    });
                }
            }
        });
        worker.start();
    }

    /** The ordinary chat path (no tools), adapted to the agent callback. */
    private void plainAsAgent(String userName, ArrayList<String> history, String message,
                              final com.idcorporation.atlas.agent.AgentCallback callback) {
        ask(userName, history, message, new AIProvider.AICallback() {
            @Override
            public void onSuccess(String responseText) {
                com.idcorporation.atlas.agent.AgentResult r = new com.idcorporation.atlas.agent.AgentResult();
                r.text = responseText;
                callback.onResult(r);
            }

            @Override
            public void onError(String errorMessage, int errorCode) {
                callback.onError(errorMessage, errorCode);
            }
        });
    }

    /**
     * Pulls the invisible memory / suggestion directives out of a final reply
     * (saving the memories right away) and returns clean natural language.
     */
    private String applyTags(String raw) {
        AtlasActionTags.MemoryExtractResult memoryResult = AtlasActionTags.extractMemoryTags(raw);
        for (int i = 0; i < memoryResult.memories.size(); i++) {
            AtlasActionTags.MemoryFact fact = memoryResult.memories.get(i);
            memoryManager.saveOrUpdateAuto(fact.key, fact.value);
        }
        AtlasActionTags.SuggestionExtractResult suggestionResult =
            AtlasActionTags.extractSuggestionTag(memoryResult.cleanText);
        lastSuggestion = suggestionResult.suggestion;
        return suggestionResult.cleanText;
    }

    /** Lets other components (the greeter) share the same provider and limits. */
    public boolean canMakeRequestNow() {
        return isNetworkAvailable() && com.idcorporation.atlas.control.RemoteControl.isAiEnabled()
            && activeProvider.isConfigured() && allowRequestNow();
    }

    public AIProvider provider() {
        return activeProvider;
    }

    private static synchronized boolean allowRequestNow() {
        long now = System.currentTimeMillis();
        for (int i = recentRequests.size() - 1; i >= 0; i--) {
            if (now - recentRequests.get(i).longValue() > WINDOW_MS) {
                recentRequests.remove(i);
            }
        }
        if (recentRequests.size() >= MAX_REQUESTS_PER_MINUTE) {
            return false;
        }
        recentRequests.add(Long.valueOf(now));
        return true;
    }

    /**
     * conversationHistory alternates user, assistant, user, assistant... so an
     * assistant turn always sits at an odd index. Used purely so the prompt can
     * discourage repeating the exact same reply twice in a row.
     */
    private String extractLastAssistantReply(ArrayList<String> history) {
        if (history == null || history.isEmpty()) {
            return null;
        }
        for (int i = history.size() - 1; i >= 0; i--) {
            boolean isAssistantTurn = (i % 2 == 1);
            if (isAssistantTurn) {
                return history.get(i);
            }
        }
        return null;
    }

    private ArrayList<String> trimHistory(ArrayList<String> fullHistory) {
        if (fullHistory.size() <= MAX_HISTORY_TURNS) {
            return fullHistory;
        }
        int startIndex = fullHistory.size() - MAX_HISTORY_TURNS;
        ArrayList<String> trimmed = new ArrayList<String>();
        for (int i = startIndex; i < fullHistory.size(); i++) {
            trimmed.add(fullHistory.get(i));
        }
        return trimmed;
    }

    public String getActiveProviderName() {
        return activeProvider.getProviderName();
    }

    /**
     * Returns the proactive suggestion (if any) the AI attached to the reply
     * that was just delivered through this same AIManager instance's last
     * onSuccess callback, and clears it. Call this from inside that
     * callback (see ChatSession.forwardToAI) - it is not meant to be
     * polled later. Voice mode simply never calls this, so a suggestion
     * tag never turns into spoken/read-aloud text there; it is stripped
     * from the text either way by wrapCallback() below.
     */
    public AtlasActionTags.SuggestionFact consumeLastSuggestion() {
        AtlasActionTags.SuggestionFact suggestion = lastSuggestion;
        lastSuggestion = null;
        return suggestion;
    }

    /**
     * Intercepts a successful reply before the caller ever sees it: pulls
     * out any \u00a7MEM\u00a7 directive and immediately persists it (this is
     * the actual fix for "ATLAS says it will remember something but the
     * Memory tab stays empty" - previously nothing but an explicit manual
     * command ever wrote to MemoryManager), then pulls out an optional
     * \u00a7SUGERIR\u00a7 directive for the caller to turn into a
     * confirmation bubble. Either way the text handed to the original
     * callback is clean natural language - the tags never reach the chat
     * bubble, the conversation history, or text-to-speech.
     */
    private AIProvider.AICallback wrapCallback(final AIProvider.AICallback original) {
        return new AIProvider.AICallback() {
            @Override
            public void onSuccess(String responseText) {
                original.onSuccess(applyTags(responseText));
            }

            @Override
            public void onError(String errorMessage, int errorCode) {
                lastSuggestion = null;
                original.onError(errorMessage, errorCode);
            }
        };
    }
}
