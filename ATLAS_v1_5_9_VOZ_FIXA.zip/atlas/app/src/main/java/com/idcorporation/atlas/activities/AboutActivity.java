package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.UserProfileManager;

public class AboutActivity extends BaseActivity {

    private static final String DEV_WHATSAPP_NUMBER = "5511912299235";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        TextView versionView = (TextView) findViewById(R.id.text_version);
        versionView.setText("Version " + getVersionName());

        setUpContactDevButton();
    }

    private void setUpContactDevButton() {
        UserProfileManager profileManager = new UserProfileManager(this);
        boolean isAdult = profileManager.getAge() >= 18;

        if (!isAdult) {
            // Under 18 (or age unknown): the button simply does not exist on screen.
            return;
        }

        TextView contactButton = (TextView) findViewById(R.id.button_contact_dev);
        contactButton.setVisibility(View.VISIBLE);
        contactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWhatsAppContact();
            }
        });
    }

    private void openWhatsAppContact() {
        Uri uri = Uri.parse("https://wa.me/" + DEV_WHATSAPP_NUMBER);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private String getVersionName() {
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "1.0.0";
        }
    }
}
