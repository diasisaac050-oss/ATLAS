package com.idcorporation.atlas.security;

import android.os.Build;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Slow, salted hashing for the Vault PIN and the local password.
 *
 * A plain SHA-256 of a 4-6 digit PIN can be brute-forced in well under a
 * second if the preferences file is ever read. PBKDF2 with a large
 * iteration count makes every single guess expensive. The stored text
 * looks like  alg$iterations$salt$hash  so the algorithm and cost that
 * were used are always known when verifying later (even after an Android
 * update or a future cost increase).
 */
public class PasswordHasher {

    private static final String ALG_SHA256 = "p256";
    private static final String ALG_SHA1 = "p1";
    private static final int ITERATIONS = 120000;
    private static final int MIN_ITERATIONS = 1000;
    private static final int MAX_ITERATIONS = 2000000;
    private static final int SALT_BYTES = 16;
    private static final int KEY_BITS = 256;
    public static final int MAX_SECRET_LENGTH = 128;

    /** Returns the text to store, or null if this device cannot hash (never stores a weak fallback). */
    public static String hash(String secret) {
        if (secret == null || secret.length() > MAX_SECRET_LENGTH) {
            return null;
        }
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        String alg = (Build.VERSION.SDK_INT >= 26) ? ALG_SHA256 : ALG_SHA1;
        byte[] derived = derive(secret, salt, ITERATIONS, alg);
        if (derived == null) {
            return null;
        }
        return alg + "$" + ITERATIONS + "$"
            + Base64.encodeToString(salt, Base64.NO_WRAP) + "$"
            + Base64.encodeToString(derived, Base64.NO_WRAP);
    }

    /** True if the stored text was produced by hash() (as opposed to the old single SHA-256 format). */
    public static boolean isModernFormat(String stored) {
        return stored != null && (stored.startsWith(ALG_SHA256 + "$") || stored.startsWith(ALG_SHA1 + "$"));
    }

    public static boolean verify(String secret, String stored) {
        if (secret == null || secret.length() > MAX_SECRET_LENGTH || !isModernFormat(stored)) {
            return false;
        }
        String[] parts = stored.split("\\$");
        if (parts.length != 4) {
            return false;
        }
        try {
            int iterations = Integer.parseInt(parts[1]);
            if (iterations < MIN_ITERATIONS || iterations > MAX_ITERATIONS) {
                return false;
            }
            byte[] salt = Base64.decode(parts[2], Base64.NO_WRAP);
            byte[] expected = Base64.decode(parts[3], Base64.NO_WRAP);
            byte[] actual = derive(secret, salt, iterations, parts[0]);
            if (actual == null) {
                return false;
            }
            return MessageDigest.isEqual(expected, actual);
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static byte[] derive(String secret, byte[] salt, int iterations, String alg) {
        PBEKeySpec spec = null;
        try {
            String factoryName = ALG_SHA256.equals(alg) ? "PBKDF2WithHmacSHA256" : "PBKDF2WithHmacSHA1";
            spec = new PBEKeySpec(secret.toCharArray(), salt, iterations, KEY_BITS);
            SecretKeyFactory factory = SecretKeyFactory.getInstance(factoryName);
            return factory.generateSecret(spec).getEncoded();
        } catch (Exception e) {
            return null;
        } finally {
            if (spec != null) {
                spec.clearPassword();
            }
        }
    }
}
