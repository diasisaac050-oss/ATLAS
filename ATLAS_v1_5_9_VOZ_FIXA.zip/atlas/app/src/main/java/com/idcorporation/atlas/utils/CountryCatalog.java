package com.idcorporation.atlas.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Countries offered on the onboarding "What is your country?" step, and
 * the single place that decides which ATLAS language a country implies.
 *
 * This does not introduce a second language system: it only produces a
 * language code from LocaleHelper's existing constants, and the
 * onboarding screen saves it through LocaleHelper.setSavedLanguage, the
 * same method Settings > Languages uses. LocaleHelper stays the one
 * source of truth for the current language.
 */
public final class CountryCatalog {

    private static final ArrayList<CountryOption> COUNTRIES = buildCountries();

    private CountryCatalog() {
    }

    public static ArrayList<CountryOption> getAllCountries() {
        return COUNTRIES;
    }

    /** Builds a flag emoji from an ISO 3166-1 alpha-2 code, e.g. "BR" -> \uD83C\uDDE7\uD83C\uDDF7. */
    private static String flagFromIso(String isoCode) {
        int firstLetter = Character.codePointAt(isoCode, 0) - 'A' + 0x1F1E6;
        int secondLetter = Character.codePointAt(isoCode, 1) - 'A' + 0x1F1E6;
        return new String(Character.toChars(firstLetter)) + new String(Character.toChars(secondLetter));
    }

    private static CountryOption country(String isoCode, String englishName, String languageCode) {
        return new CountryOption(isoCode, flagFromIso(isoCode), englishName, languageCode);
    }

    private static ArrayList<CountryOption> buildCountries() {
        ArrayList<CountryOption> list = new ArrayList<CountryOption>();

        // Portuguese (Brazil)
        list.add(country("BR", "Brazil", LocaleHelper.LANGUAGE_PORTUGUESE_BR));

        // Portuguese (Portugal)
        list.add(country("PT", "Portugal", LocaleHelper.LANGUAGE_PORTUGUESE_PT));
        list.add(country("AO", "Angola", LocaleHelper.LANGUAGE_PORTUGUESE_PT));
        list.add(country("MZ", "Mozambique", LocaleHelper.LANGUAGE_PORTUGUESE_PT));
        list.add(country("CV", "Cape Verde", LocaleHelper.LANGUAGE_PORTUGUESE_PT));

        // Spanish
        list.add(country("ES", "Spain", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("MX", "Mexico", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("AR", "Argentina", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("CO", "Colombia", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("CL", "Chile", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("PE", "Peru", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("VE", "Venezuela", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("EC", "Ecuador", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("UY", "Uruguay", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("PY", "Paraguay", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("BO", "Bolivia", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("CR", "Costa Rica", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("PA", "Panama", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("DO", "Dominican Republic", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("GT", "Guatemala", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("HN", "Honduras", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("SV", "El Salvador", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("NI", "Nicaragua", LocaleHelper.LANGUAGE_SPANISH));
        list.add(country("CU", "Cuba", LocaleHelper.LANGUAGE_SPANISH));

        // Italian
        list.add(country("IT", "Italy", LocaleHelper.LANGUAGE_ITALIAN));
        list.add(country("SM", "San Marino", LocaleHelper.LANGUAGE_ITALIAN));

        // French
        list.add(country("FR", "France", LocaleHelper.LANGUAGE_FRENCH));
        list.add(country("BE", "Belgium", LocaleHelper.LANGUAGE_FRENCH));
        list.add(country("MC", "Monaco", LocaleHelper.LANGUAGE_FRENCH));
        list.add(country("SN", "Senegal", LocaleHelper.LANGUAGE_FRENCH));
        list.add(country("CI", "Ivory Coast", LocaleHelper.LANGUAGE_FRENCH));
        list.add(country("MA", "Morocco", LocaleHelper.LANGUAGE_FRENCH));
        list.add(country("DZ", "Algeria", LocaleHelper.LANGUAGE_FRENCH));
        list.add(country("TN", "Tunisia", LocaleHelper.LANGUAGE_FRENCH));
        list.add(country("CM", "Cameroon", LocaleHelper.LANGUAGE_FRENCH));

        // German
        list.add(country("DE", "Germany", LocaleHelper.LANGUAGE_GERMAN));
        list.add(country("AT", "Austria", LocaleHelper.LANGUAGE_GERMAN));
        list.add(country("CH", "Switzerland", LocaleHelper.LANGUAGE_GERMAN));
        list.add(country("LI", "Liechtenstein", LocaleHelper.LANGUAGE_GERMAN));

        // Polish
        list.add(country("PL", "Poland", LocaleHelper.LANGUAGE_POLISH));

        // English (and everywhere else ATLAS does not have a closer match)
        list.add(country("US", "United States", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("GB", "United Kingdom", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("CA", "Canada", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("AU", "Australia", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("NZ", "New Zealand", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("IE", "Ireland", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("IN", "India", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("ZA", "South Africa", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("NG", "Nigeria", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("PH", "Philippines", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("SG", "Singapore", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("NL", "Netherlands", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("SE", "Sweden", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("NO", "Norway", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("DK", "Denmark", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("FI", "Finland", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("JP", "Japan", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("KR", "South Korea", LocaleHelper.LANGUAGE_ENGLISH));
        list.add(country("CN", "China", LocaleHelper.LANGUAGE_ENGLISH));

        Collections.sort(list, new Comparator<CountryOption>() {
            @Override
            public int compare(CountryOption a, CountryOption b) {
                return a.getDisplayName().compareToIgnoreCase(b.getDisplayName());
            }
        });

        return list;
    }
}
