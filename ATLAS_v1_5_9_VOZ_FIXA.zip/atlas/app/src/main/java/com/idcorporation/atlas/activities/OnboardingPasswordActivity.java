package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.PasswordValidator;
import com.idcorporation.atlas.utils.UserProfileManager;

/**
 * Final onboarding step: create and confirm the password, then persist
 * the full profile collected across every previous screen and hand off
 * to MainActivity.
 */
public class OnboardingPasswordActivity extends OnboardingStepActivity {

    private static final int STEP_INDEX = 5;
    private static final int TOTAL_STEPS = 6;

    private EditText passwordInput;
    private EditText passwordConfirmInput;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_password);

        View backButton = findViewById(R.id.button_step_back);
        ViewGroup dotsContainer = (ViewGroup) findViewById(R.id.container_step_dots);
        View badge = findViewById(R.id.badge_password);
        View title = findViewById(R.id.text_password_question);
        passwordInput = (EditText) findViewById(R.id.input_password);
        passwordConfirmInput = (EditText) findViewById(R.id.input_password_confirm);
        errorText = (TextView) findViewById(R.id.text_password_error);
        final View continueButton = findViewById(R.id.button_password_continue);

        renderProgressDots(dotsContainer, STEP_INDEX, TOTAL_STEPS);
        animateEntrance(badge, title, null, passwordInput, continueButton);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bounceButton(continueButton);
                attemptFinish();
            }
        });
    }

    private void attemptFinish() {
        String password = passwordInput.getText().toString();
        String passwordConfirm = passwordConfirmInput.getText().toString();

        if (!PasswordValidator.isValid(password)) {
            showFieldError(errorText, getString(R.string.error_password_invalid));
            return;
        }
        if (!password.equals(passwordConfirm)) {
            showFieldError(errorText, getString(R.string.error_password_mismatch));
            return;
        }

        Bundle data = getIntent().getExtras();
        String fullName = data != null ? data.getString(OnboardingKeys.FULL_NAME, "") : "";
        String callName = data != null ? data.getString(OnboardingKeys.CALL_NAME, "") : "";
        String email = data != null ? data.getString(OnboardingKeys.EMAIL, "") : "";
        int age = data != null ? data.getInt(OnboardingKeys.AGE, 0) : 0;
        String gender = data != null
            ? data.getString(OnboardingKeys.GENDER, UserProfileManager.GENDER_UNSPECIFIED)
            : UserProfileManager.GENDER_UNSPECIFIED;

        UserProfileManager profileManager = new UserProfileManager(this);
        profileManager.saveProfile(fullName, callName, email, age, gender, password);

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
