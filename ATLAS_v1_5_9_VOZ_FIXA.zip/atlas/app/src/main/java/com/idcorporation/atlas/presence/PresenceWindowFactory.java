package com.idcorporation.atlas.presence;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;

import com.idcorporation.atlas.utils.PresenceManager;

/**
 * Builds the window parameters for the floating Presence visual. The
 * glass layout sits at the top center under the notch; the orb layout
 * sits at the bottom center (just above the navigation buttons when the
 * phone uses 3-button navigation, so Back/Home stay tappable).
 */
public class PresenceWindowFactory {

    public static WindowManager.LayoutParams build(Context context) {
        return build(context, PresenceManager.LAYOUT_GLASS);
    }

    public static WindowManager.LayoutParams build(Context context, int layout) {
        float density = context.getResources().getDisplayMetrics().density;
        int overlayType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        // NOT_FOCUSABLE keeps the app underneath fully usable (keyboard, back
        // button) while the bubble is up; NOT_TOUCH_MODAL lets taps outside
        // the bubble window fall through to that app.
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        boolean orb = (layout == PresenceManager.LAYOUT_ORB);
        boolean nucleus = (layout == PresenceManager.LAYOUT_NUCLEUS);
        boolean card = (layout == PresenceManager.LAYOUT_CARD);
        // Both looks stack many blended gradient layers; the GPU keeps them smooth.
        flags = flags | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            flags,
            PixelFormat.TRANSLUCENT);
        Resources res = context.getResources();
        if (card) {
            params.gravity = Gravity.CENTER;
        } else if (orb || nucleus) {
            params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            params.y = nucleus ? -Math.max(0, (int)(8*density)) : bottomInset(res, density);
        } else {
            params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            int id = res.getIdentifier("status_bar_height", "dimen", "android");
            int statusBar = (id > 0) ? res.getDimensionPixelSize(id) : (int) (24 * density);
            params.y = Math.max(0, statusBar - (int) (16 * density));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return params;
    }

    /** Height of the navigation buttons bar, or a tiny gap when the phone uses gesture navigation. */
    private static int bottomInset(Resources res, float density) {
        int modeId = res.getIdentifier("config_navBarInteractionMode", "integer", "android");
        int mode = (modeId > 0) ? res.getInteger(modeId) : 0;
        if (mode == 2) {
            return (int) (4 * density);
        }
        int navId = res.getIdentifier("navigation_bar_height", "dimen", "android");
        return (navId > 0) ? res.getDimensionPixelSize(navId) : (int) (48 * density);
    }
}
