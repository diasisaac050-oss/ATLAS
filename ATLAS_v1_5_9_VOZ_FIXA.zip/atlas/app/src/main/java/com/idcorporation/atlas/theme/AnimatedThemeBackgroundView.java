package com.idcorporation.atlas.theme;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/**
 * A slow, moody animated background: the base color cross-fades toward
 * a second color and back, while a handful of soft glow dots drift
 * around. Used only by the two locked "animated" themes (Space,
 * Mega Purple) so they feel special.
 */
public class AnimatedThemeBackgroundView extends View implements ThemeBackgroundView {

    private static final int DOT_COUNT = 5;

    private int colorA;
    private int colorB;
    private int currentBackgroundColor;
    private ValueAnimator colorAnimator;

    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] dotX = new float[DOT_COUNT];
    private final float[] dotY = new float[DOT_COUNT];
    private final float[] dotRadius = new float[DOT_COUNT];
    private final float[] dotSpeedX = new float[DOT_COUNT];
    private final float[] dotSpeedY = new float[DOT_COUNT];
    private final Random random = new Random();
    private boolean dotsInitialized = false;

    public AnimatedThemeBackgroundView(Context context) {
        super(context);
    }

    public void setPalette(ThemePalette palette) {
        this.colorA = palette.getBackgroundColor();
        this.colorB = palette.getBackgroundColorAlt();
        this.currentBackgroundColor = colorA;
        startColorLoop();
    }

    private void startColorLoop() {
        if (colorAnimator != null) {
            colorAnimator.cancel();
        }
        colorAnimator = ValueAnimator.ofObject(new ArgbEvaluator(), colorA, colorB, colorA);
        colorAnimator.setDuration(9000);
        colorAnimator.setRepeatCount(ValueAnimator.INFINITE);
        colorAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                currentBackgroundColor = (Integer) animation.getAnimatedValue();
                invalidate();
            }
        });
        colorAnimator.start();
    }

    private void initDotsIfNeeded(int width, int height) {
        if (dotsInitialized || width <= 0 || height <= 0) {
            return;
        }
        for (int i = 0; i < DOT_COUNT; i++) {
            dotX[i] = random.nextFloat() * width;
            dotY[i] = random.nextFloat() * height;
            dotRadius[i] = 60f + random.nextFloat() * 90f;
            dotSpeedX[i] = (random.nextFloat() - 0.5f) * 1.4f;
            dotSpeedY[i] = (random.nextFloat() - 0.5f) * 1.4f;
        }
        dotsInitialized = true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        initDotsIfNeeded(width, height);

        canvas.drawColor(currentBackgroundColor);

        for (int i = 0; i < DOT_COUNT; i++) {
            dotX[i] = dotX[i] + dotSpeedX[i];
            dotY[i] = dotY[i] + dotSpeedY[i];

            if (dotX[i] < -dotRadius[i]) {
                dotX[i] = width + dotRadius[i];
            } else if (dotX[i] > width + dotRadius[i]) {
                dotX[i] = -dotRadius[i];
            }
            if (dotY[i] < -dotRadius[i]) {
                dotY[i] = height + dotRadius[i];
            } else if (dotY[i] > height + dotRadius[i]) {
                dotY[i] = -dotRadius[i];
            }

            RadialGradient gradient = new RadialGradient(
                dotX[i], dotY[i], dotRadius[i],
                withAlpha(colorB, 70), withAlpha(colorB, 0),
                Shader.TileMode.CLAMP);
            dotPaint.setShader(gradient);
            canvas.drawCircle(dotX[i], dotY[i], dotRadius[i], dotPaint);
        }

        invalidate();
    }

    private int withAlpha(int color, int alpha) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    public void stopAnimating() {
        if (colorAnimator != null) {
            colorAnimator.cancel();
        }
    }
}
