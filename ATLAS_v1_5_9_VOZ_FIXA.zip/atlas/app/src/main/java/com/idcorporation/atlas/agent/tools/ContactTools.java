package com.idcorporation.atlas.agent.tools;

import android.content.Intent;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.MainActivity;
import com.idcorporation.atlas.agent.AgentTool;
import com.idcorporation.atlas.agent.ToolResult;
import com.idcorporation.atlas.commands.ConfirmAction;
import com.idcorporation.atlas.contacts.ContactMatch;
import com.idcorporation.atlas.contacts.ContactResolver;
import com.idcorporation.atlas.contacts.WhatsAppMessenger;
import com.idcorporation.atlas.utils.ContactsPermissionHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Contact + WhatsApp tools. Phone numbers are NEVER put in anything sent to
 * the model: it only ever sees the spoken (emoji-free) name and a label.
 * Sending a message is never done by the agent itself - it prepares the
 * chat with the text typed in and the user taps send in WhatsApp.
 */
public final class ContactTools {

    private ContactTools() {
    }

    /** Outcome of resolving a spoken name to exactly one contact. */
    static final class Resolved {
        ContactMatch single;
        ToolResult failure;
    }

    static Resolved resolve(ToolEnv env, String spokenName) {
        Resolved r = new Resolved();
        if (spokenName.length() == 0) {
            r.failure = ToolResult.needsInfo("Which contact?", null);
            return r;
        }
        if (!ContactsPermissionHelper.hasReadContacts(env.context)) {
            askPermissionOnce(env);
            r.failure = ToolResult.needsInfo("Contacts permission is not granted. The app is asking the user "
                + "for it now; tell them to allow it and ask again.", null);
            return r;
        }
        ArrayList<ContactMatch> found = ContactResolver.findByName(env.context, spokenName);
        if (found.size() == 0) {
            r.failure = ToolResult.failed("No contact matches '" + spokenName + "'.");
            return r;
        }
        if (found.size() > 1) {
            JSONArray options = new JSONArray();
            String unnamed = env.context.getString(R.string.contact_unnamed_spoken);
            int limit = Math.min(found.size(), 5);
            for (int i = 0; i < limit; i++) {
                options.put(found.get(i).describeForSpeech(unnamed));
            }
            JSONObject data = new JSONObject();
            try {
                data.put("matches", options);
            } catch (Exception ignored) {
                // Plain values.
            }
            r.failure = ToolResult.needsInfo("Several contacts match. Ask the user which one, then call "
                + "again with the exact option text.", data);
            return r;
        }
        r.single = found.get(0);
        return r;
    }

    private static void askPermissionOnce(ToolEnv env) {
        if (!ContactsPermissionHelper.shouldPromptForPermissions(env.context)) {
            return;
        }
        ContactsPermissionHelper.markPermissionsPrompted(env.context);
        Intent intent = new Intent(env.context, MainActivity.class);
        intent.putExtra(MainActivity.EXTRA_REQUEST_CONTACT_PERMISSIONS, true);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            env.context.startActivity(intent);
        } catch (RuntimeException ignored) {
            // Nothing more to try.
        }
    }

    // -----------------------------------------------------------------

    public static class FindContact extends BaseTool {
        public FindContact(ToolEnv env) {
            super(env);
        }

        @Override
        public String name() {
            return "find_contact";
        }

        @Override
        public String description() {
            return "Check which saved contacts match a name. Returns names only, never numbers.";
        }

        @Override
        public JSONObject parameters() {
            return Schema.obj().str("name", "Name or nickname as the user says it.", true).build();
        }

        @Override
        public ToolResult execute(JSONObject args) throws Exception {
            Resolved r = resolve(env, arg(args, "name"));
            if (r.failure != null) {
                return r.failure;
            }
            JSONObject data = new JSONObject();
            data.put("name", r.single.spokenName(env.context.getString(R.string.contact_unnamed_spoken)));
            return ToolResult.ok("Exactly one contact matches.", data);
        }
    }

    public static class OpenWhatsAppChat extends BaseTool {
        public OpenWhatsAppChat(ToolEnv env) {
            super(env);
        }

        @Override
        public String name() {
            return "whatsapp_open_chat";
        }

        @Override
        public String description() {
            return "Open the WhatsApp conversation with a saved contact (no message is typed or sent).";
        }

        @Override
        public JSONObject parameters() {
            return Schema.obj().str("contact", "Contact name as the user says it.", true).build();
        }

        @Override
        public boolean changesState() {
            return true;
        }

        @Override
        public ToolResult execute(JSONObject args) throws Exception {
            if (!WhatsAppMessenger.isInstalled(env.context)) {
                return ToolResult.failed("WhatsApp is not installed.");
            }
            Resolved r = resolve(env, arg(args, "contact"));
            if (r.failure != null) {
                return r.failure;
            }
            final ContactMatch contact = r.single;
            String method = env.onMain(new java.util.concurrent.Callable<String>() {
                @Override
                public String call() {
                    return WhatsAppMessenger.openChat(env.context, contact);
                }
            }, 6000L);
            String who = contact.spokenName(env.context.getString(R.string.contact_unnamed_spoken));
            if (method == null) {
                return ToolResult.failed("Could not open a WhatsApp chat for " + who
                    + " (no usable WhatsApp entry or number).");
            }
            String proof = WhatsAppMessenger.METHOD_CONTACT_CARD.equals(method)
                ? "WhatsApp's own contact entry exists, so this contact is on WhatsApp. "
                : "Opened through a click-to-chat link; it is not confirmed that this number has WhatsApp. ";
            return ToolResult.ok("Android accepted the launch of the WhatsApp chat with " + who + ". " + proof
                + "The app cannot see WhatsApp's screen, so the visible chat is not verified.");
        }
    }

    public static class PrepareWhatsAppMessage extends BaseTool {
        public PrepareWhatsAppMessage(ToolEnv env) {
            super(env);
        }

        @Override
        public String name() {
            return "whatsapp_prepare_message";
        }

        @Override
        public String description() {
            return "Prepare a WhatsApp message to a contact. It is NOT sent: after the user's Yes the chat opens "
                + "with the text typed in and the user taps send.";
        }

        @Override
        public JSONObject parameters() {
            return Schema.obj()
                .str("contact", "Contact name as the user says it.", true)
                .str("message", "Exact text to send.", true).build();
        }

        @Override
        public boolean changesState() {
            return true;
        }

        @Override
        public ToolResult execute(JSONObject args) throws Exception {
            final String message = arg(args, "message");
            if (message.length() == 0) {
                return ToolResult.needsInfo("What should the message say?", null);
            }
            if (!WhatsAppMessenger.isInstalled(env.context)) {
                return ToolResult.failed("WhatsApp is not installed.");
            }
            Resolved r = resolve(env, arg(args, "contact"));
            if (r.failure != null) {
                return r.failure;
            }
            final ContactMatch contact = r.single;
            String who = contact.spokenName(env.context.getString(R.string.contact_unnamed_spoken));
            ConfirmAction action = new ConfirmAction() {
                @Override
                public boolean run() {
                    return WhatsAppMessenger.openChatWithMessage(env.context, contact, message);
                }
            };
            return ToolResult.needsConfirmation("Ready: message for " + who + " is NOT sent. After the user's Yes "
                + "the chat opens with the text typed in, and the user must tap send.", message, action);
        }
    }

    public static AgentTool[] all(ToolEnv env) {
        return new AgentTool[]{new FindContact(env), new OpenWhatsAppChat(env), new PrepareWhatsAppMessage(env)};
    }
}
