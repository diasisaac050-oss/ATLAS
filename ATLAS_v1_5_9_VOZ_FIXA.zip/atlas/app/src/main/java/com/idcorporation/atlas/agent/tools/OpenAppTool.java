package com.idcorporation.atlas.agent.tools;

import com.idcorporation.atlas.agent.ToolResult;
import com.idcorporation.atlas.commands.AppCommandHandler;

import org.json.JSONObject;

import java.util.concurrent.Callable;

public class OpenAppTool extends BaseTool {

    public OpenAppTool(ToolEnv env) {
        super(env);
    }

    @Override
    public String name() {
        return "open_app";
    }

    @Override
    public String description() {
        return "Open an installed app by its name (for example Gmail, Maps, Spotify, Camera).";
    }

    @Override
    public JSONObject parameters() {
        return Schema.obj().str("app", "App name as the user says it.", true).build();
    }

    @Override
    public ToolResult execute(JSONObject args) throws Exception {
        final String app = arg(args, "app");
        if (app.length() == 0) {
            return ToolResult.failed("Missing app name.");
        }
        String label = env.onMain(new Callable<String>() {
            @Override
            public String call() {
                try {
                    return new AppCommandHandler().openAppAndReturnLabel(env.context, app);
                } catch (RuntimeException e) {
                    return null;
                }
            }
        }, 6000L);
        if (label == null) {
            return ToolResult.failed("No installed app matching '" + app + "' could be launched.");
        }
        return ToolResult.ok("Android accepted the launch of '" + label + "'. The app cannot see its screen, "
            + "so what the app then shows is not verified.");
    }
}
