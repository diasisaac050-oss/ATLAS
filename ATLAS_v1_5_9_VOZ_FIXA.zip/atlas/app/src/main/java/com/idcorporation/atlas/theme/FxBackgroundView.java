package com.idcorporation.atlas.theme;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * ATLAS ESFERA themes: shared base for the animated backgrounds that speak the
 * same visual language as the sphere - soft additive light (a glow with a
 * white-hot centre) over a deep, slightly lit background, driven by real
 * time (dt) so the speed is the same on every phone.
 *
 * Subclasses only describe where the lights are (drawFx). This class owns the
 * frame loop (it stops when the screen is hidden), the background gradient and
 * the glow sprites. Nothing is allocated per frame.
 */
abstract class FxBackgroundView extends View implements ThemeBackgroundView {

    protected int bg = 0xFF000000;
    protected int bgAlt = 0xFF000000;
    protected int accent = 0xFFFFFFFF;
    protected int hot = 0xFFFFFFFF;
    protected float dens = 1f;
    protected int w = 0;
    protected int h = 0;
    protected float time = 0f;

    private final Paint bgPaint = new Paint();
    protected final Paint glowPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    protected final Paint hotPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    protected final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap sprite;
    private final Rect spriteSrc = new Rect();
    private final RectF dst = new RectF();

    private boolean running = false;
    private long lastNanos = 0L;

    FxBackgroundView(Context context) {
        super(context);
        dens = context.getResources().getDisplayMetrics().density;
        PorterDuffXfermode add = new PorterDuffXfermode(PorterDuff.Mode.ADD);
        glowPaint.setXfermode(add);
        hotPaint.setXfermode(add);
        linePaint.setXfermode(add);
        linePaint.setStyle(Paint.Style.STROKE);
        buildSprite();
    }

    // one soft round light: opaque white in the middle, fading smoothly to nothing
    private void buildSprite() {
        int s = 64;
        sprite = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(sprite);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(s / 2f, s / 2f, s / 2f,
                new int[]{0xFFFFFFFF, 0x66FFFFFF, 0x1AFFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.28f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(s / 2f, s / 2f, s / 2f, p);
        spriteSrc.set(0, 0, s, s);
    }

    @Override
    public void setPalette(ThemePalette palette) {
        bg = palette.getBackgroundColor();
        bgAlt = palette.getBackgroundColorAlt();
        accent = palette.getAccentColor();
        hot = mix(accent, 0xFFFFFFFF, 0.62f);
        glowPaint.setColorFilter(new PorterDuffColorFilter(accent, PorterDuff.Mode.SRC_IN));
        hotPaint.setColorFilter(new PorterDuffColorFilter(hot, PorterDuff.Mode.SRC_IN));
        linePaint.setColor(accent);
        rebuildBackground();
        onPalette();
        invalidate();
    }

    /** Called after the palette changed. */
    protected void onPalette() {
    }

    /** Called when the size is known (and changes): create / reposition things. */
    protected abstract void onSized(int width, int height);

    /** Draw the moving lights. dt in seconds. The canvas already holds the background. */
    protected abstract void drawFx(Canvas canvas, float dt);

    private void rebuildBackground() {
        if (w <= 0 || h <= 0) {
            return;
        }
        // a faint lit area behind where the sphere sits, falling to the deep background at the edges
        int centre = mix(bg, bgAlt, 0.7f);
        bgPaint.setShader(new RadialGradient(w * 0.5f, h * 0.46f, Math.max(w, h) * 0.78f,
                centre, bg, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        super.onSizeChanged(nw, nh, ow, oh);
        w = nw;
        h = nh;
        rebuildBackground();
        if (w > 0 && h > 0) {
            onSized(w, h);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        long now = System.nanoTime();
        float dt = lastNanos == 0L ? (1f / 60f) : (now - lastNanos) / 1_000_000_000f;
        lastNanos = now;
        if (dt > 0.05f) {
            dt = 0.05f;
        }
        time += dt;

        canvas.drawColor(bg);
        canvas.drawRect(0f, 0f, w, h, bgPaint);
        drawFx(canvas, dt);

        if (running) {
            postInvalidateOnAnimation();
        }
    }

    // ------------------------------------------------------------------
    // drawing helpers for subclasses
    // ------------------------------------------------------------------

    /** Soft light in the accent colour. alpha 0..1. */
    protected void glow(Canvas c, float x, float y, float r, float alpha) {
        if (alpha <= 0.004f) {
            return;
        }
        dst.set(x - r, y - r, x + r, y + r);
        glowPaint.setAlpha(alpha >= 1f ? 255 : (int) (alpha * 255f));
        c.drawBitmap(sprite, spriteSrc, dst, glowPaint);
    }

    /** Soft light in the white-hot tint (the bright centre of a particle). */
    protected void hotGlow(Canvas c, float x, float y, float r, float alpha) {
        if (alpha <= 0.004f) {
            return;
        }
        dst.set(x - r, y - r, x + r, y + r);
        hotPaint.setAlpha(alpha >= 1f ? 255 : (int) (alpha * 255f));
        c.drawBitmap(sprite, spriteSrc, dst, hotPaint);
    }

    /** Light stretched into an ellipse (hazes, glints, auroras). */
    protected void glowRect(Canvas c, float cx, float cy, float rx, float ry, float alpha) {
        if (alpha <= 0.004f) {
            return;
        }
        dst.set(cx - rx, cy - ry, cx + rx, cy + ry);
        glowPaint.setAlpha(alpha >= 1f ? 255 : (int) (alpha * 255f));
        c.drawBitmap(sprite, spriteSrc, dst, glowPaint);
    }

    protected static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 0xFF) * (1f - t) + ((b >> 16) & 0xFF) * t);
        int g = (int) (((a >> 8) & 0xFF) * (1f - t) + ((b >> 8) & 0xFF) * t);
        int bl = (int) ((a & 0xFF) * (1f - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    protected static float rnd(java.util.Random r, float lo, float hi) {
        return lo + r.nextFloat() * (hi - lo);
    }

    // ------------------------------------------------------------------
    // lifecycle: only animate while visible
    // ------------------------------------------------------------------

    private void setRunning(boolean run) {
        if (run == running) {
            return;
        }
        running = run;
        if (run) {
            lastNanos = 0L;
            postInvalidateOnAnimation();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        setRunning(getWindowVisibility() == View.VISIBLE);
    }

    @Override
    protected void onDetachedFromWindow() {
        setRunning(false);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        setRunning(visibility == View.VISIBLE && isAttachedToWindow());
    }

    @Override
    public void stopAnimating() {
        setRunning(false);
    }
}
