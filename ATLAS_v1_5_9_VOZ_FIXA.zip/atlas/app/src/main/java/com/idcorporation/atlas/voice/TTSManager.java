package com.idcorporation.atlas.voice;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;

import com.idcorporation.atlas.utils.LocaleHelper;

import java.util.Locale;
import java.util.Set;

public class TTSManager {

    public interface SpeechStateListener {
        void onSpeechStart();
        void onSpeechDone();
        void onSpeechError();
    }

    private static final String TAG = "AtlasTTS";
    private static final String GOOGLE_TTS_ENGINE = "com.google.android.tts";
    /** Voice names ATLAS prefers, best first (Google voice ids). Empty slots fall back to the scoring below. */
    private static final String[] PREFERRED_VOICES_PT_BR = {
        "pt-br-x-ptd-local", "pt-br-x-afs-local", "pt-br-x-ptd-network", "pt-br-x-afs-network"
    };

    private TextToSpeech textToSpeech;
    private boolean isReady = false;
    private volatile int speakGeneration = 0;
    private static final int MAX_CHUNK_CHARS = 380;
    private float speechRate = 1.0f;
    private float speechPitch = 1.0f;
    private SpeechStateListener listener;
    private final Context appContext;
    private final Handler mainThreadHandler = new Handler(Looper.getMainLooper());

    public TTSManager(Context context) {
        this.appContext = context.getApplicationContext();
        // Same engine on every phone = same voice on every phone. Without this each
        // brand uses its own default engine (Samsung, Xiaomi, Google...) and ATLAS
        // sounds different everywhere.
        createEngine(isGoogleTtsInstalled() ? GOOGLE_TTS_ENGINE : null);
    }

    private boolean isGoogleTtsInstalled() {
        try {
            appContext.getPackageManager().getPackageInfo(GOOGLE_TTS_ENGINE, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** enginePackage null = whatever the phone uses by default (last-resort fallback). */
    private void createEngine(final String enginePackage) {
        final TextToSpeech[] holder = new TextToSpeech[1];
        TextToSpeech engine = new TextToSpeech(appContext, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    if (holder[0] != null) {
                        textToSpeech = holder[0];
                    }
                    applyCurrentLanguage();
                    textToSpeech.setSpeechRate(speechRate);
                    textToSpeech.setPitch(speechPitch);
                    isReady = true;
                } else if (enginePackage != null) {
                    // The Google engine refused to start: fall back to the phone's own.
                    Log.w(TAG, "Google TTS failed to start, using the default engine");
                    try {
                        if (holder[0] != null) {
                            holder[0].shutdown();
                        }
                    } catch (Exception ignored) {
                    }
                    createEngine(null);
                } else {
                    isReady = false;
                }
            }
        }, enginePackage);
        holder[0] = engine;
        textToSpeech = engine;
        attachProgressListener(engine);
    }

    private void attachProgressListener(TextToSpeech engine) {
        engine.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            // Android calls these on a binder thread, so each one hops to the main
            // thread. Utterance ids look like atlas_u_<generation>_<index>_<count>:
            // anything from an older generation (already stopped/flushed) is ignored,
            // and "done" is reported only after the LAST piece of the reply.
            @Override
            public void onStart(final String utteranceId) {
                final int[] id = parseId(utteranceId);
                if (id == null || id[0] != speakGeneration || id[1] != 0) {
                    return;
                }
                mainThreadHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (id[0] == speakGeneration && listener != null) {
                            listener.onSpeechStart();
                        }
                    }
                });
            }

            @Override
            public void onDone(final String utteranceId) {
                final int[] id = parseId(utteranceId);
                if (id == null || id[0] != speakGeneration || id[1] != id[2] - 1) {
                    return;
                }
                mainThreadHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (id[0] == speakGeneration && listener != null) {
                            listener.onSpeechDone();
                        }
                    }
                });
            }

            @Override
            public void onError(final String utteranceId) {
                final int[] id = parseId(utteranceId);
                if (id == null || id[0] != speakGeneration) {
                    return;
                }
                // One error ends the whole reply: drop the rest of the queue so nothing keeps talking.
                speakGeneration = speakGeneration + 1;
                mainThreadHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (listener != null) {
                            listener.onSpeechError();
                        }
                    }
                });
            }
        });
    }

    private static int[] parseId(String utteranceId) {
        if (utteranceId == null || !utteranceId.startsWith("atlas_u_")) {
            return null;
        }
        String[] parts = utteranceId.split("_");
        if (parts.length != 5) {
            return null;
        }
        try {
            return new int[]{Integer.parseInt(parts[2]), Integer.parseInt(parts[3]), Integer.parseInt(parts[4])};
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public void setListener(SpeechStateListener speechStateListener) {
        this.listener = speechStateListener;
    }

    public void applyCurrentLanguage() {
        String languageCode = LocaleHelper.getSavedLanguage(appContext);
        Locale locale = LocaleHelper.getLocaleForLanguage(languageCode);
        if (isReady || textToSpeech != null) {
            int result = textToSpeech.setLanguage(locale);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech.setLanguage(Locale.ENGLISH);
                locale = Locale.ENGLISH;
            }
            applyFixedVoice(locale);
        }
    }

    /**
     * Picks ONE specific voice for the language instead of the phone's default voice.
     * Order: a name from the preferred list, then offline voices over online ones,
     * then higher quality, then alphabetical (so every phone makes the same choice).
     */
    private void applyFixedVoice(Locale locale) {
        try {
            Set<Voice> voices = textToSpeech.getVoices();
            if (voices == null || voices.isEmpty()) {
                return;
            }
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            for (Voice v : voices) {
                Locale vl = v.getLocale();
                if (vl == null || !vl.getLanguage().equalsIgnoreCase(locale.getLanguage())
                    || !vl.getCountry().equalsIgnoreCase(locale.getCountry())) {
                    continue;
                }
                if (v.getFeatures() != null && v.getFeatures().contains("notInstalled")) {
                    continue;
                }
                int score = v.getQuality();
                if (!v.isNetworkConnectionRequired()) {
                    score += 1000;
                }
                if (v.getName() != null && v.getName().contains("-x-")) {
                    score += 500; // Google neural-style ids
                }
                if ("pt".equals(locale.getLanguage()) && "BR".equalsIgnoreCase(locale.getCountry())) {
                    for (int i = 0; i < PREFERRED_VOICES_PT_BR.length; i++) {
                        if (PREFERRED_VOICES_PT_BR[i].equalsIgnoreCase(v.getName())) {
                            score += 100000 - i * 1000;
                        }
                    }
                }
                if (best == null || score > bestScore
                    || (score == bestScore && v.getName().compareTo(best.getName()) < 0)) {
                    best = v;
                    bestScore = score;
                }
            }
            if (best != null) {
                textToSpeech.setVoice(best);
                Log.i(TAG, "Fixed voice: " + best.getName());
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not fix the voice: " + e);
        }
    }

    public void setSpeechRate(float rate) {
        this.speechRate = rate;
        if (isReady) {
            textToSpeech.setSpeechRate(rate);
        }
    }

    public void setSpeechPitch(float pitch) {
        this.speechPitch = pitch;
        if (isReady) {
            textToSpeech.setPitch(pitch);
        }
    }

    public void speak(String text) {
        // Emojis and decorative symbols are never read aloud (the chat text keeps them).
        final java.util.ArrayList<String> chunks = com.idcorporation.atlas.utils.SpeechText.splitForTts(
            com.idcorporation.atlas.utils.SpeechText.forSpeech(text), MAX_CHUNK_CHARS);
        if (!isReady || chunks.isEmpty()) {
            // Nothing will be spoken, so no "done" callback will ever come.
            // Tell the listener anyway - otherwise the voice pipeline waits
            // forever for a speech-finished event that never arrives and
            // the microphone never comes back.
            mainThreadHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (listener != null) {
                        listener.onSpeechError();
                    }
                }
            });
            return;
        }
        // A new reply replaces whatever was still queued; the generation number makes
        // late callbacks from the replaced reply harmless.
        speakGeneration = speakGeneration + 1;
        int generation = speakGeneration;
        for (int i = 0; i < chunks.size(); i++) {
            String utteranceId = "atlas_u_" + generation + "_" + i + "_" + chunks.size();
            textToSpeech.speak(chunks.get(i), i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                null, utteranceId);
        }
    }

    /** Cuts the voice immediately and empties the queue; no "done" callback follows. */
    public void stopSpeaking() {
        speakGeneration = speakGeneration + 1;
        if (isReady) {
            textToSpeech.stop();
        }
    }

    public boolean isSpeaking() {
        return isReady && textToSpeech.isSpeaking();
    }

    public void shutdown() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }
}
