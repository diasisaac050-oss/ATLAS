package com.idcorporation.atlas.activities;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.adapters.MemoryListAdapter;
import com.idcorporation.atlas.memory.MemoryManager;
import com.idcorporation.atlas.models.MemoryItem;

import java.util.ArrayList;

/**
 * ATLAS GLACIAL "Memory Control": full transparency and control over
 * everything ATLAS knows about the user - view it, teach it something
 * new (remember), correct it (edit), remove a single fact (forget) or
 * wipe everything (delete all).
 */
public class MemoryActivity extends BaseActivity {

    private MemoryManager memoryManager;
    private RecyclerView recyclerView;
    private TextView emptyStateView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generic_list);

        memoryManager = new MemoryManager(this);

        TextView titleView = (TextView) findViewById(R.id.text_screen_title);
        titleView.setText(R.string.title_memory);

        emptyStateView = (TextView) findViewById(R.id.text_empty_state);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.button_clear_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDeleteAll();
            }
        });

        View addButton = findViewById(R.id.button_add_row);
        addButton.setVisibility(View.VISIBLE);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMemoryDialog(null);
            }
        });

        loadMemories();
    }

    private void confirmDeleteAll() {
        new AlertDialog.Builder(this)
            .setTitle(R.string.action_clear_all)
            .setMessage(R.string.confirm_delete_all_memory)
            .setPositiveButton(R.string.action_clear_all, new android.content.DialogInterface.OnClickListener() {
                @Override
                public void onClick(android.content.DialogInterface dialog, int which) {
                    memoryManager.deleteAllMemories();
                    loadMemories();
                }
            })
            .setNegativeButton(R.string.action_cancel, null)
            .show();
    }

    /** Pass null to create a new memory, or an existing item to edit it. */
    private void showMemoryDialog(final MemoryItem existingItem) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_memory_edit, null);

        final TextView titleView = (TextView) dialogView.findViewById(R.id.text_dialog_title);
        final EditText keyInput = (EditText) dialogView.findViewById(R.id.input_memory_key);
        final EditText valueInput = (EditText) dialogView.findViewById(R.id.input_memory_value);
        View cancelButton = dialogView.findViewById(R.id.button_dialog_cancel);
        View saveButton = dialogView.findViewById(R.id.button_dialog_save);

        titleView.setText(existingItem == null ? R.string.title_add_memory : R.string.title_edit_memory);
        if (existingItem != null) {
            keyInput.setText(existingItem.getKey());
            valueInput.setText(existingItem.getValue());
        }

        final AlertDialog dialog = new AlertDialog.Builder(this)
            .setView(dialogView)
            .create();

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String key = keyInput.getText().toString().trim();
                String value = valueInput.getText().toString().trim();

                if (key.length() == 0 || value.length() == 0) {
                    Toast.makeText(MemoryActivity.this, R.string.hint_memory_value, Toast.LENGTH_SHORT).show();
                    return;
                }

                if (existingItem == null) {
                    memoryManager.saveMemory(key, value, "manual");
                    Toast.makeText(MemoryActivity.this, R.string.toast_memory_saved, Toast.LENGTH_SHORT).show();
                } else {
                    memoryManager.updateMemory(existingItem.getId(), key, value);
                    Toast.makeText(MemoryActivity.this, R.string.toast_memory_updated, Toast.LENGTH_SHORT).show();
                }

                dialog.dismiss();
                loadMemories();
            }
        });

        dialog.show();
    }

    private void loadMemories() {
        final ArrayList<MemoryItem> memories = memoryManager.getAllMemories();

        ArrayList<MemoryItem> identity = new ArrayList<MemoryItem>();
        ArrayList<MemoryItem> preferences = new ArrayList<MemoryItem>();
        ArrayList<MemoryItem> general = new ArrayList<MemoryItem>();
        for (int i = 0; i < memories.size(); i++) {
            MemoryItem item = memories.get(i);
            int bucket = classify(item.getKey());
            if (bucket == BUCKET_IDENTITY) {
                identity.add(item);
            } else if (bucket == BUCKET_PREFERENCES) {
                preferences.add(item);
            } else {
                general.add(item);
            }
        }

        emptyStateView.setVisibility(memories.isEmpty() ? View.VISIBLE : View.GONE);

        MemoryListAdapter adapter = new MemoryListAdapter(
            getString(R.string.title_memory_section_identity), identity,
            getString(R.string.title_memory_section_preferences), preferences,
            getString(R.string.title_memory_section_general), general,
            new MemoryListAdapter.OnRowDeleteListener() {
                @Override
                public void onDelete(long rowId) {
                    memoryManager.deleteMemory(rowId);
                    loadMemories();
                }
            },
            new MemoryListAdapter.OnRowClickListener() {
                @Override
                public void onRowClick(long rowId) {
                    MemoryItem tapped = findMemoryById(memories, rowId);
                    if (tapped != null) {
                        showMemoryDialog(tapped);
                    }
                }
            });
        recyclerView.setAdapter(adapter);
    }

    private static final int BUCKET_IDENTITY = 0;
    private static final int BUCKET_PREFERENCES = 1;
    private static final int BUCKET_GENERAL = 2;

    // ATLAS FASE 3/4 item 4: a light, honest heuristic over the memory's own
    // key - it never guesses at content the user did not provide, it only
    // decides which of the three sections a real stored key belongs in.
    private static final String[] IDENTITY_KEYWORDS = {
        "nome", "name", "idade", "age", "aniversario", "birthday", "nascimento",
        "profissao", "profissão", "occupation", "job", "trabalho", "ocupacao"
    };
    private static final String[] PREFERENCE_KEYWORDS = {
        "favorit", "prefer", "gosto", "gosta"
    };

    private static int classify(String key) {
        String normalized = key == null ? "" : key.toLowerCase();
        String[] words = normalized.split("[^\\p{L}\\p{Nd}]+");
        for (int w = 0; w < words.length; w++) {
            String word = words[w];
            for (int i = 0; i < IDENTITY_KEYWORDS.length; i++) {
                if (word.equals(IDENTITY_KEYWORDS[i])) {
                    return BUCKET_IDENTITY;
                }
            }
            for (int i = 0; i < PREFERENCE_KEYWORDS.length; i++) {
                if (word.startsWith(PREFERENCE_KEYWORDS[i])) {
                    return BUCKET_PREFERENCES;
                }
            }
        }
        return BUCKET_GENERAL;
    }

    private MemoryItem findMemoryById(ArrayList<MemoryItem> memories, long id) {
        for (int i = 0; i < memories.size(); i++) {
            if (memories.get(i).getId() == id) {
                return memories.get(i);
            }
        }
        return null;
    }
}
