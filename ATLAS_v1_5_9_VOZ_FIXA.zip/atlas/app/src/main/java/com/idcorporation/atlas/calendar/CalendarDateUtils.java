package com.idcorporation.atlas.calendar;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Small helper around java.util.Calendar for the month math the
 * infinite calendar and the birthday checks need. Kept as plain
 * static methods with explicit casts, no lambdas, to match the
 * Code Assist build constraints used across ATLAS.
 */
public class CalendarDateUtils {

    public static final int ANCHOR_YEAR;
    public static final int ANCHOR_MONTH;

    static {
        Calendar now = Calendar.getInstance();
        ANCHOR_YEAR = now.get(Calendar.YEAR);
        ANCHOR_MONTH = now.get(Calendar.MONTH) + 1;
    }

    /** Converts an infinite-adapter position into a [year, month] pair. Position 0 is ANCHOR_YEAR/ANCHOR_MONTH. */
    public static int[] positionToYearMonth(int offsetFromAnchor) {
        int totalMonths = (ANCHOR_YEAR * 12 + (ANCHOR_MONTH - 1)) + offsetFromAnchor;
        int year = totalMonths / 12;
        int month = (totalMonths % 12) + 1;
        if (month <= 0) {
            month += 12;
            year -= 1;
        }
        return new int[]{year, month};
    }

    public static int daysInMonth(int year, int month) {
        Calendar cal = new GregorianCalendar(year, month - 1, 1);
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    /** 0 = Sunday .. 6 = Saturday, matching a standard Android agenda week header. */
    public static int firstWeekdayOfMonth(int year, int month) {
        Calendar cal = new GregorianCalendar(year, month - 1, 1);
        return cal.get(Calendar.DAY_OF_WEEK) - 1;
    }

    public static boolean isValidDate(int year, int month, int day) {
        if (month < 1 || month > 12 || day < 1 || year < 1900 || year > 2200) {
            return false;
        }
        return day <= daysInMonth(year, month);
    }

    public static boolean isToday(int year, int month, int day) {
        Calendar now = Calendar.getInstance();
        return now.get(Calendar.YEAR) == year
            && (now.get(Calendar.MONTH) + 1) == month
            && now.get(Calendar.DAY_OF_MONTH) == day;
    }

    /** Resolves a bare day/month spoken by the user to the next real occurrence (this year or next). */
    public static int resolveYearForUpcomingDate(int month, int day) {
        Calendar now = Calendar.getInstance();
        int thisYear = now.get(Calendar.YEAR);
        Calendar candidate = new GregorianCalendar(thisYear, month - 1, day, 23, 59);
        if (candidate.getTimeInMillis() < now.getTimeInMillis()) {
            return thisYear + 1;
        }
        return thisYear;
    }

    public static long toEpochMillis(int year, int month, int day, int hour, int minute) {
        Calendar cal = new GregorianCalendar(year, month - 1, day, Math.max(hour, 0), Math.max(minute, 0), 0);
        return cal.getTimeInMillis();
    }

    /** Days remaining until the next occurrence of month/day (0 if it is today). */
    public static int daysUntilNextOccurrence(int month, int day) {
        Calendar now = Calendar.getInstance();
        clearTime(now);
        int year = resolveYearForUpcomingDate(month, day);
        Calendar target = new GregorianCalendar(year, month - 1, day);
        clearTime(target);
        long diffMillis = target.getTimeInMillis() - now.getTimeInMillis();
        return (int) (diffMillis / (24L * 60L * 60L * 1000L));
    }

    private static void clearTime(Calendar cal) {
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
    }

    public static String monthNamePt(int month) {
        String[] names = new String[]{
            "Janeiro", "Fevereiro", "Marco", "Abril", "Maio", "Junho",
            "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
        };
        int index = month - 1;
        if (index < 0 || index >= names.length) {
            return "";
        }
        return names[index];
    }
}
