package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.services.AlarmSoundService;
import com.idcorporation.atlas.utils.AlarmScheduler;
import com.idcorporation.atlas.utils.ViewAnimUtils;

public class AlarmRingActivity extends BaseActivity {

    @Override
    protected boolean isMaintenanceExempt() {
        return true;
    }

    @Override
    protected boolean isVoiceCallScreen() {
        return false;
    }


    private static final long SNOOZE_MILLIS = 5L * 60L * 1000L;

    private String alarmTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setShowOverLockScreen();
        setContentView(R.layout.activity_alarm_ring);

        alarmTitle = getIntent().getStringExtra(AlarmScheduler.EXTRA_TITLE);
        if (alarmTitle == null || alarmTitle.length() == 0) {
            alarmTitle = getString(R.string.alarm_default_title);
        }

        TextView titleView = (TextView) findViewById(R.id.text_alarm_ring_title);
        titleView.setText(alarmTitle);

        View stopButton = findViewById(R.id.button_alarm_stop);
        View snoozeButton = findViewById(R.id.button_alarm_snooze);

        ViewAnimUtils.applyPressFeedback(stopButton);
        ViewAnimUtils.applyPressFeedback(snoozeButton);

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlarmSoundService.stop(AlarmRingActivity.this);
                finish();
            }
        });

        snoozeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlarmSoundService.stop(AlarmRingActivity.this);
                long triggerMillis = System.currentTimeMillis() + SNOOZE_MILLIS;
                int requestCode = (int) (triggerMillis % Integer.MAX_VALUE);
                AlarmScheduler.scheduleAlarm(AlarmRingActivity.this, triggerMillis, requestCode,
                    alarmTitle, getString(R.string.alarm_default_message));
                finish();
            }
        });
    }

    private void setShowOverLockScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onBackPressed() {
        // Prevent dismissing the alarm with the back button - it must be
        // stopped or snoozed explicitly, like a real alarm clock.
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }
}
