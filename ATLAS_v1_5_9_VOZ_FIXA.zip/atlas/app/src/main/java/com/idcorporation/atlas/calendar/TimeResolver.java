package com.idcorporation.atlas.calendar;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Turns "a clock time, maybe on a given date" into one real moment in
 * the future. The tricky part is an hour said with no am/pm ("as 7"):
 * for something later today it picks whichever of 7:00 / 19:00 comes
 * first (alarms at 4-9 always mean the morning, the usual wake-up);
 * for another day it assumes the usual meaning (alarms: morning;
 * reminders: 7-11 morning, 1-6 afternoon). If the time already passed
 * today it moves to tomorrow, and the spoken answer says so.
 */
public class TimeResolver {

    public static Calendar resolve(ClockExpressionParser.ClockResult clock,
            DateExpressionParser.DateResult date, Calendar now, boolean isAlarm) {
        Calendar day = (Calendar) now.clone();
        if (date != null && date.found) {
            day = new GregorianCalendar(date.year, date.month - 1, date.day);
        }
        Calendar target = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            boolean sameDay = isSameDay(day, now);
            target = pickForDay(clock, day, now, isAlarm, sameDay);
            if (target != null && target.getTimeInMillis() > now.getTimeInMillis()) {
                return target;
            }
            day.add(Calendar.DAY_OF_MONTH, 1);
        }
        return at(day, clock.hour < 0 ? 0 : clock.hour, clock.minute);
    }

    private static Calendar pickForDay(ClockExpressionParser.ClockResult clock, Calendar day, Calendar now,
            boolean isAlarm, boolean sameDay) {
        if (!clock.ambiguous) {
            return at(day, clock.hour, clock.minute);
        }
        if (isAlarm && clock.hour >= 4 && clock.hour <= 9) {
            // "despertador as 6" almost always means a wake-up in the morning, even if asked in the afternoon.
            return at(day, clock.hour, clock.minute);
        }
        if (sameDay) {
            Calendar morning = at(day, clock.hour, clock.minute);
            if (morning.getTimeInMillis() > now.getTimeInMillis()) {
                return morning;
            }
            return at(day, clock.hour + 12, clock.minute);
        }
        int hour = clock.hour;
        if (!isAlarm && hour >= 1 && hour <= 6) {
            hour += 12;
        }
        return at(day, hour, clock.minute);
    }

    private static Calendar at(Calendar day, int hour, int minute) {
        return new GregorianCalendar(day.get(Calendar.YEAR), day.get(Calendar.MONTH),
            day.get(Calendar.DAY_OF_MONTH), hour, minute, 0);
    }

    public static boolean isSameDay(Calendar a, Calendar b) {
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR)
            && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR);
    }
}
