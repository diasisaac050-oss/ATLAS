package com.idcorporation.atlas.agent.tools;

import android.content.Intent;
import android.net.Uri;

import com.idcorporation.atlas.agent.AgentTool;
import com.idcorporation.atlas.agent.ToolResult;
import com.idcorporation.atlas.commands.AppCommandHandler;

import org.json.JSONObject;

import java.util.concurrent.Callable;

public final class OpenUrlAndEmailTools {

    private OpenUrlAndEmailTools() {
    }

    public static class OpenUrl extends BaseTool {
        public OpenUrl(ToolEnv env) {
            super(env);
        }

        @Override
        public String name() {
            return "open_url";
        }

        @Override
        public String description() {
            return "Open a web page in the browser. For a Google search give a full https://www.google.com/search?q=... URL. "
                + "Only https/http links.";
        }

        @Override
        public JSONObject parameters() {
            return Schema.obj().str("url", "Full https URL.", true).build();
        }

        @Override
        public ToolResult execute(JSONObject args) throws Exception {
            final String url = arg(args, "url");
            if (!(url.startsWith("https://") || url.startsWith("http://"))) {
                return ToolResult.failed("Only http(s) links can be opened.");
            }
            Boolean opened = env.onMain(new Callable<Boolean>() {
                @Override
                public Boolean call() {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        env.context.startActivity(i);
                        return Boolean.TRUE;
                    } catch (RuntimeException e) {
                        return Boolean.FALSE;
                    }
                }
            }, 6000L);
            if (!opened.booleanValue()) {
                return ToolResult.failed("No app could open that link.");
            }
            return ToolResult.partial("The page was opened in the browser (Android accepted the launch). "
                + "Its content was not read by the app.");
        }
    }

    /**
     * There is no authorized way to READ mail here: Gmail's API needs the
     * user's OAuth sign-in and a registered client, which this app does not
     * have. So this tool honestly only opens the inbox and says that it
     * did not read anything.
     */
    public static class OpenEmailInbox extends BaseTool {
        public OpenEmailInbox(ToolEnv env) {
            super(env);
        }

        @Override
        public String name() {
            return "open_email_inbox";
        }

        @Override
        public String description() {
            return "Open the user's email app at the inbox. This cannot read or summarize messages.";
        }

        @Override
        public JSONObject parameters() {
            return Schema.obj().build();
        }

        @Override
        public ToolResult execute(JSONObject args) throws Exception {
            boolean opened = env.onMain(new Callable<Boolean>() {
                @Override
                public Boolean call() {
                    try {
                        Intent mail = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_EMAIL);
                        mail.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        env.context.startActivity(mail);
                        return Boolean.TRUE;
                    } catch (RuntimeException e) {
                        // Try the Gmail launcher next.
                    }
                    String label = null;
                    try {
                        label = new AppCommandHandler().openAppAndReturnLabel(env.context, "gmail");
                    } catch (RuntimeException ignored) {
                        // Not installed.
                    }
                    return Boolean.valueOf(label != null);
                }
            }, 6000L).booleanValue();
            if (!opened) {
                return ToolResult.failed("No email app could be opened, and mail cannot be read without an "
                    + "authorized mail integration.");
            }
            return ToolResult.partial("The email app was opened (Android accepted the launch), but NO messages were "
                + "read. Reading mail needs a Gmail API sign-in (OAuth) that is not set up in this app. Tell the "
                + "user plainly that you could only open the inbox.");
        }
    }

    public static AgentTool[] all(ToolEnv env) {
        return new AgentTool[]{new OpenUrl(env), new OpenEmailInbox(env)};
    }
}
