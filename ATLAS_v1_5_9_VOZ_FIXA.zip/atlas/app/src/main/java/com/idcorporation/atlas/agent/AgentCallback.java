package com.idcorporation.atlas.agent;

/** Delivered on the main thread. */
public interface AgentCallback {
    void onResult(AgentResult result);

    void onError(String errorMessage, int errorCode);
}
