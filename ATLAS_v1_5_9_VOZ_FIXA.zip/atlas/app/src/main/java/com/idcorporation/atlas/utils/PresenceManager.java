package com.idcorporation.atlas.utils;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

import com.idcorporation.atlas.services.PresenceOverlayService;

/**
 * ATLAS GLACIAL "Presenca": remembers whether the user turned on the
 * shake-to-activate gesture and starts/stops the background service
 * accordingly. Mirrors the pattern used by ReminderScheduler for the
 * daily notification toggle.
 */
public class PresenceManager {

    private static final String PREFS_NAME = "atlas_presence_prefs";
    private static final String KEY_ENABLED = "presence_enabled";
    private static final String KEY_LAYOUT = "presence_layout";

    /** Original look: blue liquid-glass lens that drops from the top under the notch. */
    public static final int LAYOUT_GLASS = 0;
    /** Transparent colorless orb with moving light inside that rises from the bottom. */
    public static final int LAYOUT_ORB = 1;
    /** Futuristic ATLAS nucleus that rises from below, expands at center, then retracts. */
    public static final int LAYOUT_NUCLEUS = 2;
    /** CHAMIZO INTELLIGENCE: same liquid-glass look as LAYOUT_GLASS, but a portrait card
     * that fades and blooms open in the middle of the screen instead of hugging an edge. */
    public static final int LAYOUT_CARD = 3;

    public static boolean isEnabled(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        Context appContext = context.getApplicationContext();
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply();

        if (enabled && canDrawOverlays(appContext) && ModeManager.isVoiceMode(appContext)) {
            startService(appContext);
        } else {
            stopService(appContext);
        }
    }

    /**
     * ATLAS MODOS: the shake bubble listens to your voice, so it only runs
     * in Voice mode. The user's on/off choice is kept untouched; this just
     * starts or stops the service to match the current mode.
     */
    public static void syncWithMode(Context context) {
        Context appContext = context.getApplicationContext();
        if (isEnabled(appContext) && canDrawOverlays(appContext)
                && ModeManager.isVoiceMode(appContext)) {
            startService(appContext);
        } else {
            stopService(appContext);
        }
    }

    /** Which look the shake gesture shows. Defaults to the original glass lens. */
    public static int getLayout(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int stored = prefs.getInt(KEY_LAYOUT, LAYOUT_GLASS);
        if (stored == LAYOUT_ORB) {
            return LAYOUT_ORB;
        }
        if (stored == LAYOUT_NUCLEUS) {
            return LAYOUT_NUCLEUS;
        }
        if (stored == LAYOUT_CARD) {
            return LAYOUT_CARD;
        }
        return LAYOUT_GLASS;
    }

    /** Takes effect the next time the presence is shown; the service does not need a restart. */
    public static void setLayout(Context context, int layout) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_LAYOUT, layout).apply();
    }

    public static boolean canDrawOverlays(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(context);
        }
        return true;
    }

    public static void startService(Context context) {
        Context appContext = context.getApplicationContext();
        Intent intent = new Intent(appContext, PresenceOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            appContext.startForegroundService(intent);
        } else {
            appContext.startService(intent);
        }
    }

    public static void stopService(Context context) {
        Context appContext = context.getApplicationContext();
        appContext.stopService(new Intent(appContext, PresenceOverlayService.class));
    }

    /** Called from BootReceiver: only restarts the service if the user had it on and permission still holds. */
    public static void restartIfEnabled(Context context) {
        if (isEnabled(context) && canDrawOverlays(context) && ModeManager.isVoiceMode(context)) {
            startService(context);
        }
    }
}
