package com.idcorporation.atlas.models;

public class CalendarEventItem {

    public static final String TYPE_REMINDER = "REMINDER";
    public static final String TYPE_BIRTHDAY = "BIRTHDAY";
    public static final String TYPE_ALARM = "ALARM";

    /** ATLAS FASE 3/4 item 21: recurrence rule values, mirrored in AtlasDatabase's recurrence_rule column. */
    public static final String RECURRENCE_NONE = "NONE";
    public static final String RECURRENCE_DAILY = "DAILY";
    public static final String RECURRENCE_WEEKLY = "WEEKLY";
    public static final String RECURRENCE_MONTHLY = "MONTHLY";

    private long id;
    private int year;
    private int month;
    private int day;
    private int hour;
    private int minute;
    private String title;
    private String eventType;
    private boolean repeatYearly;
    private String recurrenceRule;
    private int recurrenceInterval;

    /** Backward-compatible constructor for a plain, non-recurring event. */
    public CalendarEventItem(long id, int year, int month, int day, int hour, int minute,
            String title, String eventType, boolean repeatYearly) {
        this(id, year, month, day, hour, minute, title, eventType, repeatYearly, RECURRENCE_NONE, 1);
    }

    public CalendarEventItem(long id, int year, int month, int day, int hour, int minute,
            String title, String eventType, boolean repeatYearly, String recurrenceRule, int recurrenceInterval) {
        this.id = id;
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
        this.title = title;
        this.eventType = eventType;
        this.repeatYearly = repeatYearly;
        this.recurrenceRule = (recurrenceRule == null || recurrenceRule.length() == 0)
            ? RECURRENCE_NONE : recurrenceRule;
        this.recurrenceInterval = recurrenceInterval < 1 ? 1 : recurrenceInterval;
    }

    public long getId() {
        return id;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public boolean hasTime() {
        return hour >= 0 && minute >= 0;
    }

    public String getTitle() {
        return title;
    }

    public String getEventType() {
        return eventType;
    }

    public boolean isRepeatYearly() {
        return repeatYearly;
    }

    public String getRecurrenceRule() {
        return recurrenceRule;
    }

    public int getRecurrenceInterval() {
        return recurrenceInterval;
    }

    public boolean isRecurring() {
        return recurrenceRule != null && !RECURRENCE_NONE.equals(recurrenceRule);
    }
}
