package com.idcorporation.atlas.activities;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.speech.SpeechRecognizer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.chat.ChatAdapter;
import com.idcorporation.atlas.chat.ChatMessage;
import com.idcorporation.atlas.chat.ChatOrbView;
import com.idcorporation.atlas.chat.ChatSession;
import com.idcorporation.atlas.chat.ChatStyle;
import com.idcorporation.atlas.theme.ThemeManager;
import com.idcorporation.atlas.utils.AlarmPermissionHelper;
import com.idcorporation.atlas.utils.ContactsPermissionHelper;
import com.idcorporation.atlas.utils.DeviceInfoUtil;
import android.graphics.Bitmap;
import com.idcorporation.atlas.utils.ImageUtils;
import com.idcorporation.atlas.utils.NotificationHelper;
import com.idcorporation.atlas.utils.ViewAnimUtils;
import com.idcorporation.atlas.voice.SpeechRecognizerManager;

import java.util.ArrayList;

/**
 * ATLAS MODOS - Chat mode home screen: talk to ATLAS in writing, with
 * two shortcuts around the typing itself (added by ATLAS VISAO):
 * a tap-to-dictate microphone that only fills the text box (never a
 * continuous/always-on mic, and ATLAS never talks back out loud here),
 * and an attach button that sends a picked image to a vision-capable
 * model. Commands (reminders, alarms, notes, calendar, calls, open
 * app...) still work when typed, because the screen sits on top of the
 * same CommandManager and AIManager the voice mode uses (see
 * ChatSession).
 */
public class ChatActivity extends BaseActivity
        implements ChatSession.Listener, ChatAdapter.ActionListener {

    private static final int REQUEST_CODE_CONTACT_PERMISSIONS = 502;
    private static final int REQUEST_CODE_RECORD_AUDIO = 503;
    private static final int REQUEST_CODE_PICK_IMAGE = 504;

    private ChatSession session;
    private ChatAdapter adapter;
    private LinearLayoutManager layoutManager;
    private RecyclerView list;

    private View headerView;
    private View headerLine;
    private ChatOrbView headerOrb;
    private ChatOrbView emptyOrb;
    private View statusDot;
    private TextView statusText;
    private View emptyView;
    private View emptyPanel;
    private LinearLayout suggestionsContainer;
    private final ArrayList<TextView> suggestionChips = new ArrayList<TextView>();
    private View inputBar;
    private EditText input;
    private ImageButton sendButton;
    private ImageView sendGhost;
    private ImageButton newButton;
    private ImageButton attachButton;
    private View imagePreviewRow;
    private ImageView imagePreviewThumb;
    private ProgressBar imagePreviewProgress;
    private ImageButton imagePreviewRemove;
    private ObjectAnimator dotPulse;
    private SpeechRecognizerManager speechRecognizerManager;

    private int accent = 0xFF00E5FF;
    private boolean sendEnabled = false;
    private boolean inputFocused = false;
    private boolean listening = false;

    // The image the user picked for the next message: kept as the raw Uri
    // (for the preview + the sent bubble's thumbnail) and, once the
    // background encode finishes, its base64 JPEG (for the request). Both
    // are null again as soon as the message is sent or the attachment is
    // removed.
    private Uri pendingImageUri = null;
    private String pendingImageBase64 = null;
    private String pendingImageMimeType = null;
    private boolean pendingImageEncoding = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        session = ChatSession.get(this);
        accent = ThemeManager.getSelectedPalette(this).getAccentColor();

        speechRecognizerManager = new SpeechRecognizerManager(this);
        setUpSpeechRecognizer();

        bindViews();
        setUpList();
        setUpHeaderButtons();
        setUpInput();
        setUpImageAttachment();
        buildSuggestions();

        applyAccent();
        adapter.setAll(session.getMessages(), session.isTyping());
        updateEmptyState(false);
        updateStatus();
        updateSendState(false);
        scrollToBottom(false);

        // Same start-up chores the voice home screen does, so reminders,
        // alarms and notifications keep working when Chat is the home.
        NotificationHelper.createNotificationChannel(this);
        AlarmPermissionHelper.ensureExactAlarmPermission(this);
        AlarmPermissionHelper.ensureBatteryOptimizationExemption(this);

        ViewAnimUtils.animateEntrance(headerView, 0);
        ViewAnimUtils.animateEntrance(inputBar, 140);
        if (emptyView.getVisibility() == View.VISIBLE) {
            playEmptyEntrance();
        }
        handleLaunchExtras(getIntent());
        // ATLAS AGENT CORE: spontaneous opening line (or silence) - only on a fresh open from the
        // launcher/home, not when a notification or a permission flow brought us here.
        if (savedInstanceState == null && (getIntent() == null || getIntent().getExtras() == null)) {
            session.maybeGreetOnOpen();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleLaunchExtras(intent);
    }

    /** Chat mode never opens the microphone, on any screen. */
    @Override
    protected boolean isVoiceCallScreen() {
        return false;
    }

    // -----------------------------------------------------------------
    // Setup
    // -----------------------------------------------------------------

    private void bindViews() {
        headerView = findViewById(R.id.chat_header);
        headerLine = findViewById(R.id.chat_header_line);
        headerOrb = (ChatOrbView) findViewById(R.id.chat_header_orb);
        emptyOrb = (ChatOrbView) findViewById(R.id.chat_empty_orb);
        statusDot = findViewById(R.id.chat_status_dot);
        statusText = (TextView) findViewById(R.id.chat_status_text);
        emptyView = findViewById(R.id.chat_empty);
        emptyPanel = findViewById(R.id.chat_empty_panel);
        suggestionsContainer = (LinearLayout) findViewById(R.id.chat_suggestions);
        inputBar = findViewById(R.id.chat_input_bar);
        input = (EditText) findViewById(R.id.chat_input);
        sendButton = (ImageButton) findViewById(R.id.chat_button_send);
        sendGhost = (ImageView) findViewById(R.id.chat_send_ghost);
        newButton = (ImageButton) findViewById(R.id.chat_button_new);
        attachButton = (ImageButton) findViewById(R.id.chat_button_attach);
        imagePreviewRow = findViewById(R.id.chat_image_preview_row);
        imagePreviewThumb = (ImageView) findViewById(R.id.chat_image_preview_thumb);
        imagePreviewProgress = (ProgressBar) findViewById(R.id.chat_image_preview_progress);
        imagePreviewRemove = (ImageButton) findViewById(R.id.chat_image_preview_remove);
        list = (RecyclerView) findViewById(R.id.chat_list);
    }

    private void setUpList() {
        adapter = new ChatAdapter(this, accent);
        adapter.setActionListener(this);
        layoutManager = new LinearLayoutManager(this);
        list.setLayoutManager(layoutManager);
        list.setAdapter(adapter);
        list.setItemAnimator(null);
        list.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom,
                                       int oldLeft, int oldTop, int oldRight, int oldBottom) {
                if (bottom < oldBottom) {
                    // The keyboard just opened: keep the newest bubble in view.
                    scrollToBottom(false);
                }
            }
        });
    }

    private void setUpHeaderButtons() {
        newButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newButton.animate().rotationBy(180f).setDuration(320L)
                    .setInterpolator(new OvershootInterpolator(1.4f)).start();
                if (session.getMessages().size() == 0) {
                    return;
                }
                session.newConversation();
                Toast.makeText(ChatActivity.this, R.string.chat_new_started, Toast.LENGTH_SHORT).show();
            }
        });
        ViewAnimUtils.applyPressFeedback(newButton);

        ImageButton settingsButton = (ImageButton) findViewById(R.id.chat_button_settings);
        ViewAnimUtils.applyPressFeedback(settingsButton);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ChatActivity.this, SettingsActivity.class));
            }
        });
    }

    private void setUpInput() {
        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateSendState(true);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        input.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                inputFocused = hasFocus;
                styleInputBar();
            }
        });
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean hasContent = input.getText().toString().trim().length() > 0
                    || pendingImageUri != null;
                if (hasContent) {
                    onSendClicked();
                } else {
                    onMicClicked();
                }
            }
        });
    }

    private void buildSuggestions() {
        int[] labels = new int[]{
            R.string.chat_suggest_time, R.string.chat_suggest_battery,
            R.string.chat_suggest_reminder, R.string.chat_suggest_fact
        };
        for (int i = 0; i < labels.length; i++) {
            final TextView chip = new TextView(this);
            chip.setText(labels[i]);
            chip.setTextSize(14f);
            chip.setGravity(android.view.Gravity.CENTER);
            chip.setPadding(ChatStyle.dp(this, 18), ChatStyle.dp(this, 11),
                ChatStyle.dp(this, 18), ChatStyle.dp(this, 11));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.topMargin = ChatStyle.dp(this, 8);
            chip.setLayoutParams(params);
            ViewAnimUtils.applyPressFeedback(chip);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!session.isBusy()) {
                        session.sendUserMessage(chip.getText().toString());
                    }
                }
            });
            suggestionsContainer.addView(chip);
            suggestionChips.add(chip);
        }
    }

    private void setUpImageAttachment() {
        ViewAnimUtils.applyPressFeedback(attachButton);
        attachButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (session.isBusy()) {
                    return;
                }
                launchImagePicker();
            }
        });
        imagePreviewRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearPendingImage();
            }
        });
        ViewAnimUtils.applyPressFeedback(imagePreviewRemove);
    }

    private void setUpSpeechRecognizer() {
        speechRecognizerManager.setCallback(new SpeechRecognizerManager.RecognitionCallback() {
            @Override
            public void onReadyForSpeech() {
            }

            @Override
            public void onResult(String recognizedText) {
                listening = false;
                input.setText(recognizedText);
                input.setSelection(input.getText().length());
                updateSendState(true);
            }

            @Override
            public void onError(String errorMessage, int errorCode) {
                listening = false;
                updateSendState(true);
                if (errorCode != SpeechRecognizer.ERROR_NO_MATCH
                        && errorCode != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    Toast.makeText(ChatActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onRmsChanged(float rmsDb) {
            }

            @Override
            public void onPartial(String partialText) {
                input.setText(partialText);
                input.setSelection(input.getText().length());
            }
        });
    }

    // -----------------------------------------------------------------
    // Theme
    // -----------------------------------------------------------------

    private void applyAccent() {
        headerOrb.setAccent(accent);
        emptyOrb.setAccent(accent);
        adapter.setAccent(accent);

        headerView.setBackgroundColor(0xCC070B12);
        GradientDrawable line = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0x00000000, ChatStyle.withAlpha(accent, 0xAA), 0x00000000});
        headerLine.setBackground(line);
        emptyPanel.setBackground(ChatStyle.pill(this, ChatStyle.GLASS_FILL,
            ChatStyle.withAlpha(accent, 0x55), 1f, 24f));

        for (int i = 0; i < suggestionChips.size(); i++) {
            TextView chip = suggestionChips.get(i);
            chip.setBackground(ChatStyle.pill(this, ChatStyle.GLASS_FILL,
                ChatStyle.withAlpha(accent, 0x88), 1f, 22f));
            chip.setTextColor(ChatStyle.TEXT_PRIMARY);
        }

        sendButton.setBackground(ChatStyle.accentCircle(accent));
        sendButton.setColorFilter(ChatStyle.readableOn(accent), PorterDuff.Mode.SRC_IN);
        sendGhost.setColorFilter(accent, PorterDuff.Mode.SRC_IN);
        styleInputBar();
    }

    private void styleInputBar() {
        int strokeAlpha = inputFocused ? 0xFF : 0x77;
        inputBar.setBackground(ChatStyle.pill(this, ChatStyle.GLASS_FILL,
            ChatStyle.withAlpha(accent, strokeAlpha), inputFocused ? 1.6f : 1.2f, 28f));
    }

    // -----------------------------------------------------------------
    // Lifecycle
    // -----------------------------------------------------------------

    @Override
    protected void onResume() {
        super.onResume();
        int freshAccent = ThemeManager.getSelectedPalette(this).getAccentColor();
        if (freshAccent != accent) {
            accent = freshAccent;
            applyAccent();
        }
        session.setListener(this);
        if (adapter.getMessageCount() != session.getMessages().size()
                || adapter.isTyping() != session.isTyping()) {
            adapter.setAll(session.getMessages(), session.isTyping());
            updateEmptyState(false);
            scrollToBottom(false);
        }
        updateStatus();
        updateSendState(false);
        startDotPulse();
    }

    @Override
    protected void onPause() {
        super.onPause();
        session.clearListener(this);
        stopDotPulse();
        if (listening) {
            speechRecognizerManager.cancelListening();
            listening = false;
            refreshSendButtonIcon();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        speechRecognizerManager.destroy();
    }

    private void startDotPulse() {
        if (dotPulse != null) {
            return;
        }
        dotPulse = ObjectAnimator.ofFloat(statusDot, "alpha", 1f, 0.3f);
        dotPulse.setDuration(900L);
        dotPulse.setRepeatCount(ObjectAnimator.INFINITE);
        dotPulse.setRepeatMode(ObjectAnimator.REVERSE);
        dotPulse.start();
    }

    private void stopDotPulse() {
        if (dotPulse != null) {
            dotPulse.cancel();
            dotPulse = null;
            statusDot.setAlpha(1f);
        }
    }

    private void handleLaunchExtras(Intent intent) {
        if (intent == null) {
            return;
        }
        boolean requestContactPermissions =
            intent.getBooleanExtra(MainActivity.EXTRA_REQUEST_CONTACT_PERMISSIONS, false);
        if (requestContactPermissions) {
            intent.removeExtra(MainActivity.EXTRA_REQUEST_CONTACT_PERMISSIONS);
            String[] missing = ContactsPermissionHelper.missingPermissions(this);
            if (missing.length > 0) {
                ActivityCompat.requestPermissions(this, missing, REQUEST_CODE_CONTACT_PERMISSIONS);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startDictation();
            } else {
                Toast.makeText(this, R.string.err_mic_permission, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PICK_IMAGE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            handlePickedImage(data.getData());
        }
    }

    // -----------------------------------------------------------------
    // Image attachment
    // -----------------------------------------------------------------

    private void launchImagePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        try {
            startActivityForResult(intent, REQUEST_CODE_PICK_IMAGE);
        } catch (android.content.ActivityNotFoundException noPicker) {
            Toast.makeText(this, R.string.err_image_read_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void handlePickedImage(final Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException notPersistable) {
            // Some providers do not support a persistable grant; the
            // transient read grant from ACTION_OPEN_DOCUMENT still covers
            // reading it right now, which is all this screen needs.
        }

        pendingImageUri = uri;
        pendingImageBase64 = null;
        pendingImageMimeType = null;
        pendingImageEncoding = true;
        showImagePreview(uri, true);
        updateSendState(true);

        new Thread(new Runnable() {
            @Override
            public void run() {
                final ImageUtils.Encoded encoded = ImageUtils.loadAndEncode(ChatActivity.this, uri);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // The user may have removed the attachment (or picked
                        // a different one) while this was encoding.
                        if (pendingImageUri == null || !pendingImageUri.equals(uri)) {
                            return;
                        }
                        pendingImageEncoding = false;
                        if (encoded == null) {
                            clearPendingImage();
                            Toast.makeText(ChatActivity.this, R.string.err_image_read_failed,
                                Toast.LENGTH_SHORT).show();
                            return;
                        }
                        pendingImageBase64 = encoded.base64;
                        pendingImageMimeType = encoded.mimeType;
                        imagePreviewProgress.setVisibility(View.GONE);
                        updateSendState(true);
                    }
                });
            }
        }).start();
    }

    private void showImagePreview(Uri uri, boolean encoding) {
        // Do not use setImageURI() here: it decodes the source at full
        // resolution, and a raw camera photo can be large enough that
        // drawing it crashes with "Canvas: trying to draw too large
        // bitmap". decodeThumbnail() downsamples before decoding so the
        // preview is always small and safe to draw.
        Bitmap thumb = ImageUtils.decodeThumbnail(this, uri);
        if (thumb != null) {
            imagePreviewThumb.setImageBitmap(thumb);
        } else {
            imagePreviewThumb.setImageDrawable(null);
        }
        imagePreviewProgress.setVisibility(encoding ? View.VISIBLE : View.GONE);
        if (imagePreviewRow.getVisibility() != View.VISIBLE) {
            imagePreviewRow.setAlpha(0f);
            imagePreviewRow.setScaleX(0.85f);
            imagePreviewRow.setScaleY(0.85f);
            imagePreviewRow.setVisibility(View.VISIBLE);
            imagePreviewRow.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(220L).setInterpolator(new OvershootInterpolator(1.8f)).start();
        }
    }

    private void clearPendingImage() {
        pendingImageUri = null;
        pendingImageBase64 = null;
        pendingImageMimeType = null;
        pendingImageEncoding = false;
        if (imagePreviewRow.getVisibility() == View.VISIBLE) {
            imagePreviewRow.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).setDuration(160L)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        imagePreviewRow.setVisibility(View.GONE);
                        imagePreviewThumb.setImageDrawable(null);
                    }
                }).start();
        }
        updateSendState(true);
    }

    // -----------------------------------------------------------------
    // Dictation (tap-to-talk mic, fills the text box only)
    // -----------------------------------------------------------------

    private void onMicClicked() {
        if (session.isBusy()) {
            return;
        }
        if (listening) {
            speechRecognizerManager.stopListening();
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_CODE_RECORD_AUDIO);
            return;
        }
        startDictation();
    }

    private void startDictation() {
        listening = true;
        refreshSendButtonIcon();
        speechRecognizerManager.startListening();
    }

    // -----------------------------------------------------------------
    // Sending
    // -----------------------------------------------------------------

    private void onSendClicked() {
        String text = input.getText().toString().trim();
        boolean hasImage = pendingImageUri != null && pendingImageBase64 != null;
        if ((text.length() == 0 && !hasImage) || session.isBusy() || pendingImageEncoding) {
            return;
        }
        if (listening) {
            speechRecognizerManager.cancelListening();
            listening = false;
        }
        input.setText("");
        playSendAnimation();
        if (hasImage) {
            Uri uriToSend = pendingImageUri;
            String base64ToSend = pendingImageBase64;
            String mimeToSend = pendingImageMimeType;
            pendingImageUri = null;
            pendingImageBase64 = null;
            pendingImageMimeType = null;
            if (imagePreviewRow.getVisibility() == View.VISIBLE) {
                imagePreviewRow.setVisibility(View.GONE);
                imagePreviewThumb.setImageDrawable(null);
            }
            session.sendUserMessageWithImage(text, uriToSend, base64ToSend, mimeToSend);
        } else {
            session.sendUserMessage(text);
        }
    }


    /** A little paper plane leaves the button toward the top right. */
    private void playSendAnimation() {
        sendGhost.animate().cancel();
        sendGhost.setAlpha(1f);
        sendGhost.setTranslationX(0f);
        sendGhost.setTranslationY(0f);
        sendGhost.setScaleX(1f);
        sendGhost.setScaleY(1f);
        sendGhost.animate()
            .translationX(ChatStyle.dp(this, 34))
            .translationY(-ChatStyle.dp(this, 34))
            .scaleX(0.6f)
            .scaleY(0.6f)
            .alpha(0f)
            .setDuration(360L)
            .setInterpolator(new DecelerateInterpolator())
            .start();
    }

    private void updateSendState(boolean animate) {
        boolean enabled = !session.isBusy();
        refreshSendButtonIcon();
        if (animate && enabled == sendEnabled) {
            sendButton.setEnabled(enabled);
            return;
        }
        sendEnabled = enabled;
        sendButton.setEnabled(enabled);
        float alpha = enabled ? 1f : 0.38f;
        float scale = enabled ? 1f : 0.86f;
        if (animate) {
            sendButton.animate().alpha(alpha).scaleX(scale).scaleY(scale)
                .setDuration(240L)
                .setInterpolator(enabled ? new OvershootInterpolator(2.2f) : new DecelerateInterpolator())
                .start();
        } else {
            sendButton.setAlpha(alpha);
            sendButton.setScaleX(scale);
            sendButton.setScaleY(scale);
        }
    }

    /** Shows a send arrow once there is anything to send, otherwise a mic (or "listening") icon. */
    private void refreshSendButtonIcon() {
        boolean hasContent = input.getText().toString().trim().length() > 0
            || pendingImageUri != null;
        if (hasContent) {
            sendButton.setImageResource(R.drawable.ic_send);
        } else if (listening) {
            sendButton.setImageResource(R.drawable.ic_mic_off);
        } else {
            sendButton.setImageResource(R.drawable.ic_mic);
        }
    }

    // -----------------------------------------------------------------
    // Header status
    // -----------------------------------------------------------------

    private void updateStatus() {
        boolean typing = session.isTyping();
        boolean online = DeviceInfoUtil.isConnectedToInternet(this);
        int dotColor = accent;
        if (typing) {
            statusText.setText(R.string.chat_status_thinking);
            statusText.setTextColor(accent);
            headerOrb.setMode(ChatOrbView.MODE_THINKING);
        } else if (!online) {
            statusText.setText(R.string.chat_status_offline);
            statusText.setTextColor(ChatStyle.ERROR_COLOR);
            dotColor = ChatStyle.ERROR_COLOR;
            headerOrb.setMode(ChatOrbView.MODE_IDLE);
        } else {
            statusText.setText(R.string.chat_status_online);
            statusText.setTextColor(ChatStyle.TEXT_SECONDARY);
            headerOrb.setMode(ChatOrbView.MODE_IDLE);
        }
        statusDot.setBackground(ChatStyle.circle(dotColor));
    }

    // -----------------------------------------------------------------
    // Empty state
    // -----------------------------------------------------------------

    private void updateEmptyState(boolean animate) {
        boolean shouldShow = adapter.getMessageCount() == 0 && !adapter.isTyping();
        boolean visible = emptyView.getVisibility() == View.VISIBLE;
        if (shouldShow && !visible) {
            emptyView.animate().cancel();
            emptyView.setAlpha(1f);
            emptyView.setScaleX(1f);
            emptyView.setScaleY(1f);
            emptyView.setVisibility(View.VISIBLE);
            playEmptyEntrance();
        } else if (!shouldShow && visible) {
            if (animate) {
                emptyView.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(220L)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            emptyView.setVisibility(View.GONE);
                        }
                    }).start();
            } else {
                emptyView.setVisibility(View.GONE);
            }
        }
    }

    private void playEmptyEntrance() {
        ViewAnimUtils.animateEntrance(emptyPanel, 60);
        emptyOrb.setScaleX(0.4f);
        emptyOrb.setScaleY(0.4f);
        emptyOrb.animate().scaleX(1f).scaleY(1f).setDuration(650L)
            .setInterpolator(new OvershootInterpolator(2.2f)).start();
        for (int i = 0; i < suggestionChips.size(); i++) {
            ViewAnimUtils.animateEntrance(suggestionChips.get(i), 260 + i * 95);
        }
    }

    // -----------------------------------------------------------------
    // Scrolling
    // -----------------------------------------------------------------

    private void scrollToBottom(final boolean smooth) {
        final int last = adapter.getItemCount() - 1;
        if (last < 0) {
            return;
        }
        list.post(new Runnable() {
            @Override
            public void run() {
                if (smooth) {
                    list.smoothScrollToPosition(last);
                } else {
                    list.scrollToPosition(last);
                }
            }
        });
    }

    private boolean isNearBottom() {
        int total = adapter.getItemCount();
        if (total == 0) {
            return true;
        }
        return layoutManager.findLastVisibleItemPosition() >= total - 3;
    }

    // -----------------------------------------------------------------
    // ChatSession.Listener
    // -----------------------------------------------------------------

    @Override
    public void onMessageAdded(ChatMessage message) {
        boolean stick = message.isUser() || isNearBottom();
        adapter.addMessage(message);
        updateEmptyState(true);
        if (stick) {
            scrollToBottom(true);
        }
    }

    @Override
    public void onMessageChanged(ChatMessage message) {
        adapter.notifyMessageChanged(message);
    }

    @Override
    public void onMessageRemoved(ChatMessage message) {
        adapter.removeMessage(message);
    }

    @Override
    public void onTypingChanged(boolean typing) {
        adapter.setTyping(typing);
        updateStatus();
        updateSendState(true);
        updateEmptyState(true);
        if (typing) {
            scrollToBottom(true);
        }
    }

    @Override
    public void onConversationReset() {
        adapter.setAll(session.getMessages(), session.isTyping());
        updateEmptyState(true);
        updateStatus();
        updateSendState(true);
        scrollToBottom(false);
    }

    // -----------------------------------------------------------------
    // ChatAdapter.ActionListener
    // -----------------------------------------------------------------

    @Override
    public void onConfirm(ChatMessage message, boolean accepted) {
        session.resolveConfirmation(message, accepted);
    }

    @Override
    public void onRetry(ChatMessage message) {
        session.retryFrom(message);
    }
}
