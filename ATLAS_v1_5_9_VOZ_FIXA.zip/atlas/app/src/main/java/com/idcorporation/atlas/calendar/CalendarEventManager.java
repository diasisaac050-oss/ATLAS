package com.idcorporation.atlas.calendar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.idcorporation.atlas.memory.AtlasDatabase;
import com.idcorporation.atlas.models.CalendarEventItem;

import com.idcorporation.atlas.utils.AlarmScheduler;
import com.idcorporation.atlas.utils.AppointmentReminderScheduler;
import com.idcorporation.atlas.utils.UserProfileManager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Locale;

/**
 * All reads/writes for the calendar feature go through here: reminders
 * created by voice, the yearly-repeating birthday entry, and the quick
 * alarms shown in the agenda. Backed by the same SQLite database the
 * rest of ATLAS already uses.
 */
public class CalendarEventManager {

    private final AtlasDatabase dbHelper;
    private final Context appContext;

    public CalendarEventManager(Context context) {
        this.appContext = context.getApplicationContext();
        this.dbHelper = AtlasDatabase.getInstance(context);
    }

    public long addEvent(int year, int month, int day, int hour, int minute,
            String title, String eventType, boolean repeatYearly) {
        return addEvent(year, month, day, hour, minute, title, eventType, repeatYearly,
            CalendarEventItem.RECURRENCE_NONE, 1);
    }

    /** Same as the plain addEvent, but also records a recurrence rule (see ATLAS FASE 3/4 item 21). */
    public long addEvent(int year, int month, int day, int hour, int minute,
            String title, String eventType, boolean repeatYearly, String recurrenceRule, int recurrenceInterval) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("event_year", year);
        values.put("event_month", month);
        values.put("event_day", day);
        values.put("event_hour", hour);
        values.put("event_minute", minute);
        values.put("title", title);
        values.put("event_type", eventType);
        values.put("repeat_yearly", repeatYearly ? 1 : 0);
        values.put("recurrence_rule", recurrenceRule == null ? CalendarEventItem.RECURRENCE_NONE : recurrenceRule);
        values.put("recurrence_interval", recurrenceInterval < 1 ? 1 : recurrenceInterval);
        values.put("created_at", System.currentTimeMillis());
        return db.insert(AtlasDatabase.TABLE_CALENDAR_EVENTS, null, values);
    }

    public CalendarEventItem getEventById(long id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT id, event_year, event_month, event_day, event_hour, event_minute, "
            + "title, event_type, repeat_yearly, recurrence_rule, recurrence_interval "
            + "FROM " + AtlasDatabase.TABLE_CALENDAR_EVENTS + " WHERE id = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(id)});
        ArrayList<CalendarEventItem> result = new ArrayList<CalendarEventItem>();
        readCursorWithRecurrenceInto(cursor, result);
        return result.isEmpty() ? null : result.get(0);
    }

    /**
     * Called right after a recurring compromisso's notification fires (see
     * AppointmentReminderReceiver). Moves the same row forward to its next
     * occurrence using real calendar math (Calendar#add - so "todo mes"
     * from Jan 31 correctly lands on Feb 28, never on a made-up date) and
     * arms the alarm for that new date. Non-recurring events, or an id that
     * no longer exists, are simply left alone - this never invents a next
     * date for something that was not actually set to repeat.
     */
    public boolean rescheduleRecurrence(long id) {
        CalendarEventItem event = getEventById(id);
        if (event == null || !event.isRecurring()) {
            return false;
        }
        Calendar next = new GregorianCalendar(event.getYear(), event.getMonth() - 1, event.getDay());
        int interval = event.getRecurrenceInterval();
        if (CalendarEventItem.RECURRENCE_DAILY.equals(event.getRecurrenceRule())) {
            next.add(Calendar.DAY_OF_MONTH, interval);
        } else if (CalendarEventItem.RECURRENCE_WEEKLY.equals(event.getRecurrenceRule())) {
            next.add(Calendar.DAY_OF_MONTH, interval * 7);
        } else if (CalendarEventItem.RECURRENCE_MONTHLY.equals(event.getRecurrenceRule())) {
            next.add(Calendar.MONTH, interval);
        } else {
            return false;
        }

        int newYear = next.get(Calendar.YEAR);
        int newMonth = next.get(Calendar.MONTH) + 1;
        int newDay = next.get(Calendar.DAY_OF_MONTH);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("event_year", newYear);
        values.put("event_month", newMonth);
        values.put("event_day", newDay);
        db.update(AtlasDatabase.TABLE_CALENDAR_EVENTS, values, "id = ?", new String[]{String.valueOf(id)});

        if (event.hasTime()) {
            long triggerMillis = CalendarDateUtils.toEpochMillis(
                newYear, newMonth, newDay, event.getHour(), event.getMinute());
            int requestCode = (int) (triggerMillis % Integer.MAX_VALUE);
            String userName = new UserProfileManager(appContext).getName();
            String time = String.format(Locale.US, "%02d:%02d", event.getHour(), event.getMinute());
            String message = AppointmentReminderScheduler.buildMessage(appContext, userName, event.getTitle(), time);
            AppointmentReminderScheduler.scheduleAppointment(appContext, triggerMillis, requestCode,
                event.getTitle(), message, id);
        }
        return true;
    }

    public void deleteEvent(long id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Remember when this event was set to fire, and what type it was: deleting the
        // row alone used to leave the alarm/notification scheduled, so a deleted item
        // still fired.
        int[] when = null;
        String type = null;
        Cursor cursor = db.rawQuery("SELECT event_year, event_month, event_day, event_hour, event_minute, event_type "
            + "FROM " + AtlasDatabase.TABLE_CALENDAR_EVENTS + " WHERE id = ? AND repeat_yearly = 0",
            new String[]{String.valueOf(id)});
        if (cursor.moveToFirst() && cursor.getInt(3) >= 0 && cursor.getInt(4) >= 0) {
            when = new int[]{cursor.getInt(0), cursor.getInt(1), cursor.getInt(2),
                cursor.getInt(3), cursor.getInt(4)};
            type = cursor.getString(5);
        }
        cursor.close();

        db.delete(AtlasDatabase.TABLE_CALENDAR_EVENTS, "id = ?", new String[]{String.valueOf(id)});

        if (when != null && type != null) {
            // Two events of the same type at the same minute share one alarm slot, so it
            // is only cancelled when no other event of that same type still needs it.
            Cursor others = db.rawQuery("SELECT COUNT(*) FROM " + AtlasDatabase.TABLE_CALENDAR_EVENTS
                + " WHERE repeat_yearly = 0 AND event_type = ? AND event_year = ? AND event_month = ? "
                + "AND event_day = ? AND event_hour = ? AND event_minute = ?",
                new String[]{type, String.valueOf(when[0]), String.valueOf(when[1]), String.valueOf(when[2]),
                    String.valueOf(when[3]), String.valueOf(when[4])});
            int remaining = 0;
            if (others.moveToFirst()) {
                remaining = others.getInt(0);
            }
            others.close();
            if (remaining == 0) {
                long triggerMillis = CalendarDateUtils.toEpochMillis(when[0], when[1], when[2], when[3], when[4]);
                int requestCode = (int) (triggerMillis % Integer.MAX_VALUE);
                if (CalendarEventItem.TYPE_ALARM.equals(type)) {
                    AlarmScheduler.cancelAlarm(appContext, requestCode);
                } else {
                    AppointmentReminderScheduler.cancelAppointment(appContext, requestCode);
                }
            }
        }
    }

    /** Events landing on this exact calendar day: matches non-repeating events by full date and yearly ones by day/month only. */
    public ArrayList<CalendarEventItem> getEventsForDate(int year, int month, int day) {
        ArrayList<CalendarEventItem> result = new ArrayList<CalendarEventItem>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT id, event_year, event_month, event_day, event_hour, event_minute, "
            + "title, event_type, repeat_yearly FROM " + AtlasDatabase.TABLE_CALENDAR_EVENTS
            + " WHERE (repeat_yearly = 1 AND event_month = ? AND event_day = ?) "
            + "OR (repeat_yearly = 0 AND event_year = ? AND event_month = ? AND event_day = ?)"
            + " ORDER BY event_hour ASC, event_minute ASC";
        String[] args = new String[]{
            String.valueOf(month), String.valueOf(day),
            String.valueOf(year), String.valueOf(month), String.valueOf(day)
        };
        Cursor cursor = db.rawQuery(query, args);
        readCursorInto(cursor, result);
        return result;
    }

    /** Set of days (1-31) in the given month/year that have at least one event, for drawing dots on the grid. */
    public HashSet<Integer> getEventDaysForMonth(int year, int month) {
        HashSet<Integer> days = new HashSet<Integer>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT event_day FROM " + AtlasDatabase.TABLE_CALENDAR_EVENTS
            + " WHERE (repeat_yearly = 1 AND event_month = ?) "
            + "OR (repeat_yearly = 0 AND event_year = ? AND event_month = ?)";
        String[] args = new String[]{String.valueOf(month), String.valueOf(year), String.valueOf(month)};
        Cursor cursor = db.rawQuery(query, args);
        if (cursor.moveToFirst()) {
            do {
                days.add(Integer.valueOf(cursor.getInt(0)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return days;
    }

    /** All non-repeating events that still have a real trigger time in the future, used to re-arm alarms after reboot. */
    public ArrayList<CalendarEventItem> getFutureTimedEvents() {
        ArrayList<CalendarEventItem> result = new ArrayList<CalendarEventItem>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT id, event_year, event_month, event_day, event_hour, event_minute, "
            + "title, event_type, repeat_yearly FROM " + AtlasDatabase.TABLE_CALENDAR_EVENTS
            + " WHERE event_hour >= 0 AND event_minute >= 0 AND repeat_yearly = 0";
        Cursor cursor = db.rawQuery(query, null);
        ArrayList<CalendarEventItem> all = new ArrayList<CalendarEventItem>();
        readCursorInto(cursor, all);
        long now = System.currentTimeMillis();
        for (int i = 0; i < all.size(); i++) {
            CalendarEventItem item = all.get(i);
            long trigger = CalendarDateUtils.toEpochMillis(
                item.getYear(), item.getMonth(), item.getDay(), item.getHour(), item.getMinute());
            if (trigger > now) {
                result.add(item);
            }
        }
        return result;
    }

    public CalendarEventItem getBirthday() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT id, event_year, event_month, event_day, event_hour, event_minute, "
            + "title, event_type, repeat_yearly FROM " + AtlasDatabase.TABLE_CALENDAR_EVENTS
            + " WHERE event_type = ? LIMIT 1";
        Cursor cursor = db.rawQuery(query, new String[]{CalendarEventItem.TYPE_BIRTHDAY});
        ArrayList<CalendarEventItem> result = new ArrayList<CalendarEventItem>();
        readCursorInto(cursor, result);
        if (result.isEmpty()) {
            return null;
        }
        return result.get(0);
    }

    public void setBirthday(int year, int month, int day, String title) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(AtlasDatabase.TABLE_CALENDAR_EVENTS, "event_type = ?",
            new String[]{CalendarEventItem.TYPE_BIRTHDAY});
        addEvent(year, month, day, -1, -1, title, CalendarEventItem.TYPE_BIRTHDAY, true);
    }

    private void readCursorInto(Cursor cursor, ArrayList<CalendarEventItem> target) {
        if (cursor.moveToFirst()) {
            do {
                target.add(new CalendarEventItem(
                    cursor.getLong(0),
                    cursor.getInt(1),
                    cursor.getInt(2),
                    cursor.getInt(3),
                    cursor.getInt(4),
                    cursor.getInt(5),
                    cursor.getString(6),
                    cursor.getString(7),
                    cursor.getInt(8) == 1));
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    /** Same as readCursorInto, but for the 11-column query that also carries recurrence_rule/recurrence_interval. */
    private void readCursorWithRecurrenceInto(Cursor cursor, ArrayList<CalendarEventItem> target) {
        if (cursor.moveToFirst()) {
            do {
                target.add(new CalendarEventItem(
                    cursor.getLong(0),
                    cursor.getInt(1),
                    cursor.getInt(2),
                    cursor.getInt(3),
                    cursor.getInt(4),
                    cursor.getInt(5),
                    cursor.getString(6),
                    cursor.getString(7),
                    cursor.getInt(8) == 1,
                    cursor.getString(9),
                    cursor.getInt(10)));
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}
