package com.idcorporation.atlas.utils;

/**
 * A single country choice on the onboarding "What is your country?" step.
 * Pairs an ISO country code with a flag emoji, an English display name
 * (countries are shown by their English name to keep the picker usable
 * before a language has even been chosen) and the ATLAS language that
 * country should set as the initial language, via LocaleHelper.
 */
public class CountryOption {

    private final String isoCode;
    private final String flagEmoji;
    private final String displayName;
    private final String languageCode;

    public CountryOption(String isoCode, String flagEmoji, String displayName, String languageCode) {
        this.isoCode = isoCode;
        this.flagEmoji = flagEmoji;
        this.displayName = displayName;
        this.languageCode = languageCode;
    }

    public String getIsoCode() {
        return isoCode;
    }

    public String getFlagEmoji() {
        return flagEmoji;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getLanguageCode() {
        return languageCode;
    }
}
