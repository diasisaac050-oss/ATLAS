package com.idcorporation.atlas.agent.tools;

import com.idcorporation.atlas.agent.SensitiveActionGuard;
import com.idcorporation.atlas.agent.ToolResult;
import com.idcorporation.atlas.commands.CommandOutcome;
import com.idcorporation.atlas.commands.ConfirmAction;

import org.json.JSONObject;

import java.util.concurrent.Callable;

/**
 * Bridge to everything Atlas already does locally (alarms, reminders,
 * calendar, notes, flashlight, volume, brightness, calls, settings...).
 * The agent reuses the existing handlers instead of re-implementing them,
 * so none of that behaviour can regress.
 */
public class RunDeviceCommandTool extends BaseTool {

    public RunDeviceCommandTool(ToolEnv env) {
        super(env);
    }

    @Override
    public String name() {
        return "run_device_command";
    }

    @Override
    public String description() {
        return "Run a phone action Atlas already supports (alarms, reminders, calendar, flashlight, "
            + "volume, brightness, calls, settings, time/date/battery). Pass it as the user would say it.";
    }

    @Override
    public JSONObject parameters() {
        return Schema.obj().str("command", "The command in natural language, e.g. 'liga a lanterna'.", true).build();
    }

    @Override
    public boolean changesState() {
        return true;
    }

    @Override
    public ToolResult execute(JSONObject args) throws Exception {
        final String command = arg(args, "command");
        if (command.length() == 0) {
            return ToolResult.failed("Missing command text.");
        }
        if (env.commandManager == null) {
            return ToolResult.failed("Local command engine is not available here.");
        }
        if (SensitiveActionGuard.isSensitive(command)) {
            ConfirmAction action = new ConfirmAction() {
                @Override
                public boolean run() {
                    try {
                        CommandOutcome o = env.commandManager.process(command);
                        return o != null && o.getType() == CommandOutcome.TYPE_HANDLED;
                    } catch (RuntimeException e) {
                        return false;
                    }
                }
            };
            return ToolResult.needsConfirmation(
                "This command deletes data or involves money, so it was NOT run. Waiting for the user's Yes.",
                command, action);
        }
        CommandOutcome outcome = env.onMain(new Callable<CommandOutcome>() {
            @Override
            public CommandOutcome call() {
                return env.commandManager.process(command);
            }
        }, 8000L);
        if (outcome == null || outcome.getType() == CommandOutcome.TYPE_AI_QUESTION) {
            return ToolResult.failed("No local handler recognises this as a phone command.");
        }
        if (outcome.getType() == CommandOutcome.TYPE_NEEDS_CONFIRMATION) {
            return ToolResult.needsConfirmation(
                "The app needs the user's Yes before doing this. Not done yet.",
                outcome.getSpokenResponse(), outcome.getConfirmedAction());
        }
        return ToolResult.reported("The app's handler answered: " + clip(outcome.getSpokenResponse(), 300));
    }
}
