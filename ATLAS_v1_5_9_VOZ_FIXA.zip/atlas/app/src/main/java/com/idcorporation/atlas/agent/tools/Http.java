package com.idcorporation.atlas.agent.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;

/** Minimal HTTPS GET for the data tools. https only, size-capped, never follows a redirect to another scheme. */
public final class Http {

    private static final int CONNECT_MS = 10000;
    private static final int READ_MS = 12000;
    private static final int MAX_CHARS = 400000;
    public static final String USER_AGENT = "ATLAS/1.3 (Android; ID Corporation personal assistant)";

    private Http() {
    }

    public static String enc(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    /** @param extraHeaders alternating name, value pairs (may be null) */
    public static String get(String url, String... extraHeaders) throws IOException {
        if (url == null || !url.startsWith("https://")) {
            throw new IOException("Only https is allowed");
        }
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod("GET");
            c.setConnectTimeout(CONNECT_MS);
            c.setReadTimeout(READ_MS);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", USER_AGENT);
            c.setRequestProperty("Accept", "application/json, application/xml, text/xml, */*");
            if (extraHeaders != null) {
                for (int i = 0; i + 1 < extraHeaders.length; i += 2) {
                    c.setRequestProperty(extraHeaders[i], extraHeaders[i + 1]);
                }
            }
            int status = c.getResponseCode();
            if (status != 200) {
                throw new IOException("HTTP " + status);
            }
            return read(c.getInputStream());
        } finally {
            c.disconnect();
        }
    }

    private static String read(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, Charset.forName("UTF-8")));
        try {
            char[] buf = new char[4096];
            int n;
            while ((n = r.read(buf)) != -1) {
                sb.append(buf, 0, n);
                if (sb.length() > MAX_CHARS) {
                    break;
                }
            }
        } finally {
            r.close();
        }
        return sb.toString();
    }
}
