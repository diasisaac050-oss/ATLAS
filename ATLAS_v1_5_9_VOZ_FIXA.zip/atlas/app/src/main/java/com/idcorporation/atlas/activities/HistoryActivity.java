package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.adapters.GenericListAdapter;
import com.idcorporation.atlas.adapters.RowItem;
import com.idcorporation.atlas.chat.ChatSession;
import com.idcorporation.atlas.memory.HistoryManager;
import com.idcorporation.atlas.models.ConversationSummary;

import java.util.ArrayList;
import java.util.Date;

/**
 * History screen for Chat mode. Shows one row per conversation - not one
 * row per message - so the user can recognize, reopen and continue any of
 * their 15 most recent conversations. Older conversations are never
 * deleted just because they scroll past that limit; see
 * HistoryManager.getRecentConversations().
 */
public class HistoryActivity extends BaseActivity {

    private static final int MAX_CONVERSATIONS_SHOWN = 15;
    private static final int TITLE_MAX_CHARS = 46;
    private static final int PREVIEW_MAX_CHARS = 60;

    private HistoryManager historyManager;
    private RecyclerView recyclerView;
    private TextView emptyStateView;
    private ArrayList<ConversationSummary> conversations = new ArrayList<ConversationSummary>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generic_list);

        historyManager = new HistoryManager(this);

        TextView titleView = (TextView) findViewById(R.id.text_screen_title);
        titleView.setText(R.string.title_history);

        emptyStateView = (TextView) findViewById(R.id.text_empty_state);
        emptyStateView.setText(R.string.empty_state_history);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.button_clear_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                historyManager.deleteAllHistory();
                loadHistory();
            }
        });

        ImageButton newConversationButton = (ImageButton) findViewById(R.id.button_add_row);
        newConversationButton.setVisibility(View.VISIBLE);
        newConversationButton.setContentDescription(getString(R.string.action_new_conversation));
        newConversationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChatSession.get(HistoryActivity.this).newConversation();
                openChat();
            }
        });

        loadHistory();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHistory();
    }

    private void loadHistory() {
        conversations = historyManager.getRecentConversations(MAX_CONVERSATIONS_SHOWN);

        ArrayList<RowItem> rows = new ArrayList<RowItem>();
        for (int i = 0; i < conversations.size(); i++) {
            ConversationSummary conversation = conversations.get(i);
            String title = buildAutoTitle(conversation.getFirstMessage());
            String subtitle = buildSubtitle(conversation);
            rows.add(new RowItem(i, title, subtitle));
        }

        emptyStateView.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);

        GenericListAdapter adapter = new GenericListAdapter(rows,
            new GenericListAdapter.OnRowDeleteListener() {
                @Override
                public void onDelete(long rowId) {
                    deleteConversationAt((int) rowId);
                }
            },
            new GenericListAdapter.OnRowClickListener() {
                @Override
                public void onRowClick(long rowId) {
                    openConversationAt((int) rowId);
                }
            });
        recyclerView.setAdapter(adapter);
    }

    private void deleteConversationAt(int index) {
        if (index < 0 || index >= conversations.size()) {
            return;
        }
        String title = conversations.get(index).getConversationTitle();
        historyManager.deleteConversation(title);
        loadHistory();
    }

    private void openConversationAt(int index) {
        if (index < 0 || index >= conversations.size()) {
            return;
        }
        String title = conversations.get(index).getConversationTitle();
        ChatSession.get(this).openConversation(title);
        openChat();
    }

    private void openChat() {
        Intent intent = new Intent(this, ChatActivity.class);
        startActivity(intent);
    }

    /** A short, human title generated from the conversation's first message. */
    private String buildAutoTitle(String firstMessage) {
        String text = firstMessage == null ? "" : firstMessage.trim();
        if (text.length() == 0) {
            return getString(R.string.history_untitled_conversation);
        }
        return truncate(text, TITLE_MAX_CHARS);
    }

    /** Date/time of the last activity, plus a preview of the last message when it differs from the title. */
    private String buildSubtitle(ConversationSummary conversation) {
        String when = DateFormat.getDateFormat(this).format(new Date(conversation.getLastTimestamp()))
            + " " + DateFormat.getTimeFormat(this).format(new Date(conversation.getLastTimestamp()));

        String last = conversation.getLastMessage() == null ? "" : conversation.getLastMessage().trim();
        String first = conversation.getFirstMessage() == null ? "" : conversation.getFirstMessage().trim();
        if (conversation.getMessageCount() <= 1 || last.length() == 0 || last.equals(first)) {
            return when;
        }
        return when + "  \u00b7  " + truncate(last, PREVIEW_MAX_CHARS);
    }

    private static String truncate(String text, int maxChars) {
        String singleLine = text.replace('\n', ' ');
        if (TextUtils.isEmpty(singleLine) || singleLine.length() <= maxChars) {
            return singleLine;
        }
        return singleLine.substring(0, maxChars).trim() + "\u2026";
    }
}
