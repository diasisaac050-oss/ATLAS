package com.idcorporation.atlas.calendar;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.idcorporation.atlas.R;

import java.util.HashSet;

/**
 * Builds a month page entirely in code (weekday header + up to 6 rows
 * of 7 day cells). Kept as plain LinearLayouts/TextViews rather than a
 * nested RecyclerView/GridView so the infinite month pager can recycle
 * these pages cheaply. Background is always white, independent of the
 * active ATLAS theme, per the calendar feature spec.
 */
public class MonthGridView extends LinearLayout {

    public interface OnDayClickListener {
        void onDayClick(int year, int month, int day);
    }

    private static final String[] WEEKDAY_LABELS = new String[]{
        "Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"
    };

    public MonthGridView(Context context) {
        super(context);
        setOrientation(VERTICAL);
        setBackgroundColor(Color.WHITE);
        int padding = dp(8);
        setPadding(padding, padding, padding, padding);
    }

    public void bind(int year, int month, HashSet<Integer> eventDays, Integer birthdayDay,
            OnDayClickListener listener) {
        removeAllViews();
        addView(buildHeaderRow());

        int firstWeekday = CalendarDateUtils.firstWeekdayOfMonth(year, month);
        int daysInMonth = CalendarDateUtils.daysInMonth(year, month);
        int totalCells = firstWeekday + daysInMonth;
        int rows = (int) Math.ceil(totalCells / 7.0);

        int dayCounter = 1;
        for (int row = 0; row < rows; row++) {
            LinearLayout rowLayout = new LinearLayout(getContext());
            rowLayout.setOrientation(HORIZONTAL);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            rowLayout.setLayoutParams(rowParams);

            for (int column = 0; column < 7; column++) {
                int cellIndex = row * 7 + column;
                boolean isBlank = cellIndex < firstWeekday || dayCounter > daysInMonth;
                if (isBlank) {
                    rowLayout.addView(buildBlankCell());
                } else {
                    boolean hasEvent = eventDays != null && eventDays.contains(Integer.valueOf(dayCounter));
                    boolean isBirthday = birthdayDay != null && birthdayDay.intValue() == dayCounter;
                    rowLayout.addView(buildDayCell(year, month, dayCounter, column, hasEvent, isBirthday, listener));
                    dayCounter++;
                }
            }
            addView(rowLayout);
        }
    }

    private View buildHeaderRow() {
        LinearLayout header = new LinearLayout(getContext());
        header.setOrientation(HORIZONTAL);
        for (int i = 0; i < WEEKDAY_LABELS.length; i++) {
            TextView label = new TextView(getContext());
            label.setText(WEEKDAY_LABELS[i]);
            label.setGravity(Gravity.CENTER);
            label.setTextSize(11f);
            label.setTypeface(null, Typeface.BOLD);
            label.setTextColor(getResources().getColor(R.color.calendar_text_secondary));
            label.setLayoutParams(new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
            label.setPadding(0, dp(4), 0, dp(6));
            header.addView(label);
        }
        return header;
    }

    private View buildBlankCell() {
        View blank = new View(getContext());
        blank.setLayoutParams(new LinearLayout.LayoutParams(0, dp(44), 1f));
        return blank;
    }

    private View buildDayCell(final int year, final int month, final int day, int column,
            boolean hasEvent, boolean isBirthday, final OnDayClickListener listener) {
        LinearLayout cell = new LinearLayout(getContext());
        cell.setOrientation(VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setLayoutParams(new LinearLayout.LayoutParams(0, dp(44), 1f));
        cell.setClickable(true);
        cell.setFocusable(true);

        TextView number = new TextView(getContext());
        number.setText(String.valueOf(day));
        number.setGravity(Gravity.CENTER);
        number.setTextSize(14f);
        LinearLayout.LayoutParams numberParams = new LinearLayout.LayoutParams(dp(30), dp(30));
        numberParams.topMargin = dp(2);
        number.setLayoutParams(numberParams);

        boolean isToday = CalendarDateUtils.isToday(year, month, day);
        boolean isWeekend = column == 0 || column == 6;
        if (isToday) {
            number.setBackgroundResource(R.drawable.calendar_day_today_bg);
            number.setTypeface(null, Typeface.BOLD);
            number.setTextColor(getResources().getColor(R.color.calendar_accent));
        } else if (isWeekend) {
            number.setTextColor(getResources().getColor(R.color.calendar_weekend_text));
        } else {
            number.setTextColor(getResources().getColor(R.color.calendar_text_primary));
        }

        View dot = new View(getContext());
        LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(dp(5), dp(5));
        dotParams.topMargin = dp(2);
        dot.setLayoutParams(dotParams);
        if (isBirthday) {
            dot.setBackgroundResource(R.drawable.calendar_dot_birthday);
        } else if (hasEvent) {
            dot.setBackgroundResource(R.drawable.calendar_dot_event);
        } else {
            dot.setVisibility(INVISIBLE);
        }

        cell.addView(number);
        cell.addView(dot);

        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onDayClick(year, month, day);
                }
            }
        });

        return cell;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density);
    }
}
