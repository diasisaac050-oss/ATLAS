package com.idcorporation.atlas.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles simple spoken math without ever calling the AI API:
 * "calculate 847 times 36", "what's 15 percent of 900",
 * "square root of 144".
 */
public class Calculator {

    private static final Pattern PERCENT_OF = Pattern.compile(
        "([0-9]+(?:\\.[0-9]+)?)\\s*percent\\s*of\\s*([0-9]+(?:\\.[0-9]+)?)");

    private static final Pattern SQUARE_ROOT = Pattern.compile(
        "square\\s*root\\s*of\\s*([0-9]+(?:\\.[0-9]+)?)");

    private static final Pattern BASIC_OP = Pattern.compile(
        "([0-9]+(?:\\.[0-9]+)?)\\s*(plus|minus|times|multiplied by|divided by|over)\\s*([0-9]+(?:\\.[0-9]+)?)");

    /** Returns a spoken-friendly result, or null if the text is not a math request. */
    public static String tryCalculate(String lowerText) {

        Matcher percentMatcher = PERCENT_OF.matcher(lowerText);
        if (percentMatcher.find()) {
            double percent = Double.parseDouble(percentMatcher.group(1));
            double base = Double.parseDouble(percentMatcher.group(2));
            double result = (percent / 100.0) * base;
            return formatResult(result);
        }

        Matcher sqrtMatcher = SQUARE_ROOT.matcher(lowerText);
        if (sqrtMatcher.find()) {
            double value = Double.parseDouble(sqrtMatcher.group(1));
            double result = Math.sqrt(value);
            return formatResult(result);
        }

        Matcher basicMatcher = BASIC_OP.matcher(lowerText);
        if (basicMatcher.find()) {
            double left = Double.parseDouble(basicMatcher.group(1));
            String operation = basicMatcher.group(2);
            double right = Double.parseDouble(basicMatcher.group(3));
            double result = applyOperation(left, operation, right);
            return formatResult(result);
        }

        return null;
    }

    private static double applyOperation(double left, String operation, double right) {
        if ("plus".equals(operation)) {
            return left + right;
        }
        if ("minus".equals(operation)) {
            return left - right;
        }
        if ("times".equals(operation) || "multiplied by".equals(operation)) {
            return left * right;
        }
        if ("divided by".equals(operation) || "over".equals(operation)) {
            if (right == 0) {
                return Double.NaN;
            }
            return left / right;
        }
        return Double.NaN;
    }

    private static String formatResult(double result) {
        if (Double.isNaN(result)) {
            return "DIVIDE_BY_ZERO";
        }
        if (result == Math.floor(result) && !Double.isInfinite(result)) {
            long wholeNumber = (long) result;
            return String.valueOf(wholeNumber);
        }
        return String.valueOf(Math.round(result * 100.0) / 100.0);
    }
}
