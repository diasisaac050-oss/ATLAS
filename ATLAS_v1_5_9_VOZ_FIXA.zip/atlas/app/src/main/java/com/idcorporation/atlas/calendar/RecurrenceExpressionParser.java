package com.idcorporation.atlas.calendar;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Detects a recurrence phrase in natural Portuguese text, separately from
 * DateExpressionParser (which only ever resolves the date of the FIRST
 * occurrence - "toda sexta" already correctly resolves to the next Friday
 * there, since its weekday matching does not care what comes before the
 * weekday word).
 *
 * ATLAS FASE 3/4 item 21. Deliberately narrow: only the patterns the brief
 * explicitly lists are recognized - "toda segunda" (or any other weekday),
 * "toda semana", "todo mes", "todo dia", "a cada duas semanas" (and the
 * day/month equivalents). Anything else is simply not recognized as
 * recurring, which was already the entire previous behavior for every
 * appointment - so this can only ever add recurrence on top of what
 * already worked, never take away a date that used to resolve correctly.
 */
public final class RecurrenceExpressionParser {

    public static final String RULE_NONE = "NONE";
    public static final String RULE_DAILY = "DAILY";
    public static final String RULE_WEEKLY = "WEEKLY";
    public static final String RULE_MONTHLY = "MONTHLY";

    public static class Result {
        public String rule = RULE_NONE;
        public int interval = 1;

        public boolean isRecurring() {
            return !RULE_NONE.equals(rule);
        }
    }

    private static final Pattern EVERY_WEEKDAY = Pattern.compile(
        "\\btod[oa]s?\\s+(?:as\\s+|os\\s+)?(segunda|terca|quarta|quinta|sexta|sabado|domingo)");
    private static final Pattern EVERY_DAY = Pattern.compile("\\btodos?\\s+(?:os\\s+)?dias?\\b");
    private static final Pattern EVERY_WEEK = Pattern.compile(
        "\\btod[ao]s?\\s+(?:as\\s+)?semanas?\\b|\\bsemanalmente\\b");
    private static final Pattern EVERY_MONTH = Pattern.compile(
        "\\btod[ao]s?\\s+(?:os\\s+)?mes(?:es)?\\b|\\bmensalmente\\b");
    private static final Pattern EVERY_N_UNITS = Pattern.compile(
        "\\ba\\s+cada\\s+(" + PtNumberWords.NUM + ")\\s+(dias?|semanas?|meses|mes)\\b");

    private RecurrenceExpressionParser() {
    }

    /** normalizedText must already be lower-case/accent-stripped - see DateTimeCommandParser.normalize. */
    public static Result detect(String normalizedText) {
        Result result = new Result();
        if (normalizedText == null) {
            return result;
        }
        Matcher units = EVERY_N_UNITS.matcher(normalizedText);
        if (units.find()) {
            int amount = PtNumberWords.value(units.group(1));
            String unit = units.group(2);
            if (amount >= 1 && amount <= 60) {
                result.interval = amount;
                if (unit.startsWith("dia")) {
                    result.rule = RULE_DAILY;
                } else if (unit.startsWith("semana")) {
                    result.rule = RULE_WEEKLY;
                } else {
                    result.rule = RULE_MONTHLY;
                }
                return result;
            }
        }
        if (EVERY_WEEKDAY.matcher(normalizedText).find()) {
            result.rule = RULE_WEEKLY;
            return result;
        }
        if (EVERY_DAY.matcher(normalizedText).find()) {
            result.rule = RULE_DAILY;
            return result;
        }
        if (EVERY_WEEK.matcher(normalizedText).find()) {
            result.rule = RULE_WEEKLY;
            return result;
        }
        if (EVERY_MONTH.matcher(normalizedText).find()) {
            result.rule = RULE_MONTHLY;
            return result;
        }
        return result;
    }

    /**
     * Removes the recurrence phrase from an already-extracted title (which
     * keeps its original accents, unlike detect()'s normalized input) so a
     * reminder titled from "pagar a conta toda sexta" becomes just "pagar a
     * conta" instead of keeping a dangling "toda" in it. Falls back to the
     * original title untouched if stripping would empty it out entirely.
     */
    public static String stripFromTitle(String title) {
        if (title == null || title.length() == 0) {
            return title;
        }
        String cleaned = title;
        cleaned = cleaned.replaceAll(
            "(?iu)\\btod[oa]s?\\s+(?:as\\s+|os\\s+)?(segundas?|tercas?|ter\u00e7as?|quartas?|quintas?|"
            + "sextas?|sabados?|s\u00e1bados?|domingos?)(?:-feiras?|\\s+feiras?)?\\b", " ");
        cleaned = cleaned.replaceAll("(?iu)\\btodos?\\s+(?:os\\s+)?dias?\\b", " ");
        cleaned = cleaned.replaceAll("(?iu)\\btod[ao]s?\\s+(?:as\\s+)?semanas?\\b|(?iu)\\bsemanalmente\\b", " ");
        cleaned = cleaned.replaceAll(
            "(?iu)\\btod[ao]s?\\s+(?:os\\s+)?m\u00eas(?:es)?\\b|(?iu)\\bmensalmente\\b", " ");
        cleaned = cleaned.replaceAll("(?iu)\\ba\\s+cada\\s+\\S+\\s+(?:dias?|semanas?|m\u00eas(?:es)?)\\b", " ");
        cleaned = cleaned.replaceAll("\\s{2,}", " ").trim();
        return cleaned.length() > 0 ? cleaned : title;
    }
}
