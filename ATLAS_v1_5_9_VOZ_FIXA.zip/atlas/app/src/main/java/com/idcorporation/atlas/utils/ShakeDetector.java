package com.idcorporation.atlas.utils;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/**
 * ATLAS GLACIAL "Presenca": detects the phone being shaken side to side,
 * similar to the flashlight-toggle gesture on some Motorola phones.
 *
 * Works by counting quick left-right direction reversals on the
 * accelerometer's X axis within a short time window - a plain shake
 * (a single jolt) will not trigger it, but a deliberate back-and-forth
 * wobble will.
 */
public class ShakeDetector implements SensorEventListener {

    public interface ShakeListener {
        void onShakeDetected();
    }

    private static final float DIRECTION_CHANGE_THRESHOLD = 11f;
    private static final int REQUIRED_DIRECTION_CHANGES = 4;
    private static final long SHAKE_WINDOW_MS = 900;
    private static final long COOLDOWN_MS = 2500;

    private final SensorManager sensorManager;
    private final Sensor accelerometer;

    private ShakeListener listener;
    private float lastX = 0f;
    private int lastDirection = 0;
    private int directionChangeCount = 0;
    private long windowStartTime = 0;
    private long lastShakeTime = 0;

    public ShakeDetector(Context context) {
        sensorManager = (SensorManager) context.getApplicationContext()
            .getSystemService(Context.SENSOR_SERVICE);
        accelerometer = (sensorManager != null)
            ? sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            : null;
    }

    public boolean isAvailable() {
        return accelerometer != null;
    }

    public void setListener(ShakeListener shakeListener) {
        this.listener = shakeListener;
    }

    public void start() {
        if (sensorManager != null && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    public void stop() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        long now = System.currentTimeMillis();

        if (windowStartTime == 0 || (now - windowStartTime) > SHAKE_WINDOW_MS) {
            windowStartTime = now;
            directionChangeCount = 0;
            lastDirection = 0;
        }

        float delta = x - lastX;
        lastX = x;

        if (Math.abs(delta) < DIRECTION_CHANGE_THRESHOLD) {
            return;
        }

        int direction = (delta > 0) ? 1 : -1;
        if (lastDirection != 0 && direction != lastDirection) {
            directionChangeCount++;
        }
        lastDirection = direction;

        boolean patternComplete = directionChangeCount >= REQUIRED_DIRECTION_CHANGES;
        boolean cooldownElapsed = (now - lastShakeTime) > COOLDOWN_MS;

        if (patternComplete && cooldownElapsed) {
            lastShakeTime = now;
            directionChangeCount = 0;
            windowStartTime = 0;
            if (listener != null) {
                listener.onShakeDetected();
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed for shake detection.
    }
}
