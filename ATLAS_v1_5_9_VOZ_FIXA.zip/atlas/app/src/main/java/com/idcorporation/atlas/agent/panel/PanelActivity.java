package com.idcorporation.atlas.agent.panel;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.BaseActivity;
import com.idcorporation.atlas.theme.ThemeManager;

/**
 * In-app panel for data a tool just fetched (weather, news, search results,
 * places). Plain native Views driven by PanelData - no images are generated
 * and nothing here is invented: every value was returned by a real service.
 */
public class PanelActivity extends BaseActivity {

    private static final String EXTRA_JSON = "com.idcorporation.atlas.EXTRA_PANEL_JSON";

    /** Opens a panel from anywhere (chat, voice session, headless call). */
    public static void show(Context context, PanelData data) {
        if (data == null) {
            return;
        }
        Intent intent = new Intent(context, PanelActivity.class);
        intent.putExtra(EXTRA_JSON, data.toJson());
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
        } catch (RuntimeException ignored) {
            // The text answer still carries the essentials.
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String json = getIntent().getStringExtra(EXTRA_JSON);
        PanelData data = json == null ? new PanelData() : PanelData.fromJson(json);
        int accent = ThemeManager.getSelectedPalette(this).getAccentColor();
        int textPrimary = ContextCompat.getColor(this, R.color.atlas_text_primary);
        int textSecondary = ContextCompat.getColor(this, R.color.atlas_text_secondary);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(16), dp(16), dp(8));
        TextView title = text(data.title, 22, textPrimary, true);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text(getString(R.string.panel_close), 15, accent, true);
        close.setPadding(dp(12), dp(8), dp(4), dp(8));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        header.addView(close);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), 0, dp(16), dp(24));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        if (data.subtitle.length() > 0) {
            body.addView(text(data.subtitle, 14, textSecondary, false), matchWrap(0, 0, 0, 8));
        }
        if (data.heroValue.length() > 0) {
            LinearLayout hero = card(accent);
            hero.addView(text(data.heroValue, 56, textPrimary, true));
            hero.addView(text(data.heroLabel, 18, accent, true));
            if (data.heroDetail.length() > 0) {
                hero.addView(text(data.heroDetail, 13, textSecondary, false));
            }
            body.addView(hero, matchWrap(0, 4, 0, 12));
        }
        for (int i = 0; i < data.rows.size(); i++) {
            final PanelData.Row row = data.rows.get(i);
            LinearLayout card = card(accent);
            card.addView(text(row.title, 16, textPrimary, true));
            if (row.subtitle.length() > 0) {
                card.addView(text(row.subtitle, 13, textSecondary, false));
            }
            if (row.meta.length() > 0) {
                card.addView(text(row.meta, 12, accent, false));
            }
            if (isOpenable(row.url)) {
                card.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        open(row.url);
                    }
                });
            }
            body.addView(card, matchWrap(0, 0, 0, 10));
        }
        if (data.rows.isEmpty() && data.heroValue.length() == 0) {
            body.addView(text("-", 16, textSecondary, false));
        }
        if (data.source.length() > 0) {
            body.addView(text(getString(R.string.panel_source, data.source), 12, textSecondary, false),
                matchWrap(0, 8, 0, 0));
        }
        setContentView(root);
    }

    @Override
    protected boolean isVoiceCallScreen() {
        // The call keeps running underneath; this screen only displays data.
        return true;
    }

    private static boolean isOpenable(String url) {
        return url != null && (url.startsWith("https://") || url.startsWith("http://") || url.startsWith("geo:"));
    }

    private void open(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (RuntimeException ignored) {
            // No app to handle it.
        }
    }

    private LinearLayout card(int accent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(40, 255, 255, 255));
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)));
        c.setBackground(bg);
        return c;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        }
        return t;
    }

    private LinearLayout.LayoutParams matchWrap(int l, int t, int r, int b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(l), dp(t), dp(r), dp(b));
        return lp;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
