package com.idcorporation.atlas.presence;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;

import com.idcorporation.atlas.activities.HudStateManager;
import com.idcorporation.atlas.theme.ThemeManager;
import com.idcorporation.atlas.utils.PresenceManager;

/**
 * The floating ATLAS visual shown when the phone is shaken. It owns all
 * the animation timing (drop-in with overshoot, light igniting, idle
 * wobble, mic-level reaction, thinking and speaking modes, retract) and
 * hands each frame to a PresenceDrawer. All Presence looks share this same timing:
 * the blue liquid-glass lens under the notch (PresenceBubblePainter) and
 * the transparent colorless orb that rises from the bottom
 * (PresenceOrbPainter). It has no buttons: the controller decides what
 * taps and swipes mean.
 */
public class PresenceBubbleView extends View {

    /** Side of the small square window the sphere lives in once it is parked at the screen edge. */
    public static final float DOCK_VIEW_DP = 96f;

    private final float viewWidthDp;
    private final float viewHeightDp;

    private final PresenceBubbleState state = new PresenceBubbleState();
    private final PresenceDrawer painter;
    private final boolean glassLook;
    private final boolean nucleusLook;
    private final boolean cardLook;
    private final PresenceFrameClock clock = new PresenceFrameClock();
    private final float density;

    private ValueAnimator frameLoop;
    private ValueAnimator openAnimator;
    private ValueAnimator igniteAnimator;
    private ValueAnimator rippleAnimator;
    private ValueAnimator dockAnimator;
    private long lastFrameNanos = 0L;
    private int hudState = HudStateManager.STATE_IDLE;

    /** The original glass lens layout. */
    public PresenceBubbleView(Context context) {
        this(context, PresenceManager.LAYOUT_GLASS);
    }

    /** @param layout one of PresenceManager.LAYOUT_GLASS/LAYOUT_ORB/LAYOUT_NUCLEUS/LAYOUT_CARD */
    public PresenceBubbleView(Context context, int layout) {
        this(context, layout, false);
    }

    /**
     * ATLAS ESFERA: every layout now draws the 3D sphere (theme colour, follows the voice
     * state) in its own place and with its own entrance.
     *
     * @param lightweight true for the small live previews in Settings (lightest sphere tier)
     */
    public PresenceBubbleView(Context context, int layout, boolean lightweight) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        glassLook = (layout == PresenceManager.LAYOUT_GLASS);
        nucleusLook = (layout == PresenceManager.LAYOUT_NUCLEUS);
        cardLook = (layout == PresenceManager.LAYOUT_CARD);
        int accent = ThemeManager.getSelectedPalette(context).getAccentColor();
        painter = new PresenceSphereDrawer(density, layout, accent, lightweight);
        if (layout == PresenceManager.LAYOUT_ORB) {
            viewWidthDp = 240f;
            viewHeightDp = 190f;
        } else if (layout == PresenceManager.LAYOUT_NUCLEUS) {
            viewWidthDp = 330f;
            viewHeightDp = 720f;
        } else if (layout == PresenceManager.LAYOUT_CARD) {
            viewWidthDp = 260f;
            viewHeightDp = 380f;
        } else {
            viewWidthDp = 250f;
            viewHeightDp = 170f;
        }
        startFrameLoop();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (state.docked) {
            int mini = (int) (DOCK_VIEW_DP * density);
            setMeasuredDimension(mini, mini);
            return;
        }
        setMeasuredDimension((int) (viewWidthDp * density), (int) (viewHeightDp * density));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            painter.draw(canvas, getWidth(), getHeight(), state);
        } catch (RuntimeException e) {
            // Skip this frame instead of crashing the whole app on every redraw.
        }
    }

    // ---------------------------------------------------------------
    // Public API used by the service
    // ---------------------------------------------------------------

    public void setHudState(int newState) {
        hudState = newState;
        state.hudState = newState;
    }

    /** Feeds the raw recognizer loudness (roughly -2..10 dB) into the bubble. */
    public void setAudioLevel(float rmsDb) {
        float n = (rmsDb + 2f) / 12f;
        if (n < 0f) {
            n = 0f;
        }
        if (n > 1f) {
            n = 1f;
        }
        state.level = Math.max(state.level * 0.6f, n);
    }

    public void pingRipple() {
        if (rippleAnimator != null) {
            rippleAnimator.cancel();
        }
        rippleAnimator = ValueAnimator.ofFloat(0f, 1f);
        rippleAnimator.setDuration(760);
        rippleAnimator.setInterpolator(new DecelerateInterpolator());
        rippleAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                state.ripple = ((Float) animation.getAnimatedValue()).floatValue();
            }
        });
        rippleAnimator.addListener(new SimpleEnd() {
            @Override
            public void onAnimationEnd(Animator animation) {
                state.ripple = -1f;
            }
        });
        rippleAnimator.start();
    }

    /** Spring open (drops from the top for the glass, rises from the bottom for the orb), then the light ignites. */
    public void playOpen() {
        cancelOpenAnimators();
        state.open = 0f;
        state.ignite = 0f;
        state.phase = 0f;

        openAnimator = ValueAnimator.ofFloat(0f, 1f);
        if (glassLook) {
            // Glass: calm spring with a tiny overshoot.
            // (a little longer than before so the small sphere is seen growing)
            openAnimator.setDuration(820);
            openAnimator.setInterpolator(new PresenceSpring(0.7f));
        } else if (nucleusLook) {
            // Nucleus: smooth cinematic rise and bloom, intentionally softer
            // than a generic ball scale-up. Linear here on purpose - the
            // painter applies its own smoothstep ease to "open", so stacking
            // a second ease-out on the animator itself used to front-load
            // almost all the travel before the core was visible enough to
            // read as motion at all.
            openAnimator.setDuration(1150);
            openAnimator.setInterpolator(new LinearInterpolator());
        } else if (cardLook) {
            // Card: a calm center bloom, gentler than the orb's bounce and
            // without the glass lens's pill-first lead.
            openAnimator.setDuration(780);
            openAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
        } else {
            // Orb keeps its original bouncy rise.
            openAnimator.setDuration(680);
            openAnimator.setInterpolator(new OvershootInterpolator(1.35f));
        }
        openAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                state.open = ((Float) animation.getAnimatedValue()).floatValue();
            }
        });
        openAnimator.start();

        igniteAnimator = ValueAnimator.ofFloat(0f, 1f);
        igniteAnimator.setStartDelay(glassLook ? 260 : (nucleusLook ? 420 : (cardLook ? 300 : 170)));
        igniteAnimator.setDuration(glassLook ? 640 : (nucleusLook ? 900 : (cardLook ? 620 : 520)));
        igniteAnimator.setInterpolator(new DecelerateInterpolator(1.6f));
        igniteAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                state.ignite = ((Float) animation.getAnimatedValue()).floatValue();
            }
        });
        igniteAnimator.start();
        clock.primeSheen();
        pingRipple();
    }

    /** Retract back up under the notch, then run the callback. */
    public void playClose(final Runnable onFinished) {
        cancelOpenAnimators();
        final float startOpen = Math.min(1f, state.open);
        final float startIgnite = state.ignite;
        openAnimator = ValueAnimator.ofFloat(1f, 0f);
        // Longer than the old quick vanish: the sphere visibly contracts while it leaves
        // (up for the glass, down for the orb, in place for the card, then sinking for the nucleus).
        openAnimator.setDuration(glassLook ? 520 : (nucleusLook ? 880 : (cardLook ? 560 : 480)));
        openAnimator.setInterpolator(nucleusLook
            ? new LinearInterpolator()
            : new AccelerateDecelerateInterpolator());
        openAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float k = ((Float) animation.getAnimatedValue()).floatValue();
                state.open = startOpen * k;
                state.ignite = startIgnite * k;
            }
        });
        openAnimator.addListener(new SimpleEnd() {
            @Override
            public void onAnimationEnd(Animator animation) {
                state.open = 0f;
                if (onFinished != null) {
                    onFinished.run();
                }
            }
        });
        openAnimator.start();
    }

    // ---------------------------------------------------------------
    // Docking (parking the sphere, small, at the side of the screen)
    // ---------------------------------------------------------------

    /** Shrinks the sphere to its parked size where it is, then runs the callback. */
    public void shrinkToDock(final Runnable onFinished) {
        if (dockAnimator != null) {
            dockAnimator.removeAllListeners();
            dockAnimator.cancel();
        }
        dockAnimator = ValueAnimator.ofFloat(state.dock, 1f);
        dockAnimator.setDuration(360);
        dockAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        dockAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                state.dock = ((Float) animation.getAnimatedValue()).floatValue();
            }
        });
        dockAnimator.addListener(new SimpleEnd() {
            @Override
            public void onAnimationEnd(Animator animation) {
                state.dock = 1f;
                if (onFinished != null) {
                    onFinished.run();
                }
            }
        });
        dockAnimator.start();
    }

    /** true: the view becomes the small parked square; false: back to the normal size (sphere full again). */
    public void setDocked(boolean docked) {
        if (dockAnimator != null) {
            dockAnimator.removeAllListeners();
            dockAnimator.cancel();
            dockAnimator = null;
        }
        state.docked = docked;
        state.dock = docked ? 1f : 0f;
        requestLayout();
        invalidate();
    }

    public boolean isDocked() {
        return state.docked;
    }

    /** Where the sphere is centred inside this view right now (view pixels). */
    public float getSphereCenterX() {
        return state.sphereCx;
    }

    public float getSphereCenterY() {
        return state.sphereCy;
    }

    public void release() {
        cancelOpenAnimators();
        if (dockAnimator != null) {
            dockAnimator.removeAllListeners();
            dockAnimator.cancel();
            dockAnimator = null;
        }
        if (rippleAnimator != null) {
            rippleAnimator.cancel();
        }
        if (frameLoop != null) {
            frameLoop.cancel();
            frameLoop = null;
        }
    }

    // ---------------------------------------------------------------
    // Frame loop
    // ---------------------------------------------------------------

    private void cancelOpenAnimators() {
        if (openAnimator != null) {
            openAnimator.removeAllListeners();
            openAnimator.cancel();
        }
        if (igniteAnimator != null) {
            igniteAnimator.cancel();
        }
    }

    private void startFrameLoop() {
        frameLoop = ValueAnimator.ofFloat(0f, 1f);
        frameLoop.setDuration(1000);
        frameLoop.setRepeatCount(ValueAnimator.INFINITE);
        frameLoop.setInterpolator(new LinearInterpolator());
        frameLoop.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                stepFrame();
                invalidate();
            }
        });
        frameLoop.start();
    }

    private void stepFrame() {
        long now = System.nanoTime();
        float dt = (lastFrameNanos == 0L) ? 0.016f : (now - lastFrameNanos) / 1000000000f;
        lastFrameNanos = now;
        if (dt > 0.05f) {
            dt = 0.05f;
        }
        clock.step(dt, hudState, state);
    }

    /** Small helper so listeners only override the callback they care about. */
    private static class SimpleEnd implements Animator.AnimatorListener {
        @Override
        public void onAnimationStart(Animator animation) {
        }

        @Override
        public void onAnimationEnd(Animator animation) {
        }

        @Override
        public void onAnimationCancel(Animator animation) {
        }

        @Override
        public void onAnimationRepeat(Animator animation) {
        }
    }
}
