package com.idcorporation.atlas.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.idcorporation.atlas.calendar.CalendarDateUtils;
import com.idcorporation.atlas.calendar.CalendarEventManager;
import com.idcorporation.atlas.models.CalendarEventItem;
import com.idcorporation.atlas.utils.AlarmScheduler;
import com.idcorporation.atlas.utils.AppointmentReminderScheduler;
import com.idcorporation.atlas.utils.BirthdayScheduler;
import com.idcorporation.atlas.utils.PresenceManager;
import com.idcorporation.atlas.utils.ReminderScheduler;
import com.idcorporation.atlas.utils.UserProfileManager;

import java.util.ArrayList;
import java.util.Locale;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // BOOT_COMPLETED: phone restarted. MY_PACKAGE_REPLACED: ATLAS was just updated - Android
        // killed the Presence service (and cleared the alarms) even though the user never turned
        // anything off, so everything is brought back the same way as after a reboot.
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            if (ReminderScheduler.isDailyReminderEnabled(context)) {
                ReminderScheduler.scheduleDailyReminder(context);
            }

            UserProfileManager profileManager = new UserProfileManager(context);
            if (profileManager.hasBirthday()) {
                BirthdayScheduler.scheduleDailyCheck(context);
            }

            rescheduleTimedEvents(context);
            PresenceManager.restartIfEnabled(context);
        }
    }

    /** AlarmManager alarms do not survive a reboot, so every future reminder/alarm in the
     * database needs to be re-armed here. */
    private void rescheduleTimedEvents(Context context) {
        CalendarEventManager eventManager = new CalendarEventManager(context);
        String userName = new UserProfileManager(context).getName();
        ArrayList<CalendarEventItem> futureEvents = eventManager.getFutureTimedEvents();
        for (int i = 0; i < futureEvents.size(); i++) {
            CalendarEventItem item = futureEvents.get(i);
            long triggerMillis = CalendarDateUtils.toEpochMillis(
                item.getYear(), item.getMonth(), item.getDay(), item.getHour(), item.getMinute());
            int requestCode = (int) (triggerMillis % Integer.MAX_VALUE);
            if (CalendarEventItem.TYPE_ALARM.equals(item.getEventType())) {
                AlarmScheduler.scheduleAlarm(context, triggerMillis, requestCode, item.getTitle(), "");
            } else {
                String time = String.format(Locale.US, "%02d:%02d", item.getHour(), item.getMinute());
                String message = AppointmentReminderScheduler.buildMessage(context, userName, item.getTitle(), time);
                AppointmentReminderScheduler.scheduleAppointment(context, triggerMillis, requestCode,
                    item.getTitle(), message, item.getId());
            }
        }
    }
}
