package com.idcorporation.atlas.theme;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/** Exclusive background for the Purpura theme: soft glowing orbs that slowly bloom and fade. */
public class PurpuraBloomBackgroundView extends View implements ThemeBackgroundView {

    private static final int ORB_COUNT = 7;

    private int backgroundColor;
    private int bloomColor;
    private final float[] orbX = new float[ORB_COUNT];
    private final float[] orbY = new float[ORB_COUNT];
    private final float[] orbBaseRadius = new float[ORB_COUNT];
    private final float[] orbPhase = new float[ORB_COUNT];
    private final Random random = new Random();
    private boolean orbsInitialized = false;
    private final Paint orbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public PurpuraBloomBackgroundView(Context context) {
        super(context);
    }

    @Override
    public void setPalette(ThemePalette palette) {
        this.backgroundColor = palette.getBackgroundColor();
        this.bloomColor = palette.getAccentColor();
    }

    private void initOrbsIfNeeded(int width, int height) {
        if (orbsInitialized || width <= 0 || height <= 0) {
            return;
        }
        for (int i = 0; i < ORB_COUNT; i = i + 1) {
            orbX[i] = random.nextFloat() * width;
            orbY[i] = random.nextFloat() * height;
            orbBaseRadius[i] = 70f + random.nextFloat() * 90f;
            orbPhase[i] = random.nextFloat() * 6.28f;
        }
        orbsInitialized = true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        initOrbsIfNeeded(width, height);

        canvas.drawColor(backgroundColor);

        for (int i = 0; i < ORB_COUNT; i = i + 1) {
            orbPhase[i] = orbPhase[i] + 0.018f;
            float bloom = (float) (Math.sin(orbPhase[i]) * 0.5 + 0.5);
            float radius = orbBaseRadius[i] * (0.7f + 0.5f * bloom);
            int alpha = (int) (80 * bloom) + 20;

            RadialGradient gradient = new RadialGradient(
                orbX[i], orbY[i], radius,
                withAlpha(bloomColor, alpha), withAlpha(bloomColor, 0),
                Shader.TileMode.CLAMP);
            orbPaint.setShader(gradient);
            canvas.drawCircle(orbX[i], orbY[i], radius, orbPaint);
        }

        invalidate();
    }

    private int withAlpha(int color, int alpha) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    @Override
    public void stopAnimating() {
    }
}
