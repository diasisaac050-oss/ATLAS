package com.idcorporation.atlas.theme;

public class ThemePalette {

    private final String id;
    private final int nameResId;
    private final int backgroundColor;
    private final int backgroundColorAlt;
    private final int accentColor;
    private final boolean animated;
    private final int animationStyle;

    public ThemePalette(String id, int nameResId, int backgroundColor, int backgroundColorAlt, int accentColor,
                         boolean animated, int animationStyle) {
        this.id = id;
        this.nameResId = nameResId;
        this.backgroundColor = backgroundColor;
        this.backgroundColorAlt = backgroundColorAlt;
        this.accentColor = accentColor;
        this.animated = animated;
        this.animationStyle = animationStyle;
    }

    public String getId() {
        return id;
    }

    public int getNameResId() {
        return nameResId;
    }

    public int getBackgroundColor() {
        return backgroundColor;
    }

    /** Second color used only by animated themes. */
    public int getBackgroundColorAlt() {
        return backgroundColorAlt;
    }

    public int getAccentColor() {
        return accentColor;
    }

    public boolean isAnimated() {
        return animated;
    }

    public int getAnimationStyle() {
        return animationStyle;
    }
}
