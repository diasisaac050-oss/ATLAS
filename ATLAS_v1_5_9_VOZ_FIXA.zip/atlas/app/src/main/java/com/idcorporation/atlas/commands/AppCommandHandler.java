package com.idcorporation.atlas.commands;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;

import java.util.HashMap;

/**
 * Opens installed applications and performs browser actions through
 * standard, publicly supported Android intents only. No attempt is made
 * to bypass any Android security restriction.
 */
public class AppCommandHandler {

    private static final HashMap<String, String> KNOWN_PACKAGES = new HashMap<String, String>();

    static {
        KNOWN_PACKAGES.put("whatsapp", "com.whatsapp");
        KNOWN_PACKAGES.put("youtube", "com.google.android.youtube");
        KNOWN_PACKAGES.put("instagram", "com.instagram.android");
        KNOWN_PACKAGES.put("gmail", "com.google.android.gm");
        KNOWN_PACKAGES.put("chrome", "com.android.chrome");
        KNOWN_PACKAGES.put("spotify", "com.spotify.music");
        KNOWN_PACKAGES.put("camera", "com.android.camera2");
        KNOWN_PACKAGES.put("gallery", "com.google.android.apps.photos");
        KNOWN_PACKAGES.put("maps", "com.google.android.apps.maps");
        KNOWN_PACKAGES.put("play store", "com.android.vending");
        KNOWN_PACKAGES.put("facebook", "com.facebook.katana");
        KNOWN_PACKAGES.put("telegram", "org.telegram.messenger");
        KNOWN_PACKAGES.put("tiktok", "com.zhiliaoapp.musically");
        KNOWN_PACKAGES.put("netflix", "com.netflix.mediaclient");
        KNOWN_PACKAGES.put("drive", "com.google.android.apps.docs");
        KNOWN_PACKAGES.put("discord", "com.discord");
    }

    /** @return true if a matching, installed app was launched. */
    public boolean openAppByName(Context context, String spokenAppName) {
        return openAppAndReturnLabel(context, spokenAppName) != null;
    }

    /**
     * Opens the app the user asked for. Order of attempts:
     * 1) strong match against the real list of installed apps,
     * 2) the phone's default app for a system job (camera, gallery,
     *    calculator, clock...), 3) a weaker label match, 4) a short list
     * of well-known package names.
     *
     * @return the name to speak back ("WhatsApp"), or null if nothing opened.
     */
    public String openAppAndReturnLabel(Context context, String spokenAppName) {
        String spoken = InstalledAppFinder.normalize(spokenAppName);
        if (spoken.length() == 0) {
            return null;
        }
        String resolved = AppAliases.resolveNickname(spoken);

        InstalledAppFinder.LaunchableApp strong =
            InstalledAppFinder.find(context, resolved, InstalledAppFinder.STRONG);
        if (strong != null && InstalledAppFinder.launch(context, strong)) {
            return strong.label;
        }

        int category = AppAliases.categoryFor(resolved);
        if (category != AppAliases.NONE) {
            Intent categoryIntent = AppAliases.buildIntent(category);
            if (categoryIntent != null && startSafely(context, categoryIntent)) {
                return spokenAppName.trim();
            }
        }

        InstalledAppFinder.LaunchableApp weak =
            InstalledAppFinder.find(context, resolved, InstalledAppFinder.WEAK);
        if (weak != null && InstalledAppFinder.launch(context, weak)) {
            return weak.label;
        }

        String packageName = KNOWN_PACKAGES.get(resolved);
        if (packageName != null && openAppByPackage(context, packageName)) {
            return spokenAppName.trim();
        }
        return null;
    }

    public boolean openAppByPackage(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();
        Intent launchIntent = packageManager.getLaunchIntentForPackage(packageName);
        if (launchIntent == null) {
            return false;
        }
        return startSafely(context, launchIntent);
    }

    private boolean startSafely(Context context, Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
            return true;
        } catch (RuntimeException e) {
            // No app can handle it, or Android refused the launch.
            return false;
        }
    }

    public void openBrowser(Context context) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public void openBrowserSearch(Context context, String query) {
        Uri searchUri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query));
        Intent intent = new Intent(Intent.ACTION_VIEW, searchUri);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public void openUrl(Context context, String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
