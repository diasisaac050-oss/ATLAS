package com.idcorporation.atlas.memory;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Single local SQLite database backing memories, notes, conversation
 * history and custom commands. Plain SQLiteOpenHelper is used instead of
 * Room to avoid annotation-processor dependencies that do not resolve
 * reliably inside Code Assist.
 *
 * IMPORTANT: onUpgrade is additive only. It never drops existing tables,
 * so upgrading the app (adding ATLAS Notes projects/checklists) never
 * wipes memories, history, custom commands or calendar events that were
 * already on the device.
 */
public class AtlasDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "atlas.db";
    private static final int DATABASE_VERSION = 5;

    public static final String TABLE_MEMORIES = "memories";
    public static final String TABLE_NOTES = "notes";
    public static final String TABLE_HISTORY = "history";
    public static final String TABLE_CUSTOM_COMMANDS = "custom_commands";
    public static final String TABLE_CALENDAR_EVENTS = "calendar_events";
    public static final String TABLE_NOTE_PROJECTS = "note_projects";
    public static final String TABLE_CHECKLIST_ITEMS = "note_checklist_items";

    public static final String DEFAULT_PROJECT_NAME = "Notas Gerais";

    private static AtlasDatabase instance;

    public static synchronized AtlasDatabase getInstance(Context context) {
        if (instance == null) {
            instance = new AtlasDatabase(context.getApplicationContext());
        }
        return instance;
    }

    private AtlasDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_MEMORIES + " ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "memory_key TEXT, "
            + "memory_value TEXT, "
            + "category TEXT, "
            + "created_at INTEGER)");

        db.execSQL("CREATE TABLE " + TABLE_HISTORY + " ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "conversation_title TEXT, "
            + "role TEXT, "
            + "message TEXT, "
            + "timestamp INTEGER)");

        db.execSQL("CREATE TABLE " + TABLE_CUSTOM_COMMANDS + " ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "phrase TEXT, "
            + "action_type TEXT, "
            + "action_value TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_CALENDAR_EVENTS + " ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "event_year INTEGER, "
            + "event_month INTEGER, "
            + "event_day INTEGER, "
            + "event_hour INTEGER, "
            + "event_minute INTEGER, "
            + "title TEXT, "
            + "event_type TEXT, "
            + "repeat_yearly INTEGER, "
            + "recurrence_rule TEXT DEFAULT 'NONE', "
            + "recurrence_interval INTEGER DEFAULT 1, "
            + "created_at INTEGER)");

        createNoteProjectsTable(db);
        createNotesTableV3(db);
        createChecklistTable(db);

        long defaultProjectId = insertDefaultProject(db);
        markLegacyNotesWithProject(db, defaultProjectId);
    }

    private void createNoteProjectsTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NOTE_PROJECTS + " ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "name TEXT, "
            + "created_at INTEGER, "
            + "is_deleted INTEGER DEFAULT 0, "
            + "deleted_at INTEGER DEFAULT 0)");
    }

    private void createNotesTableV3(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NOTES + " ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "project_id INTEGER DEFAULT 0, "
            + "title TEXT, "
            + "content TEXT, "
            + "tags TEXT DEFAULT '', "
            + "is_favorite INTEGER DEFAULT 0, "
            + "is_vault INTEGER DEFAULT 0, "
            + "is_deleted INTEGER DEFAULT 0, "
            + "deleted_at INTEGER DEFAULT 0, "
            + "created_at INTEGER, "
            + "updated_at INTEGER DEFAULT 0)");
    }

    private void createChecklistTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_CHECKLIST_ITEMS + " ("
            + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + "note_id INTEGER, "
            + "item_text TEXT, "
            + "is_done INTEGER DEFAULT 0, "
            + "position INTEGER DEFAULT 0, "
            + "created_at INTEGER)");
    }

    private long insertDefaultProject(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put("name", DEFAULT_PROJECT_NAME);
        values.put("created_at", System.currentTimeMillis());
        values.put("is_deleted", 0);
        return db.insert(TABLE_NOTE_PROJECTS, null, values);
    }

    private void markLegacyNotesWithProject(SQLiteDatabase db, long defaultProjectId) {
        ContentValues values = new ContentValues();
        values.put("project_id", defaultProjectId);
        db.update(TABLE_NOTES, values, "project_id IS NULL OR project_id = 0", null);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Version 2 introduced the calendar tables; on a fresh v1 install
            // being upgraded straight to v3 this table may already exist from
            // onCreate, so guard with IF NOT EXISTS.
            db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_CALENDAR_EVENTS + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "event_year INTEGER, "
                + "event_month INTEGER, "
                + "event_day INTEGER, "
                + "event_hour INTEGER, "
                + "event_minute INTEGER, "
                + "title TEXT, "
                + "event_type TEXT, "
                + "repeat_yearly INTEGER, "
                + "created_at INTEGER)");
        }
        if (oldVersion < 3) {
            upgradeToNotesV3(db);
        }
        if (oldVersion < 4) {
            addColumnIfMissing(db, TABLE_CALENDAR_EVENTS, "recurrence_rule", "TEXT DEFAULT 'NONE'");
            addColumnIfMissing(db, TABLE_CALENDAR_EVENTS, "recurrence_interval", "INTEGER DEFAULT 1");
        }
        // Version 5 used to create the (now removed) expense tables; nothing to do any more.
    }

    private void upgradeToNotesV3(SQLiteDatabase db) {
        createNoteProjectsTable(db);
        createChecklistTable(db);

        addColumnIfMissing(db, TABLE_NOTES, "project_id", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_NOTES, "tags", "TEXT DEFAULT ''");
        addColumnIfMissing(db, TABLE_NOTES, "is_favorite", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_NOTES, "is_vault", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_NOTES, "is_deleted", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_NOTES, "deleted_at", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_NOTES, "updated_at", "INTEGER DEFAULT 0");

        long defaultProjectId = insertDefaultProject(db);
        markLegacyNotesWithProject(db, defaultProjectId);
    }

    private void addColumnIfMissing(SQLiteDatabase db, String table, String column, String definition) {
        android.database.Cursor cursor = db.rawQuery("PRAGMA table_info(" + table + ")", null);
        boolean exists = false;
        while (cursor.moveToNext()) {
            String existingName = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            if (existingName.equalsIgnoreCase(column)) {
                exists = true;
                break;
            }
        }
        cursor.close();
        if (!exists) {
            db.execSQL("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
        }
    }
}
