package com.idcorporation.atlas.theme;

/** Implemented by every animated background View used by ThemeManager. */
public interface ThemeBackgroundView {

    void setPalette(ThemePalette palette);

    void stopAnimating();
}
