package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/**
 * The bright parts of the Presence glass that are not the glass edge: the
 * sound-wave bars in the middle (see PresenceWaveform) and the double
 * ripple ring that goes out when the bubble opens or is tapped. Only shades
 * of blue and white are used.
 */
public class PresenceBubbleEffects {

    private final float d;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final PresenceWaveform waveform;

    public PresenceBubbleEffects(float density) {
        this.d = density;
        this.waveform = new PresenceWaveform(density);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    /**
     * The middle line of the bubble: sound-wave bars that move with the
     * user's voice and with ATLAS speaking.
     */
    void drawStreak(Canvas canvas, float cx, float cy, float a, float b,
                    PresenceBubbleState st, float pulse, float alpha) {
        float ig = st.ignite * alpha;
        if (ig <= 0.01f) {
            return;
        }
        waveform.draw(canvas, cx, cy - b * 0.04f, a, st, ig);
    }

    void drawRipple(Canvas canvas, Path body, float cx, float cy, PresenceBubbleState st) {
        if (st.ripple < 0f || st.ripple > 1f) {
            return;
        }
        ring(canvas, body, cx, cy, st.ripple, 1.4f, 140);
        float second = st.ripple - 0.18f;
        if (second > 0f) {
            ring(canvas, body, cx, cy, second, 1.0f, 90);
        }
    }

    private void ring(Canvas canvas, Path body, float cx, float cy, float t, float width, int peak) {
        float k = 1f + 0.30f * t;
        float fade = 1f - t;
        line.setShader(null);
        line.setStrokeWidth(width * d);
        line.setColor(PresenceBlues.alpha(PresenceBlues.LIGHT, (int) ((float) peak * fade * fade)));
        canvas.save();
        canvas.scale(k, k, cx, cy);
        canvas.drawPath(body, line);
        canvas.restore();
    }
}
