package com.idcorporation.atlas.calendar;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Finds a calendar date inside a sentence, in any of the ways people
 * actually say it: "dia 20 de abril", "20 de abril de 2027", "20/04",
 * "dia 20" (next time day 20 comes), "hoje", "amanha", "depois de
 * amanha", "sexta", "proxima segunda", "daqui a 3 dias", "semana que
 * vem". Works on normalized text (lower-case, no accents) and reports
 * where the date words are so the title extractor can skip them.
 */
public class DateExpressionParser {

    public static class DateResult {
        public boolean found;
        public int year;
        public int month;
        public int day;
        public int start = -1;
        public int end = -1;
    }

    public static final String MONTHS =
        "(?:janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)";

    private static final String[] MONTH_NAMES = new String[]{
        "janeiro", "fevereiro", "marco", "abril", "maio", "junho",
        "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
    };

    private static final String LEAD = "(?:\\b(?:para\\s+o|para|pro|pra|no|em)\\s+)?";

    private static final Pattern DAY_MONTH = Pattern.compile(
        LEAD + "(?:\\bdia\\s+)?\\b(primeiro|" + PtNumberWords.NUM + ")"
        + "\\s+(?:(?:de|do)\\s+)?(?:mes\\s+(?:de\\s+)?)?(" + MONTHS + ")\\b"
        + "(?:\\s+(?:de|do)\\s+(\\d{4}))?");

    private static final Pattern SLASH_DATE = Pattern.compile(
        LEAD + "(?:\\bdia\\s+)?\\b(\\d{1,2})\\s*/\\s*(\\d{1,2})(?:\\s*/\\s*(\\d{2,4}))?\\b");

    private static final Pattern AFTER_TOMORROW = Pattern.compile("\\bdepois\\s+de\\s+amanha\\b");
    private static final Pattern TOMORROW = Pattern.compile("\\bamanha\\b");
    private static final Pattern YESTERDAY = Pattern.compile("\\bontem\\b");
    private static final Pattern TODAY = Pattern.compile("\\b(?:hoje|esta\\s+noite|essa\\s+noite)\\b");
    // Unit is captured so the caller can tell days/weeks apart from months/years,
    // each of which needs its own real-calendar math (a month is not "30 dias").
    private static final Pattern IN_UNITS = Pattern.compile(
        "\\b(?:daqui\\s+a|daqui|dentro\\s+de|em)\\s+(" + PtNumberWords.NUM
        + ")\\s+(dias?|semanas?|meses|mes|anos?)\\b");
    private static final Pattern NEXT_WEEK = Pattern.compile(
        "\\b(?:na\\s+)?(?:semana\\s+que\\s+vem|proxima\\s+semana)\\b");
    private static final Pattern NEXT_MONTH = Pattern.compile(
        "\\b(?:no\\s+)?(?:mes\\s+que\\s+vem|proximo\\s+mes)\\b");
    private static final Pattern DAY_ONLY = Pattern.compile(LEAD + "\\bdia\\s+(\\d{1,2})\\b");
    private static final Pattern WEEKDAY = Pattern.compile(
        "(?:\\b(?:na|no|nesta|neste|esta|este)\\s+)?(?:(?:proxima|proximo)\\s+)?"
        + "\\b(segunda|terca|quarta|quinta|sexta|sabado|domingo)\\b(?:-feira|\\s+feira)?(?:\\s+que\\s+vem)?");

    public static DateResult parse(String n, Calendar now) {
        DateResult r = new DateResult();
        Matcher m = DAY_MONTH.matcher(n);
        while (m.find()) {
            int day = "primeiro".equals(m.group(1)) ? 1 : PtNumberWords.value(m.group(1));
            int month = monthIndex(m.group(2)) + 1;
            if (day < 1 || day > 31 || month < 1) {
                continue;
            }
            int year;
            if (m.group(3) != null) {
                year = Integer.parseInt(m.group(3));
                if (!CalendarDateUtils.isValidDate(year, month, day)) {
                    continue;
                }
            } else {
                year = upcomingYear(now, month, day);
                if (year < 0) {
                    continue;
                }
            }
            return fill(r, year, month, day, m.start(), m.end());
        }

        m = SLASH_DATE.matcher(n);
        while (m.find()) {
            int day = Integer.parseInt(m.group(1));
            int month = Integer.parseInt(m.group(2));
            int year;
            if (m.group(3) != null) {
                year = Integer.parseInt(m.group(3));
                if (year < 100) {
                    year += 2000;
                }
            } else {
                year = upcomingYear(now, month, day);
            }
            if (year > 0 && CalendarDateUtils.isValidDate(year, month, day)) {
                return fill(r, year, month, day, m.start(), m.end());
            }
        }

        m = AFTER_TOMORROW.matcher(n);
        if (m.find()) {
            return fromOffset(r, now, 2, m.start(), m.end());
        }
        m = TOMORROW.matcher(n);
        if (m.find()) {
            return fromOffset(r, now, 1, m.start(), m.end());
        }
        m = YESTERDAY.matcher(n);
        if (m.find()) {
            return fromOffset(r, now, -1, m.start(), m.end());
        }
        m = TODAY.matcher(n);
        if (m.find()) {
            return fromOffset(r, now, 0, m.start(), m.end());
        }
        m = IN_UNITS.matcher(n);
        if (m.find()) {
            int amount = PtNumberWords.value(m.group(1));
            String unit = m.group(2);
            if (unit.startsWith("semana")) {
                if (amount >= 1 && amount <= 52) {
                    return fromOffset(r, now, amount * 7, m.start(), m.end());
                }
            } else if (unit.startsWith("mes")) {
                // Real calendar month math (java.util.Calendar#add), never a fixed
                // "+30 dias": "daqui a um mes" from Jan 31 correctly lands on the
                // last day of February, not on a made-up 31st day of a shorter month.
                if (amount >= 1 && amount <= 60) {
                    return fromMonthOffset(r, now, amount, m.start(), m.end());
                }
            } else if (unit.startsWith("ano")) {
                if (amount >= 1 && amount <= 20) {
                    return fromYearOffset(r, now, amount, m.start(), m.end());
                }
            } else {
                if (amount >= 1 && amount <= 400) {
                    return fromOffset(r, now, amount, m.start(), m.end());
                }
            }
        }
        m = NEXT_WEEK.matcher(n);
        if (m.find()) {
            return fromOffset(r, now, 7, m.start(), m.end());
        }
        m = NEXT_MONTH.matcher(n);
        if (m.find()) {
            return fromMonthOffset(r, now, 1, m.start(), m.end());
        }
        return parseDayOnlyOrWeekday(n, now, r);
    }

    private static DateResult parseDayOnlyOrWeekday(String n, Calendar now, DateResult r) {
        Matcher m = DAY_ONLY.matcher(n);
        while (m.find()) {
            int day = Integer.parseInt(m.group(1));
            if (day < 1 || day > 31) {
                continue;
            }
            Calendar cursor = new GregorianCalendar(now.get(Calendar.YEAR), now.get(Calendar.MONTH), 1);
            for (int i = 0; i < 13; i++) {
                int year = cursor.get(Calendar.YEAR);
                int month = cursor.get(Calendar.MONTH) + 1;
                boolean notPast = i > 0 || day >= now.get(Calendar.DAY_OF_MONTH);
                if (notPast && CalendarDateUtils.isValidDate(year, month, day)) {
                    return fill(r, year, month, day, m.start(), m.end());
                }
                cursor.add(Calendar.MONTH, 1);
            }
        }
        m = WEEKDAY.matcher(n);
        if (m.find()) {
            int target = weekdayConstant(m.group(1));
            int diff = (target - now.get(Calendar.DAY_OF_WEEK) + 7) % 7;
            if (diff == 0) {
                diff = 7;
            }
            return fromOffset(r, now, diff, m.start(), m.end());
        }
        return r;
    }

    private static int weekdayConstant(String word) {
        if ("segunda".equals(word)) {
            return Calendar.MONDAY;
        }
        if ("terca".equals(word)) {
            return Calendar.TUESDAY;
        }
        if ("quarta".equals(word)) {
            return Calendar.WEDNESDAY;
        }
        if ("quinta".equals(word)) {
            return Calendar.THURSDAY;
        }
        if ("sexta".equals(word)) {
            return Calendar.FRIDAY;
        }
        if ("sabado".equals(word)) {
            return Calendar.SATURDAY;
        }
        return Calendar.SUNDAY;
    }

    private static int monthIndex(String name) {
        for (int i = 0; i < MONTH_NAMES.length; i++) {
            if (MONTH_NAMES[i].equals(name)) {
                return i;
            }
        }
        return -1;
    }

    /** First year (this one or a later one) in which month/day has not passed yet, or -1 if none is valid. */
    private static int upcomingYear(Calendar now, int month, int day) {
        int thisYear = now.get(Calendar.YEAR);
        for (int year = thisYear; year <= thisYear + 8; year++) {
            if (!CalendarDateUtils.isValidDate(year, month, day)) {
                continue;
            }
            Calendar endOfDay = new GregorianCalendar(year, month - 1, day, 23, 59, 59);
            if (endOfDay.getTimeInMillis() >= now.getTimeInMillis()) {
                return year;
            }
        }
        return -1;
    }

    private static DateResult fromOffset(DateResult r, Calendar now, int days, int start, int end) {
        Calendar c = (Calendar) now.clone();
        c.add(Calendar.DAY_OF_MONTH, days);
        return fill(r, c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), start, end);
    }

    /** Calendar.add(MONTH, ...) already clamps to the real last day of a shorter target month. */
    private static DateResult fromMonthOffset(DateResult r, Calendar now, int months, int start, int end) {
        Calendar c = (Calendar) now.clone();
        c.add(Calendar.MONTH, months);
        return fill(r, c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), start, end);
    }

    private static DateResult fromYearOffset(DateResult r, Calendar now, int years, int start, int end) {
        Calendar c = (Calendar) now.clone();
        c.add(Calendar.YEAR, years);
        return fill(r, c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), start, end);
    }

    private static DateResult fill(DateResult r, int year, int month, int day, int start, int end) {
        r.found = true;
        r.year = year;
        r.month = month;
        r.day = day;
        r.start = start;
        r.end = end;
        return r;
    }
}
