package com.idcorporation.atlas.voice;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.speech.SpeechRecognizer;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.HudStateManager;
import com.idcorporation.atlas.ai.AIManager;
import com.idcorporation.atlas.ai.AIProvider;
import com.idcorporation.atlas.commands.CommandManager;
import com.idcorporation.atlas.commands.CommandOutcome;
import com.idcorporation.atlas.commands.ConfirmAction;
import com.idcorporation.atlas.models.HistoryMessage;
import com.idcorporation.atlas.utils.SecretUnlockManager;
import com.idcorporation.atlas.utils.TextSanitizer;
import com.idcorporation.atlas.utils.UserProfileManager;

import java.util.ArrayList;

/**
 * ATLAS VOID "estilo ligacao": a single, permanent voice+AI pipeline for
 * the whole app, owned by AtlasApplication instead of any one Activity.
 *
 * Before this, every screen that wanted to talk to ATLAS had to build
 * and tear down its own SpeechRecognizer/TextToSpeech/CommandManager/
 * AIManager, and MainActivity.onPause() cancelled listening outright -
 * so the "always listening" mic only ever worked on the main screen and
 * went silent the moment the user opened Settings, Notes, History, or
 * any other tab. Now there is exactly one call session for the app's
 * entire foreground lifetime: it keeps listening no matter which ATLAS
 * screen is on top, and only really "hangs up" once every ATLAS screen
 * has left the foreground - see AtlasApplication, which owns this
 * object and decides when that happens.
 */
public class AtlasVoiceSession {

    public interface UiListener {
        void onStateChanged(int hudState);
        void onTranscriptLine(String line);
        void onMicMutedChanged(boolean muted);
        void onConfirmationNeeded(String prompt, ConfirmAction confirmedAction);
    }

    /** Live microphone loudness (roughly -2..10 dB), used by the Presence sound-wave line. */
    public interface AudioLevelListener {
        void onAudioLevel(float rmsDb);
    }

    private final Context appContext;
    private final VoiceManager voiceManager;
    private final AIManager aiManager;
    private final CommandManager commandManager;
    private final UserProfileManager profileManager;

    private final ArrayList<String> conversationHistory = new ArrayList<String>();
    private String conversationTitle;
    private UiListener uiListener;
    private AudioLevelListener audioLevelListener;
    /** Second, independent audio-level listener: the Home screen's 3D sphere (the Presence bridge keeps the first one). */
    private AudioLevelListener uiAudioLevelListener;

    private boolean micMuted = false;
    private boolean appInForeground = false;
    // True while the floating Presence bubble (shake) is showing: the call is
    // "live" for the bubble even though no ATLAS screen is in the foreground.
    private boolean presenceActive = false;
    private int silentErrorStreak = 0;
    private int hardErrorStreak = 0;
    private static final long BUSY_WATCHDOG_MS = 70000L;
    private final Handler watchdogHandler = new Handler(Looper.getMainLooper());
    private int busyToken = 0;
    private boolean permissionGranted = false;
    private int currentState = HudStateManager.STATE_IDLE;

    private final Handler restartHandler = new Handler(Looper.getMainLooper());

    // ATLAS AGENT CORE - listening while Atlas talks. While TTS is playing, the recognizer keeps
    // running ONLY to catch a stop order (see StopCommandDetector); everything else it hears
    // (other people, TV, Atlas's own echo) is ignored and never sent to the AI.
    private final Handler bargeHandler = new Handler(Looper.getMainLooper());
    private boolean speaking = false;
    private String currentSpokenText = "";
    private int bargeInErrorStreak = 0;
    private boolean bargeInGaveUp = false;
    private String weakCandidate = null;
    private static final long WEAK_STOP_STABLE_MS = 250L;
    private final Runnable weakStopRunnable = new Runnable() {
        @Override
        public void run() {
            if (speaking && weakCandidate != null) {
                stopByVoiceCommand();
            }
        }
    };

    // A confirmation prepared by an agent tool, answerable by voice ("sim"/"nao") or by the Yes/No card.
    private ConfirmAction pendingAgentConfirm = null;
    private long pendingAgentConfirmExpires = 0L;

    public AtlasVoiceSession(Context context) {
        this.appContext = context.getApplicationContext();
        this.profileManager = new UserProfileManager(appContext);
        this.aiManager = new AIManager(appContext);
        this.commandManager = new CommandManager(appContext);
        this.voiceManager = new VoiceManager(appContext);
        this.conversationTitle = "Session " + System.currentTimeMillis();
        wireVoiceEvents();
        this.voiceManager.setBargeInPartialListener(new VoiceManager.PartialTextListener() {
            @Override
            public void onPartialText(String text) {
                handleBargeInPartial(text);
            }
        });
    }

    public void setUiListener(UiListener listener) {
        this.uiListener = listener;
        if (listener != null) {
            listener.onStateChanged(currentState);
            listener.onMicMutedChanged(micMuted);
        }
    }

    public void setAudioLevelListener(AudioLevelListener listener) {
        this.audioLevelListener = listener;
    }

    public void setUiAudioLevelListener(AudioLevelListener listener) {
        this.uiAudioLevelListener = listener;
    }

    public void clearUiListener(UiListener listener) {
        if (this.uiListener == listener) {
            this.uiListener = null;
        }
    }

    private boolean callActive() {
        return appInForeground || presenceActive;
    }

    /**
     * Shake gesture: opens a live call for the floating bubble - mic ON
     * right away, no tap needed - without any ATLAS screen being open.
     * Reuses this same pipeline (voice + commands + AI) so the bubble
     * behaves exactly like the app itself instead of a second copy.
     */
    public void startPresenceCall() {
        speaking = false;
        bargeHandler.removeCallbacksAndMessages(null);
        presenceActive = true;
        silentErrorStreak = 0;
        hardErrorStreak = 0;
        permissionGranted = (androidx.core.content.ContextCompat.checkSelfPermission(
            appContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED);
        if (micMuted) {
            micMuted = false;
            if (uiListener != null) {
                uiListener.onMicMutedChanged(false);
            }
        }
        restartHandler.removeCallbacksAndMessages(null);
        voiceManager.stopSpeaking();
        voiceManager.cancelListening();
        setState(HudStateManager.STATE_IDLE);
        if (permissionGranted) {
            voiceManager.startListening();
        }
    }

    /**
     * Called by the Presence service when the microphone foreground type was
     * granted AFTER the call had already started (Android grants it a moment
     * after the overlay is visible). The turn that began before that moment
     * may have been recorded as silence, so it is thrown away and a fresh
     * one starts now that the microphone is really available.
     */
    public void refreshPresenceListening() {
        if (!presenceActive || micMuted || !permissionGranted) {
            return;
        }
        if (currentState == HudStateManager.STATE_IDLE || currentState == HudStateManager.STATE_LISTENING) {
            voiceManager.cancelListening();
            voiceManager.startListening();
        }
    }

    /** How many listening turns in a row ended with no speech heard (used to hint about mic trouble). */
    public int getSilentErrorStreak() {
        return silentErrorStreak;
    }

    public boolean hasMicPermission() {
        return permissionGranted;
    }

    /** Closes the bubble's call. Does nothing to the normal in-app call if the app is open. */
    public void endPresenceCall() {
        speaking = false;
        bargeHandler.removeCallbacksAndMessages(null);
        presenceActive = false;
        restartHandler.removeCallbacksAndMessages(null);
        voiceManager.stopSpeaking();
        voiceManager.cancelListening();
        setState(HudStateManager.STATE_IDLE);
    }

    /**
     * Hands the live call over to the full app (double tap): the bubble
     * stops owning the call, but the mic keeps listening without a gap.
     */
    public void detachPresence() {
        presenceActive = false;
    }

    public void setPartialTextListener(VoiceManager.PartialTextListener listener) {
        voiceManager.setPartialTextListener(listener);
    }

    /** Tap while ATLAS is talking: shut him up and go straight back to listening. */
    public void interruptAndListen() {
        speaking = false;
        voiceManager.stopSpeaking();
        setState(HudStateManager.STATE_IDLE);
        if (!micMuted && callActive() && permissionGranted) {
            voiceManager.cancelListening();
            voiceManager.startListening();
        }
    }

    public boolean isMicMuted() {
        return micMuted;
    }

    public int getCurrentState() {
        return currentState;
    }

    /**
     * Call from BaseActivity.onResume() on every ATLAS screen. Marks the
     * call as being on-screen again and, if it is not muted and nothing
     * else is happening right now, makes sure the mic is listening -
     * this is what keeps the call going no matter which tab the user
     * lands on.
     */
    public void onAppForeground(boolean recordAudioPermissionGranted) {
        appInForeground = true;
        permissionGranted = recordAudioPermissionGranted;
        if (permissionGranted && !micMuted && currentState == HudStateManager.STATE_IDLE) {
            voiceManager.startListening();
        }
    }

    /**
     * ATLAS MODOS: switching to Chat mode. Hangs up right now (mic off,
     * speech cut) and stops the session from listening again on any
     * screen, until the user goes back to Voice mode.
     */
    public void suspendForChatMode() {
        speaking = false;
        bargeHandler.removeCallbacksAndMessages(null);
        appInForeground = false;
        presenceActive = false;
        restartHandler.removeCallbacksAndMessages(null);
        voiceManager.stopSpeaking();
        voiceManager.cancelListening();
        setState(HudStateManager.STATE_IDLE);
    }

    /** Called once by AtlasApplication when the whole app leaves the foreground - actually hangs up. */
    public void hangUp() {
        appInForeground = false;
        if (presenceActive) {
            // The floating bubble still owns a live call; leave it listening.
            return;
        }
        restartHandler.removeCallbacksAndMessages(null);
        voiceManager.cancelListening();
    }

    public void notifyPermissionGranted() {
        permissionGranted = true;
        forceRestartListening();
    }

    /** Interrupts whatever the recognizer is doing right now and starts a fresh listening turn. */
    public void forceRestartListening() {
        if (callActive() && !micMuted && permissionGranted) {
            voiceManager.stopSpeaking();
            voiceManager.startListening();
        }
    }

    /** Used by screens that show their own typed-text field (mirrors the old per-screen pause). */
    public void pauseListening() {
        restartHandler.removeCallbacksAndMessages(null);
        voiceManager.cancelListening();
    }

    public void resumeListeningIfIdle() {
        if (!micMuted && callActive() && permissionGranted && currentState == HudStateManager.STATE_IDLE) {
            voiceManager.startListening();
        }
    }

    public void toggleMicMute() {
        micMuted = !micMuted;
        if (uiListener != null) {
            uiListener.onMicMutedChanged(micMuted);
        }
        if (micMuted) {
            restartHandler.removeCallbacksAndMessages(null);
            voiceManager.cancelListening();
            setState(HudStateManager.STATE_IDLE);
        } else if (callActive() && permissionGranted) {
            voiceManager.stopSpeaking();
            voiceManager.startListening();
        }
    }

    public void stopSpeaking() {
        // TextToSpeech.stop() never fires a "done" callback, so cutting ATLAS
        // off used to leave the session stuck in SPEAKING with the mic dead.
        if (currentState == HudStateManager.STATE_SPEAKING) {
            interruptAndListen();
        } else {
            voiceManager.stopSpeaking();
        }
    }

    public void setSpeechRate(float rate) {
        voiceManager.setSpeechRate(rate);
    }

    public void setSpeechPitch(float pitch) {
        voiceManager.setSpeechPitch(pitch);
    }

    public void sendTypedMessage(String text) {
        if (text == null || text.trim().length() == 0) {
            return;
        }
        restartHandler.removeCallbacksAndMessages(null);
        voiceManager.cancelListening();
        handleUserUtterance(text.trim());
    }

    /** Used by a UI (e.g. a Yes/No confirmation card) to speak and log its own follow-up response. */
    public void speakAndLog(String response) {
        appendTranscriptLine("ATLAS: " + response);
        commandManager.logToHistory(conversationTitle, HistoryMessage.ROLE_ATLAS, response);
        speak(response);
    }

    private void speak(String text) {
        currentSpokenText = text == null ? "" : text;
        bargeInErrorStreak = 0;
        bargeInGaveUp = false;
        weakCandidate = null;
        voiceManager.speak(text);
    }

    private boolean bargeInEnabled() {
        return appContext.getSharedPreferences("atlas_voice_prefs", Context.MODE_PRIVATE)
            .getBoolean("listen_while_speaking", true);
    }

    private void startBargeIn() {
        if (!bargeInEnabled() || micMuted || !callActive() || !permissionGranted || bargeInGaveUp || !speaking) {
            return;
        }
        voiceManager.startListening();
    }

    private void restartBargeIn(long delayMs) {
        bargeHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (speaking) {
                    startBargeIn();
                }
            }
        }, delayMs);
    }

    private void handleBargeInPartial(String partial) {
        if (!speaking) {
            return;
        }
        bargeInErrorStreak = 0;
        StopCommandDetector.Level level = StopCommandDetector.classify(partial, currentSpokenText);
        bargeHandler.removeCallbacks(weakStopRunnable);
        if (level == StopCommandDetector.Level.STRONG) {
            stopByVoiceCommand();
        } else if (level == StopCommandDetector.Level.WEAK) {
            // Ambiguous ("para"): only stop if it stays that way for a moment, so the start
            // of a normal sentence ("para a gente ir...") does not cut the voice.
            weakCandidate = partial;
            bargeHandler.postDelayed(weakStopRunnable, WEAK_STOP_STABLE_MS);
        } else {
            weakCandidate = null;
        }
    }

    private void handleBargeInFinal(String text) {
        bargeInErrorStreak = 0;
        StopCommandDetector.Level level = StopCommandDetector.classify(text, currentSpokenText);
        if (level != StopCommandDetector.Level.NONE) {
            stopByVoiceCommand();
        } else {
            // Parallel conversation, noise or echo: keep talking, keep listening.
            restartBargeIn(120L);
        }
    }

    private void handleBargeInError(int errorCode) {
        if (SpeechRecognizerManager.isHardError(errorCode)) {
            // The voice order is now the ONLY way to cut Atlas off, so never give up on it:
            // just wait a little longer between attempts when the recogniser keeps failing.
            bargeInErrorStreak = bargeInErrorStreak + 1;
            long wait = 600L + 400L * Math.min(bargeInErrorStreak, 8);
            restartBargeIn(wait);
        } else {
            restartBargeIn(120L);
        }
    }

    private void stopByVoiceCommand() {
        weakCandidate = null;
        bargeHandler.removeCallbacksAndMessages(null);
        interruptAndListen();
    }

    // ---- agent confirmations (spoken yes/no) ----

    private ConfirmAction onceOnly(final ConfirmAction action) {
        final java.util.concurrent.atomic.AtomicBoolean used = new java.util.concurrent.atomic.AtomicBoolean(false);
        return new ConfirmAction() {
            @Override
            public boolean run() {
                if (!used.compareAndSet(false, true)) {
                    return true;
                }
                return action.run();
            }
        };
    }

    /** Returns a spoken reply when this utterance answered a pending agent confirmation, else null. */
    private String answerPendingAgentConfirm(String text) {
        if (pendingAgentConfirm == null) {
            return null;
        }
        if (System.currentTimeMillis() > pendingAgentConfirmExpires) {
            pendingAgentConfirm = null;
            return null;
        }
        if (com.idcorporation.atlas.commands.ContactCommandParser.isAffirmative(text)) {
            ConfirmAction action = pendingAgentConfirm;
            pendingAgentConfirm = null;
            boolean ok;
            try {
                ok = action.run();
            } catch (RuntimeException e) {
                ok = false;
            }
            return appContext.getString(ok ? R.string.resp_done : R.string.resp_action_failed);
        }
        if (com.idcorporation.atlas.commands.ContactCommandParser.isNegative(text)) {
            pendingAgentConfirm = null;
            return appContext.getString(R.string.resp_cancelled);
        }
        return null;
    }

    private boolean isIdleOrListening() {
        return currentState == HudStateManager.STATE_IDLE || currentState == HudStateManager.STATE_LISTENING;
    }

    /** Spontaneous opening line (or silence) when the voice screen opens. */
    public void maybeGreetOnOpen() {
        if (micMuted || !isIdleOrListening()) {
            return;
        }
        com.idcorporation.atlas.ai.ProactiveGreeter.maybeGreet(appContext, aiManager,
            new com.idcorporation.atlas.ai.ProactiveGreeter.Callback() {
                @Override
                public void onGreeting(String text) {
                    if (isIdleOrListening() && !micMuted) {
                        speakAndLog(text);
                    }
                }
            });
    }

    private void setState(int state) {
        currentState = state;
        busyToken = busyToken + 1;
        if (state == HudStateManager.STATE_PROCESSING || state == HudStateManager.STATE_THINKING) {
            armBusyWatchdog(busyToken);
        }
        if (uiListener != null) {
            uiListener.onStateChanged(state);
        }
    }

    /** If a reply never arrives, do not leave the call frozen (mic dead) forever. */
    private void armBusyWatchdog(final int token) {
        watchdogHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (token != busyToken) {
                    return;
                }
                if (currentState == HudStateManager.STATE_PROCESSING
                        || currentState == HudStateManager.STATE_THINKING) {
                    setState(HudStateManager.STATE_IDLE);
                    if (!micMuted && callActive() && permissionGranted) {
                        voiceManager.startListening();
                    }
                }
            }
        }, BUSY_WATCHDOG_MS);
    }

    private void appendTranscriptLine(String line) {
        if (uiListener != null) {
            uiListener.onTranscriptLine(line);
        }
    }

    private void wireVoiceEvents() {
        voiceManager.setEventListener(new VoiceManager.VoiceEventListener() {
            @Override
            public void onListeningStarted() {
                if (speaking) {
                    return; // listening-while-talking must not change what the screen shows
                }
                hardErrorStreak = 0;
                setState(HudStateManager.STATE_LISTENING);
            }

            @Override
            public void onUserSaid(String text) {
                if (speaking) {
                    handleBargeInFinal(text);
                    return;
                }
                silentErrorStreak = 0;
                hardErrorStreak = 0;
                handleUserUtterance(text);
            }

            @Override
            public void onVoiceError(String message, int errorCode) {
                if (speaking) {
                    handleBargeInError(errorCode);
                    return;
                }
                silentErrorStreak = silentErrorStreak + 1;
                if (errorCode == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    // Permission was taken away: retrying would loop forever.
                    // Screens re-arm the mic once the permission is granted again.
                    permissionGranted = false;
                    setState(HudStateManager.STATE_IDLE);
                    return;
                }
                if (SpeechRecognizerManager.isHardError(errorCode)) {
                    hardErrorStreak = hardErrorStreak + 1;
                } else {
                    hardErrorStreak = 0;
                }
                // With the mic always on, a "no speech"/timeout error fires
                // constantly during normal silence - that is expected, not
                // a real problem, so just quietly listen again instead of
                // flashing an error state every few seconds.
                if (micMuted || !callActive()) {
                    setState(HudStateManager.STATE_IDLE);
                    return;
                }
                long delay = 500L;
                if (hardErrorStreak >= 6) {
                    delay = 8000L;
                } else if (hardErrorStreak >= 3) {
                    delay = 2500L;
                }
                if (currentState == HudStateManager.STATE_LISTENING) {
                    setState(HudStateManager.STATE_IDLE);
                }
                restartHandler.removeCallbacksAndMessages(null);
                restartHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!micMuted && callActive() && permissionGranted
                                && currentState != HudStateManager.STATE_SPEAKING
                                && currentState != HudStateManager.STATE_PROCESSING
                                && currentState != HudStateManager.STATE_THINKING) {
                            voiceManager.startListening();
                        }
                    }
                }, delay);
            }

            @Override
            public void onSpeakingStarted() {
                speaking = true;
                setState(HudStateManager.STATE_SPEAKING);
                startBargeIn();
            }

            @Override
            public void onSpeakingFinished() {
                boolean wasSpeaking = speaking;
                speaking = false;
                weakCandidate = null;
                bargeHandler.removeCallbacksAndMessages(null);
                if (currentState == HudStateManager.STATE_IDLE
                        || currentState == HudStateManager.STATE_LISTENING) {
                    // Already moved on (e.g. the user tapped to interrupt) -
                    // a late "done" callback must not restart the mic twice.
                    return;
                }
                setState(HudStateManager.STATE_IDLE);
                if (!micMuted && callActive() && permissionGranted) {
                    if (wasSpeaking) {
                        voiceManager.cancelListening(); // drop the stop-word listener, start a normal turn
                    }
                    voiceManager.startListening();
                }
            }

            @Override
            public void onAudioLevel(float rmsDb) {
                if (audioLevelListener != null) {
                    audioLevelListener.onAudioLevel(rmsDb);
                }
                if (uiAudioLevelListener != null) {
                    uiAudioLevelListener.onAudioLevel(rmsDb);
                }
            }
        });
    }

    private void handleUserUtterance(String text) {
        appendTranscriptLine("You: " + text);
        commandManager.logToHistory(conversationTitle, HistoryMessage.ROLE_USER, text);

        if (SecretUnlockManager.matchesSecretCode(text) && !SecretUnlockManager.isPermanentlyViewed(appContext)) {
            SecretUnlockManager.unlock(appContext);
            speakAndLog(appContext.getString(R.string.secret_history_unlocked));
            return;
        }

        String confirmAnswer = answerPendingAgentConfirm(text);
        if (confirmAnswer != null) {
            speakAndLog(confirmAnswer);
            return;
        }

        if (StopCommandDetector.classify(text, "") != StopCommandDetector.Level.NONE) {
            // "para de falar" / "Atlas, chega": Atlas was already quiet (or just finished), so there is
            // nothing to cut - and it must not become a question for the AI that Atlas then answers aloud.
            voiceManager.stopSpeaking();
            speaking = false;
            setState(HudStateManager.STATE_IDLE);
            if (!micMuted && callActive() && permissionGranted) {
                voiceManager.cancelListening();
                voiceManager.startListening();
            }
            return;
        }

        com.idcorporation.atlas.ai.ProactiveGreeter.noteInteraction(appContext);
        setState(HudStateManager.STATE_PROCESSING);

        CommandOutcome outcome = commandManager.process(text);

        if (outcome.getType() == CommandOutcome.TYPE_HANDLED) {
            speakAndLog(outcome.getSpokenResponse());
        } else if (outcome.getType() == CommandOutcome.TYPE_NEEDS_CONFIRMATION) {
            // No screen may be attached to confirm this right now - the
            // prompt is always spoken so the user hears what would
            // happen, but the action itself only runs if a UI listener
            // (a screen with a real Yes/No card) is attached to confirm
            // it. Otherwise it plays it safe and does not execute.
            setState(HudStateManager.STATE_IDLE);
            appendTranscriptLine("ATLAS: " + outcome.getSpokenResponse());
            speak(outcome.getSpokenResponse());
            if (uiListener != null) {
                uiListener.onConfirmationNeeded(outcome.getSpokenResponse(), outcome.getConfirmedAction());
            }
        } else {
            forwardToAI(text);
        }
    }

    private void forwardToAI(final String userMessage) {
        setState(HudStateManager.STATE_THINKING);

        aiManager.askAgent(profileManager.getName(), conversationHistory, userMessage, commandManager,
            new com.idcorporation.atlas.agent.AgentCallback() {
                @Override
                public void onResult(com.idcorporation.atlas.agent.AgentResult result) {
                    String cleanText = TextSanitizer.stripMarkdown(result.text);
                    if (cleanText == null || cleanText.trim().length() == 0) {
                        setState(HudStateManager.STATE_ERROR);
                        appendTranscriptLine("ATLAS: " + appContext.getString(R.string.err_no_ai_connection));
                        returnToIdleSoon();
                        return;
                    }
                    // The pair is stored only after a good answer. Adding the user
                    // line before asking duplicated it in the request and, after
                    // any error, left the history out of user/assistant order.
                    conversationHistory.add(userMessage);
                    conversationHistory.add(cleanText);
                    while (conversationHistory.size() > 40) {
                        conversationHistory.remove(0);
                        conversationHistory.remove(0);
                    }
                    if (result.panel != null) {
                        com.idcorporation.atlas.agent.panel.PanelActivity.show(appContext, result.panel);
                    }
                    if (result.confirmAction != null) {
                        ConfirmAction once = onceOnly(result.confirmAction);
                        pendingAgentConfirm = once;
                        pendingAgentConfirmExpires = System.currentTimeMillis() + 45000L;
                        speakAndLog(cleanText);
                        if (uiListener != null) {
                            uiListener.onConfirmationNeeded(cleanText, once);
                        }
                    } else {
                        speakAndLog(cleanText);
                    }
                }

                @Override
                public void onError(String errorMessage, int errorCode) {
                    setState(HudStateManager.STATE_ERROR);
                    // Technical details (server text, exception names) are never
                    // shown to the user: only a friendly message.
                    appendTranscriptLine("ATLAS: " + appContext.getString(R.string.err_no_ai_connection));
                    returnToIdleSoon();
                }
            });
    }

    private void returnToIdleSoon() {
        restartHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                setState(HudStateManager.STATE_IDLE);
                if (!micMuted && callActive() && permissionGranted) {
                    voiceManager.startListening();
                }
            }
        }, 2000);
    }
}
