package com.idcorporation.atlas.commands;

import android.content.Context;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.calendar.CalendarDateUtils;
import com.idcorporation.atlas.calendar.CalendarEventManager;
import com.idcorporation.atlas.calendar.DateTimeCommandParser;
import com.idcorporation.atlas.calendar.RecurrenceExpressionParser;
import com.idcorporation.atlas.calendar.TitleExtractor;
import com.idcorporation.atlas.models.CalendarEventItem;
import com.idcorporation.atlas.utils.AlarmScheduler;
import com.idcorporation.atlas.utils.AppointmentReminderScheduler;
import com.idcorporation.atlas.utils.SoundManager;
import com.idcorporation.atlas.utils.UserProfileManager;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Creates reminders (calendar events) and real alarms from free-form
 * speech. When something is missing it asks for just that piece instead
 * of telling the user how to phrase things: no time -> "Para que
 * horas?", no day -> "Para quando?", no title -> "Como eu chamo esse
 * lembrete?". The next sentence is then read as the answer.
 */
public class ReminderAlarmHandler {

    private static final long PENDING_TTL_MS = 60000L;
    private static final int PENDING_NONE = 0;
    private static final int PENDING_ALARM_TIME = 1;
    private static final int PENDING_REMINDER_DATE = 2;
    private static final int PENDING_REMINDER_TITLE = 3;

    private static final Pattern CANCEL_ANSWER = Pattern.compile(
        "^\\s*(?:(?:ei|ok|oi)\\s+)?(?:atlas\\s+)?(?:cancela\\w*|deixa|deixe|esquece\\w*|nao\\s+precisa"
        + "|nao\\s+quero|desisti\\w*|chega|nada)\\b");

    private final Context context;
    private final CalendarEventManager calendarEventManager;

    private int pendingKind = PENDING_NONE;
    private long pendingExpiresAt = 0L;
    private String pendingTitle = null;
    private int[] pendingDate = null;
    private int pendingHour = -1;
    private int pendingMinute = -1;
    // ATLAS FASE 3/4 item 21: carried across the ask-for-date / ask-for-title
    // turns so a recurrence phrase mentioned in an earlier message of a
    // multi-turn reminder is not lost by the time the reminder is finally
    // created.
    private String pendingRecurrenceRule = RecurrenceExpressionParser.RULE_NONE;
    private int pendingRecurrenceInterval = 1;

    public ReminderAlarmHandler(Context context) {
        this.context = context.getApplicationContext();
        this.calendarEventManager = new CalendarEventManager(this.context);
    }

    /** Returns the outcome, or null when this sentence has nothing to do with reminders or alarms. */
    public synchronized CommandOutcome handle(String text, String lowerText) {
        return handle(text, System.currentTimeMillis());
    }

    public synchronized CommandOutcome handle(String text, long nowMillis) {
        if (pendingKind != PENDING_NONE && nowMillis > pendingExpiresAt) {
            clearPending();
        }
        if (pendingKind != PENDING_NONE) {
            CommandOutcome answer = handleAnswer(text, nowMillis);
            if (answer != null) {
                return answer;
            }
        }
        if (ReminderIntentDetector.isAlarmIntent(text)) {
            return handleAlarm(text, nowMillis, null);
        }
        if (ReminderIntentDetector.isReminderIntent(text)) {
            return handleReminder(text, nowMillis);
        }
        return null;
    }

    private CommandOutcome handleAnswer(String text, long nowMillis) {
        String normalized = DateTimeCommandParser.normalize(text);
        int kind = pendingKind;
        if (CANCEL_ANSWER.matcher(normalized).find()) {
            clearPending();
            return CommandOutcome.handled(context.getString(R.string.resp_pending_cancelled));
        }
        if (ReminderIntentDetector.isAlarmIntent(text) || ReminderIntentDetector.isReminderIntent(text)) {
            clearPending();
            return null;
        }
        if (kind == PENDING_ALARM_TIME) {
            DateTimeCommandParser.ParsedAlarm alarm = DateTimeCommandParser.parseAlarm(text, nowMillis, pendingDate);
            if (!alarm.found) {
                // A bare answer like "seis da manha" or "7 e meia" is a time even without "as" in front.
                alarm = DateTimeCommandParser.parseAlarm("as " + text, nowMillis, pendingDate);
            }
            clearPending();
            if (alarm.found) {
                return scheduleAlarm(alarm, nowMillis);
            }
            return null;
        }
        if (kind == PENDING_REMINDER_DATE) {
            DateTimeCommandParser.ParsedReminder reminder = DateTimeCommandParser.parseReminder(text, nowMillis);
            String title = pendingTitle != null ? pendingTitle : reminder.title;
            RecurrenceExpressionParser.Result rec = RecurrenceExpressionParser.detect(normalized);
            String carriedRule = pendingRecurrenceRule;
            int carriedInterval = pendingRecurrenceInterval;
            clearPending();
            if (!reminder.found) {
                return null;
            }
            if (!rec.isRecurring()) {
                rec.rule = carriedRule;
                rec.interval = carriedInterval;
            }
            return reminderWithTitleOrAsk(reminder, RecurrenceExpressionParser.stripFromTitle(title),
                nowMillis, rec.rule, rec.interval);
        }
        if (kind == PENDING_REMINDER_TITLE) {
            int[] date = pendingDate;
            int hour = pendingHour;
            int minute = pendingMinute;
            String rule = pendingRecurrenceRule;
            int interval = pendingRecurrenceInterval;
            clearPending();
            if (CommandParser.isOpenAppCommand(text.toLowerCase()) || CommandParser.isTimeRequest(text.toLowerCase())
                    || CommandParser.isDateRequest(text.toLowerCase())) {
                return null;
            }
            String title = TitleExtractor.extract(text, normalized, new boolean[normalized.length()], false);
            if (title == null) {
                title = context.getString(R.string.default_reminder_title);
            }
            title = RecurrenceExpressionParser.stripFromTitle(title);
            return createReminder(date[0], date[1], date[2], hour, minute, title, nowMillis, rule, interval);
        }
        return null;
    }

    private CommandOutcome handleAlarm(String text, long nowMillis, int[] forcedDate) {
        DateTimeCommandParser.ParsedAlarm alarm = DateTimeCommandParser.parseAlarm(text, nowMillis, forcedDate);
        if (alarm.found) {
            return scheduleAlarm(alarm, nowMillis);
        }
        startPending(PENDING_ALARM_TIME, nowMillis);
        pendingDate = alarm.partialDate;
        return CommandOutcome.handled(context.getString(R.string.resp_alarm_ask_time));
    }

    private CommandOutcome scheduleAlarm(DateTimeCommandParser.ParsedAlarm alarm, long nowMillis) {
        int requestCode = (int) (alarm.triggerMillis % Integer.MAX_VALUE);
        String title = alarm.label;
        if (title == null || title.length() == 0) {
            title = context.getString(R.string.alarm_default_title);
        }
        AlarmScheduler.scheduleAlarm(context, alarm.triggerMillis, requestCode, title,
            context.getString(R.string.alarm_default_message));
        // Persisted so the Compromissos screen can list it and let the user check/cancel it.
        calendarEventManager.addEvent(alarm.year, alarm.month, alarm.day, alarm.hour, alarm.minute,
            title, CalendarEventItem.TYPE_ALARM, false);
        String clock = formatClock(alarm.hour, alarm.minute);
        if (alarm.relative) {
            return CommandOutcome.handled(context.getString(R.string.resp_alarm_set_in,
                describeDuration(alarm.delayMillis), clock));
        }
        String when = describeDay(alarm.year, alarm.month, alarm.day, nowMillis);
        return CommandOutcome.handled(context.getString(R.string.resp_alarm_set_at, when, clock));
    }

    private CommandOutcome handleReminder(String text, long nowMillis) {
        DateTimeCommandParser.ParsedReminder reminder = DateTimeCommandParser.parseReminder(text, nowMillis);
        RecurrenceExpressionParser.Result rec =
            RecurrenceExpressionParser.detect(DateTimeCommandParser.normalize(text));
        String title = RecurrenceExpressionParser.stripFromTitle(reminder.title);
        if (!reminder.found) {
            startPending(PENDING_REMINDER_DATE, nowMillis);
            pendingTitle = title;
            pendingRecurrenceRule = rec.rule;
            pendingRecurrenceInterval = rec.interval;
            return CommandOutcome.handled(context.getString(R.string.resp_reminder_ask_date));
        }
        return reminderWithTitleOrAsk(reminder, title, nowMillis, rec.rule, rec.interval);
    }

    private CommandOutcome reminderWithTitleOrAsk(DateTimeCommandParser.ParsedReminder reminder, String title,
            long nowMillis, String recurrenceRule, int recurrenceInterval) {
        if (title == null || title.length() == 0) {
            startPending(PENDING_REMINDER_TITLE, nowMillis);
            pendingDate = new int[]{reminder.year, reminder.month, reminder.day};
            pendingHour = reminder.hour;
            pendingMinute = reminder.minute;
            pendingRecurrenceRule = recurrenceRule;
            pendingRecurrenceInterval = recurrenceInterval;
            String when = describeWhen(reminder.year, reminder.month, reminder.day,
                reminder.hour, reminder.minute, nowMillis);
            return CommandOutcome.handled(context.getString(R.string.resp_reminder_ask_title, when));
        }
        return createReminder(reminder.year, reminder.month, reminder.day, reminder.hour, reminder.minute,
            title, nowMillis, recurrenceRule, recurrenceInterval);
    }

    /**
     * Same parsing and scheduling path handleReminder() uses, called instead
     * from a proactive AI suggestion the user just accepted (see
     * CommandManager.createReminderFromSuggestion). Returns false, never
     * fake-succeeds, when whenText cannot be resolved to an actual date -
     * the caller is expected to tell the user honestly when that happens.
     */
    public synchronized boolean createFromSuggestion(String title, String whenText, long nowMillis) {
        if (whenText == null || whenText.trim().length() == 0) {
            return false;
        }
        DateTimeCommandParser.ParsedReminder reminder = DateTimeCommandParser.parseReminder(whenText, nowMillis);
        if (!reminder.found) {
            return false;
        }
        RecurrenceExpressionParser.Result rec =
            RecurrenceExpressionParser.detect(DateTimeCommandParser.normalize(whenText));
        String finalTitle = (title != null && title.trim().length() > 0)
            ? RecurrenceExpressionParser.stripFromTitle(title.trim()) : reminder.title;
        if (finalTitle == null || finalTitle.length() == 0) {
            finalTitle = context.getString(R.string.default_reminder_title);
        }
        createReminder(reminder.year, reminder.month, reminder.day, reminder.hour, reminder.minute,
            finalTitle, nowMillis, rec.rule, rec.interval);
        return true;
    }

    private CommandOutcome createReminder(int year, int month, int day, int hour, int minute, String title,
            long nowMillis, String recurrenceRule, int recurrenceInterval) {
        long eventId = calendarEventManager.addEvent(year, month, day, hour, minute, title,
            CalendarEventItem.TYPE_REMINDER, false, recurrenceRule, recurrenceInterval);
        SoundManager.playEventMarked(context);
        String when = describeWhen(year, month, day, hour, minute, nowMillis);
        if (hour >= 0 && minute >= 0) {
            // A compromisso only notifies at the right time - it never rings like a
            // despertador. That is ATLAS Genesys' whole point: it notes it down and
            // gently reminds you, it does not wake up the whole room.
            long triggerMillis = CalendarDateUtils.toEpochMillis(year, month, day, hour, minute);
            int requestCode = (int) (triggerMillis % Integer.MAX_VALUE);
            String userName = new UserProfileManager(context).getName();
            String message = AppointmentReminderScheduler.buildMessage(context, userName, title,
                formatClock(hour, minute));
            AppointmentReminderScheduler.scheduleAppointment(context, triggerMillis, requestCode, title, message,
                eventId);
            return CommandOutcome.handled(context.getString(R.string.resp_reminder_created_when_time, title, when));
        }
        return CommandOutcome.handled(context.getString(R.string.resp_reminder_created_when, title, when));
    }

    private void startPending(int kind, long nowMillis) {
        clearPending();
        pendingKind = kind;
        pendingExpiresAt = nowMillis + PENDING_TTL_MS;
    }

    private void clearPending() {
        pendingKind = PENDING_NONE;
        pendingTitle = null;
        pendingDate = null;
        pendingHour = -1;
        pendingMinute = -1;
        pendingRecurrenceRule = RecurrenceExpressionParser.RULE_NONE;
        pendingRecurrenceInterval = 1;
    }

    private String describeWhen(int year, int month, int day, int hour, int minute, long nowMillis) {
        String dayText = describeDay(year, month, day, nowMillis);
        if (hour >= 0 && minute >= 0) {
            return context.getString(R.string.when_at_time, dayText, formatClock(hour, minute));
        }
        return dayText;
    }

    private String describeDay(int year, int month, int day, long nowMillis) {
        Calendar now = new GregorianCalendar();
        now.setTimeInMillis(nowMillis);
        Calendar target = new GregorianCalendar(year, month - 1, day);
        if (sameDay(now, target)) {
            return context.getString(R.string.when_today);
        }
        now.add(Calendar.DAY_OF_MONTH, 1);
        if (sameDay(now, target)) {
            return context.getString(R.string.when_tomorrow);
        }
        return context.getString(R.string.when_date, String.valueOf(day), CalendarDateUtils.monthNamePt(month));
    }

    private boolean sameDay(Calendar a, Calendar b) {
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR)
            && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR);
    }

    private String formatClock(int hour, int minute) {
        return String.format(Locale.US, "%02d:%02d", hour, minute);
    }

    private String describeDuration(long millis) {
        long totalSeconds = Math.round(millis / 1000.0);
        if (totalSeconds < 60) {
            int s = (int) totalSeconds;
            return context.getString(s == 1 ? R.string.time_second : R.string.time_seconds, s);
        }
        int totalMinutes = (int) Math.round(totalSeconds / 60.0);
        int hours = totalMinutes / 60;
        int minutes = totalMinutes % 60;
        String hourText = hours == 0 ? "" : context.getString(hours == 1 ? R.string.time_hour : R.string.time_hours, hours);
        String minuteText = minutes == 0 ? ""
            : context.getString(minutes == 1 ? R.string.time_minute : R.string.time_minutes, minutes);
        if (hourText.length() > 0 && minuteText.length() > 0) {
            return context.getString(R.string.time_join_and, hourText, minuteText);
        }
        return hourText.length() > 0 ? hourText : minuteText;
    }
}
