package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.utils.LocaleHelper;

import java.util.LinkedHashMap;
import java.util.Map;

public class LanguageActivity extends BaseActivity {

    private final Map<String, LinearLayout> rowsByCode = new LinkedHashMap<>();
    private final Map<String, ImageView> checksByCode = new LinkedHashMap<>();
    private String selectedCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        bindRow(LocaleHelper.LANGUAGE_PORTUGUESE_BR, R.id.row_pt, R.id.check_pt);
        bindRow(LocaleHelper.LANGUAGE_PORTUGUESE_PT, R.id.row_pt_pt, R.id.check_pt_pt);
        bindRow(LocaleHelper.LANGUAGE_ENGLISH, R.id.row_en, R.id.check_en);
        bindRow(LocaleHelper.LANGUAGE_SPANISH, R.id.row_es, R.id.check_es);
        bindRow(LocaleHelper.LANGUAGE_ITALIAN, R.id.row_it, R.id.check_it);
        bindRow(LocaleHelper.LANGUAGE_FRENCH, R.id.row_fr, R.id.check_fr);
        bindRow(LocaleHelper.LANGUAGE_GERMAN, R.id.row_de, R.id.check_de);
        bindRow(LocaleHelper.LANGUAGE_POLISH, R.id.row_pl, R.id.check_pl);

        selectCurrentLanguage();
    }

    private void bindRow(final String languageCode, int rowId, int checkId) {
        LinearLayout row = findViewById(rowId);
        ImageView check = findViewById(checkId);
        rowsByCode.put(languageCode, row);
        checksByCode.put(languageCode, check);

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onLanguageChosen(languageCode);
            }
        });
    }

    private void selectCurrentLanguage() {
        String current = LocaleHelper.getSavedLanguage(this);
        if (!rowsByCode.containsKey(current)) {
            current = LocaleHelper.LANGUAGE_PORTUGUESE_BR;
        }
        setSelectedRow(current);
    }

    private void setSelectedRow(String languageCode) {
        selectedCode = languageCode;
        for (Map.Entry<String, LinearLayout> entry : rowsByCode.entrySet()) {
            boolean isSelected = entry.getKey().equals(languageCode);
            entry.getValue().setBackgroundResource(isSelected
                    ? R.drawable.language_row_selected_bg
                    : R.drawable.language_row_normal_bg);
            ImageView check = checksByCode.get(entry.getKey());
            if (check != null) {
                check.setImageResource(isSelected
                        ? R.drawable.ic_language_selected
                        : R.drawable.ic_language_unselected);
            }
        }
    }

    private void onLanguageChosen(String languageCode) {
        if (languageCode.equals(selectedCode)) {
            return;
        }
        setSelectedRow(languageCode);
        LocaleHelper.setSavedLanguage(this, languageCode);
        restartToMain();
    }

    private void restartToMain() {
        Intent intent = com.idcorporation.atlas.utils.ModeManager.homeIntent(this);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}
