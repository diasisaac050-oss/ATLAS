package com.idcorporation.atlas.voice;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;

/**
 * Decides whether something the microphone heard WHILE Atlas is talking is
 * an order to stop - as opposed to TV noise or Atlas's own voice coming back
 * through the speaker.
 *
 * It never uses "a voice was detected" as a reason to interrupt. A stop
 * order is recognised when:
 *
 *   - the whole utterance is a stop phrase ("para", "chega", "cala a boca",
 *     "para de falar", "Atlas, silencio", "pode parar"...), or
 *   - it comes right after Atlas's name ("Atlas, para com isso, ja deu"), or
 *   - it ends a longer utterance as a clear multi-word order ("... para de
 *     falar"), which is what the recogniser hears when the user talks over
 *     Atlas's own voice.
 *
 *   STRONG - safe to act on a partial result right away
 *   WEAK   - a single word like "para" or "chega" said without Atlas's name:
 *            the caller waits for the final result or for the partial to
 *            stay stable for a moment, so the start of a normal sentence
 *            ("para a gente ir...") does not cut the voice
 *   NONE   - everything else, including echo of Atlas's own speech.
 */
public final class StopCommandDetector {

    public enum Level { NONE, WEAK, STRONG }

    private static final HashSet<String> FILLERS = new HashSet<String>(Arrays.asList(
        "por", "favor", "favorzinho", "agora", "ai", "ja", "um", "pouco", "so", "mano", "cara", "ta", "ok",
        "oi", "ei", "ey", "hey", "ola", "entao", "e", "ne", "pf", "please", "now", "just", "porfavor", "pode",
        "la", "ai", "ta", "bom", "ta bom", "por gentileza", "vai", "eh", "ah", "ow", "opa", "xi"));

    private static final HashSet<String> ATLAS_NAMES = new HashSet<String>(Arrays.asList(
        "atlas", "atles", "atlass", "atlaz", "atlis", "atlas's"));

    /** Clear, multi-word stop orders - accepted without saying "Atlas". */
    private static final HashSet<String> STRONG_PHRASES = new HashSet<String>(Arrays.asList(
        "para de falar", "pare de falar", "parar de falar", "para de falar isso", "para de falar tudo",
        "para de falar mais", "pare de falar mais", "stop talking", "stop speaking", "para de hablar",
        "pare com isso", "para com isso", "para tudo", "pare tudo", "chega de falar", "nao fale mais",
        "nao fala mais", "nao precisa falar mais", "nao precisa continuar", "pode parar de falar",
        "cala a boca", "cale a boca", "cala boca", "fecha a boca", "shut up", "be quiet", "stop it"));

    /** Short orders: single words (or short phrases) that stop Atlas. */
    private static final HashSet<String> BARE_STOPS = new HashSet<String>(Arrays.asList(
        "para", "pare", "parar", "stop", "basta", "chega", "silencio", "quieto", "quieta", "cala", "cale",
        "ja deu", "deu", "enough", "hush", "quiet", "callate", "silence", "fica quieto", "fique quieto",
        "fica quieta", "fique quieta", "cale se", "cala te", "chega disso", "ja chega", "para ai",
        "para um pouco", "chega ai"));

    private static final int MAX_CORE_TOKENS = 5;

    private StopCommandDetector() {
    }

    public static Level classify(String heard, String currentlySpokenText) {
        ArrayList<String> tokens = tokenize(heard);
        if (tokens.isEmpty()) {
            return Level.NONE;
        }
        boolean addressed = false;
        int lastAtlas = -1;
        ArrayList<String> core = new ArrayList<String>();
        for (int i = 0; i < tokens.size(); i++) {
            String t = tokens.get(i);
            if (ATLAS_NAMES.contains(t)) {
                addressed = true;
                lastAtlas = i;
            } else if (!FILLERS.contains(t)) {
                core.add(t);
            }
        }
        if (core.isEmpty()) {
            return Level.NONE;
        }

        // 1) the whole utterance is a stop order
        if (core.size() <= MAX_CORE_TOKENS) {
            String phrase = join(core);
            boolean isOrder = STRONG_PHRASES.contains(phrase) || BARE_STOPS.contains(phrase);
            if (isOrder) {
                if (addressed) {
                    return Level.STRONG;
                }
                // "para" / "chega" are ordinary words Atlas says too, so a single word alone is
                // not treated as echo; a longer match with Atlas's own sentence is.
                if (core.size() >= 2 && isEchoOf(core, currentlySpokenText)) {
                    return Level.NONE;
                }
                if (STRONG_PHRASES.contains(phrase)) {
                    return Level.STRONG;
                }
                return Level.WEAK;
            }
        }

        // 2) a stop order right after Atlas's name, followed by something else ("Atlas, para com isso, ja deu")
        if (addressed) {
            ArrayList<String> after = new ArrayList<String>();
            for (int i = lastAtlas + 1; i < tokens.size(); i++) {
                if (!FILLERS.contains(tokens.get(i)) && !ATLAS_NAMES.contains(tokens.get(i))) {
                    after.add(tokens.get(i));
                }
            }
            for (int len = Math.min(4, after.size()); len >= 1; len--) {
                String head = join(new ArrayList<String>(after.subList(0, len)));
                if (STRONG_PHRASES.contains(head) || BARE_STOPS.contains(head)) {
                    return Level.STRONG;
                }
            }
        }

        // 3) a clear multi-word order that ends a longer utterance: the user talking over Atlas's voice
        for (int len = Math.min(4, core.size()); len >= 2; len--) {
            ArrayList<String> tail = new ArrayList<String>(core.subList(core.size() - len, core.size()));
            if (STRONG_PHRASES.contains(join(tail)) && !isEchoOf(tail, currentlySpokenText)) {
                return Level.STRONG;
            }
        }
        return Level.NONE;
    }

    /** True when every heard word sits, in order, inside what Atlas is currently saying. */
    static boolean isEchoOf(ArrayList<String> coreTokens, String spokenText) {
        if (spokenText == null || spokenText.length() == 0 || coreTokens.isEmpty()) {
            return false;
        }
        ArrayList<String> spoken = tokenize(spokenText);
        int n = coreTokens.size();
        for (int start = 0; start + n <= spoken.size(); start++) {
            boolean all = true;
            for (int k = 0; k < n; k++) {
                if (!spoken.get(start + k).equals(coreTokens.get(k))) {
                    all = false;
                    break;
                }
            }
            if (all) {
                return true;
            }
        }
        return false;
    }

    static ArrayList<String> tokenize(String text) {
        ArrayList<String> out = new ArrayList<String>();
        if (text == null) {
            return out;
        }
        String n = Normalizer.normalize(text.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "")
            .replaceAll("[^a-z0-9 ]", " ");
        String[] parts = n.trim().split("\\s+");
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].length() > 0) {
                out.add(parts[i]);
            }
        }
        return out;
    }

    private static String join(ArrayList<String> tokens) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tokens.size(); i++) {
            if (i > 0) {
                sb.append(' ');
            }
            sb.append(tokens.get(i));
        }
        return sb.toString();
    }
}
