package com.idcorporation.atlas.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.security.SecurityManager;
import com.idcorporation.atlas.utils.UserProfileManager;

public class ProfileActivity extends BaseActivity {

    private UserProfileManager profileManager;
    private EditText fullNameInput;
    private EditText nameInput;
    private EditText emailInput;
    private RadioGroup genderGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profileManager = new UserProfileManager(this);
        fullNameInput = (EditText) findViewById(R.id.input_full_name);
        nameInput = (EditText) findViewById(R.id.input_name);
        emailInput = (EditText) findViewById(R.id.input_email);
        genderGroup = (RadioGroup) findViewById(R.id.radio_group_gender);

        fullNameInput.setText(profileManager.getFullName());
        nameInput.setText(profileManager.getName());
        emailInput.setText(profileManager.getEmail());
        selectCurrentGender();

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.button_save_profile).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveProfile();
            }
        });
    }

    private void selectCurrentGender() {
        String gender = profileManager.getGender();
        int idToCheck = R.id.radio_gender_unspecified;
        if (UserProfileManager.GENDER_MALE.equals(gender)) {
            idToCheck = R.id.radio_gender_male;
        } else if (UserProfileManager.GENDER_FEMALE.equals(gender)) {
            idToCheck = R.id.radio_gender_female;
        }
        genderGroup.check(idToCheck);
    }

    private String resolveGender() {
        int checkedId = genderGroup.getCheckedRadioButtonId();
        if (checkedId == R.id.radio_gender_male) {
            return UserProfileManager.GENDER_MALE;
        }
        if (checkedId == R.id.radio_gender_female) {
            return UserProfileManager.GENDER_FEMALE;
        }
        return UserProfileManager.GENDER_UNSPECIFIED;
    }

    private void saveProfile() {
        String fullName = fullNameInput.getText().toString();
        String name = nameInput.getText().toString();
        String email = emailInput.getText().toString();

        if (!SecurityManager.isValidName(fullName)) {
            Toast.makeText(this, R.string.error_full_name_required, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!SecurityManager.isValidName(name)) {
            Toast.makeText(this, R.string.error_name_required, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!SecurityManager.isValidEmail(email)) {
            Toast.makeText(this, R.string.error_email_invalid, Toast.LENGTH_SHORT).show();
            return;
        }

        profileManager.setFullName(fullName.trim());
        profileManager.setName(name.trim());
        profileManager.setEmail(email.trim());
        profileManager.setGender(resolveGender());
        Toast.makeText(this, R.string.btn_save, Toast.LENGTH_SHORT).show();
        finish();
    }
}
