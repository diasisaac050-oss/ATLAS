package com.idcorporation.atlas.services;

import android.Manifest;
import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.content.ContextCompat;

import com.idcorporation.atlas.AtlasApplication;
import com.idcorporation.atlas.presence.PresenceGuard;
import com.idcorporation.atlas.presence.PresenceOverlayController;
import com.idcorporation.atlas.utils.NotificationHelper;
import com.idcorporation.atlas.utils.ShakeDetector;

/**
 * ATLAS VOID Presence: stays alive in the background listening for a
 * side-to-side shake. On shake it drops in the glass bubble
 * (PresenceOverlayController) with the microphone already on.
 *
 * Why this service declares a microphone foreground-service type: since
 * Android 11 a background app that is not a "microphone" foreground
 * service gets SILENCE from the mic - the recognizer looked alive (the
 * bubble even reacted) but never heard a word, which is exactly the
 * "he does not understand me" bug. So whenever the bubble appears the
 * service upgrades itself to specialUse + microphone. That upgrade is
 * only attempted while the overlay window is visible (Android only
 * allows it then), and it is wrapped in a fallback because a boot-time
 * start is not allowed to claim the microphone type.
 */
public class PresenceOverlayService extends Service {

    private static final int NOTIFICATION_ID = 6001;

    private ShakeDetector shakeDetector;
    private PresenceGuard guard;
    private PresenceOverlayController controller;
    private boolean microphoneTypeActive = false;

    // The microphone foreground type can only be granted once Android sees
    // the overlay window as visible, which takes a few frames. One single
    // attempt right after addView() often lost that race, the type was not
    // granted, and the recognizer then recorded silence ("it shows up but
    // does not hear me"). So the upgrade is retried, and the microphone is
    // only opened after it succeeded.
    private static final long MIC_RETRY_MS = 200L;
    private static final int MIC_BEGIN_ANYWAY_AFTER = 8;
    private static final int MIC_MAX_ATTEMPTS = 25;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int micAttempts = 0;
    private boolean callBegun = false;
    private Runnable micRunnable;

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationHelper.createPresenceNotificationChannel(this);
        // Started from Settings (app on screen) the microphone type is allowed
        // right away; started from boot/background it is not, so begin plain.
        boolean appOnScreen = AtlasApplication.isForeground(this);
        if (!(appOnScreen && enterForeground(true))) {
            enterForeground(false);
        }

        controller = new PresenceOverlayController(this);
        shakeDetector = new ShakeDetector(this);
        shakeDetector.setListener(new ShakeDetector.ShakeListener() {
            @Override
            public void onShakeDetected() {
                if (com.idcorporation.atlas.utils.ModeManager.isChatMode(PresenceOverlayService.this)) {
                    // Chat mode is text only: the voice bubble never opens.
                    return;
                }
                if (!guard.canActivate()) {
                    // Screen is off or a camera is in use: the shake is ignored.
                    return;
                }
                if (AtlasApplication.isForeground(PresenceOverlayService.this)) {
                    // ATLAS itself is open, so the always-on call session is
                    // already listening - nothing to show on top of it.
                    return;
                }
                if (controller.show()) {
                    // Window is up now, which is what lets Android grant the
                    // microphone type to a background service.
                    startCallWhenMicrophoneReady();
                }
            }
        });

        // Presence rules: never active with the screen off or while a camera
        // is open. Turning the screen off also stops the accelerometer
        // (saves battery); the bubble is closed silently if it was showing.
        guard = new PresenceGuard(this, new PresenceGuard.Listener() {
            @Override
            public void onScreenChanged(boolean on) {
                shakeDetector.stop();
                if (on) {
                    shakeDetector.start();
                } else {
                    controller.destroy();
                }
            }

            @Override
            public void onCameraBusy() {
                controller.destroy();
            }
        });
        guard.start();
        if (guard.isScreenOn()) {
            shakeDetector.start();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private boolean micUpgradeNeeded() {
        boolean micGranted = (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED);
        return Build.VERSION.SDK_INT >= 30 && micGranted && !microphoneTypeActive;
    }

    private void cancelMicRetry() {
        if (micRunnable != null) {
            handler.removeCallbacks(micRunnable);
            micRunnable = null;
        }
    }

    /**
     * Gets the microphone foreground type first, then opens the call. If
     * Android is slow to grant it, the call still starts after a short
     * wait (so the user is never left waiting), and when the grant finally
     * arrives the listening turn is restarted.
     */
    private void startCallWhenMicrophoneReady() {
        cancelMicRetry();
        micAttempts = 0;
        callBegun = false;
        micRunnable = new Runnable() {
            @Override
            public void run() {
                if (controller == null || !controller.isShowing()) {
                    return;
                }
                if (!micUpgradeNeeded() || enterForeground(true)) {
                    if (callBegun) {
                        controller.refreshCall();
                    } else {
                        controller.beginCall();
                        callBegun = true;
                    }
                    return;
                }
                micAttempts = micAttempts + 1;
                if (micAttempts == MIC_BEGIN_ANYWAY_AFTER && !callBegun) {
                    controller.beginCall();
                    callBegun = true;
                }
                if (micAttempts < MIC_MAX_ATTEMPTS) {
                    handler.postDelayed(this, MIC_RETRY_MS);
                }
            }
        };
        micRunnable.run();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        cancelMicRetry();
        if (guard != null) {
            guard.stop();
        }
        if (shakeDetector != null) {
            shakeDetector.stop();
        }
        if (controller != null) {
            controller.destroy();
        }
    }

    /** Returns true if the foreground call (with the requested type) was accepted. */
    private boolean enterForeground(boolean withMicrophone) {
        Notification notification = NotificationHelper.buildPresenceForegroundNotification(this);
        boolean micGranted = (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED);
        if (withMicrophone && (!micGranted || Build.VERSION.SDK_INT < 30)) {
            // Nothing to upgrade to: no permission yet, or an Android old
            // enough not to restrict background microphone use.
            return false;
        }
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
                if (withMicrophone) {
                    type = type | ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                }
                startForeground(NOTIFICATION_ID, notification, type);
            } else if (Build.VERSION.SDK_INT >= 30) {
                int type = withMicrophone ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE : 0;
                startForeground(NOTIFICATION_ID, notification, type);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            microphoneTypeActive = withMicrophone;
            return true;
        } catch (RuntimeException e) {
            // Android refused this type right now (typically a background
            // start). Fall back to the plain foreground call so the service
            // at least stays alive and the shake gesture keeps working.
            if (!withMicrophone) {
                try {
                    startForeground(NOTIFICATION_ID, notification);
                } catch (RuntimeException ignored) {
                    // Nothing more can be done from here.
                }
            }
            return false;
        }
    }
}
