package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

/**
 * ATLAS NUCLEUS: a physical-looking manifestation of the assistant.
 * The core rises from below the window, blooms into a layered plasma
 * sphere with orbiting energy rings and drifting particles, reacts in
 * real time to listening / processing / speaking, and retracts
 * elegantly back below the screen when the conversation ends.
 * Canvas-only, no bitmap assets, so it compiles the same way on
 * CodeAssist. This class owns placement, timing and the ambient light
 * behind the core; everything from the surface of the core inward is
 * drawn by PresenceNucleusCore, the same split PresenceOrbPainter uses
 * with PresenceOrbInner.
 */
public class PresenceNucleusPainter implements PresenceDrawer {

    private static final float CORE_R_DP = 58f;
    /** Resting height once fully risen, in dp measured from the top of the (720dp tall) drawing surface. */
    private static final float RESTING_CY_DP = 400f;
    /** Starting/retracted height, safely past the bottom edge of the surface so the core is fully hidden below the screen before it rises. */
    private static final float HIDDEN_CY_DP = 800f;

    private final float d;
    private final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ripplePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final PresenceNucleusCore core;

    public PresenceNucleusPainter(float density) {
        d = density;
        core = new PresenceNucleusCore(density);
        ripplePaint.setStyle(Paint.Style.STROKE);
        ripplePaint.setStrokeCap(Paint.Cap.ROUND);
        // Unit halo (center 0,0, radius 1): stretched to size every frame
        // with a canvas transform instead of rebuilding the gradient, so
        // redrawing at 60fps never allocates.
        haloPaint.setShader(new RadialGradient(0f, 0f, 1f,
            new int[] {0x46BEF6FF, 0x1C3FA8FF, 0x00173F9E},
            new float[] {0f, 0.42f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas canvas, int w, int h, PresenceBubbleState st) {
        if (st.open <= 0.005f) {
            return;
        }

        // A single smoothstep on the raw open value (0..1) drives position
        // AND opacity together, so the core is visibly gliding the whole
        // time it rises or retracts, never "popping" fully opaque mid-flight.
        float open = Math.max(0f, Math.min(1.08f, st.open));
        float posT = Math.max(0f, Math.min(1f, open));
        float glide = posT * posT * (3f - 2f * posT);
        float cx = w * 0.5f;
        float cy = (HIDDEN_CY_DP + (RESTING_CY_DP - HIDDEN_CY_DP) * glide) * d;

        float voice = Math.min(1f, st.level * 1.2f);
        float active = Math.max(voice, Math.max(st.thinkAmt, st.speakAmt));
        float breathe = 1f + 0.03f * (float) Math.sin(st.phase * 2.1f);
        // Reactivity now lives mostly in the rings/particles/waves inside
        // PresenceNucleusCore, not in the overall scale - the whole point
        // of this remodel is that it should read as a living core, not a
        // ball that simply grows when it gets louder.
        float r = CORE_R_DP * d * (0.86f + 0.14f * glide) * (1f + active * 0.10f) * breathe;
        float alpha = glide;

        drawAmbientField(canvas, cx, cy, r, active, alpha);
        core.draw(canvas, cx, cy, r, st, alpha, active);
        drawRipple(canvas, cx, cy, r, st, alpha);
    }

    /** Soft light bleeding into the room behind the core, brighter while it is active. */
    private void drawAmbientField(Canvas c, float cx, float cy, float r, float active, float alpha) {
        float reach = r * (2.5f + active * 0.7f);
        float power = (0.55f + active * 0.55f) * alpha;
        haloPaint.setAlpha((int) (255f * power));
        c.save();
        c.translate(cx, cy);
        c.scale(reach, reach);
        c.drawCircle(0f, 0f, 1f, haloPaint);
        c.restore();
    }

    private void drawRipple(Canvas c, float cx, float cy, float r, PresenceBubbleState st, float a) {
        if (st.ripple < 0f || st.ripple > 1f) {
            return;
        }
        float fade = 1f - st.ripple;
        ripplePaint.setStrokeWidth(1.4f * d);
        ripplePaint.setColor(argb((int) (150f * fade * fade * a), 0x54E8FF));
        c.drawCircle(cx, cy, r * (1f + 0.9f * st.ripple), ripplePaint);
        ripplePaint.setColor(argb((int) (80f * fade * fade * a), 0x2FB6FF));
        c.drawCircle(cx, cy, r * (1.25f + 0.6f * st.ripple), ripplePaint);
    }

    private static int argb(int alpha, int rgb) {
        int a = Math.max(0, Math.min(255, alpha));
        return (a << 24) | (rgb & 0x00FFFFFF);
    }
}
