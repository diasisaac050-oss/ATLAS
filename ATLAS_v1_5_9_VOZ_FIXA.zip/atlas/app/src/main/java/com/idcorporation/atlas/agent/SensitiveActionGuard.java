package com.idcorporation.atlas.agent;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Decides, in code (not in the prompt), whether a free-text device command
 * is destructive or involves money and therefore must be confirmed by the
 * user with an explicit Yes before it runs.
 *
 * "apaga a lanterna" is harmless; "apaga minhas notas" is not - a
 * destructive verb only counts when it targets user data.
 */
public final class SensitiveActionGuard {

    private static final Pattern DESTRUCTIVE_VERB = Pattern.compile(
        "\\b(apagar|apague|apaga|apago|excluir|exclua|exclui|deletar|delete|deleta|remover|remova|remove|"
        + "limpar|limpe|limpa|zerar|zere|formatar|formate|erase|clear|wipe)\\b");

    private static final Pattern DATA_NOUN = Pattern.compile(
        "\\b(nota|notas|mensagem|mensagens|contato|contatos|lembrete|lembretes|alarme|alarmes|compromisso|"
        + "compromissos|evento|eventos|memoria|memorias|historico|conversa|conversas|arquivo|arquivos|foto|"
        + "fotos|tudo|dados|conta|todos|todas|note|notes|message|messages|contact|contacts|reminder|"
        + "reminders|alarm|alarms|event|events|memory|memories|history|file|files|photo|photos|"
        + "everything|all|data|account)\\b");

    private static final Pattern MONEY = Pattern.compile(
        "\\b(pagar|pague|pagamento|pix|transferir|transfira|transferencia|comprar|compre|assinar|assine|"
        + "cancelar assinatura|pay|payment|purchase|buy|transfer|subscribe|send money)\\b");

    private SensitiveActionGuard() {
    }

    public static boolean isSensitive(String command) {
        if (command == null) {
            return false;
        }
        String n = Normalizer.normalize(command.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "");
        if (MONEY.matcher(n).find()) {
            return true;
        }
        return DESTRUCTIVE_VERB.matcher(n).find() && DATA_NOUN.matcher(n).find();
    }
}
