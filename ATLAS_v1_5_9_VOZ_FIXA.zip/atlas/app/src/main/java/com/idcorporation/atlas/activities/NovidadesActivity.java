package com.idcorporation.atlas.activities;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.idcorporation.atlas.R;

/**
 * CHAMIZO INTELLIGENCE update pack: a dedicated "What's new" screen so the
 * user can see the version number, the pack name, and a short summary of
 * what changed, instead of that living only in commit history.
 */
public class NovidadesActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novidades);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        TextView versionView = (TextView) findViewById(R.id.text_novidades_version);
        String packName = getString(R.string.about_update_pack_name);
        versionView.setText(packName + " - v" + getVersionName());
    }

    private String getVersionName() {
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "1.0.0";
        }
    }
}
