package com.idcorporation.atlas.presence;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;

/** The small glass pill under the bubble that shows what ATLAS heard and answered. */
public class PresenceCaption {

    private static final long FADE_DELAY_MS = 6500;

    private final TextView view;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable fadeRunnable;
    private boolean fadeBlocked = false;
    private boolean suppressed = false;

    public PresenceCaption(TextView view) {
        this.view = view;
    }

    /** While true (ATLAS is speaking) the pill never fades out on its own. */
    public void setFadeBlocked(boolean blocked) {
        fadeBlocked = blocked;
    }

    /** While true (the sphere is parked at the screen edge) the pill is hidden and show() does nothing. */
    public void setSuppressed(boolean value) {
        suppressed = value;
        if (value) {
            cancelFade();
            view.animate().cancel();
            view.setVisibility(View.GONE);
        }
    }

    public void show(String text, boolean fadeLater) {
        if (suppressed) {
            return;
        }
        if (text == null || text.trim().length() == 0) {
            return;
        }
        view.setText(text.trim());
        if (view.getVisibility() != View.VISIBLE || view.getAlpha() < 0.05f) {
            float rise = 8f * view.getResources().getDisplayMetrics().density;
            view.setAlpha(0f);
            view.setTranslationY(rise);
            view.setVisibility(View.VISIBLE);
        }
        view.animate().alpha(1f).translationY(0f).setDuration(240)
            .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        cancelFade();
        if (fadeLater) {
            fadeRunnable = new Runnable() {
                @Override
                public void run() {
                    if (!fadeBlocked) {
                        view.animate().alpha(0f).setDuration(320).start();
                    }
                }
            };
            handler.postDelayed(fadeRunnable, FADE_DELAY_MS);
        }
    }

    public void hideNow() {
        cancelFade();
        view.animate().alpha(0f).setDuration(180).start();
    }

    public void cancelFade() {
        if (fadeRunnable != null) {
            handler.removeCallbacks(fadeRunnable);
            fadeRunnable = null;
        }
    }
}
