package com.idcorporation.atlas.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.activities.AlarmRingActivity;
import com.idcorporation.atlas.activities.MainActivity;
import com.idcorporation.atlas.services.AlarmSoundService;

public class NotificationHelper {

    public static final String CHANNEL_ID = "atlas_main_channel";
    public static final String CHANNEL_ID_CALL = "atlas_call_channel";
    public static final String CHANNEL_ID_ALARM = "atlas_alarm_channel";
    public static final String CHANNEL_ID_BIRTHDAY = "atlas_birthday_channel";
    public static final String CHANNEL_ID_PRESENCE = "atlas_presence_channel";
    public static final int NOTIFICATION_ID_DAILY_GREETING = 1001;
    public static final int NOTIFICATION_ID_BIRTHDAY_WARNING = 1002;
    public static final int NOTIFICATION_ID_BIRTHDAY_TODAY = 1003;

    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) {
                return;
            }
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(context.getString(R.string.notif_channel_desc));
            manager.createNotificationChannel(channel);

            NotificationChannel callChannel = new NotificationChannel(
                CHANNEL_ID_CALL,
                context.getString(R.string.notif_channel_call_name),
                NotificationManager.IMPORTANCE_HIGH);
            callChannel.setDescription(context.getString(R.string.notif_channel_call_desc));
            callChannel.enableVibration(true);
            manager.createNotificationChannel(callChannel);
        }
    }

    public static void showNotification(Context context, int notificationId, String title, String message) {
        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int pendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingIntentFlags = pendingIntentFlags | PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent contentIntent = PendingIntent.getActivity(
            context, notificationId, openAppIntent, pendingIntentFlags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(contentIntent);

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(context);
        try {
            managerCompat.notify(notificationId, builder.build());
        } catch (SecurityException e) {
            // POST_NOTIFICATIONS not granted; silently skip rather than crash.
        }
    }

    public static void showCallStyleNotification(Context context, int notificationId, String title, String message) {
        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int pendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingIntentFlags = pendingIntentFlags | PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent contentIntent = PendingIntent.getActivity(
            context, notificationId, openAppIntent, pendingIntentFlags);

        long[] vibrationPattern = new long[]{0, 400, 200, 400, 200, 400};

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_CALL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVibrate(vibrationPattern)
            .setAutoCancel(true)
            .setContentIntent(contentIntent);

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(context);
        try {
            managerCompat.notify(notificationId, builder.build());
        } catch (SecurityException e) {
            // POST_NOTIFICATIONS not granted; silently skip rather than crash.
        }
    }

    public static void createAlarmNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) {
                return;
            }
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID_ALARM,
                context.getString(R.string.notif_channel_alarm_name),
                NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(context.getString(R.string.notif_channel_alarm_desc));
            // Sound is played by AlarmSoundService itself (needs looping); keep the channel silent
            // so the alarm tone does not play twice at once.
            channel.setSound(null, null);
            channel.enableVibration(false);
            manager.createNotificationChannel(channel);
        }
    }

    public static void createBirthdayNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) {
                return;
            }
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID_BIRTHDAY,
                context.getString(R.string.notif_channel_birthday_name),
                NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(context.getString(R.string.notif_channel_birthday_desc));
            Uri soundUri = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.sfx_birthday);
            AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
            channel.setSound(soundUri, attributes);
            manager.createNotificationChannel(channel);
        }
    }

    /** Persistent notification shown by AlarmSoundService while it holds the foreground-service state. */
    public static Notification buildAlarmForegroundNotification(Context context, String title) {
        Intent fullScreenIntent = new Intent(context, AlarmRingActivity.class);
        fullScreenIntent.putExtra(AlarmScheduler.EXTRA_TITLE, title);
        fullScreenIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
            | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags | PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(
            context, AlarmSoundService.NOTIFICATION_ID, fullScreenIntent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_ALARM)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(context.getString(R.string.alarm_ringing_text))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .addAction(R.drawable.ic_close, context.getString(R.string.alarm_stop),
                AlarmSoundService.buildStopPendingIntent(context));

        return builder.build();
    }

    public static void createPresenceNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) {
                return;
            }
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID_PRESENCE,
                context.getString(R.string.title_settings_presence),
                NotificationManager.IMPORTANCE_MIN);
            channel.setDescription(context.getString(R.string.desc_settings_presence));
            channel.setSound(null, null);
            channel.enableVibration(false);
            manager.createNotificationChannel(channel);
        }
    }

    /** Low-priority persistent notification required to keep the shake-detector service alive. */
    public static Notification buildPresenceForegroundNotification(Context context) {
        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags | PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent contentIntent = PendingIntent.getActivity(context, 6001, openAppIntent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_PRESENCE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.presence_notification_title))
            .setContentText(context.getString(R.string.presence_notification_text))
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setContentIntent(contentIntent);

        return builder.build();
    }

    /** Brief persistent notification shown by ScreenshotService for the second or two it needs to capture. */
    public static Notification buildScreenshotForegroundNotification(Context context) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.screenshot_permission_title))
            .setContentText(context.getString(R.string.resp_screenshot_taking))
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true);
        return builder.build();
    }

    public static void showBirthdayNotification(Context context, int notificationId, String title, String message) {
        createBirthdayNotificationChannel(context);
        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int pendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingIntentFlags = pendingIntentFlags | PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent contentIntent = PendingIntent.getActivity(
            context, notificationId, openAppIntent, pendingIntentFlags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_BIRTHDAY)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentIntent);

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(context);
        try {
            managerCompat.notify(notificationId, builder.build());
        } catch (SecurityException e) {
            // POST_NOTIFICATIONS not granted; silently skip rather than crash.
        }
    }
}
