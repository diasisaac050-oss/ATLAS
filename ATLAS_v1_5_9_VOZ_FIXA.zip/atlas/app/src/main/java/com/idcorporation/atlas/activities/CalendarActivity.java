package com.idcorporation.atlas.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.calendar.CalendarDateUtils;
import com.idcorporation.atlas.calendar.CalendarEventManager;
import com.idcorporation.atlas.calendar.CalendarMonthAdapter;
import com.idcorporation.atlas.calendar.MonthGridView;

/**
 * Endless agenda-style calendar: horizontal paging through months in
 * both directions, years before and after today, with a dot under any
 * day that has a reminder, alarm or the yearly birthday marker. Always
 * rendered on a white background regardless of the active ATLAS theme.
 */
public class CalendarActivity extends BaseActivity {

    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private CalendarMonthAdapter adapter;
    private TextView titleView;
    private CalendarEventManager eventManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
        forceLightCalendarBackground();

        eventManager = new CalendarEventManager(this);
        titleView = (TextView) findViewById(R.id.text_calendar_title);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_calendar_months);

        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new CalendarMonthAdapter(this, eventManager, new MonthGridView.OnDayClickListener() {
            @Override
            public void onDayClick(int year, int month, int day) {
                Intent intent = new Intent(CalendarActivity.this, DayEventsActivity.class);
                intent.putExtra(DayEventsActivity.EXTRA_YEAR, year);
                intent.putExtra(DayEventsActivity.EXTRA_MONTH, month);
                intent.putExtra(DayEventsActivity.EXTRA_DAY, day);
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(adapter);

        SnapHelper snapHelper = new PagerSnapHelper();
        snapHelper.attachToRecyclerView(recyclerView);

        recyclerView.scrollToPosition(CalendarMonthAdapter.CENTER_POSITION);
        updateTitleForPosition(CalendarMonthAdapter.CENTER_POSITION);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView view, int newState) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    int position = layoutManager.findFirstCompletelyVisibleItemPosition();
                    if (position == RecyclerView.NO_POSITION) {
                        position = layoutManager.findFirstVisibleItemPosition();
                    }
                    if (position != RecyclerView.NO_POSITION) {
                        updateTitleForPosition(position);
                    }
                }
            }
        });

        findViewById(R.id.button_calendar_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.button_month_prev).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scrollToAdjacentMonth(-1);
            }
        });

        findViewById(R.id.button_month_next).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scrollToAdjacentMonth(1);
            }
        });
    }

    private void scrollToAdjacentMonth(int direction) {
        int current = layoutManager.findFirstCompletelyVisibleItemPosition();
        if (current == RecyclerView.NO_POSITION) {
            current = layoutManager.findFirstVisibleItemPosition();
        }
        if (current == RecyclerView.NO_POSITION) {
            current = CalendarMonthAdapter.CENTER_POSITION;
        }
        int target = current + direction;
        recyclerView.smoothScrollToPosition(target);
        updateTitleForPosition(target);
    }

    private void updateTitleForPosition(int position) {
        int[] yearMonth = adapter.yearMonthForPosition(position);
        String label = CalendarDateUtils.monthNamePt(yearMonth[1]) + " " + yearMonth[0];
        titleView.setText(label);
    }

    @Override
    protected void onResume() {
        super.onResume();
        forceLightCalendarBackground();
    }

    /** The calendar is always white, independent of the user's chosen ATLAS theme. */
    private void forceLightCalendarBackground() {
        View root = findViewById(R.id.calendar_root);
        if (root != null) {
            root.setBackgroundColor(Color.WHITE);
        }
        ViewGroup contentRoot = (ViewGroup) findViewById(android.R.id.content);
        if (contentRoot != null) {
            View animatedBg = contentRoot.findViewWithTag("atlas_animated_bg");
            if (animatedBg != null) {
                animatedBg.setVisibility(View.GONE);
            }
        }
    }
}
