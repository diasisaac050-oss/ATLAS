package com.idcorporation.atlas.chat;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.idcorporation.atlas.theme.ThemeManager;

/**
 * Small living ATLAS core used in the Chat header, next to every ATLAS
 * bubble and in the empty state. A soft glow, two counter-rotating arcs
 * and a glossy ball. In THINKING mode the arcs spin fast and the ball
 * pulses, so you can see ATLAS working without reading a label.
 */
public class ChatOrbView extends View {

    public static final int MODE_IDLE = 0;
    public static final int MODE_THINKING = 1;

    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint corePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcBounds = new RectF();

    private int accent = 0xFF00E5FF;
    private int mode = MODE_IDLE;
    private float phase = 0f;
    private float spin = 0f;
    private long lastFrameNanos = 0L;
    private float speedBlend = 0f;
    private ValueAnimator animator;

    public ChatOrbView(Context context) {
        super(context);
        init(context);
    }

    public ChatOrbView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeCap(Paint.Cap.ROUND);
        if (!isInEditMode()) {
            accent = ThemeManager.getSelectedPalette(context).getAccentColor();
        }
    }

    public void setAccent(int color) {
        this.accent = color;
        rebuildShaders();
        invalidate();
    }

    public void setMode(int newMode) {
        this.mode = newMode;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuildShaders();
    }

    private void rebuildShaders() {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) {
            return;
        }
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) / 2f;

        glowPaint.setShader(new RadialGradient(cx, cy, r,
            new int[]{ChatStyle.withAlpha(accent, 0x80), ChatStyle.withAlpha(accent, 0x22),
                ChatStyle.withAlpha(accent, 0x00)},
            new float[]{0.35f, 0.7f, 1f}, Shader.TileMode.CLAMP));

        float coreR = r * 0.42f;
        corePaint.setShader(new RadialGradient(cx - coreR * 0.3f, cy - coreR * 0.3f, coreR * 1.5f,
            new int[]{ChatStyle.lighten(accent, 0.75f), accent, ChatStyle.darken(accent, 0.5f)},
            new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startLoop();
    }

    @Override
    protected void onDetachedFromWindow() {
        stopLoop();
        super.onDetachedFromWindow();
    }

    private void startLoop() {
        if (animator != null) {
            return;
        }
        lastFrameNanos = 0L;
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(2400L);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                advance(((Float) valueAnimator.getAnimatedValue()).floatValue());
            }
        });
        animator.start();
    }

    private void stopLoop() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
    }

    private void advance(float newPhase) {
        long now = System.nanoTime();
        float dt = 0.016f;
        if (lastFrameNanos != 0L) {
            dt = (now - lastFrameNanos) / 1000000000f;
        }
        lastFrameNanos = now;

        float target = (mode == MODE_THINKING) ? 1f : 0f;
        speedBlend = speedBlend + (target - speedBlend) * Math.min(1f, dt * 5f);
        float degreesPerSecond = 38f + 300f * speedBlend;
        spin = (spin + degreesPerSecond * dt) % 360f;
        phase = newPhase;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) {
            return;
        }
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) / 2f;
        double angle = phase * Math.PI * 2.0;

        float glowScale = 0.92f + 0.08f * (float) Math.sin(angle) + 0.1f * speedBlend;
        canvas.save();
        canvas.scale(glowScale, glowScale, cx, cy);
        canvas.drawCircle(cx, cy, r, glowPaint);
        canvas.restore();

        float ringRadius = r * 0.74f;
        float stroke = Math.max(1.5f, r * 0.075f);
        ringPaint.setStrokeWidth(stroke);
        arcBounds.set(cx - ringRadius, cy - ringRadius, cx + ringRadius, cy + ringRadius);

        ringPaint.setColor(ChatStyle.withAlpha(accent, 0xEE));
        canvas.save();
        canvas.rotate(spin, cx, cy);
        canvas.drawArc(arcBounds, 0f, 110f, false, ringPaint);
        canvas.drawArc(arcBounds, 180f, 50f, false, ringPaint);
        canvas.restore();

        float innerRadius = r * 0.6f;
        arcBounds.set(cx - innerRadius, cy - innerRadius, cx + innerRadius, cy + innerRadius);
        ringPaint.setColor(ChatStyle.withAlpha(ChatStyle.lighten(accent, 0.5f), 0x99));
        ringPaint.setStrokeWidth(Math.max(1f, stroke * 0.6f));
        canvas.save();
        canvas.rotate(-spin * 1.4f, cx, cy);
        canvas.drawArc(arcBounds, 60f, 70f, false, ringPaint);
        canvas.restore();

        float pulse = 1f + (0.03f + 0.07f * speedBlend) * (float) Math.sin(angle * (1f + speedBlend));
        canvas.save();
        canvas.scale(pulse, pulse, cx, cy);
        canvas.drawCircle(cx, cy, r * 0.42f, corePaint);
        canvas.restore();
    }
}
