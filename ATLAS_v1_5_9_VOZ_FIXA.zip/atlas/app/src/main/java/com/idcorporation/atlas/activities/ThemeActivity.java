package com.idcorporation.atlas.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.idcorporation.atlas.R;
import com.idcorporation.atlas.theme.ThemeManager;
import com.idcorporation.atlas.theme.ThemePalette;
import com.idcorporation.atlas.utils.SoundManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Theme picker screen. Themes are grouped into labeled "type" rows
 * (Color / Drift / Pulse / Particles / etc, one per animation engine
 * plus a row for the flat static themes) shown as horizontally
 * scrolling cards, instead of one long vertical list.
 */
public class ThemeActivity extends BaseActivity {

    private final ArrayList<View> themeCards = new ArrayList<View>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);

        findViewById(R.id.button_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        buildThemeSections();
        refreshCardState();
    }

    private void buildThemeSections() {
        LinearLayout container = (LinearLayout) findViewById(R.id.container_theme_rows);
        LayoutInflater inflater = LayoutInflater.from(this);
        ArrayList<ThemePalette> palettes = ThemeManager.getAllPalettes();

        LinkedHashMap<Integer, ArrayList<ThemePalette>> grouped =
            new LinkedHashMap<Integer, ArrayList<ThemePalette>>();

        for (int i = 0; i < palettes.size(); i = i + 1) {
            ThemePalette palette = palettes.get(i);
            int categoryKey = ThemeManager.getCategoryKey(palette);
            ArrayList<ThemePalette> bucket = grouped.get(categoryKey);
            if (bucket == null) {
                bucket = new ArrayList<ThemePalette>();
                grouped.put(categoryKey, bucket);
            }
            bucket.add(palette);
        }

        Iterator<Map.Entry<Integer, ArrayList<ThemePalette>>> sections = grouped.entrySet().iterator();
        while (sections.hasNext()) {
            Map.Entry<Integer, ArrayList<ThemePalette>> section = sections.next();
            addCategorySection(container, inflater, section.getKey().intValue(), section.getValue());
        }
    }

    private void addCategorySection(LinearLayout container, LayoutInflater inflater,
                                     int categoryKey, ArrayList<ThemePalette> bucket) {
        TextView header = (TextView) inflater.inflate(R.layout.item_theme_category_header, container, false);
        header.setText(ThemeManager.getCategoryNameResId(categoryKey));
        container.addView(header);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int paddingPx = Math.round(16f * getResources().getDisplayMetrics().density);
        row.setPadding(paddingPx, 0, paddingPx, 0);

        HorizontalScrollView scrollView = new HorizontalScrollView(this);
        scrollView.setHorizontalScrollBarEnabled(false);
        scrollView.addView(row, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        container.addView(scrollView);

        for (int i = 0; i < bucket.size(); i = i + 1) {
            final ThemePalette palette = bucket.get(i);
            View card = inflater.inflate(R.layout.item_theme_card, row, false);
            card.setTag(palette.getId());

            View preview = card.findViewById(R.id.preview_theme_card);
            preview.setBackground(ThemeManager.buildCardPreviewDrawable(preview, palette));

            TextView nameLabel = (TextView) card.findViewById(R.id.label_theme_card_name);
            nameLabel.setText(palette.getNameResId());

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectTheme(palette.getId());
                }
            });

            row.addView(card);
            themeCards.add(card);
        }
    }

    private void selectTheme(String themeId) {
        SoundManager.playScifiClick(this);
        ThemeManager.setSelectedTheme(this, themeId);
        ThemeManager.applyToActivity(this);
        refreshCardState();
    }

    private void refreshCardState() {
        String selected = ThemeManager.getSelectedThemeId(this);

        for (int i = 0; i < themeCards.size(); i = i + 1) {
            View card = themeCards.get(i);
            String themeId = (String) card.getTag();
            boolean isSelected = themeId.equals(selected);

            ImageView check = (ImageView) card.findViewById(R.id.check_theme_card);
            check.setVisibility(isSelected ? View.VISIBLE : View.GONE);

            View ring = card.findViewById(R.id.ring_theme_card);
            ring.setVisibility(isSelected ? View.VISIBLE : View.GONE);
        }
    }
}
