package com.idcorporation.atlas.chat;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.idcorporation.atlas.theme.ThemeManager;

/** Three dots that bounce in a wave: the "ATLAS is writing" indicator. */
public class TypingDotsView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int accent = 0xFF00E5FF;
    private float phase = 0f;
    private ValueAnimator animator;

    public TypingDotsView(Context context) {
        super(context);
        init(context);
    }

    public TypingDotsView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        if (!isInEditMode()) {
            accent = ThemeManager.getSelectedPalette(context).getAccentColor();
        }
    }

    public void setAccent(int color) {
        this.accent = color;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (animator == null) {
            animator = ValueAnimator.ofFloat(0f, 1f);
            animator.setDuration(1100L);
            animator.setRepeatCount(ValueAnimator.INFINITE);
            animator.setInterpolator(new LinearInterpolator());
            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    phase = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                    invalidate();
                }
            });
            animator.start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) {
            return;
        }
        float radius = h * 0.17f;
        float gap = radius * 2.9f;
        float startX = w / 2f - gap;
        float baseY = h / 2f + radius * 0.6f;
        float amplitude = h * 0.26f;

        for (int i = 0; i < 3; i++) {
            double angle = (phase - i * 0.16f) * Math.PI * 2.0;
            float wave = (float) Math.max(0.0, Math.sin(angle));
            float y = baseY - wave * amplitude;
            int alpha = 110 + (int) (wave * 145f);
            paint.setColor(ChatStyle.withAlpha(accent, alpha));
            canvas.drawCircle(startX + i * gap, y, radius * (1f + wave * 0.25f), paint);
        }
    }
}
