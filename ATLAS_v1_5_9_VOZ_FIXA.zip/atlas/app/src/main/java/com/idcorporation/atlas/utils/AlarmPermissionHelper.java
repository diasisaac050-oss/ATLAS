package com.idcorporation.atlas.utils;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

/**
 * On Android 12+ (API 31+), AlarmManager.setExactAndAllowWhileIdle can
 * silently fall back to an inexact, possibly-delayed-by-many-minutes
 * alarm if the app does not hold exact-alarm access. Declaring the
 * permission in the manifest is not enough on its own on every OEM
 * build, so this asks for the dedicated system screen once, the first
 * time the app runs with it missing. Without this, a "wake me in
 * 10 minutes" alarm can silently ring late or not at all.
 */
public class AlarmPermissionHelper {

    private static final String PREFS_NAME = "atlas_permission_prefs";
    private static final String KEY_ASKED_EXACT_ALARM = "asked_exact_alarm";
    private static final String KEY_ASKED_BATTERY_OPT = "asked_battery_optimization";

    public static void ensureExactAlarmPermission(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return;
        }
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_ASKED_EXACT_ALARM, false)) {
            return;
        }
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null && !alarmManager.canScheduleExactAlarms()) {
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                intent.setData(Uri.parse("package:" + context.getPackageName()));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Exception e) {
                // Some OEM builds do not expose this screen; the alarm still falls back
                // to an inexact trigger instead of crashing.
            }
        }
        prefs.edit().putBoolean(KEY_ASKED_EXACT_ALARM, true).apply();
    }

    /** Aggressive OEM battery managers (common on many Android phones) can stop a
     * background app before its alarm broadcast is handled. Asking to be excluded
     * from battery optimization once makes real alarm delivery far more reliable. */
    public static void ensureBatteryOptimizationExemption(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return;
        }
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_ASKED_BATTERY_OPT, false)) {
            return;
        }
        PowerManager powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        if (powerManager != null && !powerManager.isIgnoringBatteryOptimizations(context.getPackageName())) {
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + context.getPackageName()));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Exception e) {
                // Some OEM builds block this screen entirely; nothing further to do here.
            }
        }
        prefs.edit().putBoolean(KEY_ASKED_BATTERY_OPT, true).apply();
    }
}
