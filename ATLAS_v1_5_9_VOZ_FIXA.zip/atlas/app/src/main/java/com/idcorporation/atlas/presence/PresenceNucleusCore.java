package com.idcorporation.atlas.presence;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

/**
 * Everything that makes the NUCLEO read as a physical manifestation of
 * ATLAS instead of a ball that simply grows: a layered plasma body with
 * churning inner light, a glossy highlight, two tilted orbit rings with
 * a travelling comet of light, drifting particles, and three separate
 * effects so listening, processing and speaking each look visibly
 * different instead of sharing one generic pulse. Colors stay inside a
 * single blue/cyan family on purpose. PresenceNucleusPainter owns
 * placement and the outer halo and calls draw() once per frame.
 */
final class PresenceNucleusCore {

    private static final float[] PETAL_ANGLE = {0f, 51f, 107f, 158f, 214f, 272f, 322f};
    private static final float[] PETAL_SPEED = {1.0f, -1.4f, 0.7f, -1.1f, 1.3f, -0.8f, 1.6f};
    private static final float[] PETAL_LEN = {0.92f, 0.78f, 0.98f, 0.70f, 0.88f, 0.66f, 0.80f};
    private static final float[] PETAL_WIDTH = {0.62f, 0.48f, 0.55f, 0.42f, 0.58f, 0.46f, 0.40f};
    private static final float[] PETAL_WOBBLE = {1.6f, 2.1f, 1.1f, 2.4f, 1.4f, 1.9f, 2.6f};
    private static final int[] PETAL_ALPHA = {64, 50, 70, 44, 58, 42, 48};

    private final float d;
    private final Path petal = new Path();
    private final Path clip = new Path();
    private final RectF oval = new RectF();
    private final Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint petalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint specPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint starPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float spin = 0f;
    private float lastPhase = 0f;

    PresenceNucleusCore(float density) {
        d = density;

        // One unit petal lying along +X, from (0,0) to (1,0). Scaled,
        // rotated and re-colored on the canvas instead of rebuilt per frame.
        petal.moveTo(0f, 0f);
        petal.quadTo(0.42f, -1f, 1f, 0f);
        petal.quadTo(0.42f, 1f, 0f, 0f);
        petal.close();

        bodyPaint.setShader(new RadialGradient(-0.22f, -0.26f, 1.3f,
            new int[] {0xFFF1FFFF, 0xFFA9F3FF, 0xFF4FC3FF, 0xFF1257C9, 0x000A1C4A},
            new float[] {0f, 0.14f, 0.42f, 0.74f, 1f}, Shader.TileMode.CLAMP));

        specPaint.setShader(new RadialGradient(0f, 0f, 1f,
            new int[] {0xE6FFFFFF, 0x30FFFFFF, 0x00FFFFFF},
            new float[] {0f, 0.5f, 1f}, Shader.TileMode.CLAMP));

        starPaint.setShader(new RadialGradient(0f, 0f, 1f,
            new int[] {0xFFFFFFFF, 0xCCBFF6FF, 0x0055C8FF},
            new float[] {0f, 0.35f, 1f}, Shader.TileMode.CLAMP));

        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeCap(Paint.Cap.ROUND);
        dotPaint.setStyle(Paint.Style.FILL);
    }

    void draw(Canvas c, float cx, float cy, float r, PresenceBubbleState st, float alpha, float active) {
        float dt = st.phase - lastPhase;
        lastPhase = st.phase;
        if (dt < 0f || dt > 0.25f) {
            dt = 0f;
        }
        // One shared clock drives every rotation below; it speeds up while
        // ATLAS is thinking or being spoken to, so the whole core visibly
        // "spins up" instead of just getting brighter.
        spin = spin + dt * (0.55f + st.thinkAmt * 2.4f + st.level * 1.3f + st.speakAmt * 0.9f);
        float a = alpha * (1f - 0.4f * st.errAmt);

        drawOrbitRings(c, cx, cy, r, a);
        drawPlasmaBody(c, cx, cy, r, st, a, active);
        drawSpecular(c, cx, cy, r, a);
        drawInnerStar(c, cx, cy, r, st, a, active);
        drawParticles(c, cx, cy, r, st, a, active);
        // The three states are not mutually exclusive draws - each reads
        // its own smoothed amount, so a transition (e.g. listening fading
        // into processing) blends naturally instead of snapping.
        drawListening(c, cx, cy, r, st, a);
        drawProcessing(c, cx, cy, r, st, a);
        drawSpeaking(c, cx, cy, r, st, a);
    }

    /** Two tilted rings, like a small gyroscope, each with a bright travelling comet of light. */
    private void drawOrbitRings(Canvas c, float cx, float cy, float r, float a) {
        for (int i = 0; i < 2; i++) {
            float rx = r * (1.42f + i * 0.22f);
            float ry = rx * (0.34f + i * 0.05f);
            c.save();
            c.rotate((i == 0 ? 1f : -0.7f) * spin * 26f + i * 46f, cx, cy);
            ringPaint.setStrokeWidth((1f + i * 0.5f) * d);
            ringPaint.setColor(argb((int) ((46 + i * 14) * a), 0x2FB6FF));
            oval.set(cx - rx, cy - ry, cx + rx, cy + ry);
            c.drawOval(oval, ringPaint);
            ringPaint.setColor(argb((int) (190 * a), 0x9EF3FF));
            c.drawArc(oval, spin * 70f * (i == 0 ? 1f : -1.3f), 34f + i * 12f, false, ringPaint);
            c.restore();
        }
    }

    /** The sphere itself: a glassy gradient plus soft churning petals clipped inside it. */
    private void drawPlasmaBody(Canvas c, float cx, float cy, float r, PresenceBubbleState st, float a, float active) {
        c.save();
        c.translate(cx, cy);
        c.scale(r, r);
        bodyPaint.setAlpha((int) (255f * a));
        c.drawCircle(0f, 0f, 1f, bodyPaint);
        c.restore();

        c.save();
        clip.reset();
        clip.addCircle(cx, cy, r, Path.Direction.CW);
        c.clipPath(clip);
        petalPaint.setColor(0xFF8DF4FF);
        for (int i = 0; i < PETAL_ANGLE.length; i++) {
            float wobble = 1f + 0.12f * (float) Math.sin(st.phase * PETAL_WOBBLE[i] + i) + active * 0.16f;
            float len = r * PETAL_LEN[i] * wobble;
            c.save();
            c.translate(cx, cy);
            c.rotate(PETAL_ANGLE[i] + spin * PETAL_SPEED[i] * 46f);
            c.scale(len, len * PETAL_WIDTH[i]);
            petalPaint.setAlpha((int) (PETAL_ALPHA[i] * a));
            c.drawPath(petal, petalPaint);
            c.restore();
        }
        c.restore();

        ringPaint.setStrokeWidth(1.3f * d);
        ringPaint.setColor(argb((int) (140f * a), 0x8DF4FF));
        c.drawCircle(cx, cy, r * 0.99f, ringPaint);
    }

    /** A small glossy highlight so the core reads as a solid, lit sphere instead of a flat disc. */
    private void drawSpecular(Canvas c, float cx, float cy, float r, float a) {
        c.save();
        c.translate(cx - r * 0.34f, cy - r * 0.4f);
        c.scale(r * 0.42f, r * 0.30f);
        specPaint.setAlpha((int) (200f * a));
        c.drawCircle(0f, 0f, 1f, specPaint);
        c.restore();
    }

    /** A tiny bright point at the exact center - the "life" of the core, pulsing faster the more active it is. */
    private void drawInnerStar(Canvas c, float cx, float cy, float r, PresenceBubbleState st, float a, float active) {
        float pulse = 1f + 0.22f * (0.4f + active * 0.6f) * (float) Math.sin(st.phase * (3.4f + active * 4f));
        float rad = r * 0.16f * pulse;
        c.save();
        c.translate(cx, cy);
        c.scale(rad, rad);
        starPaint.setAlpha((int) (255f * a));
        c.drawCircle(0f, 0f, 1f, starPaint);
        c.restore();
    }

    /** Fine energy dust drifting outward from the core and fading, denser and quicker while active. */
    private void drawParticles(Canvas c, float cx, float cy, float r, PresenceBubbleState st, float a, float active) {
        int count = 10 + (int) (active * 8f);
        for (int i = 0; i < count; i++) {
            float life = spin * (0.12f + (i % 4) * 0.02f) + i * 0.171f;
            life = life - (float) Math.floor(life);
            double ang = i * 2.399 + spin * 0.2 * ((i % 2 == 0) ? 1.0 : -1.0);
            float dist = r * (1.05f + 0.85f * life + active * 0.15f);
            float x = cx + (float) Math.cos(ang) * dist;
            float y = cy + (float) Math.sin(ang) * dist * 0.88f;
            float fade = (float) Math.sin(Math.PI * life);
            dotPaint.setColor(argb((int) (150f * fade * a), 0x7EEBFF));
            c.drawCircle(x, y, (0.9f + (i % 3) * 0.55f) * d, dotPaint);
        }
    }

    /** LISTENING: a thin ring that tightens and brightens directly with live microphone loudness. */
    private void drawListening(Canvas c, float cx, float cy, float r, PresenceBubbleState st, float a) {
        if (st.level <= 0.04f) {
            return;
        }
        ringPaint.setStrokeWidth(1.6f * d);
        ringPaint.setColor(argb((int) (170f * st.level * a), 0xBFF6FF));
        c.drawCircle(cx, cy, r * (1.08f + 0.16f * st.level), ringPaint);
    }

    /** PROCESSING: three tight orbiting nodes plus a fast scanning arc, like the core is working. */
    private void drawProcessing(Canvas c, float cx, float cy, float r, PresenceBubbleState st, float a) {
        if (st.thinkAmt <= 0.02f) {
            return;
        }
        dotPaint.setColor(argb((int) (230f * st.thinkAmt * a), 0xE9FFFF));
        for (int k = 0; k < 3; k++) {
            double ang = Math.toRadians(spin * 220f + k * 120f);
            float x = cx + (float) Math.cos(ang) * r * 0.7f;
            float y = cy + (float) Math.sin(ang) * r * 0.7f;
            c.drawCircle(x, y, 2.6f * d, dotPaint);
        }
        float scanR = r * 1.62f;
        oval.set(cx - scanR, cy - scanR, cx + scanR, cy + scanR);
        ringPaint.setStrokeWidth(1.6f * d);
        ringPaint.setColor(argb((int) (140f * st.thinkAmt * a), 0x38DFFF));
        c.drawArc(oval, spin * 140f, 46f, false, ringPaint);
    }

    /** SPEAKING: soundwave-style rings bursting outward on a repeating cycle. */
    private void drawSpeaking(Canvas c, float cx, float cy, float r, PresenceBubbleState st, float a) {
        if (st.speakAmt <= 0.02f) {
            return;
        }
        ringPaint.setStrokeWidth(1.6f * d);
        for (int k = 0; k < 2; k++) {
            float t = st.phase * 1.1f + k * 0.5f;
            t = t - (float) Math.floor(t);
            ringPaint.setColor(argb((int) (150f * (1f - t) * st.speakAmt * a), 0x54E8FF));
            c.drawCircle(cx, cy, r * (1f + 0.9f * t), ringPaint);
        }
    }

    private static int argb(int alpha, int rgb) {
        int a = Math.max(0, Math.min(255, alpha));
        return (a << 24) | (rgb & 0x00FFFFFF);
    }
}
