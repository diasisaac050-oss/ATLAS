# ATLAS release rules.
#
# Activities, services and receivers declared in the manifest, and custom
# views used in layout XML, are kept automatically by the Android build.
# ATLAS uses no reflection, so nothing else has to be kept.

# Keep file names and line numbers so a crash report still points to the
# right line (names are scrambled; the mapping file translates them).
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Remove every android.util.Log call from the release build.
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}

# If you ever need readable crash reports from a release build and cannot
# use the mapping file, remove the "#" on the next line:
# -dontobfuscate
